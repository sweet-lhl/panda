#### panda-seve脚手架

> 使用前请确保你的电脑安装了node环境。

Use language: node.js

#### 安装

```bash
npm install -g git+ssh://git@git.panda-inner.co:common/panda-serve.git
```

#### 使用教程

```bash
panda-serve -h
```

1. Windows需要在`git bash`命令行运行`pamda-serve`相关命令，Mac、Linux不受此限制。
2. `panda-serve`内置标准的帮助文档，通常情况下载命令后添加`-h`即可查看帮助与描述。
3. `panda-serve`的工作目录为当前运行命令的文件夹。

####维护说明

package.json

template_class: List #目前可处理的项目模板

命令相关维护仓库：

- [create](http://p.panda-inner.co/source/panda-template)

#### review功能说明

> 你只能在使用Git进行版本管理的项目中使用该命令，不受平台限制。但会受到命令行解析环境及`pandn-serve`运行要求相关的限制。

```bash
panda-serve review -h
```

- `panda-serve review`继承自`panda-serve`，意味着所有操作你都可以链式执行。如：命令`panda-serve review -f -r --push`是合法生效的。
- `panda-serve review [branch] options`，branch是可以省略的，省略后的默认值是当前工作目录的当前分支。

##### 通过GitLab克隆的项目

1. 运行`panda-serve review -i`初始化当前项目仓库，根据提示输入必要的信息即可完成`Gerrit`相关配置。
2. 首次提交Review（即新开一个Review条目），需要使用Git提交代码，如：`git commit -am "message"`。
3. 修复Review代码后，运行`panda-serve review -f`将代码提交并保存到本地。
4. 运行`panda-serve review --push`即可将本地保存的提交推送到Gerrit仓库，这意味着你的__首次代码提交__仍然可以使用该命令进行推送。
5. 运行`panda-serve review -r`使用穿透提交模式，这通常是 leader/owner 新建项目分支时使用的模式，需要赋予相关Gerrit权限才能运行。
6. 运行`panda-serve review -D`删除通过`panda-serve`工具初始化的项目中的review支持项。

##### 通过Gerrit克隆的项目

+ 无需运行`panda-serve review -i`初始化，后续命令仍然可用。`panda-serve`会自动尝试推送到与`origin`关联的远程仓库，这可能会抛出一个警告，你可以无需理会。