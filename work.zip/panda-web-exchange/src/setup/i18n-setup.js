/* eslint-disable camelcase */
import Vue from 'vue';
import VueI18n from 'vue-i18n';
import http from 'axios';
// eslint-disable-next-line import/no-cycle
import en from 'element-ui/lib/locale/lang/en'; // 英语
import zh from 'element-ui/lib/locale/lang/zh-CN'; // 英语
import ko from 'element-ui/lib/locale/lang/ko'; // 韩语
import tw from 'element-ui/lib/locale/lang/zh-TW'; // 繁体中文
// eslint-disable-next-line import/no-cycle
import en_US from '../lang/en-US.yml';
import zh_CN from '../lang/zh-CN.yml';
import zh_TW from '../lang/zh-TW.yml';
import ko_KR from '../lang/ko-KR.yml';
// eslint-disable-next-line import/no-cycle
import { cookies } from '../utils/common';
// eslint-disable-next-line import/no-cycle
import { setZendeskLanguage } from './zenDesk-setup';

Vue.use(VueI18n);

const [
  isProduction,
  localeDefault,
] = [
  process.env.NODE_ENV === 'production',
  cookies.get('language') || window.navigator.language,
];

const messages = { // 语言包
  'en-US': Object.assign(en, en_US),
  'zh-CN': Object.assign(zh, zh_CN),
  'zh-TW': Object.assign(tw, zh_TW),
  'ko-KR': Object.assign(ko, ko_KR),
};

const languages = Object.keys(messages);

const fallbackLocale = languages.includes(localeDefault)
  ? localeDefault
  : languages.find(lan => lan.indexOf(localeDefault.split('-')[0]) > -1) || localeDefault;

const i18n = new VueI18n({
  locale: fallbackLocale, // 设置语言环境
  fallbackLocale, // 如果未找到key,需要回溯到语言包的环境
  silentTranslationWarn: isProduction, // 警告信息
  messages, // 设置语言环境信息
});

export function setI18nLanguage(lang = fallbackLocale) { // 设置规则：完全匹配 -> 模糊匹配 -> 默认语言
  const { locale, availableLocales } = i18n;
  if (locale === lang) return lang; // 不允许重复设置语言
  cookies.set('language', lang, { expires: Infinity }); // 记住语言
  setZendeskLanguage(lang);
  const language = availableLocales.includes(lang)
    ? lang
    : availableLocales.find(lan => lan.indexOf(lang.split('-')[0]) > -1) || localeDefault;

  [
    i18n.locale, // set vue-i18n
    http.defaults.headers.common['Accept-Language'], // set http
  ] = new Array(2).fill(language);

  document.querySelector('html').setAttribute('lang', language); // set html
  return language;
}

export default i18n;
