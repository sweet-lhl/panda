/* eslint no-param-reassign: ["error", {
      "props": true,
      "ignorePropertyModificationsFor": ["state"]
    }] */

import { cookies } from '../utils/common';

export default {// 同步函数，遵循Vue同步规则
  updateWbSocketInfo(state, config) {
    state.webSocketInfo = config;
  },
  updateCountryList(state, payload) {
    state.countryList = payload;
  },
  updateSystemConfig(state, payload) {
    state.systemConfig = payload;
  },
  updateUserInfo(state, payload) {
    cookies.set('isDialogStatus', payload.tradeReconfirm);
    state.userInfo = payload;
  },
  updateMoneyList(state, payload) {
    state.moneyList = payload;
  },
  updateMoneySelect(state, payload) {
    state.moneySelect = payload;
  },
  updateCoinList(state, payload) {
    state.coinList = payload;
  },
  updateUsdtPrice(state, payload) {
    state.usdtPrice = payload;
  },
};
