import { cookies } from '../utils/common';

export default { // 计算属性
  mqttConfig({ webSocketInfo }) { // 客户端mqtt所需要的配置
    const { protocol } = window.location;
    const isSSL = protocol.includes('https');
    const newProtocol = isSSL ? 'wss:' : 'ws:';
    const {
      port, host, password, user: username, path = '',
    } = webSocketInfo/* [isSSL ? 'wssPort' : 'wsPort'] */;

    return {
      domain: `${newProtocol}//${host}:${port}${path}`,
      config: {
        username,
        password,
        keepalive: 5,
        encoding: 'utf8',
      },
    };
  },
  isLogin({ userInfo }) {
    return Boolean(userInfo.floginname && cookies.get('token'));
  },
};
