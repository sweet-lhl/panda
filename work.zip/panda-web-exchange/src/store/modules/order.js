import api from '../../api/order';

/* eslint no-param-reassign: ["error", {
      "props": true,
      "ignorePropertyModificationsFor": ["state"]
    }] */

// 用户总资产

export default {
  namespaced: true,
  state: {
    entrust: {}, // 订单列表
  },
  mutations: {
    updateEntrust(state, payload) {
      state.entrust = payload;
    },
  },
  actions: {
    fetchAllAssets({ commit }) {
      api.getUserEntrust().then(r => commit('updateEntrust', r));
    },
  },
};
