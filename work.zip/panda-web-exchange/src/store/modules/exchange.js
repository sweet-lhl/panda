import api from '../../api/order';
import socket from '../../plugins/mqttService';
import { route } from '../../setup/router-setup';
import { cookies } from '../../utils/common';
/* eslint no-param-reassign: ["error", {
      "props": true,
      "ignorePropertyModificationsFor": ["state"]
    }] */

export default {
  namespaced: true,
  state: {
    tradeSummaryStatus: false, // 交易对请求状态
    fullDepthStatus: false, // 订单薄请求状态
    tradeSummaryList: {},
    fullDepth: {},
    tradeSelects: [],
    recommendPrice: { // 推荐的买卖价格
      buyPrice: 0,
      sellPrice: 0,
    },
  },
  mutations: {
    updateTradeSummaryStatus(state, status = true) {
      state.tradeSummaryStatus = status;
    },
    updateFullDepthStatus(state, status = true) {
      state.fullDepthStatus = status;
    },
    updateTradeSummaryList(state, payload) { // 更新所有交易对
      state.tradeSummaryList = payload;
    },
    updateTradeSummaryItem(state, payload) { // 更新单个交易对
      const { tradeSummaryList } = state;
      payload.forEach((item) => {
        if (item?.tradeName in tradeSummaryList) tradeSummaryList[item?.tradeName] = Object.assign(tradeSummaryList[item?.tradeName] || {}, item);
      });
    },
    updateFullDepth(state, payload) { // 更新所有订单信息
      state.fullDepth = payload;
    },
    updateNewDeal(state, payload) { // 更新最新成交的订单
      const { fullDepth } = state;
      const { success = [] } = JSON.parse(JSON.stringify(fullDepth));
      if (success.length >= 50) success.splice(-1, payload.length);
      success.unshift(...payload);
      state.fullDepth = { ...fullDepth, success };
    },
    updateRecommendPrice(state, payload) {
      state.recommendPrice = payload;
    },
    updateOrderBook(state, { sell, buy }) { // 更新订单薄
      state.fullDepth = { ...state.fullDepth, sell, buy };
    },
    updateGather(state, { gatherBuy, gatherSell }) { // 更新深度图
      state.fullDepth = { ...state.fullDepth, gatherBuy, gatherSell };
    },
    updateTradeSelects(state, payload) {
      state.tradeSelects = payload;
    },
  },
  actions: {
    fetchTradeSummaryList({ commit, dispatch }) {
      const tradeSummaryId = 'kline/MARKET_TRADE_SUMMARY'/* 'MARKET_TRADE_SUMMARY' */;
      dispatch('closeTradeSummaryList'); // 先取消再订阅
      commit('updateTradeSummaryStatus', false);

      return api.tradeSummaryList()
        .then(r => commit('updateTradeSummaryList', r))
        .then(() => socket.instance.subscribe(tradeSummaryId)(response => commit('updateTradeSummaryItem', response) || commit('updateTradeSummaryStatus')));
    },
    closeTradeSummaryList(/* { commit } */) {
      const tradeSummaryId = 'kline/MARKET_TRADE_SUMMARY';
      socket.instance.unsubscribe(tradeSummaryId);
      // commit('updateTradeSummaryList', {});
    },
    fetchFullDepth({ commit, state: { tradeSummaryList } }) {
      commit('updateFullDepthStatus', false);
      return api.fullDepth().then(r => commit('updateFullDepth', { ...r, sell: r.sell.reverse() })).then(() => {
        const { id } = route.query;
        commit('updateFullDepthStatus');
        const { tradeName } = Object.values(tradeSummaryList).find(({ tradeId }) => tradeId === Number(id));
        const tradePair = tradeName?.toLowerCase().replace('/', '_');
        const transactionDepthId = `kline/MARKET_DEPTH_${tradePair}`;
        const orderBookId = `kline/MARKET_TRADE_${tradePair}`;
        const depthId = `kline/MARKET_DEPTH_GATHER_${tradePair}`;

        socket.instance.subscribe(transactionDepthId)(({ buy, sell }) => commit('updateOrderBook', { buy, sell: sell.reverse() }));
        socket.instance.subscribe(orderBookId)(response => commit('updateNewDeal', response));
        socket.instance.subscribe(depthId)(({ buy: gatherBuy, sell: gatherSell }) => commit('updateGather', { gatherBuy, gatherSell }));
      });
    },
    fetchRecommendPrice({ commit }) {
      api.buySellPrice().then(r => commit('updateRecommendPrice', r));
    },
    closeFullDepth({ commit }, tradeName) {
      const tradePair = tradeName?.toLowerCase().replace('/', '_');
      const transactionDepthId = `kline/MARKET_DEPTH_${tradePair}`;
      const orderBookId = `kline/MARKET_TRADE_${tradePair}`;
      const depthId = `kline/MARKET_DEPTH_GATHER_${tradePair}`;

      socket.instance.unsubscribe(transactionDepthId);
      socket.instance.unsubscribe(orderBookId);
      socket.instance.unsubscribe(depthId);
      commit('updateFullDepth', {});
    },
    fetchTradeSelects({ commit, rootGetters /* dispatch */ }) { // 用户自选交易对
      const tradeSelects = JSON.parse(localStorage.getItem('tradeSelects') || null) || [];
      if (rootGetters.isLogin || cookies.get('token')) {
        api.selectSelf().then((r) => {
          const newData = r.filter(({ tradeType }) => tradeType === 1);
          /* const data = tradeSelects.filter(({ tradeId }) => !newData.some(({ tradeId: _tradeId }) => _tradeId === tradeId)); // 需要新增的收藏
          if (data.length) {
            dispatch('addCoinBatch', data.map(({ tradeId }) => tradeId), { root: true });
            return;
          } */
          commit('updateTradeSelects', newData);
        });
      } else commit('updateTradeSelects', tradeSelects);
    },
  },
  getters: {
    tradePairList({ tradeSummaryList, tradeSelects }) { // 包含用户自选交易对的所有交易对
      return Object.entries(tradeSummaryList).reduce((acc, [key, value]) => Object.assign(
        { [key]: { ...value, tradeType: 1, isCollection: tradeSelects.some(({ tradeId }) => tradeId === value.tradeId) } },
        acc,
      ), Object.create(null));
    },
  },
};
