import api from '../../api/order';
import future from '../../api/future';
import socket from '../../plugins/mqttService';
import { route } from '../../setup/router-setup';
import { cookies } from '../../utils/common';
/* eslint no-param-reassign: ["error", {
      "props": true,
      "ignorePropertyModificationsFor": ["state"]
    }] */
const pathMqtt = {
  rateId: 'futures_kline/MARKET_FUTURES_RATE_',
  transactionDepthId: 'futures_kline/MARKET_FUTURES_DEPTH_',
  orderBookId: 'futures_kline/MARKET_FUTURES_TRADE_',
  depthId: 'futures_kline/MARKET_FUTURES_DEPTH_GATHER_',
};

export default {
  namespaced: true,
  state: {
    tradeSummaryStatus: false, // 交易对请求状态
    fullDepthStatus: false, // 订单薄请求状态
    tradeSummaryList: {},
    accountList: {}, // 合约账户列表
    positionList: {}, // 持仓列表
    fullDepth: {},
    tradeSelects: [],
    tradeUnit: 'sheet', // 交易单位
    recommendPrice: { // 推荐的买卖价格
      buyPrice: 0,
      sellPrice: 0,
    },
    accuracyList: [], // 精度列表
    contractCoinList: [], // 合约支持的币种列表
    getOrderSetting: [], // 查询期货下单配置
    openAssignment: false, // 是否更新当前持仓可屏量
  },
  mutations: {
    updateTradeSummaryStatus(state, status = true) {
      state.tradeSummaryStatus = status;
    },
    updateOpenAssignment(state, status = true) {
      state.openAssignment = status;
    },
    updateFullDepthStatus(state, status = true) {
      state.fullDepthStatus = status;
    },
    updateTradeSummaryList(state, payload) { // 更新所有交易对
      let [tab, list] = [[], {}];

      payload.forEach((value) => {
        tab = [...tab, { type: value.type, showName: value.showName }];
        list = Object.assign(
          Object.values(value.list).reduce((acc, item) => Object.assign(
            { [item.symbol]: item },
            acc,
          ), Object.create(null)),
          list,
        );
      });
      state.tradeSummaryList = { tab, list };
    },
    updateAccountList(state, payload) {
      state.accountList = payload;
    },
    updatePositionList(state, payload) {
      state.positionList = payload;
    },
    updateTradeSummaryItem(state, payload) { // 更新单个交易对
      const { tradeSummaryList } = state;
      /* console.log('更新单个交易对', payload); */
      payload.forEach((item) => {
        if (item.tradeName in tradeSummaryList?.list) tradeSummaryList.list[item.tradeName] = Object.assign(tradeSummaryList.list[item.tradeName] || {}, item);
      });
    },
    updateFullDepth(state, payload) { // 更新所有订单信息
      state.fullDepth = payload;
    },
    updateNewDeal(state, payload) { // 更新最新成交的订单
      const { fullDepth } = state;
      const { success = [] } = JSON.parse(JSON.stringify(fullDepth));
      if (success.length >= 50) success.splice(-1, payload.length);
      success.unshift(...payload);
      state.fullDepth = { ...fullDepth, success };
    },
    updateNew(state, success) { // 最新成交订单历史
      state.fullDepth = { ...state.fullDepth, success };
    },
    updateRecommendPrice(state, payload) {
      state.recommendPrice = payload;
    },
    updateOrderBook(state, { sell, buy }) { // 更新订单薄
      state.fullDepth = { ...state.fullDepth, sell, buy };
    },
    updateGather(state, { gatherBuy, gatherSell }) { // 更新深度图
      state.fullDepth = { ...state.fullDepth, gatherBuy, gatherSell };
    },
    updateTradeSelects(state, payload) {
      state.tradeSelects = payload;
    },
    updateTradeUnit(state, payload) {
      state.tradeUnit = payload;
    },
    updateAccuracyList(state, payload) { // 更新合约币种精度列表
      state.accuracyList = payload;
    },
    updateCoinList(state, payload) { // 更新合约支持币种列表
      state.contractCoinList = payload;
    },
    updateGetOrderSetting(state, payload) { // 更新合约支持币种列表
      state.getOrderSetting = payload;
    },
  },
  actions: {
    fetchAccuracyList({ commit }) { // 获取币种精度列表
      future.precision().then(r => commit('updateAccuracyList', r));
    },
    fetchCoinList({ commit }) { // 获取合约支持币种
      future.contractCoinList().then(r => commit('updateCoinList', r));
    },
    fetchGetOrderSetting({ commit }, symbolId) { // 查询期货下单配置
      future.getOrderSetting({ symbolId }).then(r => commit('updateGetOrderSetting', r));
    },
    setTradeUnit({ commit }, value) {
      localStorage.setItem('tradeUnit', value);
      commit('updateTradeUnit', value);
    },
    contractAddCoin({ dispatch, rootGetters }, tradeId) { // 收藏币
      if (rootGetters.isLogin) {
        api.addSelf(tradeId).then(() => dispatch('contractFetchTradeSelects'));
        return;
      }

      const tradeSelects = JSON.parse(localStorage.getItem('tradeSelectsContract') || null) || [];
      localStorage.setItem('tradeSelectsContract', JSON.stringify(tradeSelects.concat({ tradeId })));
      dispatch('contractFetchTradeSelects');
    },
    contractRemoveCoin({ dispatch, rootGetters }, tradeId) { // 移除币
      if (rootGetters.isLogin) {
        api.removeSelf(tradeId).then(() => dispatch('contractFetchTradeSelects'));
        return;
      }

      const tradeSelects = JSON.parse(localStorage.getItem('tradeSelectsContract') || null) || [];
      const idx = tradeSelects.findIndex(({ tradeId: _tradeId }) => tradeId === _tradeId);
      if (idx !== -1) tradeSelects.splice(idx, 1);
      localStorage.setItem('tradeSelectsContract', JSON.stringify(tradeSelects));
      dispatch('contractFetchTradeSelects');
    },
    contractFetchTradeSummaryList({ commit, dispatch }) { // 行情概要
      const tradeSummaryId = 'futures_kline/MARKET_FUTURES_TRADE_SUMMARY';

      dispatch('contractCloseTradeSummaryList'); // 先取消再订阅
      commit('updateTradeSummaryStatus', false);
      return future.tradeSummaryList()
        .then(r => commit('updateTradeSummaryList', r))
        .then(() => {
          commit('updateTradeSummaryStatus');
          socket.instance.subscribe(tradeSummaryId)(response => commit('updateTradeSummaryItem', response));
        });
    },
    contractFetchAccountList({ commit }) {
      return future.accountList()
        .then(r => commit('updateAccountList', r));
    },
    contractFetchPositionList({ commit }, contractId) {
      return future.futuresPositionList({ contractId })
        .then(r => commit('updatePositionList', r));
    },
    contractCloseTradeSummaryList(/* { commit } */) {
      const tradeSummaryId = 'futures_kline/MARKET_FUTURES_TRADE_SUMMARY';
      socket.instance.unsubscribe(tradeSummaryId);
      // commit('updateTradeSummaryList', {});
    },
    contractFetchFullDepth({ commit, dispatch }) {
      commit('updateFullDepthStatus', false);

      const { id } = route.query;
      return future.fullDepth({ symbol: id }).then(r => commit('updateFullDepth', { ...r, sell: r.sell.reverse() })).then(() => {
        const transactionDepthId = `${pathMqtt.transactionDepthId}${id}`; // 买卖盘接口
        const orderBookId = `${pathMqtt.orderBookId}${id}`; // 成交订单接口
        const rateId = `${pathMqtt.rateId}${id}`;// 预测资金费率

        commit('updateFullDepthStatus');
        dispatch('contractFetchMarketTrade'); // 触发最新订单请求
        socket.instance.subscribe(transactionDepthId)(({ buy, sell }) => commit('updateOrderBook', { buy, sell: sell.reverse() }));
        socket.instance.subscribe(orderBookId)(response => commit('updateNewDeal', response));
        socket.instance.subscribe(rateId)(({ rate, symbol: tradeName }) => commit('updateTradeSummaryItem', [{ tradeName, rate }]));
      });
    },
    contractFetchFullGatherDepth({ commit }) { // 合约总深度
      const { id } = route.query;
      const depthId = `${pathMqtt.depthId}${id}`;// 深度接口

      return future.fullGatherDepth({ symbol: id }).then(({ buy: gatherBuy, sell: gatherSell }) => commit('updateGather', { gatherBuy: gatherBuy.reverse(), gatherSell })).then(() => {
        socket.instance.subscribe(depthId)(({ buy: gatherBuy, sell: gatherSell }) => commit('updateGather', { gatherBuy: gatherBuy.reverse(), gatherSell }));
      });
    },
    contractFetchMarketTrade({ commit }) { // 合约最新成交记录
      const { id } = route.query;
      if (id) future.marketTrade({ symbol: id }).then(r => commit('updateNew', r));
    },
    /*   contractFetchRecommendPrice({ commit }) {
      api.buySellPrice().then(r => commit('updateRecommendPrice', r));
    }, */
    contractCloseFullDepth({ commit }, id) {
      Object.keys(pathMqtt).map(item => socket.instance.unsubscribe(`${pathMqtt[item]}${id}`));
      commit('updateFullDepth', {});
    },
    contractFetchTradeSelects({ commit, rootGetters /* dispatch */ }) { // 用户自选交易对
      const tradeSelects = JSON.parse(localStorage.getItem('tradeSelectsContract') || null) || [];
      if (rootGetters.isLogin || cookies.get('token')) {
        api.selectSelf().then((r) => {
          const newData = r.filter(({ tradeType }) => tradeType === 2);
          /* const data = tradeSelects.filter(({ tradeId }) => !newData.some(({ tradeId: _tradeId }) => _tradeId === tradeId)); // 需要新增的收藏
          if (data.length) {
            // eslint-disable-next-line camelcase
            dispatch('addCoinBatch', data.map(({ tradeId }) => tradeId), { root: true });
            return;
          } */
          commit('updateTradeSelects', newData);
        });
      } else commit('updateTradeSelects', tradeSelects);
    },
  },
  getters: {
    contractTradePairList({ tradeSummaryList, tradeSelects }) {
      const list = tradeSummaryList?.list || {};
      return Object.values(list).map(value => Object.assign(
        value,
        { tradeType: 2 },
        { isCollection: tradeSelects.some(({ tradeId }) => tradeId === value.id) },
      )).reverse();
      /* return Object.values(tradeSummaryList).reduce((acc, value) => [...acc, ...value.list], []); */

      /* const { usd = [] } = tradeSummaryList;
       return usd.map((item) => {
        const { contracts } = item;
        contracts[0].fast = item.symbol;
        const coOption = Object.entries(item).reduce((acc, [key, value]) => Object.assign(
          key === 'contracts' ? {} : { [key]: value },
          acc,
        ), Object.create(null));

        return contracts.map(value => Object.assign(
          value,
          coOption,
          { isCollection: tradeSelects.some(({ tradeId }) => Number(tradeId) === Number(value.symbolName)) },
        ));
      }).reduce((acc, current) => [...acc, ...current], []); */
    },
    getTradeUnit({ tradeUnit }) {
      return localStorage.getItem('tradeUnit') || tradeUnit;
    },
  },
};
