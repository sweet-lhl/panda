import api from '../../api/apiModule_1';

/* eslint no-param-reassign: ["error", {
      "props": true,
      "ignorePropertyModificationsFor": ["state"]
    }] */

export default {
  namespaced: true,
  state: {
    bannerList: [],
    noticeList: [],
  },
  mutations: {
    updateBannerList(state, payload) {
      state.bannerList = payload;
    },
    updateNoticeList(state, payload) {
      state.noticeList = JSON.parse(payload)?.articles;
    },
  },
  actions: {
    fetchBannerList({ commit }) {
      api.getBanner().then(r => commit('updateBannerList', r));
    },
    fetchNoticeList({ commit }, payload) {
      api.getZendesk(payload).then(r => commit('updateNoticeList', r));
    },
  },
};
