import api from '../../api/asset';

/* eslint no-param-reassign: ["error", {
      "props": true,
      "ignorePropertyModificationsFor": ["state"]
    }] */

// 用户总资产

export default {
  namespaced: true,
  state: {
    allAssets: {}, // 用户总资产
    otcAssets: {}, // 用户OTC资产
    allAmountDecimal: {}, // 资产精度
  },
  mutations: {
    updateAllAssets(state, payload) {
      state.allAssets = payload;
      const data = {};
      // eslint-disable-next-line no-unused-expressions
      payload.userWalletList ?.forEach((obj) => { data[obj.coinName] = obj.amountDecimal; });
      state.allAmountDecimal = data;
    },
    updateOtcAssets(state, payload) {
      state.otcAssets = payload;
    },
  },
  actions: {
    fetchAllAssets({ commit }) {
      api.coinAllAssets().then(r => commit('updateAllAssets', r));
    },
    fetchOtcFinancial({ commit, rootState }) {
      const coinId = rootState.coinList.find(({ coinType }) => coinType.name === 'USDT')?.setting?.coinId;
      return api.otcFinancial(coinId).then(r => commit('updateOtcAssets', r));
    },
  },
};
