import api from '../../api/apiModule_1';

/* eslint no-param-reassign: ["error", {
      "props": true,
      "ignorePropertyModificationsFor": ["state"]
    }] */

export default {
  namespaced: true,
  state: {
    authenticationInfo_1: {},
    authenticationInfo_2: {},
  },
  mutations: {
    updateAuthenticationInfo_1(state, payload) {
      state.authenticationInfo_1 = payload;
    },
    updateAuthenticationInfo_2(state, payload) {
      state.authenticationInfo_2 = payload;
    },
  },
  actions: {
    fetchAuthenticationInfoOne({ commit }) {
      api.primaryAuthInfo().then(r => commit('updateAuthenticationInfo_1', r));
    },
    fetchAuthenticationInfoTwo({ commit }) {
      api.seniorAuthInfo().then(r => commit('updateAuthenticationInfo_2', r));
    },
  },
};
