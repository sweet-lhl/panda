import api from '../api/apiModule_1';
import order from '../api/order';
import future from '../api/future';
import asset from '../api/asset';
import i18n from '../setup/i18n-setup';

export default {
  fetchWebSocketInfo({ commit }) {
    const { pathname } = window.location;
    const apiPath = pathname.includes('future') ? future : order;
    return apiPath.webSocketInfo().then(r => commit('updateWbSocketInfo', r));
  },
  fetchSystemConfig({ commit }) {
    api.systemConfig().then(r => commit('updateSystemConfig', r));
  },
  async updateRatesConf(context) {
    const rateConf = await api.fetchRatesConf();
    context.commit('updateRatesConf', rateConf.list);
  },
  fetchUserInfo(context) { // 查询用户信息
    api.userInfo().then(r => context.commit('updateUserInfo', r));
  },
  fetchMoneyList({ commit }) { // 查询法币支持币信息
    return order.moneyList().then((r) => { commit('updateMoneyList', r); });
  },
  addCoin({ dispatch, rootGetters }, tradeId) { // 收藏币
    if (rootGetters.isLogin) {
      order.coinAddSelf(tradeId).then(() => dispatch('exchange/fetchTradeSelects'));
      return;
    }

    const tradeSelects = JSON.parse(localStorage.getItem('tradeSelects') || null) || [];
    localStorage.setItem('tradeSelects', JSON.stringify(tradeSelects.concat({ tradeId })));
    dispatch('exchange/fetchTradeSelects');
  },
  addCoinBatch({ dispatch, rootGetters }, tradeIds) { // 批量收藏币
    if (rootGetters.isLogin) {
      order.batchAddSelf(tradeIds).then(() => {
        localStorage.removeItem('tradeSelects');
        dispatch('exchange/fetchTradeSelects');
      });
    }
  },
  removeCoin({ dispatch, rootGetters }, tradeId) { // 移除币
    if (rootGetters.isLogin) {
      order.coinRemoveSelf(tradeId).then(() => dispatch('exchange/fetchTradeSelects'));
      return;
    }

    const tradeSelects = JSON.parse(localStorage.getItem('tradeSelects') || null) || [];
    const idx = tradeSelects.findIndex(({ tradeId: _tradeId }) => tradeId === _tradeId);
    if (idx !== -1) tradeSelects.splice(idx, 1);
    localStorage.setItem('tradeSelects', JSON.stringify(tradeSelects));
    dispatch('exchange/fetchTradeSelects');
  },
  fetchCoinList({ commit }) {
    asset.coinList().then(r => commit('updateCoinList', r));
  },
  fetchCountryList({ commit }) { // 获取国家列表信息
    const { locale: lang } = i18n;
    api.countryList().then(({ normalList }) => commit('updateCountryList', normalList.map(item => ({
      className: item.icon,
      area: item.areaCode,
      label: (lang === 'zh-CN' || lang === 'zh-TW') ? item.nameCn : item.nameEn,
      value: item.nameEn,
    }))));
  },
};
