import { cookies } from '../utils/common';

export default {
  msg: 'hello vue.app',
  userInfo: {}, // 用户信息
  status: {
    // login: false,
  },
  coinList: [], // 平台支持的币种列表
  moneyList: [], // 所有的法币支持列表
  moneySelect: cookies.get('currencyUnit') || 'CNY', // 选择的法币单位
  countryList: [], // 国家列表
  usdtPrice: {}, // 费率对象
  webSocketInfo: /* { // 服务端返回的mqtt配置信息
    isShow: false,
    mqttHost: 'mq.noteScript.app',
    subscriber: '',
    subscriberPwd: '',
    tcpPort: 0,
    topicPrefix: '',
    wsPort: '80',
    wssPort: '443',
  } */ null,
  systemConfig: {}, // config配置接口
};
