import http from '../plugins/http';
import { route } from '../setup/router-setup';
// import store from '../store';

const key = '/order/v1';

const api = http[key] || http.instance(key); // api modules.test

class Service {
  api = api;

  // 需要验证参数的接口请使用@validate装饰器同步抛出错误给下一层业务组件
  // 不关心返回状态的api,可直接返回api的promise，无需重复书写async功能函数
  // @validate(schemas.test) // 可以在此处验证参数


  getUserEntrustList(params) { // 币币订单列表_新
    return this.api.post('/trade/order/getUserEntrustList', params);
  }

  getDealFlowDetail(params) { // 币币订单-成交明细
    return this.api.post('/trade/order/getDealFlowDetail', params);
  }

  coinAllAssets() { // 用户总资产
    return this.api.get('/assets/coin/allAssets');
  }

  webSocketInfo() { // mqtt配置获取
    return this.api.post('/market/webSocketInfo');
  }

  tradeSummaryList() { // 币种行情接口
    return this.api.post('/market/tradeSummaryList');
  }

  moneyList() { // 法币支持列表
    return this.api.post('/market/moneyList');
  }

  fullDepth() { // k线深度&成交订单获取
    const { id: tradeId } = route.query;
    return tradeId ? this.api.post('/market/kline/fullDepth', { tradeId }) : Promise.reject(new Error('交易对ID发生错误，阻断继续请求'));
  }

  orderCancel(params) { // 获取订单列表
    return this.api.post('/trade/order/cancel', params);
  }

  getUserEntrust(params) { // 获取订单列表
    return this.api.post('/trade/order/getUserEntrust', params);
  }

  klineQuery(params, cancelToken) { // K线历史数据
    return this.api.post('/market/kline/query', params, { cancelToken });
  }

  createBuy(params) { // 币币买单
    return this.api.post('/trade/order/create/buy', params);
  }

  createSell(params) { // 币币买单
    return this.api.post('/trade/order/create/sell', params);
  }

  selectSelf() { // 用户自选交易对列表
    return this.api.post('/market/coin/selectChoose');
  }

  batchAddSelf(tradeIds) { // 用户自选交易对列表（批量）
    return this.api.post('/market/coin/batchAddSelf', { tradeIds: tradeIds.join(',') });
  }

  coinAddSelf(tradeId) { // 用户自选交易对添加
    return this.api.post('/market/coin/addSelf', { tradeId, type: 0 });
  }

  coinRemoveSelf(tradeId) { // 用户自选交易对删除
    return this.api.post('/market/coin/addSelf', { tradeId, type: 1 });
  }

  addSelf(tradeId) { // 合约用户自选交易对添加 tradeType：1=币币，2=合约
    return this.api.post('/market/coin/addSelf', { type: 0, tradeType: 2, tradeId });
  }

  removeSelf(tradeId) { // 合约用户自选交易对删除
    return this.api.post('/market/coin/addSelf', { type: 1, tradeType: 2, tradeId });
  }

  buySellPrice() { // 根据不同的交易对获取不同的推荐价格
    const { id: tradeId } = route.query;
    return tradeId ? this.api.post('/market/buySellPrice', { tradeId }) : Promise.reject(new Error('交易对ID发生错误，阻断继续请求'));
  }
}

export default new Service();
