import http from '../plugins/http';
// import store from '../store';

const key = '/asset/v1';

const api = http[key] || http.instance(key); // api modules.test

class Service {
  api = api;

  // 需要验证参数的接口请使用@validate装饰器同步抛出错误给下一层业务组件
  // 不关心返回状态的api,可直接返回api的promise，无需重复书写async功能函数
  // @validate(schemas.test) // 可以在此处验证参数

  otcGetFlashPrice(params) { // 获取一键买币最新报价
    return this.api.get('/otc/getFlashPrice', { params });
  }

  otcCheckRealAuth() { // 获取当前用户实名信息
    return this.api.get('/otc/checkRealAuth');
  }

  coinAllAssets() { // 用户总资产
    return this.api.get('/assets/coin/allAssets');
  }

  financialTransfer(params) { // 资金互转
    return this.api.post('/otc/financial/transfer', params);
  }

  otcFinancial(coinId) { // 资产详情-单币种
    return this.api.get('/otc/financial', { params: { coinId } });
  }

  coinList() {
    return this.api.get('/assets/coin/list');
  }

  getRechargeAddress(coinId) { // 获取充币地址
    return this.api.get('/assets/coin/getRechargeAddress', { params: { coinId } });
  }

  coinOperationAll(params) { // 获取所有重提币历史记录
    return this.api.get('/assets/coin/operation/all/page', { params });
  }

  coinOperation(params) { // 分页获取充提记录
    return this.api.get('/assets/coin/operation/page', { params });
  }

  coinCheckAddress(params) { // 验证提币地址
    return this.api.post('/assets/coin/checkAddress', params);
  }

  addWithdrawAddress(params) { // 添加提币地址
    return this.api.post('/assets/coin/addWithdrawAddress', params);
  }

  coinWithdraw(params) { // 提币申请
    return this.api.post('/assets/coin/withdraw', params);
  }

  getUserAssetDetails(params) { // 资产记录
    return this.api.get('/assets/coin/getUserAssetDetails', { params });
  }

  cancelWithdraw(params) { // 取消提币
    return this.api.get('/assets/coin/cancleCoinOperationOrder', { params });
  }
}

export default new Service();
