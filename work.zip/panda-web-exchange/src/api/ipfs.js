import http from '../plugins/http';

const key = '/api/v1/ipfs';

const api = http[key] || http.instance(key); // api modules.test

class Service {
  api = api;

  // 需要验证参数的接口请使用@validate装饰器同步抛出错误给下一层业务组件
  // 不关心返回状态的api,可直接返回api的promise，无需重复书写async功能函数
  // @validate(schemas.test) // 可以在此处验证参数


  fetchIpfsOrderList(currentPage) { // 获取订单列表
    return this.api.get('/orderList', { params: { currentPage } });
  }

  fetchIpfsList() { // 获取项目列表
    return this.api.get('/list');
  }

  fetchIpfsInfo(id) { // 获取项目详情
    return this.api.get('/info', { params: { id } });
  }

  postIpfsPlaceOrder({ id: projectId, quantity: number }) { // ipfs下单
    return this.api.post('/placeOrder', { number, projectId });
  }

  // eslint-disable-next-line class-methods-use-this
  fetchIpfsProfit() {
    return Promise.resolve({
      data: [
        // { createTime: 1589526441927, power: 2.2222, profit: 0.0001, coinName: 'USDT' },
      ],
      currentPage: 1,
      pageSize: 15,
      totalRows: 0,
    });
  }
}

export default new Service();
