import http from '../plugins/http';

const key = '/api/v1/launchpad';

const api = http[key] || http.instance(key); // api modules.test

class Service {
    api = api;

    fetchLaunchpadInfo(id) { // 项目详情
      return this.api.get('/info', { params: { id } });
    }

    fetchLaunchpadOrderList(currentPage) { // 订单列表
      return this.api.get('/orderList', { params: { currentPage } });
    }

    fetchLaunchpadList() { // 项目列表
      return this.api.get('/list');
    }

    fetchLaunchpadPlaceOrder(params) { // 下单
      return this.api.get('/placeOrder', { params });
    }
}

export default new Service();
