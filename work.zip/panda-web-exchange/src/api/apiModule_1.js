// eslint-disable-next-line import/no-cycle
import http from '../plugins/http';
// eslint-disable-next-line import/no-cycle
import { Joi } from '../utils/common';
// import store from '../store';
import schemas from './schemas';

const key = '/api/v1';

const api = http[key] || http.instance(key); // api modules.test

class Service {
  api = api;

  // 需要验证参数的接口请使用@validate装饰器同步抛出错误给下一层业务组件
  // 不关心返回状态的api,可直接返回api的promise，无需重复书写async功能函数
  // @validate(schemas.test) // 可以在此处验证参数
  test(params) {
    // 进行参数验证的promise，在then方法回调里必须返回一个新的promise对象，否则会导致请求失败后走成功(then)方法，期望去catch处理异常。
    // return this.api.post('/news', params);
    return Joi.validate(params, schemas.test).then(values => this.api.post('/news', values));
  }

  systemConfig() { // config接口
    return this.api.post('/system/config');
  }

  updateReconfirm(params) { // 修改交易二次确认
    return this.api.post('/user/updateReconfirm', params);
  }

  tradeExport(params) { // 导出记录
    return this.api.get('/trade/export', { params }, { responseType: 'blob' });
  }

  zendeskChatTitle(params) { // zendesk聊天国际化
    return this.api.get('/zendesk/chatTitle', { params });
  }

  homeLinks() { // 友情链接
    return this.api.get('/home/links');
  }

  appConfigInfo() { // app 版本信息
    return this.api.get('/app/configInfo');
  }

  voteList() { // 获取投币列表
    return this.api.get('/vote/list');
  }

  voteAvailableVotes() { // 获取可用票数
    return this.api.get('/vote/availableVotes');
  }

  voteVoteRecord() { // 投票记录
    return this.api.get('/vote/voteRecord');
  }

  voteVote(params) { // 进行投票
    return this.api.get('/vote/vote', { params });
  }

  countryList(params) { // 国家信息
    return this.api.get('/country/list', { params });
  }

  inviteCode() { // 活动详情
    return this.api.get('/inviteCode');
  }

  activityInfo() { // 活动详情
    return this.api.get('/activity/info');
  }

  invitationOverview() { // 返佣总览
    return this.api.get('/invitation/invitationOverview');
  }

  invitationRecord(params) { // 邀请记录
    return this.api.get('/invitation/invitationRecord', { params });
  }

  feesBackRecord(params) { // 返佣记录
    return this.api.get('/invitation/feesBackRecord', { params });
  }

  userSetLog(params) { // 设置日志
    return this.api.post('/user/setLog', params);
  }

  userLoginLog(params) { // 登录日志
    return this.api.post('/user/loginLog', params);
  }

  uploadFile(params) {
    this.api.post('/upload/file', params);
  }

  webSocketInfo() { // mqtt配置获取
    this.api.post('/market/webSocketInfo');
  }

  quotationHistory(params) {
    this.api.post('/quotation/history', params);
  }

  register(params) { // 注册
    return this.api.post('/user/register', params);
  }

  sendRegEmail(params) { // 发送邮件
    return this.api.post('/user/sendRegEmail', params);
  }

  sendSms(params) { // 发送短信
    return this.api.post('/user/sendSms', params);
  }

  login(params) {
    return this.api.post('/user/login', params);
  }

  checkBindInfo(params) { // 获取绑定信息
    return this.api.post('/user/checkBindInfo', params);
  }

  sendLoginEmail(params) { // 发送登录邮件
    return this.api.post('/user/sendLoginEmail', params);
  }

  getLoginToken(params) { // 获取登录凭证
    return this.api.post('/user/getLoginToken', params);
  }

  userInfo(params) { // 获取用户信息
    return this.api.post('/user/info', params);
  }

  resetPassword(params) { // 找回密码
    return this.api.post('/user/resetPassword', params);
  }

  sendFindBackMail(params) { // 发送找回密码邮件
    return this.api.post('/user/sendFindBackMail', params);
  }

  checkIntroUser(params) { // 邀请码验证码（用于注册）
    return this.api.post('/user/checkIntroUser', params);
  }

  bindEmail(params) { // 绑定邮箱
    return this.api.post('/user/bindEmail', params);
  }

  sendBindEmail(params) { // 绑定邮箱发送验证码
    return this.api.post('/user/sendBindEmail', params);
  }

  getGoogleDevice(params) { // 获取谷歌密钥绑定
    return this.api.post('/user/getGoogleDevice', params);
  }

  getUpdateGoogleDevice(params) { // 获取谷歌密钥绑定
    return this.api.post('/user/getUpdateGoogleDevice', params);
  }

  bindGoogleAuth(params) { // 绑定谷歌验证码
    return this.api.post('/user/bindGoogleAuth', params);
  }

  updateGoogleAuth(params) { // 更换谷歌验证码
    return this.api.post('/user/updateGoogleAuth', params);
  }

  sendBindGoogleEmail(params) { // 发送绑定谷歌邮箱验证码
    return this.api.post('/user/sendBindGoogleEmail', params);
  }

  updatePhone(params) { // 修改手机
    return this.api.post('/user/updatePhone', params);
  }

  loginOut() { // 退出登录
    return this.api.post('/user/loginOut');
  }

  bindPhone(params) { // 绑定手机
    return this.api.post('/user/bindPhone', params);
  }

  sendBindPhoneEmail() { // 发送绑定手机验证码
    return this.api.post('/user/sendBindPhoneEmail');
  }

  sendUpdatePwdEmail() { // 发送修改登录密码邮件验证码
    return this.api.post('/user/sendUpdatePwdEmail');
  }

  sendAssetsEmail() { // 发送修改资金密码邮件验证码
    return this.api.post('/user/sendAssetsEmail');
  }

  modifyPassword(params) { // 修改登录和交易密码
    return this.api.post('/user/modifyPassword', params);
  }

  checkFirstPwd(params) { // 校验原登录密码
    return this.api.post('/user/checkFirstPwd', params);
  }

  identityUpload(params) { // 身份认证传输文件
    return this.api.post('/user/identityUpload', params);
  }

  identityAuth(params) { // 一级认证-国内
    return this.api.post('/user/identityAuth', params);
  }

  identityOtherAuth(params) { // 一级认证-国外
    return this.api.post('/user/identityOtherAuth', params);
  }

  highIdentification() { // 查看一级身份证认证详情-国内
    return this.api.post('/user/highIdentification');
  }

  identitySeniorOtherAuth(params) { // 二级身份证认证-国外
    return this.api.post('/user/identitySeniorOtherAuth', params);
  }

  primaryAuthInfo() { // 查看一级认证信息-国外
    return this.api.post('/user/primaryAuthInfo');
  }

  seniorAuthInfo() { // 查看二级认证信息
    return this.api.post('/user/seniorAuthInfo');
  }

  tradeSummaryList() { // 币种行情接口
    return this.api.post('/market/tradeSummaryList');
  }

  sendDrawCoinEmail() { // 发送提币邮箱验证码
    return this.api.post('/user/sendDrawCoinEmail');
  }

  getBanner() { // 首页banner获取
    return this.api.get('/home/banner');
  }

  getNotice() { // 首页notice获取
    return this.api.get('/home/notice');
  }

  getZendesk(params) { // zendesk签名
    return this.api.get('/zendesk/sign', { params });
  }
}

export default new Service();
