import http from '../plugins/http';
// import store from '../store';

const key = '/futures/futures/v1';

const api = http[key] || http.instance(key); // api modules.test

class Service {
  api = api;

  // 需要验证参数的接口请使用@validate装饰器同步抛出错误给下一层业务组件
  // 不关心返回状态的api,可直接返回api的promise，无需重复书写async功能函数
  // @validate(schemas.test) // 可以在此处验证参数

  assets(params) { // 获取单个合约资产信息
    return this.api.get('/assets', { params });
  }

  setRiskLimit(params) { // 设置风险限额
    return this.api.post('/position/setRiskLimit', params);
  }

  getOrderSetting(params) { // 查询期货下单配置
    return this.api.get('/position/getOrderSetting', { params });
  }

  openTreaty(params) { // 开通合约协议
    return this.api.get('/home/openTreaty', { params });
  }

  open(params) { // 开通合约
    return this.api.post('/account/open', params);
  }

  profitInfo(params) { // 合约计算器-计算收益信息
    return this.api.post('/profitInfo', params);
  }

  liquidationPrice(params) { // 合约计算器-计算强平价
    return this.api.post('/liquidationPrice', params);
  }

  /* accountInfo(params) { // 下单持仓信息
    return this.api.get('/order/accountInfo', { params });
  } */

  tradeSummaryList(params) { // 合约列表
    return this.api.get('/contract/list', { params });
  }

  marketIndex(params) { // 获取指数价格
    return this.api.get('/market/index', { params });
  }

  accountList(params) { // 合约账户列表
    return this.api.get('/account/list', { params });
  }

  precision(params) { // 合约币种精度
    return this.api.get('/precision', { params });
  }

  klineQuery(params, cancelToken) { // K线历史数据
    return this.api.get('/market/history/kline', { params }, { cancelToken });
  }

  fullDepth(params) { // k线深度&成交订单获取
    return this.api.get('/market/depth', { params });
  }

  fullGatherDepth(params) { // 合约总深度
    return this.api.get('/market/gatherDepth', { params });
  }

  marketTrade(params) { // 合约最新成交记录
    return this.api.get('/market/trade', { params });
  }

  webSocketInfo(params) { // websocket配置信息
    return this.api.post('/market/websocket/info', params);
  }

  create(params) { // 创建订单
    return this.api.post('/order/create', params);
  }

  blastingOrders(params) { // 强平订单
    return this.api.get('/blastingOrders', { params });
  }

  futuresDelivery(params) { // 交割结算记录
    return this.api.get('Delivery', { params });
  }

  reserveList(params) { // 风险准备金
    return this.api.get('/account/reserveList', { params });
  }

  longShortPositionRatio(path, params) { // 交易数据-多空持仓人数比
    return this.api.get(`/longShortPositionRatio/${path}`, { params });
  }

  openInterestAndVolume(path, params) { // 交易数据-合约持仓总量及交易量
    return this.api.get(`/openInterestAndVolume/${path}`, { params });
  }

  takerTradeVolume(path, params) { // 交易数据-合约主动买入卖出情况
    return this.api.get(`/takerTradeVolume/${path}`, { params });
  }

  futuresPositionList(params) {
    return this.api.get('/position/list', { params });
  }

  futuresOrderPending(params) { // 当前委托
    return this.api.get('/order/pending', { params });
  }

  futuresOrderCancel(params) { // 撤销订单
    return this.api.post('/order/cancel', params);
  }

  futuresOrderMatchInfo(params) { // 成交明细
    return this.api.get('/order/matchInfo', { params });
  }

  futuresOrderModifyMargin(params) { // 修改保证金
    return this.api.post('/order/modifyMargin', params);
  }

  futuresOrderTrades(params) { // 成交记录
    return this.api.get('/order/trades', { params });
  }

  futuresOrderHistory(params) { // 历史委托
    return this.api.get('/order/history', { params });
  }

  accountTransferAmount(params) { // 可划转金额
    return this.api.post('/account/transferAmount', params);
  }

  futuresBalanceFlow(params) { // 用户资金明细
    return this.api.get('/balanceFlow', { params });
  }

  futuresAccountTransfer(params) { // 资金划转
    return this.api.post('/account/transfer', params);
  }

  futuresOrderGetOrderInfo(params) { // 查询单个委托信息
    return this.api.get('/order/getOrderInfo', { params });
  }

  contractCoinList() { // 合约支持的币种
    return this.api.get('/contract/coin/list');
  }
}

export default new Service();
