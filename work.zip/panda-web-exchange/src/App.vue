<template>
  <div id="app" class="overflow-scroll-y">
    <Alert />
    <Confirm />
    <Toast />
    <router-view />
  </div>
</template>

<script>
// @ is an alias to /src

import { components } from './plugins/components';
import {
  mapState, isMobile, mapMutations, mapActions,
} from './utils/common';
import store from './store';

const { Alert, Confirm, Toast } = components;

export default {
  name: 'app',
  components: {
    // Header,
    Alert,
    Confirm,
    Toast,
  },
  computed: {
    ...mapState(['userInfo']),
  },
  created() {
    // 需要全局请求的接口在此执行
    this.fetchCountryList();
    // window.addEventListener('message', this.acceptMessage, false); // 接收外部消息
    if (isMobile()) window.location.href = process.env.VUE_APP_DOWNLOAD;
    this.$store.watch(() => this.$i18n?.locale, () => { //
      // this.$store.dispatch('exchange/closeTradeSummaryList');
      this.$store.dispatch('exchange/fetchTradeSummaryList');
    });
    this.fetchMoneyList();
    this.fetchSystemConfig();
  },
  methods: {
    ...mapMutations(['updateCountryList']),
    ...mapActions(['fetchCountryList', 'fetchMoneyList', 'fetchSystemConfig']), // 获取国家列表
    // eslint-disable-next-line consistent-return
    /* acceptMessage({ source, data: { type }, origin }) { // 对外部消息进行响应
      const { userInfo } = this;
      const { VUE_APP_CROSS: origins } = process.env;

      if (origins?.split(',')?.includes(origin)) {
        switch (type) {
          case 'getToken':
            return source.postMessage({ type: 'setToken', payload: { token: cookies.get('token') } }, origin);
          case 'getBindStatus':
            return source.postMessage({ type: 'setBindStatus', payload: { userInfo } }, origin);
          default:
            return null;
        }
      }
    }, */
  },
  beforeCreate() { // 加载页面之前开始订阅mqtt
    store.dispatch('exchange/fetchTradeSummaryList');
  },
  beforeDestroy() {
    // window.removeEventListener('message', this.acceptMessage, false);
  },
};
</script>

<style lang="scss">
#app {
  height: 100%;
  width: 100%;
  min-width: 1310px;
  overflow-x: scroll;
  min-height: 667px;
  -webkit-overflow-scrolling: touch;

  #main {
    -webkit-box-align: stretch;
    -ms-flex-align: stretch;
    align-items: stretch;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -ms-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;

    #header {
      -ms-flex-negative: 0;
      flex-shrink: 0;
      -webkit-box-flex: 0;
      -ms-flex-positive: 0;
      flex-grow: 0;
    }

    #content {
      -ms-flex-negative: 0;
      flex-shrink: 0;
      -webkit-box-flex: 1;
      -ms-flex-positive: 1;
      flex-grow: 1;
    }

    #footer {
      -ms-flex-negative: 0;
      flex-shrink: 0;
      -webkit-box-flex: 0;
      -ms-flex-positive: 0;
      flex-grow: 0;
    }
  }
}
</style>
