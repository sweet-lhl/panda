// import process from 'process';
import { Message, MessageBox } from 'element-ui';
// eslint-disable-next-line import/no-cycle,no-unused-vars
import i18n from '../setup/i18n-setup';
// import event from './eventEmitter';

export { default as http } from 'axios';
export { default as cookies } from 'cookies-js'; // https://github.com/ScottHamper/Cookies
export { default as md5 } from 'md5';
export { default as moment } from 'moment';
export { default as QRCode } from 'qrcode'; // https://github.com/davidshimjs/qrcodejs#readme
export { default as Joi } from 'joi-browser'; // https://github.com/hapijs/joi
export { default as calc } from 'js-calculation'; // https://github.com/noteScript/js-calculation
export {
  mapState, mapGetters, mapMutations, mapActions,
} from 'vuex';

export const alert = (title, message, options = { confirmButtonText: '确定' }) => MessageBox.alert(message, title, options);
export const toast = (message, type = 'success') => Message({
  message,
  type,
});

export const confirm = (title, message, options = {
  confirmButtonText: i18n.t('btnText[0]'),
  cancelButtonText: i18n.t('btnText[1]'),
  type: 'warning',
}) => MessageBox.confirm(title, message, options);

export function toFullscreen(el) { // Dom全屏
  switch ('function') {
    case typeof el.requestFullscreen:
      return el.requestFullscreen();
    case typeof el.webkitRequestFullScreen:
      return el.webkitRequestFullScreen();
    case typeof el.mozRequestFullScreen:
      return el.mozRequestFullScreen();
    case typeof el.msRequestFullscreen:
      return el.msRequestFullscreen();
    default:
      return false;
  }
}

export function isMobile() {
  const userAgent = navigator.userAgent.toLowerCase();
  // eslint-disable-next-line no-bitwise
  return (~userAgent.indexOf('iphone') || ~userAgent.indexOf('android'));
}

export const language = () => { // 全局处理zendesk跳转链接语言
  const { locale: lang } = i18n;
  if (lang === 'ko-KR') return 'en-us';
  return lang.toLowerCase();
};

export function handleDownloadFile(res) { // 下载账单
  try {
    window.location.href = `${window.location.origin}/${res}`;
  } catch (e) {
    toast(i18n.t('toast[5]'), 'error');
  }
}
