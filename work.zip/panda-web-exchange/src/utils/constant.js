export const PagingDefaultConf = {
  pageIndex: 1,
  pageSize: 12,
};

export const Regex = {
  CHINA_PHONE: /^1[3-9]{1}\d{9}$/,
  PHONE: /^\d{5,20}$/, // 国际
  EMAIL: /^[\S]+@[\w|\d]+\.[\w|\d]+$/,
  ACCOUNT: /(^\d{5,20}$)|(^[\S]+@[\w|\d]+\.[\w|\d]+$)/,
  QR_CODE_FIX: /^commission:\/\//,
  PASSWORD: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[^]{8,20}$/,
  CODE: /^\d{6}$/,
  SPECIAL_CHARACTERS: new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？%+_]"), // 特殊字符匹配(无法识别)
  SECURITY_PWD: /^[1-9]\d{5}(18|19|20)\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/,
  ID_CARD: /^[\uFF08-\uFF09()A-Za-z0-9]{15,18}$/,
  IS_DECIMAL: /^\d+\.\d+$/, // 是否是小数
  NUMBER: /^(1|[1-9][0-9]*)$/, // 只能输入1和非零开头的数字
  THOUSANDS_REGULAR: /\B(?=(\d{3})+(?!\d))/g, // 千分符
  IS_URL: /^(https?:\/\/(([a-zA-Z0-9]+-?)+[a-zA-Z0-9]+\.)+[a-zA-Z]+)(:\d+)?(\/.*)?(\?.*)?(#.*)?$/, // 判断是否是域名链接
};

export const TITLE = window.document.title;

// tradingView config start ------
export const DARK_STUDIES_OVERRIDES = {
  // 'volume.precision': 2,
  'Williams %R.hlines background.visible': false,
  'stochastic.hlines background.visible': false,
  'Relative Strength Index.hlines background.visible': false,
  'volume.volume.color.1': '#00ce7d', // 绿
  'volume.volume.color.0': '#e55541', // 红
  'stochastic.%D.color': '#FF5B7D',
  'stochastic.%K.color': '#4D81F3',
  'Relative Strength Index.Plot.color': '#E04DF3',
  'Williams %R.Plot.color': '#5E4DF3',
  'Moving Average.Plot.color': '#4D81F3',
  'Bollinger Bands.Median.color': '#FF5B7D',
  'Bollinger Bands.Upper.color': '#4D81F3',
  'Bollinger Bands.Lower.color': '#4D81F3',
  'MACD.Histogram.color': '#FF5B7D',
  'MACD.MACD.color': '#4D81F3',
  'MACD.Signal.color': '#FF5B7D',
  // 'MA Cross.short:plot.color': '#dddddd',
  // 'MA Cross.long:plot.colo': '#dddddd',


};
export const DARK_OVER_RIDES = {
  // 'paneProperties.topMargin': 10,
  'paneProperties.bottomMargin': 5,
  'paneProperties.legendProperties.showLegend': false, // 左上角指标展示开关
  'mainSeriesProperties.showPriceLine': true, // 最新价的水平虚线
  'scalesProperties.lineColor': '#666666',
  'scalesProperties.textColor': '#e6e6e6',
  'paneProperties.background': '#13252F',
  'paneProperties.crossHairProperties.color': '#666666',
  'mainSeriesProperties.barStyle.upColor': '#00CE7D', // 蜡烛图颜色-绿
  'mainSeriesProperties.barStyle.downColor': '#E55541', // 蜡烛图颜色-红
  'mainSeriesProperties.candleStyle.wickUpColor': '#00CE7D',
  'mainSeriesProperties.candleStyle.wickDownColor': '#E55541',
  'paneProperties.vertGridProperties.color': 'rgba(107,111,158, 0.3)',
  'paneProperties.horzGridProperties.color': 'rgba(107,111,158, 0.3)',
};

export const DISABLE_FEATURES = [
  'left_toolbar',
  'header_widget',
  'padding',
  'header_widget_dom_node',
  'header_resolutions',
  'header_settings',
  'header_indicators',
  'header_symbol_search',
  'compare_symbol',
  'display_market_status',
  'go_to_date',
  'header_saveload',
  'adaptive_logo',
  'header_chart_type',
  'header_compare',
  'header_interval_dialog_button',
  'header_resolutions',
  'header_screenshot',
  'header_symbol_search',
  'header_undo_redo',
  'legend_context_menu',
  'show_hide_button_in_legend',
  'show_interval_dialog_on_key_press',
  'snapshot_trading_drawings',
  'header_fullscreen_button',
  'header_layouttoggle',
  'symbol_info',
  'timeframes_toolbar',
  'use_localstorage_for_settings',
  'volume_force_overlay', // 禁用指标中左下角volume展示的数据
  'adptive_logo',
];
export const ENABLED_FEATURES = [
  'dont_show_boolean_study_arguments',
  'hide_last_na_study_output',
  // 'move_logo_to_main_pane',
  'header_widget_dom_node',
  'header_layouttoggle',
  'same_data_requery',
  'disable_resolution_rebuild', // 显示完全由 datafeed 提供的 K 线时间而不进行任何调整
  // 'adaptive_logo', 允许您在小屏幕设备上隐藏 logo 的TradingView文字
  'side_toolbar_in_fullscreen_mode',
];

// tradingView config end ------
