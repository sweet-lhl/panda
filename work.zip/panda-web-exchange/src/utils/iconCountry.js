// country config
export default [
  {
    className: '#icon-zhongguo', area: '86', label: '中国', value: 'China',
  },
  {
    className: '#icon-HKG', area: '852', label: '中国香港', value: 'Hong Kong (SAR)',
  },
  {
    className: '#icon-zhongguojitaiwan', area: '886', label: '中国台湾 ', value: 'Taiwan',
  },
  {
    className: '#icon-xinjiapo', area: '65', label: '新加坡', value: 'Singapore',
  },
  {
    className: '#icon-laozhua', area: '856', label: '老挝', value: 'Laos',
  },
  {
    className: '#icon-hanguo', area: '82', label: '韩国', value: 'Korea',
  },
  {
    className: '#icon-malaixiya', area: '60', label: '马来西亚', value: 'Malaysia',
  },
  {
    className: '#icon-yuenan', area: '84', label: '越南', value: 'Vietnam',
  },
  {
    className: '#icon-jianpuzhai', area: '855', label: '柬埔寨 ', value: 'Kampuchea',
  },
  {
    className: '#icon-feilvbin', area: '63', label: '菲律宾', value: 'Philippines',
  },
  {
    className: '#icon-yindunixiya', area: '62', label: '印度尼西亚', value: 'Indonesia',
  },
  {
    className: '#icon-wenlai', area: '673', label: '文莱', value: 'Brunei',
  },
  {
    className: '#icon-yindu', area: '91', label: '印度', value: 'India',
  },
  {
    className: '#icon-taiguo', area: '66', label: '泰国', value: 'Thailand',
  },
  {
    className: '#icon-aodaliya', area: '61', label: '澳大利亚 ', value: 'Australia',
  },
  {
    className: '#icon-xinxilan', area: '64', label: '新西兰', value: 'New Zealand',
  },
  {
    className: '#icon-yingguo-', area: '44', label: '英国', value: 'United Kingdom',
  },
  {
    className: '#icon-faguo', area: '33', label: '法国', value: 'France',
  },
  {
    className: '#icon-deguo', area: '49', label: '德国', value: 'Germany',
  },
  {
    className: '#icon-eluosi', area: '7', label: '俄罗斯', value: 'Russia',
  },
  {
    className: '#icon-xila', area: '30', label: '希腊', value: 'Greece',
  },
  {
    className: '#icon-tuerqi', area: '90', label: '土耳其', value: 'Turkey',
  },
  {
    className: '#icon-ruidian', area: '46', label: '瑞典', value: 'Sweden',
  },
  {
    className: '#icon-ruishi', area: '41', label: '瑞士', value: 'Switzerland',
  },
  {
    className: '#icon-helan', area: '31', label: '荷兰', value: 'Netherlands',
  },
  {
    className: '#icon-fenlan', area: '358', label: '芬兰', value: 'Finland',
  },
  {
    className: '#icon-seychellessaisheer', area: '248', label: '塞舌尔', value: 'Seychelles',
  },
  {
    className: '#icon-xibanya', area: '34', label: '西班牙', value: 'Spain',
  },
  {
    className: '#icon-yidali', area: '39', label: '意大利', value: 'Italy',
  },
  {
    className: '#icon-putaoya', area: '351', label: '葡萄牙', value: 'Portugal',
  },
  {
    className: '#icon-yiselie', area: '972', label: '以色利', value: 'Israel',
  },
  {
    className: '#icon-agenting', area: '54', label: '阿根廷', value: 'Argentina',
  },

];
