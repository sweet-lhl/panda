// tradingview
import http from 'axios';
import { widget as Widget } from './charting_library.min';
import {
  DARK_STUDIES_OVERRIDES, DARK_OVER_RIDES, DISABLE_FEATURES, ENABLED_FEATURES,
} from './constant';
import api from '../api/order';
import socket from '../plugins/mqttService';
import { route } from '../setup/router-setup';
import { moment } from './common';
import event from './eventEmitter';
import store from '../store';
import i18n from '../setup/i18n-setup';

const { CancelToken } = http;
let httpSource;
let entityIds;
let transactionKlineId = null;

function fetchQuotationHistory(range, endTime = new Date().getTime()) {
  const { id } = route.query;
  const { tradeSummaryList } = store.state.exchange;
  const tradePairs = Object.values(tradeSummaryList).find(({ tradeId }) => tradeId === Number(id)) ?.tradeName;
  const startTime = endTime - (range * 600);
  // eslint-disable-next-line camelcase
  const [left_pair, right_pair] = tradePairs.split('/');
  return tradePairs ? api.klineQuery({
    left_pair,
    right_pair,
    time_unit: range,
    begin: moment(startTime).unix(),
    end: moment(endTime).unix(),
  }, httpSource ?.token) : Promise.reject(new Error('symbol获取错误'));
}

class DataFeedContainer { // datafeed
  constructor(range) {
    this.topicRange = range;
  }

  configuration = {};

  lastTime = new Date().getTime(); // 历史交易最后的时间

  priceMax = null;

  kChartSubscriberList = [];

  realtimeCallback;

  resetCacheNeededCallback;

  async fetchChartData() {
    const { id } = route.query;
    const { tradeSummaryList } = store.state.exchange;
    const tradePairs = Object.values(tradeSummaryList).find(({ tradeId }) => tradeId === Number(id)) ?.tradeName;
    transactionKlineId = `kline/MARKET_KLINE_${this.topicRange}_${tradePairs.toLowerCase().replace('/', '_')}`;
    socket.instance.subscribe(transactionKlineId)((order) => {
      // console.log(moment.unix(order.id).format('YYYY-MM-DD HH:mm:ss'));
      this.realtimeCallback({
        close: Number(order.close),
        open: Number(order.open),
        high: Number(order.high),
        low: Number(order.low),
        volume: Number(order.amount),
        time: moment.unix(order.id).valueOf(),
      });
    });
  }

  onReady(callback) {
    const { configuration: configurationData } = this;
    if (configurationData) process.nextTick(() => callback(configurationData));
    // else this.on('configuration_ready', callback(this.configurationData));
  }

  /* searchSymbols(userInput, exchange, symbolType, onResultReadyCallback) { // 提供一个匹配用户搜索的商品列表
  } */
  resolveSymbol( //  图表库用户遇到的72.2％的问题，都是由于错误的/格式错误的SymbolInfo数据引起的,请勿轻易修改
    symbolName,
    onSymbolResolvedCallback,
    // onResolveErrorCallback,
  ) { // 通过商品名称解析商品信息
    const { topicRange: ticker } = this;
    const { id } = route.query;
    const { tradeSummaryList } = store.state.exchange;
    const data = Object.values(tradeSummaryList).find(({ tradeId }) => tradeId === Number(id));
    const tradePairs = data ?.tradeName;
    const pricescale = 10 ** data ?.cnyDigit;
    const options = { // Symbology -> https://b.aitrade.ga/books/tradingview/book/Symbology.html#%E5%95%86%E5%93%81%E4%BF%A1%E6%81%AF%E7%BB%93%E6%9E%84
      name: tradePairs, // 商品名称
      ticker, // 这里的值必须要在确保切换交易对的时候一样，否则无法绘制（与时间周期无关）
      timezone: 'Asia/Shanghai', // 交易时区
      pricescale,
      minmov: 1,
      minmov2: 0,
      // format: 'volume',
      format: {
        volume: 1000,
      },
      description: '', // 商品说明
      session: '24x7', // 交易时段
      type: 'stock', // 仪表类型
      // has_fractional_volume: true,
      has_intraday: true, // 布尔值显示商品是否具有日内（分钟）历史数据
      has_weekly_and_monthly: true, // 是否有周线和月线
      has_no_volume: false, // 是否将成交量独立出来
      autosize: true,
      has_daily: true, // 布尔值显示商品是否具有以日为单位的历史数据
      has_empty_bars: false, // 布尔值显示在交易过程中，当datafeed没有数据返回时,library是否会生成空的K柱
      has_seconds: true, // 布尔值显示商品是否具有以秒为单位的历史数据
      has_fractional_volume: true,
      intraday_multipliers: ['1'], // 包含日内周期(分钟单位)的数组，datafeed将会自行构建它
      regular_session: '24x7',
      volume_precision: 0,
      fullscreen: false,
      supported_resolutions: [ // 支持的周期数组
        '1',
        '5',
        '15',
        '30',
        '60',
        '240',
        '360',
        '720',
        // '1440',
        // '10080',
        'D',
        'W',
      ],
    };
    return process.nextTick(() => onSymbolResolvedCallback(options));
  }

  getBars(
    symbolInfo,
    resolution,
    from,
    to,
    onHistoryCallback,
    onErrorCallback,
    firstDataRequest,
  ) { // 通过日期范围获取历史K线数据。图表库希望通过onHistoryCallback仅一次调用，接收所有的请求历史。而不是被多次调用。
    if (firstDataRequest) {
      this.lastTime = new Date().getTime();
    }
    const { topicRange } = this;
    return fetchQuotationHistory(topicRange, this.lastTime || to)
      .then(r => r.map(order => ({
        close: Number(order.close),
        open: Number(order.open),
        high: Number(order.high),
        low: Number(order.low),
        volume: Number(order.amount),
        time: moment.unix(order.timestamp).valueOf(),
      })))
      .then((r) => {
        if (r.length > 1) {
          [
            this.lastTime,
          ] = [r[0].time];
          onHistoryCallback(r, { noData: false });
        } else {
          onHistoryCallback([], { noData: true });
        }
        event.emit('closeKlineLoading');
      })
      .catch(() => {
        onHistoryCallback([], { noData: true });
        event.emit('closeKlineLoading');
      });
    // }
    // return onHistoryCallback([], { noData: false });
    // onHistoryCallback(bars, { noData: true , nextTime: data.nb || data.nextTime });
  }

  subscribeBars(
    symbolInfo,
    resolution,
    onRealtimeCallback,
    subscriberUID,
    onResetCacheNeededCallback, // 在bars数据发生变化时执行
  ) { // 订阅K线数据。图表库将调用onRealtimeCallback方法以更新实时数据
    if (this.kChartSubscriberList.some(
      kChartSubscriber => kChartSubscriber.subscriberUID === subscriberUID,
    )) return;
    this.kChartSubscriberList.push({ // 记录订阅uid
      symbol: symbolInfo,
      resolution,
      subscriberUID,
      // callback: onRealtimeCallback,
    });
    [ // 依赖realtimeCallback回调方法进行同步图表数据
      this.realtimeCallback,
      this.resetCacheNeededCallback,
    ] = [
      onRealtimeCallback,
      onResetCacheNeededCallback,
    ];
  }

  unsubscribeBars(subscriberUID) { // 取消订阅K线数据
    const idx = this.kChartSubscriberList.findIndex(
      kChartSubscriber => kChartSubscriber.subscriberUID === subscriberUID,
    );
    // if (transactionKlineId) socket.instance.unsubscribe(transactionKlineId); //
    if (idx < 0) return;
    this.kChartSubscriberList.splice(idx, 1); // 移除订阅uid
  }

  /* calculateHistoryDepth(
  resolution,
  resolutionBack,
  intervalBack
  ) { // 图表库在它要请求一些历史数据的时候会调用这个函数，让你能够覆盖所需的历史深度
  } */

  /* getMarks(
  symbolInfo,
  startDate,
  endDate,
  onDataCallback,
  resolution
  ) { // 图表库调用这个函数来获得可见的K线范围的标记。 图表预期每调用一次getMarks就会调用一次onDataCallback

  } */

  /* getTimescaleMarks(
  symbolInfo,
  startDate,
  endDate,
  onDataCallback,
  resolution
  ) { // 图表库调用此函数获取可见K线范围的时间刻度标记。图表预期您每个调用getTimescaleMarks会调用一次onDataCallback。

  } */

  // getServerTime(callback){}
}

export default class TvWidget {
  constructor({
    // eslint-disable-next-line camelcase
    range, interval, type, id: container_id, height = '100%',
    theme = 'Dark',
    width = '100%',
    timezone = 'Asia/Shanghai',
    // eslint-disable-next-line no-nested-ternary
    // locale = i18n.locale === 'zh-CN' ? 'zh' : (i18n.locale === 'en-US' ? 'en' : i18n.locale),
  }) {
    this.datafeed = new DataFeedContainer(range);
    const { id } = route.query;
    const { tradeSummaryList } = store.state.exchange;
    const tradePairs = Object.values(tradeSummaryList).find(({ tradeId }) => tradeId === Number(id));
    const options = {
      datafeed: this.datafeed,
      symbol: tradePairs ?.tradeName,
      interval,
      type,
      overrides: DARK_OVER_RIDES,
      disabled_features: DISABLE_FEATURES,
      enabled_features: ENABLED_FEATURES,
      studies_overrides: DARK_STUDIES_OVERRIDES,
      // toolbar_bg: 'red',
      container_id,
      height,
      width,
      // fullscreen: true,
      autosize: true,
      theme,
      library_path: '/tradeview/charting_library/',
      custom_css_url: './black.css',
      timezone,
      locale: this.language,
      customFormatters: {
        dateFormatter: {
          format(date) { return `${date.getUTCFullYear()}-${date.getUTCMonth() + 1}-${date.getUTCDate()}`; },
        },
      },
      debug: false/* process.env.NODE_ENV !== 'production' */,
      padding: 0,
    };

    // eslint-disable-next-line no-undef
    this.chartInstance = new Widget(options);
    this.chartInstance.onChartReady(() => {
      const activeChart = this.chartInstance.activeChart
        ? this.chartInstance.activeChart()
        : this.chartInstance.chart();
      const colors = ['#10B886', '#FA5152', '#CD8980', '#61D1C0'];
      // const { tradeSummaryList } = store.state.exchange;
      // const data = Object.values(tradeSummaryList).find(({ tradeId }) => tradeId === Number(id));
      entityIds = ['5', '15', '30', '60'].map((_range, index) => activeChart.createStudy('Moving Average', false, false, [_range], null, {
        'Plot.color': colors[index],
        precision: tradePairs ?.cnyDigit,
      }));
      activeChart.onIntervalChanged().subscribe(null, (/* interval, obj */) => {
        this.chartInstance.changingInterval = false;
      });
      activeChart.setChartType(type);
      // activeChart.selectLineTool('zoom');
      // activeChart.getPanes(1);
      /* activeChart.createShape({ // 创建最新价格的时间线
        timre:
      }) */

      [
        this.chartInstance.MAStudies,
        this.chartInstance.selectedIntervalButton,
        this.range,
      ] = [
        [],
        null,
        range,
      ];
    });
  }


  // eslint-disable-next-line class-methods-use-this
  get language() { // 使用get返回语言
    if (i18n.locale === 'zh-TW') return 'zh_TW';
    return i18n.locale.substr(0, 2);
  }

  get range() { // eslint-disable-next-line no-underscore-dangle
    return this._range;
  }

  set range(value) {
    if (transactionKlineId) socket.instance.unsubscribe(transactionKlineId); // 取消订阅
    if (httpSource) httpSource.cancel();
    httpSource = CancelToken.source();
    this.datafeed.fetchChartData();
  }

  get chartType() {
    // eslint-disable-next-line no-underscore-dangle
    return this._chartType;
  }

  set chartType(type) {
    // eslint-disable-next-line no-underscore-dangle
    const { chartInstance } = this;
    // 美国线 STYLE_BARS = 0;
    // K线图 STYLE_CANDLES = 1;
    // 线形图 STYLE_LINE = 2;
    // 面积图 STYLE_AREA = 3;
    // 平均K线图 STYLE_HEIKEN_ASHI = 8;
    // 空心K线图 STYLE_HOLLOW_CANDLES = 9;

    // 砖形图 STYLE_RENKO* = 4;
    // 卡吉图 STYLE_KAGI* = 5;
    // 点数图 STYLE_PNF* = 6;
    // 新价图 STYLE_PB* = 7;

    // eslint-disable-next-line no-underscore-dangle
    if (!chartInstance._ready) return;

    const activeChart = chartInstance.activeChart
      ? chartInstance.activeChart()
      : chartInstance.chart();

    activeChart.setChartType(type);
  }

  // get resolution() {
  //   // eslint-disable-next-line no-underscore-dangle
  //   return this._resolution;
  // }

  resolution(type, range, status) {
    /* eslint-disable no-underscore-dangle */
    // this._resolution = value;
    const { chartInstance } = this;
    if (!chartInstance) return;
    // if (transactionKlineId) socket.instance.unsubscribe(transactionKlineId); // 取消订阅
    if (transactionKlineId) socket.instance.unsubscribe(transactionKlineId); // 取消订阅
    // if (httpSource) httpSource.cancel();
    // httpSource = CancelToken.source(); // 每次设置range，都将对后续请求分配一个token(共用)
    this.datafeed.lastTime = new Date().getTime();
    //       this.datafeed.priceMax,
    this.datafeed.topicRange = range;
    // this.datafeed.priceMax = 222.02;
    const activeChart = chartInstance.activeChart
      ? chartInstance.activeChart()
      : chartInstance.chart();
    this.datafeed.resetCacheNeededCallback(); // 保持在resetData之前
    // activeChart.resetData();
    const { tradeSummaryList } = store.state.exchange;
    const { id } = route.query;
    const tradePairs = Object.values(tradeSummaryList).find(({ tradeId }) => tradeId === Number(id));
    // '1440',
    // '10080',
    let timeName = String(range / 60000);
    // eslint-disable-next-line no-nested-ternary
    timeName = timeName === '1440' ? 'D' : timeName === '10080' ? 'W' : timeName;
    this.chartInstance.setSymbol(tradePairs ?.tradeName, timeName, () => {
    });
    // 更改时间线;
    if (status) {
      entityIds.forEach(entityId => activeChart.removeEntity(entityId));
      const colors = ['#10B886', '#FA5152', '#CD8980', '#61D1C0'];
      entityIds = ['5', '15', '30', '60'].map((_range, index) => activeChart.createStudy('Moving Average', false, false, [_range], null, {
        'Plot.color': colors[index],
        precision: tradePairs ?.cnyDigit,
      }));
    }
    activeChart.setChartType(type); // 设置
    this.chartInstance.changingInterval = true;
    this.datafeed.fetchChartData();
    event.emit('closeKlineLoading');
  }

  openSettingDialog() { // 显示设置
    if (!this.chartInstance) return;

    const activeChart = this.chartInstance.activeChart
      ? this.chartInstance.activeChart()
      : this.chartInstance.chart();

    activeChart.executeActionById('chartProperties');
  }

  openInsertIndicator() { // 显示指标
    if (!this.chartInstance) return;
    const activeChart = this.chartInstance.activeChart
      ? this.chartInstance.activeChart()
      : this.chartInstance.chart();

    activeChart.executeActionById('insertIndicator');
  }

  close() {
    return this.chartInstance.remove();
  }
}
