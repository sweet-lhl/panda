<template>
  <transition name="custom-classes-transition" enter-active-class="animated fadeIn" mode="out-in">
    <router-view/>
  </transition>
</template>

<script>
import { mapActions } from '../../utils/common';

export default {
  name: 'assetManagement', // 我的资产
  methods: {
    ...mapActions('assets', ['fetchAllAssets', 'fetchOtcFinancial']),
  },
  created() {
    this.fetchAllAssets();
  },
};
</script>

<style scoped>
</style>
