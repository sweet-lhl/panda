<i18n>
  zh-CN:
   title:
    - 资金记录
    - '{value}记录'
    - 充币
    - 提币
    - 划转
    - 其他
   placeholder:
    - 搜索币种
   label:
    - 时间
    - 币种
    - 地址
    - 类型
    - 到账数量
    - 网络手续费
    - 提币状态
    - 数量
    - 充币状态
    - 金额
    - 手续费
    - 操作
    - 详情
   assetsBtnText:
    - 取消提币
    - '标签'
    - '撤销'
   message:
    - 暂无记录
    - '确认取消提币吗？'
    - 提示
    - 取消提币成功
   btn:
    - 账单下载
  en-US:
   title:
    - 'Fund History'
    - '{value} History'
    - 'Deposit'
    - 'Withdraw'
    - 'Transfer'
    - 'Others'
   placeholder:
    - 'Search Coin'
   label:
    - Time
    - Coin
    - Address
    - Type
    - 'Arrival Amount'
    - 'Fee'
    - 'Withdrawal Status'
    - Amount
    - 'Deposit status'
    - Amount
    - Fee
    - 'Operation'
    - 'Detail'
   assetsBtnText:
    - 'Cancel'
    - 'Label'
    - 'Label'
    - 'Revoke'
   message:
    - 'No open orders yet'
    - 'Are you sure to cancel the withdrawal？'
    - Prompt
    - 'Cancel the success'
   btn:
    - 'Bill download'
  zh-TW:
   title:
    - 資金記錄
    - '{value}記錄'
    - 充幣
    - 提幣
    - 劃轉
    - 其他
   placeholder:
    - 搜索幣種
   label:
    - 時間
    - 幣種
    - 地址
    - 類型
    - 到賬數量
    - 網路手續費
    - 提幣狀態
    - 數量
    - 充幣狀態
    - 金額
    - 手續費
    - 操作
    - '詳情'
   assetsBtnText:
    - 取消提幣
    - '標籤'
    - '撤銷'
   message:
    - 暫無記錄
    - '確認取消提幣嗎？'
    - 提示
    - 取消提幣成功
   btn:
    - 賬單下載
  ko-KR:
   title:
    - '펀드 기록'
    - '{value}기록'
    - '입금 기록'
    - '출금 기록'
    - '전송 기록'
    - '기타 기록'
   placeholder:
    - '검색'
   label:
    - '시간'
    - '코인명'
    - '주소'
    - '유형'
    - '도착 수'
    - '수수료'
    - '출금 상태'
    - '수량'
    - '상태'
    - '금액'
    - '수수료'
    - '작업'
    - '수수료 안내'
    - '조작'
    - '세부 정보'
   assetsBtnText:
    - '탈퇴 취소'
    - '라벨'
    - '철회하다'
   message:
    - '기록 없음'
    - '출금을 취소 하시겠습니까？'
    - '프롬프트'
    - '성공을 취소'
   btn:
    - '빌 다운로드'
</i18n>
<template>
  <div class="assetManagement">
    <div class="asset-box">
      <div class="asset_header flex-justify-content-space-between">
        <div class="header_left">
          <!-- <p class="text-weight-8">资产总折合：{{allAssets.totalToBTC | toFixed(8)}} BTC</p>
          <label>≈ {{allAssets[`totalTo${moneySelect}`]}} {{moneySelect}}</label>-->
          <p class="text-weight-5">{{$t('title[0]')}}</p>
          <!-- 资金记录  -->
        </div>
        <div class="header_right"></div>
      </div>
      <div class="asset-content">
        <div class="table-content position-relative">
          <div
            v-if="activeName==='first' || activeName ==='second'"
            class="flex-justify-content-flex-end flex-align-items-center position-absolute header_right_download">
            <svg class="icon header_right_icon" aria-hidden="true">
              <use xlink:href="#icon-ziyuan" />
            </svg>
            <el-link
              type="primary"
              class="text-size-12 text-color-blue margin-left-6"
              @click.stop="$refs.recordAssetsDialog.handleShowDialog()">
              {{$t('btn[0]')}}
            </el-link>
          </div>
          <el-tabs v-model="activeName"
                   class="table-tabs"
                   @tab-click="getUserAssetDetails">
            <el-tab-pane
              v-for="(key, value) in activeTitles"
              :label="key.label"
              :name="key.name"
              :key="value.name"
            />
            <div class="table-header">
              <div class="left">
                <div class="title">{{$t('title[1]', { value: titleText })}}</div>
                <!-- 记录  -->
              </div>
              <div class="right">
                <el-autocomplete
                  v-if="activeName==='first' || activeName ==='second'"
                  v-model="coinName"
                  :fetch-suggestions="querySearchAsync"
                  :placeholder="$t('placeholder[0]')"
                  size="mini"
                  @select="handleSelect">
                  <!-- 搜索币种  -->
                  <svg slot="prefix" class="icon icon-tishi" aria-hidden="true">
                    <use xlink:href="#icon-sousuo1" />
                  </svg>
                </el-autocomplete>
              </div>
            </div>
            <el-table
              :align="center"
              :data="tableData || []"
              v-loading="loading"
              ref="table"
              @expand-change="expandChange"
              :cell-style="{fontSize: '12px',borderBottom: 'none',color: '#41414c',height:'60px'}"
              :header-cell-style="{background:'#f8f8f8',color:'rgba(65, 65, 76, 0.6) !important', fontSize: '12px'}">
              <el-table-column
                key="1"
                prop="time"
                :label="$t('label[0]')"
                label-class-name="text-align-left  text-weight-4"
                class-name="text-align-left text-weight-4"
                :width="activeName==='second'?140:'auto'">
                <!-- 时间  -->
                <template slot-scope="{row}">{{row.time | timeStampToDate('YYYY-MM-DD HH:mm:ss')}}</template>
              </el-table-column>
              <el-table-column
                key="2"
                prop="coinName"
                :label="$t('label[1]')"
                label-class-name="text-align-right  text-weight-4"
                class-name="text-align-right text-weight-4"
                :width="activeName === 'second' ? 60 : 'auto'"/>
              <!-- 币种  -->
              <!-- <el-table-column
                key="3"
                v-if="activeName === 'second'"
                :label="$t('label[2]')"
                label-class-name="text-align-center text-weight-4"
                class-name="text-align-right text-weight-4"
                width="240">
                <template slot-scope="{row: { withdrawaddress }}">
                  {{withdrawaddress}}
                </template>
              </el-table-column> -->
              <!-- 地址  -->
              <el-table-column
                :label="$t('label[3]')"
                label-class-name="text-align-right text-weight-4"
                class-name="text-align-right text-weight-4"
                :width="activeName === 'second'?100:'auto'">
                <template slot-scope="{row: { typeName }}">
                  {{typeName}}
                </template>
              </el-table-column>
              <!-- 类型  -->
              <el-table-column
                :label="$t('label[4]')"
                prop="number"
                label-class-name="text-align-right text-weight-4"
                class-name="text-align-right text-weight-4"
                v-if=" activeName==='second'"
                width="auto">
                <template
                  slot-scope="{row}"
                >{{row.number | toFixed(allAmountDecimal[row.coinName])}}</template>
              </el-table-column>
              <!-- 到账数量  -->
              <el-table-column
                :label="$t('label[5]')"
                prop="fees"
                label-class-name="text-align-right text-weight-4"
                class-name="text-align-right text-weight-4"
                v-if=" activeName==='second'"
                width="auto">
                <template slot-scope="{row}">{{row.fees | toFixed(row.withdrawDecimal)}}</template>
              </el-table-column>
              <!-- 网络手续费  -->
              <el-table-column
                :label="$t('label[6]')"
                prop="status"
                label-class-name="text-align-right text-weight-4"
                class-name="text-align-right text-weight-4"
                v-if=" activeName==='second'"
                width="auto">
                <!-- 提币状态  -->
                <template slot-scope="{row}">
                    <span
                      v-if="row.status"
                      :style="{color:[row.statusEn==='FAILURE_WITHDRAW' ? '#E05C74':'',row.statusEn==='PROCESSING' ?'#F5A623':'']}"
                    >{{row.status}}</span>
                  <span class="revoke cursor-pointer" v-if="row.cancel" @click="handleCancelWithdraw({id: row.id})">
                    {{$t('assetsBtnText[2]')}}<!--撤销-->
                  </span>
                </template>
              </el-table-column>
              <el-table-column
                width="auto"
                prop="number"
                label-class-name="text-align-right text-weight-4"
                class-name="text-align-right text-weight-4"
                v-if="activeName==='first' "
                :label="$t('label[7]')">
                <template
                  slot-scope="{row}"
                >{{row.number | toFixed(allAmountDecimal[row.coinName])}}</template>
              </el-table-column>
              <!-- 数量  -->
              <el-table-column
                :label="$t('label[8]')"
                prop="status"
                label-class-name="text-align-right text-weight-4"
                class-name="text-align-right text-weight-4"
                v-if="activeName==='first'"
                width="auto">
                <!-- 充币状态  -->
                <template slot-scope="{row}">
                    <span
                      v-if="row.status"
                      :style="{color:[row.statusEn==='FAILURE_WITHDRAW' ? '#E05C74':'',row.statusEn==='PROCESSING' ?'#F5A623':'']}"
                    >{{row.status}}</span>
                </template>
              </el-table-column>
              <el-table-column
                :label="$t('label[9]')"
                prop="number"
                label-class-name="text-align-right text-weight-4"
                class-name="text-align-right text-weight-4"
                v-if="activeName==='third'"
                width="auto" >
                <template
                  slot-scope="{row}"
                >{{row.number | toFixed(allAmountDecimal[row.coinName])}}</template>
              </el-table-column>
              <!-- 金额  -->
              <el-table-column
                :label="$t('label[9]')"
                prop="number"
                label-class-name="text-align-right text-weight-4"
                class-name="text-align-right text-weight-4"
                v-if=" activeName==='fourth'"
                width="auto">
                <template slot-scope="{row}">
                  {{row.number | toFixed(allAmountDecimal[row.coinName])}}
                </template>
              </el-table-column>
              <!-- 金额  -->
              <el-table-column
                :label="$t('label[10]')"
                prop="fees"
                label-class-name="text-align-right text-weight-4"
                class-name="text-align-right text-weight-4"
                v-if="activeName==='third'"
                width="auto"/>
              <!-- 手续费  -->
              <!--       <el-table-column
                       label-class-name="text-align-right  text-weight-4"
                       class-name="text-align-right  text-weight-4"
                       :label="$t('label[11]')"
                       v-if="activeName==='second'"
                       width="70px">
                       &lt;!&ndash; 操作  &ndash;&gt;
                       <template slot-scope="{row}">
                         <el-button
                           type="text"
                           v-if="row.cancel"
                           @click="handleCancelWithdraw({id: row.id})">{{$t('assetsBtnText[0]')}}</el-button>
                         &lt;!&ndash; 取消提币  &ndash;&gt;
                         <span v-else>- -</span>
                       </template>
                     </el-table-column>-->

              <el-table-column
                label-class-name="text-align-right text-weight-4"
                class-name="text-align-right text-weight-4"
                v-if="activeName==='first'||activeName==='second'"
                width="100px"
                :label="$t('label[11]')">
                <!--    操作    -->
                <template slot-scope="scope">
                  <div
                    class="flex-justify-content-flex-end flex-align-items-center cursor-pointer text-color-blue"
                    @click.stop="toggleRow(scope.row, scope.$index, tableData)">
                    {{$t('label[12]')}}
                    <svg :class="['icon', 'table_icon']" :style="{transform: rotateIndex === scope.row.id ? 'rotate(270deg)' : 'rotate(90deg)'}"  aria-hidden="true">
                      <use xlink:href="#icon-jinru" />
                    </svg>
                  </div>
                  <!--    详情    -->
                </template>
              </el-table-column>
              <el-table-column
                width="1"
                type="expand">
                <template slot-scope="scope">
                  <div class="form_layout">
                    <div class="popper__arrow"></div>
                    <div class="text-align-left form_item_desc">{{scope.id}}</div>
                    <div class="form_layout_content flex-justify-content-space-between">
                      <p><!--地址：-->{{$t('label[2]')}}：</p>
                      <label class="text-size-12">{{activeName==='second' ? scope.row.withdrawaddress : scope.row.rechargeaddress}}</label>
                    </div>
                    <div class="form_layout_content flex-justify-content-space-between" v-if="scope.row.labelCoinAddress">
                      <p><!--标签-->{{$t('assetsBtnText[1]')}}：</p>
                      <label class="text-size-12">{{scope.row.labelCoinAddress}}</label>
                    </div>
                    <div class="form_layout_content flex-justify-content-space-between" v-if="isShowTxid(scope.row.txid)">
                      <p>Txid：</p>
                      <p class="cursor-pointer" @click.stop="handleJumpPage(scope.row)">{{scope.row.txid || '--'}}</p>
                    </div>
                  </div>
                </template>
              </el-table-column>
              <template #empty>
                <empty />
              </template>
            </el-table>
            <!-- <el-tab-pane label="提币" name="second"></el-tab-pane>
            <el-tab-pane label="划转" name="third"></el-tab-pane>
            <el-tab-pane label="其他" name="fourth"></el-tab-pane>-->
          </el-tabs>
          <div class="asset-pagination">
            <el-pagination
              small
              background
              :hide-on-single-page="true"
              layout="prev, pager, next"
              :current-page.sync="pagination.page"
              @current-change="getUserAssetDetails"
              :total="pagination.total"/>
          </div>
        </div>
      </div>
    </div>
    <RecordAssetsDialog ref="recordAssetsDialog" />
  </div>
</template>

<script>
import api from '../../api/asset';
import RecordAssetsDialog from './RecordAssetsDialog.vue';
import { mapState, mapActions } from '../../utils/common';
import { Regex } from '../../utils/constant';
// import { Regex } from '../../utils/constant';

export default {
  name: 'recordAssets', // 我的资产
  components: { RecordAssetsDialog },
  data() {
    return {
      ruleForm: { quantity: 0 }, // 页面表单 // 交易数量
      pagination: {
        page: 1,
        number: 10,
        total: 0,
      },
      tableData: [],
      coinName: '',
      loading: true,
      checked: '',
      seeMoney: true,
      activeName: sessionStorage.getItem('tabIndex') || 'first',
      showSmallAmount: false,
      rotateIndex: null,
    };
  },
  methods: {
    ...mapActions('assets', ['fetchAllAssets', 'fetchOtcFinancial']),
    toggleRow(row, index, tableData) { // 二级表格展示与否
      this.rotateIndex = row.id;
      tableData.forEach((item) => {
        if (row.id !== item.id) this.$refs.table.toggleRowExpansion(item, false);
      });
      this.$refs.table.toggleRowExpansion(row);
    },
    expandChange(row, expand) { // 监听表格行的关闭与开启
      this.rotateIndex = expand[0]?.id || null;
    },
    isShowTxid(value) { // 是否显示Txid
      if (value) return value.substr(1, 4) !== '平台互转';
      return false;
    },
    handleJumpPage({ coinName, blockUrl, txid }) { // 跳转到相应币种页面
      if (coinName === 'USDT') {
        const hasTxid = txid.substr(0, 2) === '0x';
        if (hasTxid && Regex.IS_URL.test(blockUrl)) window.open(`${blockUrl.split(',')[1]}${txid}`);

        if (!hasTxid && Regex.IS_URL.test(blockUrl)) window.open(`${blockUrl.split(',')[0]}${txid}`);
      }
      if (coinName !== 'USDT' && Regex.IS_URL.test(blockUrl)) window.open(`${blockUrl}${txid}`);
    },
    querySearchAsync(queryString, cb) {
      const { allAssets: { userWalletList = [] } } = this;
      const restaurants = userWalletList.map(obj => ({
        value: obj.coinName,
      }));
      const results = queryString ? restaurants.filter(this.createStateFilter(queryString)) : restaurants;
      cb(results);
      // clearTimeout(this.timeout);
      // this.timeout = setTimeout(() => {
      //   cb(results);
      // }, 1000 * Math.random());
    },
    createStateFilter(queryString) {
      return state => (state.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0);
    },
    handleCancelWithdraw(id) { // 取消提币
      this.$confirm(this.$t('message[1]'), this.$t('message[2]'), { // 确认取消提币吗？ /  提示
        type: 'warning',
        confirmButtonText: this.$t('btnText[0]'), // 确定
        cancelButtonText: this.$t('btnText[1]'), // 取消
      })
        .then(() => api.cancelWithdraw(id).then(() => {
          this.getUserAssetDetails(); // 更新用户资产
          this.fetchAllAssets(); // 更新用户资产
          this.$toast(this.$t('message[3]')); // 取消提币成功
        }));
    },
    handleSelect() {
      this.getUserAssetDetails();
    },
    getUserAssetDetails() {
      sessionStorage.setItem('tabIndex', this.activeName);
      this.coinName = '';
      const { pagination: { page, number } } = this;
      this.loading = true;
      const typeList = {
        first: 1,
        second: 2,
        third: -2,
        fourth: -3,
      };
      const query = {
        page, number, type: typeList[this.activeName],
      };
      if (this.coinName) query.coinName = this.coinName;
      api.getUserAssetDetails(query).then(({ details: { data, totalCount } }) => {
        this.loading = false;
        [this.tableData, this.pagination.total] = [data, totalCount];
      }).catch(() => {
        this.loading = false;
      });
    },

  },
  watch: {
    coinName(value) {
      if (!value) this.getUserAssetDetails();
    },
    activeName: {
      handler(n, o) {
        if (n !== o) {
          this.pagination = { page: 1, number: 10, total: 0 };
          this.rotateIndex = null;
          this.tableData = [];
        }
      },
      deep: true,
      immediate: true,
    },
  },
  computed: {
    ...mapState(['moneySelect', 'coinList']),
    ...mapState('exchange', ['tradeSummaryList']),
    ...mapState('assets', ['allAssets', 'otcAssets', 'allAmountDecimal']),
    activeTitles() {
      return [
        {
          name: 'first',
          label: this.$t('title[2]'),
        }, // 充币
        {
          name: 'second',
          label: this.$t('title[3]'),
        }, // 提币
        {
          name: 'third',
          label: this.$t('title[4]'),
        }, // 划转
        {
          name: 'fourth',
          label: this.$t('title[5]'),
        }, // 其它
      ];
    },
    titleText() { // 下标title
      const { activeTitles, activeName } = this;
      return activeTitles.find(({ name }) => name === activeName)?.label || {};
    },
  },
  created() {
    this.getUserAssetDetails();
  },
};
</script>

<style lang="scss" scoped>
  .header_right_download {
    margin-left: 1080px;
    margin-top: 20px;
    z-index: 200;
  }

  .header_right_icon {
    width: 14px;
    height: 17px;
  }
  .assetManagement {
    height: 100%;
    width: 100%;
    background: rgba(243, 246, 248, 1);
    padding-top: 20px;
    margin-bottom: 60px;
    .asset-box {
      width: 1200px;
      margin: 0 auto;
    }
    .balance {
      margin-left: 100px;
      position: absolute;
    }
    .input_text {
      font-size: 12px;
      color: #1581f2;
      margin-right: 10px;
    }

    .asset_header {
      height: 60px;
      background: rgba(255, 255, 255, 1);
      width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 20px;
      margin-bottom: 20px;

      .header_left {
        p {
          font-size: 24px;
          font-family: PingFangSC-Medium, PingFang SC;
          font-weight: 500;
          color: rgba(47, 57, 68, 1);
          line-height: 24px;
        }
        label {
          font-size: 12px;
          color: #e0e0e7;
          opacity: 0.6;
        }
      }
      .header_right {
        display: flex;
        justify-content: space-between;
        .el-button--success {
          width: 110px;
          height: 36px;
          background: rgba(39, 192, 139, 1);
          border-radius: 2px;
          font-size: 16px;
          font-family: PingFangSC-Medium, PingFang SC;
          font-weight: 500;
          line-height: 16px;
          display: flex;
          align-items: center;
          justify-content: center;
          .icon-huazhuan {
            width: 16px;
            height: 16px;
            //  padding-top: 2px;
            margin-right: 5px;
          }
          &:hover {
            // background: rgba(144, 223, 195, 0.8);
            opacity: 0.8;
          }
        }
      }
    }
    .asset-content {
      width: 100%;
      background: #ffffff;
      // padding-bottom: 200px;
      padding: 0 20px 60px 20px;
      margin-bottom: 60px;
      min-height: 680px;
      .table-content {
        padding-top: 20px;
        .table-tabs {
          ::v-deep .el-tabs__nav {
            display: flex;
            .el-tabs__active-bar {
              background-color: #27c08b;
            }
          }
          ::v-deep .el-tabs__nav-wrap::after {
            height: 1px;
          }
          ::v-deep .el-tabs__item {
            font-size: 16px;
            font-family: PingFangSC-Semibold, PingFang SC;
            font-weight: 600;
            color: rgba(152, 165, 179, 1);
            line-height: 16px;
            padding: 28px 30px 28px 0;
            // margin: 0 20px;
            width: auto;
            display: flex;
            justify-content: center;
            align-items: center;
            &.is-active {
              color: #495a6c;
            }
            &:hover {
              color: #495a6c;
            }
            &:last-child {
              padding-right: 0px;
            }
          }
        }
        .table-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding-bottom: 20px;
          .left,
          .right {
            display: flex;
            // justify-content: space-between;
            align-items: center;
            .title {
              font-size: 16px;
              font-family: PingFangSC-Semibold, PingFang SC;
              font-weight: 600;
              color: #98a5b3;
              line-height: 16px;
              padding-right: 30px;
            }
            ::v-deep .el-input__inner {
              height: 26px;
              border-radius: 13px;
              width: 133px;
              // border: 1px solid rgba(238, 238, 238, 1);
              // margin-right: 30px;
            }
            ::v-deep .el-input__inner:focus {
              border-color: #27c08b;
            }
            ::v-deep .el-input__prefix {
              display: flex;
              justify-content: center;
              align-items: center;
              left: 0;
            }
            .icon-tishi {
              width: 12px;
              height: 12px;
              margin-left: 10px;
            }
          }
        }
        & ::v-deep th {
          height: 42px;
          padding: 0 !important;
          &.descending .sort-caret.descending {
            border-top-color: #27c08b !important;
          }
          &.ascending .sort-caret.ascending {
            border-bottom-color: #27c08b !important;
          }
          .sort-caret {
            border-left-width: 4px;
            border-right-width: 4px;
          }
        }
        .default {
          padding: 3px 8px;
          border-radius: 1px;
          border: 1px solid rgba(39, 192, 139, 1);
          font-size: 14px;
          font-family: PingFangSC-Regular, PingFang SC;
          font-weight: 400;
          color: rgba(39, 192, 139, 1);
          line-height: 14px;
          &:hover {
            // padding: 3px 8px;
            background: rgba(39, 192, 139, 1);
            color: rgba(255, 255, 255, 1);
          }
        }
      }
      & ::v-deep .el-loading-mask {
        background-color: #ffffff !important;
      }
    }
  }

  .el-form-item {
    margin-bottom: 10px;
  }

  .cancel-btn,
  .confirm-btn {
    border: none;
    transition: all 0.25s ease-in-out;
  }

  .confirm-btn {
    background-color: #27c08b;

    &:hover {
      background-color: #2ed89d;
    }
  }

  .cancel-btn {
    background-color: #f5f5f5;
    color: #41414c;

    &:hover {
      color: #27c08b;
    }
  }
  ::v-deep .el-tooltip__popper.is-light {
    border: 1px solid #ffffff;
  }
  ::v-deep .el-table::before {
    height: 0;
  }
  .asset-pagination {
    margin-top: 30px;
    text-align: right;
    ::v-deep .el-pagination.is-background .el-pager li:not(.disabled).active {
      background-color: #27c08b;

      &:hover {
        color: white;
      }
    }

    ::v-deep .el-pagination.is-background .el-pager li:not(.disabled):hover {
      color: #27c08b;
    }

    ::v-deep .el-pagination {
      font-weight: normal !important;
    }
  }

  ::v-deep .el-table__expanded-cell {
    padding: 0;
    border-radius: 4px;
    border: 1px solid #ECECED;
  }
  ::v-deep .popper__arrow::before ,::v-deep .popper__arrow::after{
    content:"";
    width:0;
    height:0;
    position:absolute;
    right: 23px;
    top: -7px;
    border-radius: 2px;
    border-left:solid 7px transparent;
    border-bottom:solid 7px #8c8a8a;
    border-right:solid 7px transparent;
  }
  ::v-deep .popper__arrow::after{
    border-bottom:solid 7px white;
  }
  ::v-deep .el-table__header,::v-deep .el-table .cell{
    white-space:nowrap;
    overflow:hidden;
  }
</style>
