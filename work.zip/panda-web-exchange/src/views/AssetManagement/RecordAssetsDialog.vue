<i18n>
  zh-CN:
   title:
    - 账单下载工具
   placeholder:
    - 充币记录
    - 开始日期
    - 结束日期
   btn:
    - 立即下载
   selectOption:
    - 充币记录
    - 提币记录
   timeMessage:
    - 请选择时间
    - 开始时间不能大于结束时间
    - 账单导出时间不能超过6个月
  en-US:
   title:
    - 'Bill Download Tool'
   placeholder:
    - 'Deposit History'
    - 'Start Date'
    - 'End Date'
   btn:
    - 'Download'
   selectOption:
    - 'Deposit History'
    - 'Withdraw History'
   timeMessage:
    - 'Please select a time'
    - 'The start time cannot be greater than the end time'
    - 'Bill export time should not exceed 6 months'
  zh-TW:
   title:
    - 賬單下載工具
   placeholder:
    - 充幣記錄
    - 開始日期
    - 結束日期
   btn:
    - 立即下載
   selectOption:
    - 充幣記錄
    - 提幣記錄
   timeMessage:
    - 請選擇時間
    - 開始時間不能大於結束時間
    - 賬單導出時間不能超過6個月
  ko-KR:
   title:
    - '청구서 다운로드 도구'
   placeholder:
    - '입금 내역'
    - '시작일'
    - '종료일'
   btn:
    - '다운로드'
   selectOption:
    - '입금 기록기록'
    - '출금 기록기록'
   timeMessage:
    - '시간을 선택하십시오'
    - '시작 시간은 종료 시간보다 클 수 없습니다'
    - '빌 수출 시간은 6 개월을 초과하지 않아야합니다'
</i18n>
<template>
  <el-dialog
    :title="$t('title[0]')"
    :visible.sync="dialogVisible"
    :close-on-click-modal="false"
    custom-class="record-assets-dialog">
    <!--  账单下载工具  -->
    <el-divider class="el-divider--horizontal" />
    <div class="dialog_content">
      <el-select v-model="searchList.recording" :placeholder="$t('placeholder[0]')">
      <!--    充币记录    -->
        <el-option
          v-for="item in selectOptions"
          :key="item.value"
          :label="item.label"
          :value="item.value">
          <span class="text-size-12">{{item.label}}</span>
        </el-option>
      </el-select>
      <el-date-picker
        type="datetime"
        value-format="timestamp"
        v-model="searchList.beginTime"
        :picker-options="pickerOptions"
        :placeholder="$t('placeholder[1]')">
        <!--    开始日期    -->
      </el-date-picker>
      <el-date-picker
        v-model="searchList.endTime"
        type="datetime"
        :picker-options="pickerOptions"
        :placeholder="$t('placeholder[2]')"
        value-format="timestamp">
        <!--    结束日期    -->
      </el-date-picker>
      <el-button type="success" @click.stop="handleDownload">{{$t('btn[0]')}}</el-button>
      <!--    立即下载    -->
    </div>
  </el-dialog>
</template>

<script>
import api from '../../api/apiModule_1';
import { handleDownloadFile } from '../../utils/common';

export default {
  name: 'RecordAssetsDialog',
  data() {
    const beforeDay = new Date() - 1000 * 3600 * 24; // 中间错开1天时间
    return {
      dialogVisible: false,
      searchList: { // 搜索列表
        recording: this.$t('selectOption[0]'),
        beginTime: beforeDay,
        endTime: new Date().getTime(),
      },
      pickerOptions: { // 半年前的时间不能选
        disabledDate(time) {
          return time.getTime() > Date.now();
          // return time.getTime() < isHaifYear || time.getTime() > Date.now();
        },
      },
    };
  },
  methods: {
    handleShowDialog() {
      this.dialogVisible = true;
      const { activeName } = this.$parent;
      this.searchList.recording = activeName === 'first' ? this.$t('selectOption[0]') : this.$t('selectOption[1]');
    },
    handleDownload() {
      const { type, searchList: { beginTime, endTime } } = this;
      const isHaifYear = 1000 * 3600 * 24 * 180; // 半年

      if (beginTime < (endTime - isHaifYear)) {
        this.$message.warning(this.$t('timeMessage[2]'));
        return false;
      }

      if (beginTime && endTime && endTime > beginTime) {
        api.tradeExport({
          type,
          beginTime,
          endTime,
        }).then((res) => { handleDownloadFile(res); });
      }

      if (!beginTime || !endTime) this.$message.warning(this.$t('timeMessage[0]'));

      if (endTime < beginTime) {
        this.searchList.beginTime = '';
        this.searchList.endTime = '';
        this.$message.warning(this.$t('timeMessage[1]'));
      }
      return null;
    },
  },
  computed: {
    selectOptions() {
      return [{
        value: '1',
        label: this.$t('selectOption[0]'), // 充币记录
      }, {
        value: '2',
        label: this.$t('selectOption[1]'), // 提币记录
      }];
    },
    type() { // 判断哪个tab下载
      const { selectOptions, searchList: { recording } } = this;
      return selectOptions.find(({ label }) => label === recording)?.value || recording;
    },
  },
};
</script>

<style lang="scss" scoped>
  .el-divider--horizontal {
    margin-top: 0;
    margin-bottom: 20px;
    background: #EEEEEE;
  }

  .dialog_content {
    margin-bottom: 63px;
  }

  ::v-deep .el-dialog__title {
    font-size: 16px;
    color: #41414c;
  }

  ::v-deep .el-select {
    width: 150px;
    margin-right: 20px;
  }

  ::v-deep .el-dialog__body {
    font-size: 12px;
  }

  ::v-deep .el-date-editor {
    width: 195px;
    margin-right: 20px;
  }

  ::v-deep .el-input--suffix .el-input__inner {
    padding-right: 10px;
    font-size: 12px;
  }

  ::v-deep .el-button--success {
    width: 100px;
    background-color: #27c08b;
    border: 0;
    font-size: 12px;

    &:hover{
      background-color: #32dba0;
    }
  }
</style>
