<i18n>
  zh-CN:
   title:
    - 提币
    - 提币地址
    - 链名称
    - 提币数量
    - '可提现额度：'
    - '，冻结额度：'
    - 手续费
    - 安全验证
    - '提币标签'
    - '（填写错误可能导致资产损失，请仔细核对）'
    - '请填写提币标签'
    - '无标签'
   label:
    - 选择币种
    - 提币时间
    - 币种
    - 提币数量
    - 状态
    - 操作
   placeholder:
    - 请选择
   coinBtnText:
    - 全部提出
    - '{name}提币记录'
    - 全部提币记录
    - 提交
    - 去设置
    - '详情'
    - '地址'
    - '标签'
    - '撤销'
   dialogText:
    - '系统检测到您账号安全项未设置，为了账户安全，请前往设置'
    - 手机绑定
    - 已绑定
    - 未绑定
    - 资金密码
    - 已设置
    - 未设置
    - 基础信息认证
    - 已认证
    - 未认证
   message:
    - 请输入提币地址
    - 地址输入不正确
    - 请输入提币备注
    - '当前提币数量不得低于{number}{name}'
    - '当前提币数量不得大于{number}{name}'
    - '当前提币数量不得大于可用余额{number}'
    - 手续费不能为空
    - '确认取消提币吗？'
    - 提示
    - 取消提币成功
    - 提币申请发起成功
   status:
    - 取消提币
    - 无
   confirmText:
    - '通常情况下，{value}提币需要填写标签，遗漏可能造成资产损失。'
    - 注意
  en-US:
   title:
    - Withdraw
    - 'Withdrawal address'
    - 'Chain name'
    - Amount
    - 'Withdrawal limit：'
    - '，Freezing amount:'
    - Fee
    - 'Safety verification'
    - 'Currency Tags'
    - '(wrong filling may lead to asset loss, please check carefully)'
    - 'Please fill in the withdrawal label'
    - 'No label'
   label:
    - 'Coin'
    - Time
    - Coin
    - Withdrawal Amount
    - Status
    - Operation
   placeholder:
    - 'Please Choose'
   coinBtnText:
    - 'All'
    - '{name} Withdrawals History'
    - 'All Withdrawal History'
    - Submit
    - 'Go to set'
    - 'Detail'
    - 'Address'
    - 'Label'
    - 'Revoke'
   dialogText:
    - 'The system has detected that your account security item is not set. For account security, please go to the settings.'
    - 'Phone binding'
    - Bind
    - Unbound
    - 'Fund password'
    - 'Setted'
    - 'Not set'
    - 'Basic information authentication'
    - Verified
    - 'Not certified'
   message:
    - 'Please enter the withdrawal address'
    - 'Address input is incorrect'
    - 'Please enter a withdrawal note'
    - 'Amount to withdraw must be at least {number}{name}'
    - 'Amount to withdraw must be less than {number}{name}'
    - 'Withdrawal amount exceeds available amount {number}'
    - 'Fee cannot be empty'
    - 'Confirm cancel withdrawal？'
    - Prompt
    - 'Cancel withdrawal success'
    - 'The withdrawal of the application is successful'
   status:
    - Cancel
    - None
   confirmText:
    - 'Under normal circumstances, {value} withdrawals need to fill in tags, Omitting the tag will lead to the loss of funds!'
    - 'Notice'
  zh-TW:
   title:
    - 提幣
    - 提幣地址
    - 鏈名稱
    - 提幣數量
    - '可提現額度：'
    - '，凍結額度：'
    - 手續費
    - 安全驗證
    - '提幣標籤'
    - '（填寫錯誤可能導致資產損失，請仔細核對）'
    - '請填寫提幣標籤'
    - '無標籤'
   label:
    - 選擇幣種
    - 提幣時間
    - 幣種
    - 提幣數量
    - 狀態
    - 操作
   placeholder:
    - 請選擇
   coinBtnText:
    - 全部提出
    - '{name}提幣記錄'
    - 全部提幣記錄
    - 提交
    - 去設置
    - '詳情'
    - '地址'
    - '標籤'
    - '撤銷'
   dialogText:
    - '系統檢測到您帳號安全項未設置，為了帳戶安全，請前往設置'
    - 手機綁定
    - 已綁定
    - 未綁定
    - 資金密碼
    - 已設置
    - 未設置
    - 基礎實名認證
    - 已認證
    - 未認證
   message:
    - 請輸入提幣地址
    - 地址輸入不正確
    - 請輸入提幣備註
    - '當前提幣數量不得低於{number}{name}'
    - '當前提幣數量不得大於{number}{name}'
    - '當前提幣數量不得大於可用餘額{number}'
    - 手續費不能為空
    - '確認取消提幣嗎？'
    - 提示
    - 取消提幣成功
    - 提幣申請發起成功
   status:
    - 取消提幣
    - 無
   confirmText:
    - '通常情況下，{value}提幣需要填寫標籤，遺漏可能造成資產損失。'
    - 注意
  ko-KR:
   title:
    - '출금'
    - '출금 주소'
    - '체인 이름'
    - '출금 수량'
    - '주문가능：'
    - '，냉동 량 :'
    - '수수료 안내'
    - '보안 인증'
    - '지폐 태그'
    - '(오류를 작성하면 자산 손실을 초래할 수 있으니 자세히 체크해 보세요)'
    - '지폐 태그 를 기입하시오'
    - '태그 없음'
   label:
    - '코인명'
    - 시간
    - 코인명
    - 수량
    - 상태
    - 작업
   placeholder:
    - '선택하세요'
   coinBtnText:
    - '모든 출금'
    - '{name}출금기록'
    - '전체 출금 기록'
    - '제출'
    - '세트로 이동'
    - '세부 정보'
    - '주소'
    - '라벨'
    - '철회하다'
   dialogText:
    - '시스템에서 계정 보안 항목이 설정되지 않은 것을 감지했습니다. 계정 보안을 위해 설정으로 이동하십시오.'
    - '전화 바인딩'
    - '바인드'
    - '언 바운드'
    - '자금 비밀번호'
    - '세트'
    - '미 설정'
    - '기본 정보 인증'
    - '인증'
    - '미 인증'
   message:
    - '출금 주소 입력하세요'
    - '출금 주소 잘못되었습니다'
    - '출금 메모를 입력하십시오'
    - '전제 조건 수가 다음보다 낮을 수없는 경우{number}{name}'
    - '전제 조건 수가 다음보다 클 수없는 경우{number}{name}'
    - '전제 조건이 사용 가능한 잔액을 초과 할 수없는 경우{number}'
    - '수수료는 비워 둘 수 없습니다'
    - '탈퇴 취소를 확인 하시겠습니까?'
    - '프롬프트'
    - '인출 성공 취소'
    - '인출 요청이 성공적으로 시작되었습니다'
   status:
    - 취소 출금
    - 아니요
   confirmText:
    - '정상적인 상황에서 {value} 인출은 태그를 작성해야합니다.주소 태그가 누락되면 자금 손실로 이어집니다.'
    - '주의'
</i18n>
<template>
  <div class="multi" id="withdrawCoin">
    <!-- <el-alert
        title="2019-07-26, 10:09:55您的账户于异地登录地点：成都,CNIP地址：182.148.53.206若非本人操作，请及时更改登录密码并联系客服"
        type="warning"
        center
        :closable="false"
        show-icon>
    </el-alert> -->
    <div class="multi_content">
      <div class="multi_title margin-bottom-5">{{$t('title[0]')}}</div>
      <!-- 提币  -->
      <!--<div class="multi_prompt">
          <i class="el-icon-warning prompt_color"></i>
          <p>您的提币操作有可能触发客服审核，若有来自01056592189，01086394365的电话，请您注意接听，进行操作确认。提币过程中，可能需要高级视频认证审核，请留意下方提币记录中的状态提醒</p>
      </div>-->
      <el-form
        :model="withdrawForm"
        :rules="withdrawRules"
        ref="withdrawForm"
        class="form-block"
        :validate-on-rule-change="false"
        :hide-required-asterisk="true">
        <el-form-item :label="$t('label[0]')" prop="coinId" class="width-half">
          <el-select v-model="withdrawForm.coinId" :placeholder="$t('label[0]')">
            <!-- 选择币种  / 选择币种 -->
            <el-option
              v-for="(coin, index) in coinList"
              :key="`coin-select-${index}`"
              :label="coin.coinType.name"
              :value="coin.coinType.id"
              :disabled="!coin.coinType.isWithdraw"
            />
          </el-select>
        </el-form-item>

        <el-form-item :label="$t('title[1]')" prop="address" class="width-half">
          <!-- 提币地址 -->
          <el-input v-model="withdrawForm.address" />
        </el-form-item>

        <el-form-item
          :label="$t('title[2]')"
          v-if="currentCoin.coinType.name === 'USDT'"
          class="width-half"
        >
          <!-- 链名称 -->
          <el-select v-model="chainSelect" :placeholder="$t('placeholder[0]')">
            <!-- 请选择 -->
            <el-option
              v-for="(coin, index) in coinChain"
              :key="`coinChain-select-${index}`"
              :label="coin"
              :value="coin"
            />
          </el-select>
        </el-form-item>
        <el-form-item
          v-if="isShowTag"
          prop="memo"
          class="width-half">
          <!-- 提币标签 -->
          <div class="flex-justify-content-space-between currency-tags">
            <div><!--提币标签-->{{$t('title[8]')}} <span><!--（填写错误可能导致资产损失，请仔细核对）-->{{$t('title[9]')}}</span></div>
            <el-checkbox v-model="checked" @change="withdrawForm.memo = ''"><!--无标签-->{{$t('title[11]')}}</el-checkbox>
          </div>
          <el-input v-model="withdrawForm.memo" :disabled="showTag" :placeholder="$t('title[10]')"/><!--请填写提币标签-->
        </el-form-item>

        <el-form-item prop="withdrawAmount" class="width-half">
          <template #label>
            <div class="flex-align-items-center flex-justify-content-space-between">
              <p>{{$t('title[3]')}}</p>
              <!-- 提币数量  -->
              <p>
                {{$t('title[4]')}}
                <!-- 可提现额度：  -->
                <span
                  class="text-color-blue text-size-12"
                >{{toFixed(currentAssets.total, currentCoin.coinType.withdrawDecimal)}}</span>
                {{$t('title[5]')}}
                <!-- ，冻结额度：  -->
                <span
                  class="text-color-grey text-size-12"
                >{{toFixed(currentAssets.frozen, currentCoin.coinType.amountDecimal)}}</span>
              </p>
            </div>
          </template>
          <el-input
            v-model="withdrawForm.withdrawAmount"
            v-only-number:[currentCoin.coinType.withdrawDecimal]="withdrawForm.withdrawAmount"
          >
            <template #suffix>
              <span>{{currentCoin.coinType.name}}</span>
              <span
                class="text-color-blue margin-left-10 cursor-pointer"
                @click.stop="withdrawForm.withdrawAmount = toFixed(currentAssets.total, currentCoin.coinType.withdrawDecimal)"
              >{{$t('coinBtnText[0]')}}</span>
              <!-- 全部提出  -->
            </template>
          </el-input>
        </el-form-item>

        <el-form-item :label="$t('title[6]')" class="width-half">
          <!-- 手续费  -->
          <el-input :value="toFixed(withdrawForm.btcFees,currentCoin.coinType.withdrawDecimal)"  :disabled="true">
            <template #suffix>{{currentCoin.coinType.name}}</template>
          </el-input>
        </el-form-item>
        <el-row>
          <el-col
            :span="24"
            v-html="currentCoin.coinType.withdrawInfo"
            class="coin-info text-size-12"
          />
        </el-row>
        <el-row :gutter="20" class="flex-justify-content-center">
          <el-button
            type="success"
            @click.prevent="handleSubmit"
            class="submit-btn"
          >{{$t('coinBtnText[3]')}}</el-button>
          <!-- 提交  -->
        </el-row>
      </el-form>
      <div class="content_table">
        <div class="table_tag">
          <div
            :class="['tag_left', 'cursor-pointer', tabIndex === 2 && 'tag_left_active']"
            @click.stop="tabIndex = 2"
          >{{$t('coinBtnText[1]', {name: currentCoin.coinType.name})}}</div>
          <!-- 提币记录  -->
          <div
            :class="['tag_left', 'cursor-pointer', tabIndex === 3 && 'tag_left_active']"
            @click.stop="tabIndex = 3"
          >{{$t('coinBtnText[2]')}}</div>
          <!-- 全部提币记录  -->
          <!--<i class="el-icon-info tab_info"></i>-->
        </div>
        <el-table
          :data="tableData"
          ref="table"
          @expand-change="expandChange"
          :cell-style="{fontSize: '12px',borderBottom: 'none', color: '#41414c'}"
          :header-cell-style="{background:'#f8f8f8',color:'rgba(65, 65, 76, 0.6) !important',height: '40px', fontSize: '12px'}"
        >
          width="100%">
          :header-cell-style="{background:'#f8f8f8',color:'rgba(65, 65, 76, 0.6) !important',height: '40px', fontSize: '12px'}">
          <el-table-column
            prop="createTime"
            label-class-name="text-align-left text-weight-4"
            class-name="text-align-left text-weight-4"
            :label="$t('label[1]')"
            width="auto"
          >
            <!-- 提币时间  -->
            <template slot-scope="{row}">
              <p class="text-align-left">{{row.createTime | timeStampToDate}}</p>
            </template>
          </el-table-column>
          <el-table-column
            width="auto"
            label-class-name="text-weight-4"
            class-name="text-weight-4"
            prop="fcoinname"
            :label="$t('label[2]')"
          />
          <!-- 币种  -->
          <!--<el-table-column
              width="auto"
              label-class-name="text-weight-4"
              class-name="text-weight-4"
              prop="withdrawAddress"
              label="提币地址">
          </el-table-column>-->
          <el-table-column
            width="auto"
            label-class-name="text-weight-4"
            class-name="text-weight-4"
            prop="famount"
            :label="$t('label[3]')"
          >
            <!-- 提币数量  -->
            <template slot-scope="{row}">{{toFixed(row.famount, row.decimal)}}</template>
          </el-table-column>
          <el-table-column
            label-class-name="text-weight-4"
            class-name="text-weight-4"
            width="auto"
            prop="ffees"
            :label="$t('title[6]')"
          >
            <template slot-scope="{row}">{{toFixed(row.ffees, row.decimal)}}</template>
          </el-table-column>
          <!-- 手续费  -->
          <!--<el-table-column
              width="auto"
              label-class-name="text-weight-4"
              class-name="text-weight-4"
              prop="ffees"
              label="描述">
              <template>-&#45;&#45;</template>
          </el-table-column>-->
          <el-table-column
            width="auto"
            prop="fstatus"
            label-class-name="text-align-left text-weight-4"
            class-name="text-align-left text-weight-4"
            :label="$t('label[4]')"
          >
            <!-- 状态  -->
            <template slot-scope="{row}">
              {{row.fstatus | withdrawalStatus}}
              <span class="revoke cursor-pointer" v-if="row.fstatus === 1" @click="handleCancelWithdraw({id: row.id})">{{$t('coinBtnText[8]')}}<!--撤销--></span>
            </template>

          </el-table-column>

          <el-table-column
            label-class-name="text-align-right text-weight-4"
            class-name="text-align-right text-weight-4"
            :label="$t('label[5]')">
            <!--    操作    -->
            <template slot-scope="scope">
              <div
                class="flex-justify-content-flex-end flex-align-items-center cursor-pointer text-color-blue"
                @click.stop="toggleRow(scope.row, scope.$index, tableData)">
                {{$t('coinBtnText[5]')}}
                <svg :class="['icon', 'table_icon']" :style="{transform: rotateIndex === scope.row.id ? 'rotate(270deg)' : 'rotate(90deg)'}"  aria-hidden="true">
                  <use xlink:href="#icon-jinru" />
                </svg>
              </div>
              <!--    详情    -->
            </template>
          </el-table-column>
          <el-table-column
            width="1"
            type="expand">
            <template slot-scope="scope">
              <div class="form_layout">
                <div class="popper__arrow"></div>
                <div class="form_layout_content flex-justify-content-space-between">
                  <p><!--地址：-->{{$t('coinBtnText[6]')}}：</p>
                  <label class="text-size-12">{{scope.row.withdrawAddress}}</label>
                </div>
                <div class="form_layout_content flex-justify-content-space-between" v-if="scope.row.labelCoinAddress">
                  <p><!--标签-->{{$t('coinBtnText[7]')}}：</p>
                  <label class="text-size-12">{{scope.row.labelCoinAddress}}</label>
                </div>
                <div class="form_layout_content flex-justify-content-space-between" v-if="isShowTxid(scope.row.txid)">
                  <p>Txid：</p>
                  <p class="cursor-pointer" @click.stop="handleJumpPage(scope.row)">{{scope.row.txid || '--'}}</p>
                </div>
              </div>
            </template>
          </el-table-column>
          <template #empty>
            <empty />
          </template>
        </el-table>
        <el-pagination
          layout="prev, pager, next"
          class="margin-top-10"
          :total="pagination.total"
          hide-on-single-page
          :current-page.sync="pagination.pageIndex"
          :page-size="pagination.pageSize"
        />
      </div>
    </div>
    <WithdrawCoinDialog
      ref="withdrawCoinDialog"
      :withdrawData="withdrawForm"
      @onSubmit="handleWithdraw"
    />
    <el-dialog
      :title="$t('title[7]')"
      :close-on-click-modal="false"
      custom-class="custom-dialog"
      :visible.sync="dialogShow">
      <!-- 安全验证  -->
      <el-alert type="warning" :closable="false" show-icon>
        <template #title>
          <p class="text-align-center text-size-12">{{$t('dialogText[0]')}}</p>
          <!-- 系统检测到您账号安全项未设置，为了账户安全，请前往设置  -->
        </template>
      </el-alert>
      <div class="flex-justify-content-space-between flex-align-items-center dialog_layout">
        <p>{{$t('dialogText[1]')}}</p>
        <!-- 手机绑定  -->
        <P
          :class="[userBindInfo.isPhoneBind ? 'dialog_desc_default' : 'dialog_desc']"
        >{{userBindInfo.isPhoneBind ? $t('dialogText[2]') : $t('dialogText[3]')}}</P>
        <!-- 已绑定  / 未绑定 -->
      </div>
      <div class="flex-justify-content-space-between flex-align-items-center dialog_layout">
        <p>{{$t('dialogText[4]')}}</p>
        <!-- 资金密码  -->
        <P
          :class="[userBindInfo.isTradePasswordSet ? 'dialog_desc_default' : 'dialog_desc']"
        >{{userBindInfo.isTradePasswordSet ? $t('dialogText[5]') : $t('dialogText[6]')}}</P>
        <!-- 已设置 / 未设置 -->
      </div>
      <div class="flex-justify-content-space-between flex-align-items-center dialog_layout">
        <p>{{$t('dialogText[7]')}}</p>
        <!-- 基础信息认证  -->
        <P
          :class="[userBindInfo.isRealAuth ? 'dialog_desc_default' : 'dialog_desc']"
        >{{userBindInfo.isRealAuth ? $t('dialogText[8]') : $t('dialogText[9]')}}</P>
        <!-- 已认证 / 未认证  -->
      </div>
      <el-row :gutter="20" class="margin-bottom-10">
        <el-col :span="12">
          <el-button
            type="info"
            class="width-screen"
            @click.stop="dialogShow = false"
          >{{$i18n.t('btnText[1]')}}</el-button>
          <!-- 取消  -->
        </el-col>
        <el-col :span="12">
          <el-button
            type="success"
            class="width-screen"
            @click.stop="$router.push('/userManagement')">
            {{$t('coinBtnText[4]')}}
          </el-button>
          <!-- 去设置  -->
        </el-col>
      </el-row>
    </el-dialog>
  </div>
</template>

<script>
import { mapState, mapActions } from '../../utils/common';
import { PagingDefaultConf, Regex } from '../../utils/constant';
import api from '../../api/asset';
import fill from '../../plugins/filters';
import WithdrawCoinDialog from './WithdrawCoinDialog.vue';

export default {
  name: 'withdrawCoin', // 多链
  components: { WithdrawCoinDialog },
  data() {
    const { id } = this.$route.query;
    return {
      pagination: {
        ...PagingDefaultConf,
        total: 0,
      },
      tabIndex: 2, // tab index
      withdrawForm: { // 页面表单
        coinId: Number(id),
        address: '',
        memo: '', // 提币标签
        withdrawAmount: 0,
        btcFees: 0,
      },
      tableData: [],
      chainSelect: 'USDT-ERC20',
      dialogShow: false,
      userBindInfo: {}, // 用户认证信息
      rotateIndex: null,
      checked: false, // 是否选中标签
      showTag: false, // 点击【确定】选中，【提币标签】不可填写
      isShowTag: false,
    };
  },
  watch: {
    checked() {
      // eslint-disable-next-line no-unused-expressions
      this.checked ? this.open() : this.showTag = false;
    },
    currentCoin: {
      handler(n, o) {
        if (JSON.stringify(n) !== JSON.stringify(o)) { // 对象不能直接用于对比
          this.tabIndex = 2; // 重置tabIndex
          process.nextTick(() => {
            this.getCoinOperation();
            this.handleResetWithdrawForm();
            this.$refs.withdrawForm.clearValidate(); // 移除校验信息
          });
        }
      },
      deep: true,
      immediate: true,
    },
    tabIndex: {
      handler(n, o) {
        if (n !== o) {
          this.pagination = { // 重置分页
            ...PagingDefaultConf,
            total: 0,
          };
          process.nextTick(this[n === 2 ? 'getCoinOperation' : 'getCoinOperationAll']);
          this.rotateIndex = null;
        }
      },
      deep: true,
      immediate: true,
    },
    'pagination.pageIndex': {
      handler(n, o) {
        if (n !== o) {
          if (this.tabIndex === 2) this.getCoinOperation();
          if (this.tabIndex === 3) this.getCoinOperationAll();
        }
      },
      deep: true,
      immediate: true,
    },
    'withdrawForm.coinId': {
      handler(n, o) {
        if (n !== o) this.fetchRechargeAddress();
      },
      deep: true,
      immediate: true,
    },
  },
  computed: {
    ...mapState(['coinList', 'userInfo']),
    ...mapState('assets', ['allAssets']),
    currentCoin() {
      const { withdrawForm: { coinId }, coinList } = this;
      return coinList.find(coin => coin.coinType.id === coinId) || { setting: {}, coinType: {} };
    },
    coinChain() {
      // const { coinList } = this;
      return ['USDT-ERC20'];
    },
    currentAssets() { // 用户当前币种的资产
      const { withdrawForm: { coinId }, allAssets: { userWalletList } } = this;
      return userWalletList ?.find(({ coinId: _coinId }) => _coinId === coinId) || {};
    },
    withdrawRules() {
      const { withdrawForm: { coinId }, currentCoin: { setting, coinType }, currentAssets } = this;
      const available = currentAssets.total;
      const errAddress = this.$t('message[1]');
      const withdrawMinText = this.$t('message[3]', { number: this.toFixed(setting.withdrawMin, coinType.withdrawDecimal), name: coinType.name });
      const withdrawMaxText = this.$t('message[4]', { number: this.toFixed(setting.withdrawMax, coinType.withdrawDecimal), name: coinType.name });
      const balanceText = this.$t('message[5]', { number: available, name: coinType.name });
      const tag = this.$t('title[10]');
      return { // 输入验证
        address: [
          { required: true, message: this.$t('message[0]'), trigger: 'blur' }, // 请输入提币地址
          {
            validator(rule, value, callback) {
              api.coinCheckAddress({ coinId, address: value }).then(r => (r ? callback() : callback(errAddress))); // 地址输入不正确
            },
            trigger: 'blur',
          },
        ],
        /* memo: [
          { required: true, message: this.$t('message[2]'), trigger: 'blur' }, // 请输入提币备注
        ], */
        memo: [
          { required: !this.showTag, message: !this.showTag && tag, trigger: 'blur' }, // 请输入提币标签
        ],
        withdrawAmount: [
          {
            validator(rule, value, callback) {
              if (value < setting.withdrawMin) return callback(withdrawMinText); // 当前提币数量不得低于
              if (value > setting.withdrawMax) return callback(withdrawMaxText); // 当前提币数量不得大于
              if (value > available) return callback(balanceText); // 当前提币数量不得大于可用余额:
              return callback();
            },
            trigger: 'blur',
          },
        ],
        btcFees: [
          { required: true, message: this.$t('message[6]'), trigger: 'blur' }, // 手续费不能为空
        ],
      };
    },
  },
  methods: {
    ...mapActions('assets', ['fetchAllAssets']),
    toggleRow(row, index, tableData) { // 二级表格展示与否
      this.rotateIndex = row.id;
      tableData.forEach((item) => {
        if (row.id !== item.id) this.$refs.table.toggleRowExpansion(item, false);
      });
      this.$refs.table.toggleRowExpansion(row);
    },
    expandChange(row, expand) { // 监听表格行的关闭与开启
      this.rotateIndex = expand[0]?.id || null;
    },
    isShowTxid(value) { // 是否显示Txid
      if (value) return value.substr(1, 4) !== '平台互转';
      return false;
    },
    handleJumpPage({ fcoinname, blockUrl, txid }) { // 跳转到相应币种页面
      if (fcoinname === 'USDT') {
        const hasTxid = txid.substr(0, 2) === '0x';
        if (hasTxid && Regex.IS_URL.test(blockUrl)) window.open(`${blockUrl.split(',')[1]}${txid}`);

        if (!hasTxid && Regex.IS_URL.test(blockUrl)) window.open(`${blockUrl.split(',')[0]}${txid}`);
      }
      if (fcoinname !== 'USDT' && Regex.IS_URL.test(blockUrl)) window.open(`${blockUrl}${txid}`);
    },
    open() {
      this.$confirm(this.$t('confirmText[0]', { value: this.currentCoin.coinType.name }), this.$t('confirmText[1]'), {
        confirmButtonText: this.$t('btnText[0]'), // 确定
        cancelButtonText: this.$t('btnText[1]'), // 取消
        type: 'warning',
      }).then(() => {
        this.showTag = true;
      }).catch(() => {
        this.checked = false;
      });
    },
    getCoinOperation() {
      const { withdrawForm: { coinId }, pagination: { pageIndex: pageNum, pageSize } } = this;
      api.coinOperation({
        coinId, pageNum, pageSize, type: 2,
      }).then(({ data, totalRows }) => {
        [this.tableData, this.pagination.total] = [data, totalRows];
      });
    },
    handleCancelWithdraw(id) { // 取消提币
      const { tabIndex } = this;
      this.$confirm(this.$t('message[7]'), this.$t('message[8]'), { // '确认取消提币吗？'
        type: 'warning',
        confirmButtonText: this.$t('btnText[0]'), // 确定
        cancelButtonText: this.$t('btnText[1]'), // 取消
      })
        .then(() => api.cancelWithdraw(id)
          .then(() => {
            this[tabIndex === 2 ? 'getCoinOperation' : 'getCoinOperationAll'](); // 更新订单状态
            this.fetchAllAssets(); // 更新用户资产
            this.$toast(this.$t('message[9]')); // 取消提币成功
          }));
    },
    getCoinOperationAll() {
      const { pagination: { pageIndex: pageNum, pageSize } } = this;
      api.coinOperationAll({
        pageNum, pageSize, type: 2,
      }).then(({ data, totalRows }) => {
        [this.tableData, this.pagination.total] = [data, totalRows];
      });
    },
    handleResetWithdrawForm() { // 重置提币表单
      const { withdrawForm: { coinId }, currentCoin } = this;
      this.withdrawForm = {
        coinId,
        address: '',
        memo: '',
        withdrawAmount: 0,
        btcFees: currentCoin.setting.withdrawFee,
      };
    },
    handleSubmit() { // 提币提交
      // this.dialogShow = true;
      this.$refs.withdrawForm.validate((valid) => {
        if (valid) {
          const { userBindInfo: { isRealAuth, isPhoneBind, isTradePasswordSet } } = this;
          this.dialogShow = !isRealAuth || !isPhoneBind || !isTradePasswordSet;
          this.$refs.withdrawCoinDialog.dialogVisible = !this.dialogShow && valid;
        }
      });
    },
    handleWithdraw({
      email, google, phone, password,
    }) {
      const { withdrawForm, tabIndex } = this;
      api.coinWithdraw(Object.assign({
        tradePwd: password, googleCode: google, phoneCode: phone, emailCode: email,
      }, withdrawForm)).then(() => {
        this.$toast(this.$t('message[10]')); // 提币申请发起成功
        this[tabIndex === 2 ? 'getCoinOperation' : 'getCoinOperationAll']();
        this.fetchAllAssets();
        this.handleResetWithdrawForm();
        this.$refs.withdrawCoinDialog.handleResetSecForm();
        this.$refs.withdrawCoinDialog.dialogVisible = false;
      });
    },
    toFixed(...arg) {
      return fill.filters.toFixed(...arg);
    },
    fetchOtcCheckRealAuth() { // 获取用户认证信息
      return api.otcCheckRealAuth().then((res) => {
        this.userBindInfo = res;
      });
    },
    fetchRechargeAddress() {
      const { withdrawForm: { coinId } } = this;
      return api.coinList().then((data) => {
        this.isShowTag = Boolean(data.find(({ coinType: { id } }) => id === coinId)?.coinType.isLabelCoin);
      });
    },
  },
  created() {
    this.fetchRechargeAddress();
    this.fetchOtcCheckRealAuth();
  },
};
</script>

<style lang="scss" scoped>
.dialog_desc_default {
  color: #999999;
}

.dialog_desc {
  color: #2196f3;
}

::v-deep .el-button--info {
  height: 38px;
}

::v-deep .el-button--success {
  background-color: #27c08b;
  height: 38px;

  &:hover {
    background-color: #32dba0;
  }
}

.dialog_layout {
  height: 40px;
  background-color: #f8f8f8;
  border-radius: 2px;
  margin-bottom: 20px;
  padding: 0 10px;
  font-size: 14px;
}

.dialog_title {
  font-size: 14px;
  margin-bottom: 30px;
}

::v-deep .el-dialog__title {
  font-size: 16px;
}

::v-deep .el-icon-close {
  margin-top: 10px;
}

#withdrawCoin {
  padding-bottom: 123px;
}

.el-alert {
  margin: 20px 0;
}

.multi {
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  .coin_notice {
    width: 100%;
    height: 32px;
    background: #e5c9c9;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 12px;
    color: #27c08b;
    .notice_color {
      margin-right: 10px;
      height: 12px;
      width: 12px;
      color: #c54949;
    }
  }
  .multi_content {
    width: 71%;

    .multi_title {
      padding-top: 40px;
      font-size: 16px;
      color: #41414c;
      border-bottom: 1px solid #dddddd;
      padding-bottom: 10px;
    }
    .multi_prompt {
      background: #dff3e0;
      margin-top: 10px;
      margin-bottom: 10px;
      border-radius: 4px;
      flex-direction: row;
      height: 55px;
      display: flex;
      justify-content: center;
      align-items: center;

      .prompt_color {
        margin-left: 14px;
        margin-right: 5px;
        width: 14px;
        height: 14px;
        color: #64af68;
      }
      p {
        font-size: 12px;
        color: #64af68;
        line-height: 22px;
      }
    }
    .content_table {
      margin-top: 70px;
      .table_tag {
        display: flex;
        flex-direction: row;
        align-items: center;
        font-size: 16px;
        color: #41414c;
        border-bottom: 1px solid #dddddd;
        .tag_left {
          height: 36px;
          line-height: 36px;
          text-align: center;
          margin-right: 20px;
        }
        .tag_left:nth-child(2) {
          margin-right: 0;
        }
        .tag_left_active {
          border-bottom: 2px solid #27c08b;
        }
        .tab_info {
          width: 15px;
          height: 15px;
          color: #4ec549;
        }
      }
    }
  }
}

.el-table ::v-deep th.is-leaf {
  border-bottom: none;
}

.el-table:before {
  display: none;
}

.el-alert {
  height: 45px;
}

.coin-info {
  line-height: 2;
  opacity: 0.6;
  padding: 20px;
}

.submit-btn {
  background: #27c08b;
  border-radius: 4px;
  color: white;
  font-size: 14.67px;
  border: none;
  transition: 0.25s background-color ease-in-out;
  margin-top: 50px;
  width: 380px;

  &:hover {
    background-color: #32dba0;
  }
}

.coin-info {
  background-color: #f8f8f8;
}

.form-block {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;

  .el-row {
    width: 100%;
    flex-basis: 100%;
  }

  .width-half {
    width: 100%;
  }
}

.width-screen {
  width: 100%;
}

::v-deep .el-table__expanded-cell {
  padding: 0;
  border-radius: 4px;
  border: 1px solid #ECECED;
}
::v-deep .popper__arrow::before ,::v-deep .popper__arrow::after{
  content:"";
  width:0;
  height:0;
  position:absolute;
  right: 23px;
  top: -7px;
  border-radius: 2px;
  border-left:solid 7px transparent;
  border-bottom:solid 7px #8c8a8a;
  border-right:solid 7px transparent;
}
::v-deep .popper__arrow::after{
  border-bottom:solid 7px white;
}

  .currency-tags{
    font-size: 12px;
    line-height: normal;
    margin-bottom: 10px;
    color: #606266;
    vertical-align: middle;
    ::v-deep .el-checkbox__label{
      font-size: 12px;
      vertical-align: middle;
    }
    span{
      color: #DC5449;
    }
  }

</style>
