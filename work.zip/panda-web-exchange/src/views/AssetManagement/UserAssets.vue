<i18n>
  zh-CN:
   title:
    - 资产详情
    - 资金划转
    - '总资产折合：'
    - '可用资产折合：'
    - '冻结资产折合：'
    - 币币账户
    - 查看资金记录
   placeholder:
    - 搜索
    - 请选择
   coinBtnText:
    - 隐藏小额资产
    - 全部划转
    - 充值
    - 提现
    - 交易
   tooltip:
    - '小于 0.001 BTC'
    - 当前币种暂不支持充值
    - 当前币种暂不支持提现
    - 当前币种暂不支持交易
   label:
    - 币种
    - '余额:'
    - 到
    - 数量
    - 总额
    - 'BTC估值'
    - 可用
    - 冻结
    - 操作
   value:
    - '币币账户'
    - 'OTC账户'
   message:
    - 数量不能为空
    - 请输入划转数量
    - 划转数量不能大于账户余额
    - 转入成功
   labelText:
    - '从'
    - '永续合约账户'
    - '余额：'
    - '您还未开通合约，请先开通'
  en-US:
   title:
    - 'Asset Details'
    - 'Transfer'
    - 'Estimated Value:'
    - 'Estimated Available:'
    - 'Estimated Frozen:'
    - 'Exchange Account'
    - 'View financial history'
   placeholder:
    - 'Search Coin'
    - 'please choose'
   coinBtnText:
    - 'Hide Small Balances'
    - 'All'
    - Deposit
    - Withdraw
    - Exchange
   tooltip:
    - 'Below 0.001 BTC'
    - 'Cryptocurrency does not support deposit now'
    - 'Cryptocurrency does not support withdrawal now'
    - 'Cryptocurrency does not support trading now'
   label:
    - Coin
    - 'Available:'
    - To
    - Amount
    - Total
    - 'BTC Valuation'
    - Available
    - 'Frozen'
    - Action
   value:
    - 'Exchange Account'
    - 'OTC Account'
   message:
    - 'Amount cannot be empty'
    - 'Please enter the number of transfers'
    - 'The number of transfers cannot be greater than the account balance'
    - 'Successful transfer'
   labelText:
    - 'From'
    - 'Swap account'
    - 'Balance：'
    - 'You have not yet opened a contract, please open it first'
  zh-TW:
   title:
    - 資產詳情
    - 資金劃轉
    - '總資產折合：'
    - '可用資產折合：'
    - '凍結資產折合：'
    - 幣幣帳戶
    - 查看資金記錄
   placeholder:
    - 搜索幣種
    - 請選擇
   coinBtnText:
    - 隱藏小額資產
    - 全部劃轉
    - 充值
    - 提現
    - 交易
   tooltip:
    - '小於 0.001 BTC'
    - 當前幣種暫不支持充值
    - 當前幣種暫不支持提現
    - 當前幣種暫不支持交易
   label:
    - 幣種
    - '餘額:'
    - 到
    - 數量
    - 總額
    - 'BTC估值'
    - 可用
    - 凍結
    - 操作
   value:
    - '幣幣帳戶'
    - 'OTC帳戶'
   message:
    - 數量不能為空
    - 請輸入劃轉數量
    - 劃轉數量不能大於帳戶餘額
    - 轉入成功
   labelText:
    - '從'
    - '永續合約賬戶'
    - '餘額：'
    - '您還未開通合約，請先開通'
  ko-KR:
   title:
    - '자산 세부 사항'
    - '자금 이체'
    - '총 자산 환산:'
    - '예상 가능:'
    - '예상 동결:'
    - '거래 계정'
    - '펀드 레코드보기'
   placeholder:
    - '검색'
    - '선택하세요'
   coinBtnText:
    - '소액 자산 숨기기'
    - '모든 전송'
    - '입금'
    - '출금'
    - '거래'
   tooltip:
    - '0.001 BTC 이하'
    - '현재 통화는 현재 충전을 지원하지 않습니다'
    - '현재 통화는 현금 인출을 지원하지 않습니다'
    - '현재 통화는 현재 거래를 지원하지 않습니다'
   label:
    - '코인명'
    - '잔액:'
    - '도착'
    - '수량'
    - '합계'
    - 'BTC 가치'
    - '주문가능'
    - '대기주문'
    - '작업'
   value:
    - '계정 에서 '
    - 'OTC 계정'
   message:
    - '수량은 비워 둘 수 없습니다'
    - '환승 횟수를 입력하십시오'
    - '송금 횟수는 계정 잔액을 초과 할 수 없습니다'
    - '성공적인 이체'
   labelText:
    - '부터'
    - '영구 계약 계정'
    - '잔고：'
    - '당신 은 아직 계약 을 개통 하지 않 았 습 니 다, 우선 개통 하 세 요.'
</i18n>
<template>
  <div class="assetManagement">
    <div class="asset-box">
      <div class="asset_header flex-justify-content-space-between">
        <div class="header_left">
          <!-- <p class="text-weight-8">资产总折合：{{allAssets.totalToBTC | toFixed(8)}} BTC</p>
          <label>≈ {{allAssets[`totalTo${moneySelect}`]}} {{moneySelect}}</label>-->
          <p class="text-weight-5">{{$t('title[0]')}}</p>
          <!--    资产详情      -->
        </div>
        <div class="header_right">
          <!-- <div
            class="right_button button_active text-weight-4"
            @click.stop="dialogVisible = true"
          >资金划转</div>-->
          <div @click.stop="dialogVisible = true" class="el-button--success cursor-pointer">
            <svg class="icon icon-huazhuan" aria-hidden="true">
              <use xlink:href="#icon-huazhuan-copy" />
            </svg>
            {{$t('title[1]')}}
            <!--    资金划转      -->
          </div>
        </div>
      </div>
      <div class="asset-content">
        <div class="asset-summation-box">
          <div class="asset-summation">
            <p>{{$t('title[2]')}}</p>
            <!--    总资产折合：      -->
            <div class="asset-summation-money">
              <svg class="icon icon-bitebi" aria-hidden="true">
                <use xlink:href="#icon-bitebi" />
              </svg>
              <span class="money-ustd">{{allAssets.totalToBTC| toFixed(8) | strReplace(seeMoney)}}</span>
              <span
                class="money-cny"
              >{{moneySelect === 'CNY' ? '&yen;' : '&#36;'}} {{allAssets[`totalTo${moneySelect}`] | currencyFormat(2)| strReplace(seeMoney)}}</span>
            </div>
          </div>
          <div class="asset-summation">
            <p>{{$t('title[3]')}}</p>
            <!--    可用资产折合：      -->
            <div class="asset-summation-money">
              <svg class="icon icon-bitebi" aria-hidden="true">
                <use xlink:href="#icon-bitebi" />
              </svg>
              <span
                class="money-ustd"
              >{{allAssets.totalToBTC - allAssets.frozenBTC | toFixed(8) | strReplace(seeMoney)}}</span>
              <span
                class="money-cny"
              >{{moneySelect === 'CNY' ? '&yen;' : '&#36;'}}{{allAssets[`totalTo${moneySelect}`] - allAssets[`frozen${moneySelect}`] | currencyFormat(2)| strReplace(seeMoney)}}</span>
            </div>
          </div>
          <div class="asset-summation">
            <p>{{$t('title[4]')}}</p>
            <!--    冻结资产折合：      -->
            <div class="asset-summation-money">
              <svg class="icon icon-bitebi" aria-hidden="true">
                <use xlink:href="#icon-bitebi" />
              </svg>
              <span class="money-ustd">{{allAssets.frozenBTC | toFixed(8) | strReplace(seeMoney)}}</span>
              <span
                class="money-cny"
              >{{moneySelect === 'CNY' ? '&yen;' : '&#36;'}} {{allAssets[`frozen${moneySelect}`] | currencyFormat(2)| strReplace(seeMoney)}}</span>
            </div>
          </div>
          <div class="asset-summation" @click="seeMoney=!seeMoney">
            <svg class="icon icon-buxianshi" aria-hidden="true" v-if="seeMoney">
              <use xlink:href="#icon-buxianshi" />
            </svg>
            <svg class="icon icon-buxianshi" aria-hidden="true" v-else>
              <use xlink:href="#icon-xianshi1" />
            </svg>
          </div>
        </div>
        <div class="table-content">
          <div class="table-header">
            <div class="left">
              <div class="title">{{$t('title[5]')}}</div>
              <!--    币币账户      -->
              <el-link
                type="primary"
                class="link"
                @click="$router.push('/assetManagement/recordAssets')"
              >
                <svg class="icon icon-zijinjilu" aria-hidden="true">
                  <use xlink:href="#icon-zijinjilu" />
                </svg>
                {{$t('title[6]')}}
                <!--    查看资金记录      -->
              </el-link>
            </div>
            <div class="right">
              <el-autocomplete
                v-model="shortName"
                :fetch-suggestions="querySearchAsync"
                :placeholder="$t('placeholder[0]')"
                size="mini"
              >
                <!--    搜索币种      -->
                <svg slot="prefix" class="icon icon-tishi" aria-hidden="true">
                  <use xlink:href="#icon-sousuo1" />
                </svg>
              </el-autocomplete>
              <el-checkbox v-model="showSmallAmount">{{$t('coinBtnText[0]')}}</el-checkbox>
              <!--    隐藏小额资产      -->
              <el-tooltip
                popper-class="el_tooltip"
                :content="$t('tooltip[0]')"
                placement="top"
                effect="light"
              >
                <svg class="icon icon-tishi cursor-pointer" aria-hidden="true">
                  <use xlink:href="#icon-tishi" />
                </svg>
              </el-tooltip>
            </div>
          </div>
          <el-table
            :align="center"
            :data="tradeData || []"
            :cell-style="{fontSize: '12px',color: '#41414c',height:'60px'}"
            :header-cell-style="{background:'#f8f8f8',color:'rgba(65, 65, 76, 0.6) !important', fontSize: '12px'}"
          >
            <el-table-column
              prop="shortName"
              :label="$t('label[0]')"
              label-class-name="text-align-left text-weight-4"
              class-name="text-align-left text-weight-6"
              sortable
              :sort-method="sortTradeName"
              width="150"
            >
              <template slot-scope="{row}">
                <div class="flex-align-items-center">
                  <div
                    :style="`background-image: url(${row.logo});width:16px;height:16px;`"
                    class="background-image-none background-reset background-size-cover margin-right-10"
                  ></div>
                  <span>{{row.shortName }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column
              :label="$t('label[4]')"
              label-class-name="text-align-right text-weight-4"
              class-name="text-align-right text-weight-4"
              sortable
              :sort-method="roseTotal"
              width="auto"
            >
              <!--    总额      -->
              <template slot-scope="{row}">
                <span>{{(row.total + row.frozen) | toFixed(row.amountDecimal) | strReplace(seeMoney)}}</span>
              </template>
            </el-table-column>
            <el-table-column
              label-class-name="text-align-center text-weight-4"
              class-name="text-align-left text-weight-4"
              sortable
              :sort-method="roseTotalBTC"
              width="350"
              :label="$t('label[5]')"
            >
              <!--    BTC估值      -->
              <template slot-scope="{row}">
                <span
                  style="padding-left: 100px;"
                >{{row.totalBTC | toFixed(8) | strReplace(seeMoney)}}</span>
                <span
                  style="color:rgba(152,165,179,1);"
                >&nbsp;≈&nbsp;{{row[`total${moneySelect}`] | currencyFormat(2) | strReplace(seeMoney)}}{{moneySelect}}</span>
              </template>
            </el-table-column>
            <el-table-column
              :label="$t('label[6]')"
              label-class-name=" text-align-right text-weight-4"
              class-name=" text-align-right text-weight-4"
              width="auto"
            >
              <!--    可用      -->
              <template slot-scope="{row}">
                <span>{{ row.total | toFixed(row.amountDecimal) | strReplace(seeMoney)}}</span>
              </template>
            </el-table-column>
            <el-table-column
              width="auto"
              label-class-name="text-align-right text-weight-4"
              class-name="text-align-right text-weight-4"
              :label="$t('label[7]')"
            >
              <!--    冻结      -->
              <template slot-scope="{row}">
                <span>{{row.frozen | toFixed(row.amountDecimal) | strReplace(seeMoney)}}</span>
              </template>
            </el-table-column>
            <el-table-column
              label-class-name="text-align-right text-weight-4"
              class-name="text-align-right text-weight-4"
              :label="$t('label[8]')"
              width="250px"
            >
              <template slot-scope="{row}" style="display: inline-block;">
                <el-tooltip
                  popper-class="el_tooltip"
                  :content="$t('tooltip[1]')"
                  placement="top"
                  effect="light"
                  :disabled="isNavigation(row.coinId,'isRecharge')"
                >
                  <!--  - 当前币种暂不支持充值   -->
                  <div style="display: inline-block">
                    <el-button
                      type="text"
                      size="mini"
                      :class="['default',!isNavigation(row.coinId,'isRecharge') && 'opacity'] "
                      :disabled="!isNavigation(row.coinId,'isRecharge')"
                      @click.stop="$router.push(`/assetManagement/rechargeCoin?id=${row.coinId}`)"
                    >{{$t('coinBtnText[2]')}}</el-button>
                    <!--    充值    -->
                  </div>
                </el-tooltip>
                <el-tooltip
                  popper-class="el_tooltip"
                  :content="$t('tooltip[2]')"
                  placement="top"
                  effect="light"
                  :disabled="isNavigation(row.coinId,'isWithdraw')"
                >
                  <!--  - 当前币种暂不支持提现    -->
                  <div style="display: inline-block">
                    <el-button
                      type="text"
                      size="mini"
                      :class="['default',!isNavigation(row.coinId,'isWithdraw') && 'opacity'] "
                      :disabled="!isNavigation(row.coinId,'isWithdraw')"
                      @click.stop="$router.push(`/assetManagement/withdrawCoin?id=${row.coinId}`)"
                    >{{$t('coinBtnText[3]')}}</el-button>
                    <!--    提现    -->
                  </div>
                </el-tooltip>
                <el-tooltip
                  popper-class="el_tooltip"
                  :content="$t('tooltip[3]')"
                  placement="top"
                  effect="light"
                  :disabled="row.firstTradeId || row.shortName !=='USDT'"
                >
                  <!--    - 当前币种暂不支持交易      -->
                  <div style="display: inline-block">
                    <el-button
                      type="text"
                      size="mini"
                      :class="['default',(!row.firstTradeId || row.shortName==='USDT') && 'opacity'] "
                      :disabled="!row.firstTradeId || row.shortName==='USDT'"
                      @click.stop="$router.push(`/exchange?id=${row.firstTradeId}`)"
                    >{{$t('coinBtnText[4]')}}</el-button>
                    <!--    交易    -->
                  </div>
                </el-tooltip>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
      <el-dialog
        :title="$t('title[1]')"
        :visible.sync="dialogVisible"
        custom-class="custom-dialog"
        @closed="handleClose"
        :close-on-click-modal="false">
        <!--    资金划转      -->
        <el-form
          :model="ruleForm"
          :rules="rules"
          ref="ruleForm"
          class="form-block"
          :hide-required-asterisk="true"
        >
          <el-row>
            <el-col :span="24">
              <el-form-item :label="$t('label[0]')" prop="currency">
                <!--    币种      -->
                <el-select
                  v-if="tabUser === 0"
                  :value="userWalletUSDT && userWalletUSDT.coinName"
                  :placeholder="$t('placeholder[1]')">
                  <!--    请选择      -->
                  <el-option>{{userWalletUSDT && userWalletUSDT.coinName}}</el-option>
                </el-select>
                <el-select v-else v-model="transferList.coinName" :placeholder="$t('placeholder[1]')" @change="handleChangeCoin">
                  <el-option
                    v-for="item in contractCoinList"
                    :key="item.coinId"
                    :label="item.coinName"
                    :value="item.coinId">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item>
                <template #label>
                  <span>{{$t('labelText[0]')}}</span>
                  <!--    从      -->
                </template>
                <el-select :value="$t('value[0]')" :placeholder="$t('placeholder[1]')">
                  <el-option>{{$t('value[0]')}}</el-option>
                </el-select>
                <!--    从&nbsp;币币账户  / 请选择     -->
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item :label="$t('label[2]')">
                <!--    到     -->
                <el-select v-model="transferList.contract" :placeholder="$t('placeholder[1]')" @change="handleChangeTab">
                  <el-option
                    v-for="item in contractList"
                    :key="item.value"
                    :label="item.label"
                    v-if="item.show"
                    :value="item.value">
                  </el-option>
                </el-select>
                <!--    到&nbsp;法币账户 / 请选择      -->
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item :label="$t('label[3]')" prop="quantity">
            <!--    数量      -->
            <el-input v-model="ruleForm.quantity" v-only-number:8="ruleForm.quantity">
              <template #suffix>
                <p
                  class="input_text cursor-pointer"
                  @click.stop="handleClickAllUsd"
                >{{$t('coinBtnText[1]')}}</p>
                <!--    全部划转      -->
              </template>
            </el-input>
          </el-form-item>
          <span v-if="tabUser === 0">
            {{$t('labelText[2]')}} <em class="text-color-blue text-style-normal">{{userWalletUSDT.total | toFixed(userWalletUSDT.amountDecimal)}}</em>&nbsp;&nbsp;USDT
            <!--      余额：      -->
          </span>
          <span v-else>
            {{$t('labelText[2]')}} <em class="text-color-blue text-style-normal">
            <!--      余额：      -->
            <label v-if="transferList.balance">{{transferList.balance | toFixedSize(currencyAccuracy)}} </label>
            <label v-else>--</label>
          </em>
          </span>
          <el-row :gutter="20" style="margin-top: 20px; margin-bottom: 10px">
            <el-col :span="12">
              <el-button
                type="info"
                style="width: 100%"
                @click.stop="dialogVisible = false"
                class="cancel-btn"
              >{{$t('btnText[1]')}}</el-button>
              <!--    取消      -->
            </el-col>
            <el-col :span="12">
              <el-button
                type="success"
                style="width: 100%"
                @click.prevent="handleSubmitForm"
                class="confirm-btn"
              >{{$t('btnText[0]')}}</el-button>
              <!--    确认      -->
            </el-col>
          </el-row>
        </el-form>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import api from '../../api/asset';
import { mapState, mapActions } from '../../utils/common';
import future from '../../api/future';
// import { Regex } from '../../utils/constant';

export default {
  name: 'assetManagement', // 我的资产
  data() {
    return {
      ruleForm: { // 页面表单
        quantity: 0, // 交易数量
      },
      tabUser: 0, // 默认展示币币支持币种select
      shortName: '',
      checked: '',
      seeMoney: false,
      showSmallAmount: false,
      dialogVisible: false, // dialog状态
      transferList: {
        coinName: 'BTC',
        coins: '', // 币币
        contract: this.$t('value[1]'), // 永续合约
        balance: '', // 余额
      },
    };
  },
  methods: {
    ...mapActions('assets', ['fetchAllAssets', 'fetchOtcFinancial']),
    ...mapActions('contractExchange', ['fetchCoinList', 'fetchAccuracyList']),
    handleClickAllUsd() { // 全部划转
      const { userWalletUSDT: { total } } = this;
      if (this.tabUser === 0) this.ruleForm.quantity = total;
      if (this.tabUser === 1) this.ruleForm.quantity = this.transferList.balance;
    },
    handleSubmitForm() { // 提交互转数据
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          const { userWalletUSDT: { coinId } } = this;
          if (this.tabUser === 0) {
            api.financialTransfer({
              amount: Number(this.ruleForm.quantity),
              coinId,
              type: 1,
            }).then(() => {
              this.dialogVisible = false;
              this.fetchAllAssets();
              this.$message({
                center: true,
                message: this.$t('message[3]'), // 转入成功
                type: 'success',
              });
            });
          }
          if (this.tabUser === 1) {
            if (this.userInfo.openFutures === 0) this.$message.warning(this.$t('labelText[3]')); // 您还未开通合约，请先开通
            future.futuresAccountTransfer({
              coinId: this.fetchCoinId,
              amount: this.ruleForm.quantity,
              direction: 1,
            }).then(() => {
              this.$message.success(this.$t('message[3]')); // 转入成功
              this.dialogVisible = false;
              this.fetchAllAssets();
            });
          }
        }
      });
    },
    isNavigation(id, key) {
      const { coinList } = this;
      return coinList.find(({ setting }) => setting.coinId === id) ?.coinType[key];
    },
    querySearchAsync(queryString, cb) {
      const { allAssets: { userWalletList = [] } } = this;
      const restaurants = userWalletList.map(obj => ({
        value: obj.coinName,
      }));
      const results = queryString ? restaurants.filter(this.createStateFilter(queryString)) : restaurants;
      cb(results);
    },
    createStateFilter(queryString) {
      return state => (state.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0);
    },
    sortTradeName(a, b) {
      return a.shortName.localeCompare(b.shortName);
    },
    roseTotal(n, o) {
      return (n.total + n.frozen) - (o.total + o.frozen);
    },
    roseTotalBTC(n, o) {
      return n.totalBTC - o.totalBTC;
    },
    sortPrice({ totalCNY, totalUSD }) { // 显示CNY / USD
      const { moneySelect } = this;
      if (moneySelect === 'CNY') return totalCNY;
      return totalUSD;
    },
    handleChangeTab(value) { // 切换划转账户
      this.tabUser = value;
      if (this.userInfo.openFutures === 0 && value === 1) {
        this.$message.warning(this.$t('labelText[3]')); // 您还未开通合约，请先开通
        return;
      }
      if (value === 1) this.fetchAccountTransferAmount(value, this.fetchCoinId);
    },
    handleChangeCoin() { // 切换币种
      if (this.userInfo.openFutures === 0) {
        this.$message.warning(this.$t('labelText[3]')); // 您还未开通合约，请先开通
        return;
      }
      const { transferList: { contract } } = this;
      this.fetchAccountTransferAmount(contract, this.fetchCoinId);
    },
    fetchAccountTransferAmount(type, coinId) { // 获取划转余额
      future.accountTransferAmount({ coinId, type }).then((data) => { this.transferList.balance = data; });
    },
    handleClose() {
      this.$refs.ruleForm.resetFields();
      this.dialogVisible = false;
    },
  },
  watch: {
    dialogVisible(n, o) {
      if (n !== o) this.fetchOtcFinancial();
    },
  },
  computed: {
    ...mapState(['moneySelect', 'coinList', 'userInfo', 'systemConfig']),
    ...mapState('exchange', ['tradeSummaryList']),
    ...mapState('assets', ['allAssets', 'otcAssets']),
    ...mapState('contractExchange', ['contractCoinList', 'accuracyList']),
    userWalletUSDT() {
      const { allAssets: { userWalletList = [] } } = this;
      return userWalletList.find(({ coinName }) => coinName === 'USDT') || {};
    },
    /* currentTradeId() {
      const { tradeSummaryList } = this;
      return tradeSummaryList['BTC/USDT'] ?.tradeId;
    },
    currentCoinId() {
      const { coinList } = this;
      return coinList.find(({ coinType }) => coinType.name === 'BTC') ?.coinType ?.id;
    }, */
    tradeData() {
      const { allAssets: { userWalletList = [] } } = this;
      return userWalletList.filter(({ shortName, totalBTC }) => (this.shortName ? this.shortName === shortName : true) && (this.showSmallAmount ? (totalBTC > 0.001) : true)) || [];
    },
    fetchCoinId() { // 获取coinId
      const { transferList: { coinName: name }, contractCoinList } = this;
      return contractCoinList?.find(({ coinName, coinId }) => name === coinName || name === coinId)?.coinId || {};
    },
    currencyAccuracy() { // 获取合约精度
      const { transferList: { coinName: name }, accuracyList } = this;
      return accuracyList?.find(({ coinId, coinName }) => coinId === name || coinName === name)?.assetSize || {};
    },
    contractList() {
      return [{
        value: 0,
        show: true,
        label: this.$t('value[1]'),
      }, {
        value: 1,
        show: Number(this.systemConfig.isShowFuturesAssets) === 1,
        label: this.$t('labelText[1]'),
      }];
    },
    rules() { // 验证规则
      const quantityText = this.$t('message[1]');
      const quantityFont = this.$t('message[2]');
      return {
        quantity: [
          { required: true, message: this.$t('message[0]'), trigger: 'blur' }, // 数量不能为空
          {
            validator: (rule, value, callback) => { // 数量验证
              const { userWalletUSDT: { total }, transferList: { balance } } = this;
              if (!value) return callback(quantityText); // 请输入划转数量
              if (value > total && this.tabUser === 0) return callback(quantityFont); // 划转数量不能大于账户余额
              if (value > balance && this.tabUser === 1) return callback(quantityFont); // 划转数量不能大于账户余额
              return callback();
            },
            trigger: 'blur',
          },
        ],
      };
    },
  },
  created() {
    this.fetchCoinList();
    this.fetchAccuracyList();
  },
};
</script>

<style lang="scss" scoped>
.assetManagement {
  height: 100%;
  width: 100%;
  background: rgba(243, 246, 248, 1);
  padding-top: 20px;
  margin-bottom: 60px;
  .asset-box {
    width: 1200px;
    margin: 0 auto;
  }
  .balance {
    margin-left: 100px;
    position: absolute;
  }
  .input_text {
    font-size: 12px;
    color: #1581f2;
    margin-right: 10px;
  }

  .asset_header {
    height: 60px;
    background: rgba(255, 255, 255, 1);
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 20px;
    margin-bottom: 20px;

    .header_left {
      p {
        font-size: 24px;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 500;
        color: rgba(47, 57, 68, 1);
        line-height: 24px;
      }
      label {
        font-size: 12px;
        color: #e0e0e7;
        opacity: 0.6;
      }
    }
    .header_right {
      display: flex;
      justify-content: space-between;
      .el-button--success {
        width: 110px;
        height: 36px;
        // background: rgba(39, 192, 139, 1);
        border-radius: 2px;
        font-size: 14px;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 500;
        line-height: 14px;
        display: flex;
        background: #ffffff;
        align-items: center;
        justify-content: center;
        border: 1px solid rgba(39, 192, 139, 1);
        color: rgba(39, 192, 139, 1);
        .icon-huazhuan {
          width: 12px;
          height: 12px;
          //  padding-top: 2px;
          margin-right: 5px;
        }
        &:hover {
          // background: rgba(144, 223, 195, 0.8);
          opacity: 0.7;
        }
      }
    }
  }
  .asset-content {
    width: 100%;
    background: #ffffff;
    // padding-bottom: 200px;
    padding: 0 20px 60px 20px;
    margin-bottom: 60px;
    .asset-summation-box {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 40px 0;

      border-bottom: 1px solid #eeeeee;
      .asset-summation {
        display: flex;
        flex-flow: column;
        > p {
          font-size: 14px;
          font-family: PingFangSC-Regular, PingFang SC;
          font-weight: 400;
          color: rgba(73, 90, 108, 1);
          line-height: 14px;
        }
        .icon-buxianshi {
          width: 18px;
          height: 10px;
        }
        .asset-summation-money {
          display: flex;
          padding-top: 30px;
          align-items: flex-end;
          .money-ustd {
            font-size: 24px;
            font-family: PingFangSC-Medium, PingFang SC;
            font-weight: 500;
            color: rgba(47, 57, 68, 1);
            line-height: 24px;
          }
          .icon-bitebi {
            width: 20px;
            height: 24px;
            padding-bottom: 2px;
          }
          .money-cny {
            padding-left: 30px;
            font-size: 18px;
            font-family: PingFangSC-Medium, PingFang SC;
            font-weight: 500;
            color: rgba(152, 165, 179, 1);
            line-height: 18px;
          }
        }
      }
    }
    .table-content {
      padding-top: 40px;

      .table-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-bottom: 20px;
        .left,
        .right {
          display: flex;
          // justify-content: space-between;
          align-items: center;
          .title {
            font-size: 16px;
            font-family: PingFangSC-Semibold, PingFang SC;
            font-weight: 600;
            color: rgba(73, 90, 108, 1);
            line-height: 16px;
            padding-right: 30px;
          }
          ::v-deep .el-input__inner {
            height: 26px;
            border-radius: 13px;
            width: 133px;
            // border: 1px solid rgba(238, 238, 238, 1);
            margin-right: 30px;
          }
          ::v-deep .el-input__inner:focus {
            border-color: #27c08b;
          }
          ::v-deep .el-input__prefix {
            display: flex;
            justify-content: center;
            align-items: center;
            left: 0;
          }
          .icon-tishi {
            width: 12px;
            height: 12px;
            margin-left: 10px;
          }
          .icon-zijinjilu {
            width: 12px;
            height: 13px;
            margin-right: 5px;
          }
          ::v-deep .el-link--inner {
            font-size: 12px;
            display: flex;
            color: rgba(39, 192, 139, 1);
            align-items: flex-end;
          }
          ::v-deep .el-link:hover:after {
            border-color: rgba(39, 192, 139, 1);
          }
          ::v-deep .el-checkbox {
            display: flex;
            align-items: flex-end;
            outline: none;
            .el-checkbox__input.is-checked .el-checkbox__inner {
              background-color: #27c08b;
              border-color: #27c08b;
            }
            .el-checkbox__input.is-checked + .el-checkbox__label {
              color: #27c08b;
            }
            .el-checkbox__inner {
              width: 14px;
              height: 14px;
              outline: none;
              border-color: #dcdfe6;
              &.is-focus {
                border-color: #27c08b;
              }
            }
            .el-checkbox__inner:hover {
              border-color: #27c08b;
              outline: none;
            }
            .el-checkbox__label {
              font-size: 12px;
              padding-left: 5px;
              outline: none;
            }
          }
          ::v-deep .el-checkbox__original {
            outline: none;
          }
        }
      }
      & ::v-deep th {
        height: 42px;
        padding: 0 !important;
        &.descending .sort-caret.descending {
          border-top-color: #27c08b !important;
        }
        &.ascending .sort-caret.ascending {
          border-bottom-color: #27c08b !important;
        }
        .sort-caret {
          border-left-width: 4px;
          border-right-width: 4px;
        }
        &.label-btc {
          padding-right: 92px !important;
        }
      }
      .default {
        /*padding: 3px 5px;*/
        /*border-radius: 1px;*/
        border: 0;
        font-size: 12px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: rgba(39, 192, 139, 1);
        line-height: 12px;
        margin-left: 30px;
        &:hover {
          color: #36d69f;
        }
        &.opacity {
          opacity: 0.5;
          &:hover {
            // padding: 3px 8px;
            /*background: #ffffff;*/
            color: rgba(39, 192, 139, 1);
          }
        }
      }
    }
  }
}

.el-form-item {
  margin-bottom: 15px;
}

.cancel-btn,
.confirm-btn {
  border: none;
  transition: all 0.25s ease-in-out;
}

.confirm-btn {
  background-color: #27c08b;

  &:hover {
    background-color: #2ed89d;
  }
}

.cancel-btn {
  background-color: #f5f5f5;
  color: #41414c;

  &:hover {
    color: #27c08b;
  }
}
</style>
