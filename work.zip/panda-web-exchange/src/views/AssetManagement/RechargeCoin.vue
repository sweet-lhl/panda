<i18n>
  zh-CN:
   title:
    - 充币
    - 选择币种
    - 充币地址
    - '充币标签'
   tips:
    - '注意'
    - '我已知晓'
    - '地址标签和充币地址同时正确才能充值 {name} 到 Panda Global，遗漏地址标签将导致资金丢失！'
   placeholder:
    - 请选择
    - '请稍等...'
   coinBtnText:
    - 复制
    - '{name} 充币记录'
    - 全部充币记录
    - '详情'
    - '地址'
    - '标签'
   label:
    - 链名称
    - 充币时间
    - 币种
    - 充币数量
    - 状态
    - 操作
  en-US:
   title:
    - Deposit
    - 'Coin'
    - 'Deposit Address'
    - 'Coin label'
   tips:
    - 'Be careful'
    - 'I already know'
    - 'Add {name} to Panda Global only when the address tag and the charging address are correct at the same time. Missing the address tag will result in capital loss!'
   placeholder:
    - 'Please choose'
    - 'Please wait...'
   coinBtnText:
    - Copy
    - '{name} Deposit History'
    - 'All Deposit History'
    - 'Detail'
    - 'Address'
    - 'Label'
   label:
    - 'Chain name'
    - 'Time'
    - Coin
    - Amount
    - Status
    - Operation
  zh-TW:
   title:
    - 充幣
    - 選擇幣種
    - 充幣地址
    - '充幣標籤'
   tips:
    - '注意'
    - '我已知曉'
    - '地址標籤和充幣地址同時正確才能充值{name}到Panda Global，遺漏地址標籤將導致資金遺失！'
   placeholder:
    - 請選擇
    - '請稍等...'
   coinBtnText:
    - 複製
    - '{name} 充幣記錄'
    - 全部充幣記錄
    - '詳情'
    - '地址'
    - '標籤'
   label:
    - 鏈名稱
    - 充幣時間
    - 幣種
    - 充幣數量
    - 狀態
    - '操作'
  ko-KR:
   title:
    - 입금
    - '코인명'
    - '계정 주소'
    - '보전 태그'
   tips:
    - '주의하다'
    - '나는 이미 안다'
    - '주소 탭과 충전주소를 동시에 맞출 수 있습니다 {name} Panda Global, 누락된 주소 탭으로 자금을 잃게 됩니다.'
   placeholder:
    - '선택하세요'
    - '잠시만 기다려주세요...'
   coinBtnText:
    - 복사
    - '{name}입금기록'
    - '완전 충전 기록'
    - '세부 정보'
    - '주소'
    - '라벨'
   label:
    - '체인 명칭'
    - '시간'
    - '코인명'
    - '수량'
    - '상태'
    - 조작

</i18n>
<template>
<div class="coin" id="recharge">
  <!--<el-alert
    title="目前不支持使用智能合约或区块奖励（Coinbase）的转账充值，请你谅解。"
    type="warning"
    center
    :closable="false"
    show-icon>
  </el-alert>-->
  <div class="coin_content">
    <div class="content_title">
      <label>{{$t('title[0]')}}</label>
      <!--  充币  -->
    </div>
    <el-form class="form-block" :hide-required-asterisk="true">
      <div >
        <el-form-item :label="$t('title[1]')" class="width-half">
          <!--  选择币种  -->
          <el-select v-model.number="coinSelect" :placeholder="$t('placeholder[0]')">
            <!--  请选择  -->
            <el-option
              v-for="(coin, index) in coinListArray"
              :key="`coin-select-${index}`"
              :label="coin.coinType.name"
              :value="coin.coinType.id"
              :disabled="!coin.coinType.isRecharge">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('title[2]')" class="width-half">
          <!--  充币地址  -->
          <el-input :readonly="true" :value="rechargeAddress" :placeholder="$t('placeholder[1]')">
            <!--  请稍等...  -->
            <template #suffix>
              <div class="flex-align-items-center height-40 input_layout">
                <p @click.stop="rechargeAddress && handleCopyText(rechargeAddress)" class="cursor-pointer">{{$t('coinBtnText[0]')}}</p>
                <!--  复制  -->
                <el-popover
                  placement="bottom"
                  trigger="hover">
                  <div :style="{backgroundImage: `url(${rechargeQRCode})`}" class="address-qrCode background-reset"></div>
                  <svg slot="reference" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" v-popover:popover
                       class="svg-inline--fa fa-qrcode fa-w-14 fa-3x">
                    <path fill="currentColor"
                          d="M0 224h192V32H0v192zM64 96h64v64H64V96zm192-64v192h192V32H256zm128 128h-64V96h64v64zM0 480h192V288H0v192zm64-128h64v64H64v-64zm352-64h32v128h-96v-32h-32v96h-64V288h96v32h64v-32zm0 160h32v32h-32v-32zm-64 0h32v32h-32v-32z"
                          class="">
                    </path>
                  </svg>
                </el-popover>
              </div>
            </template>
          </el-input>
        </el-form-item>

        <el-form-item :label="$t('title[3]')" class="width-half" v-if="tagAddress">
          <!--  充币标签  -->
          <el-input :readonly="true" :value="tagAddress" :placeholder="$t('placeholder[1]')">
            <!--  请稍等...  -->
            <template #suffix>
              <div class="flex-align-items-center height-40 input_layout">
                <p @click.stop="tagAddress && handleCopyText(tagAddress)" class="cursor-pointer">{{$t('coinBtnText[0]')}}</p>
                <!--  复制  -->
                <el-popover
                  placement="bottom"
                  trigger="hover">
                  <div :style="{backgroundImage: `url(${tagQRCode})`}" class="address-qrCode background-reset"></div>
                  <svg slot="reference" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" v-popover:popover
                       class="svg-inline--fa fa-qrcode fa-w-14 fa-3x">
                    <path fill="currentColor"
                          d="M0 224h192V32H0v192zM64 96h64v64H64V96zm192-64v192h192V32H256zm128 128h-64V96h64v64zM0 480h192V288H0v192zm64-128h64v64H64v-64zm352-64h32v128h-96v-32h-32v96h-64V288h96v32h64v-32zm0 160h32v32h-32v-32zm-64 0h32v32h-32v-32z"
                          class="">
                    </path>
                  </svg>
                </el-popover>
              </div>
            </template>
          </el-input>
        </el-form-item>

        <!--<el-form-item label="充币标签" prop="address" class="width-half">
          &lt;!&ndash; 充币标签 &ndash;&gt;
          <el-input v-model="coinLabel" />
        </el-form-item>-->
        <el-form-item :label="$t('label[0]')" class="width-half" v-if="currentCoin.coinType.name === 'USDT'">
          <!--  链名称  -->
          <el-select v-model.number="chainSelect" :placeholder="$t('placeholder[0]')">
            <!--  请选择  -->
            <el-option
              v-for="(coin, index) in coinChain"
              :key="`coinChain-select-${index}`"
              :label="coin"
              :value="coin">
            </el-option>
          </el-select>
        </el-form-item>
      </div>
      <!--<div class="flex-justify-content-space-between" v-if="currentCoin.coinType.name === 'USDT'">
        <el-form-item :label="$t('label[0]')" class="width-half">
          &lt;!&ndash;  链名称  &ndash;&gt;
          <el-select v-model.number="chainSelect" :placeholder="$t('placeholder[0]')">
            &lt;!&ndash;  请选择  &ndash;&gt;
            <el-option
              v-for="(coin, index) in coinChain"
              :key="`coinChain-select-${index}`"
              :label="coin"
              :value="coin">
            </el-option>
          </el-select>
        </el-form-item>
      </div>-->
    </el-form>

    <div class="content_text coin-info" v-html="rechargeInfo"></div>
    <div class="content_table">
      <div class="table_tag">
        <div :class="['tag_left', 'cursor-pointer', tabIndex === 1 && 'tag_left_active']" @click.stop="tabIndex = 1">
          {{$t('coinBtnText[1]', { name: currentCoin.coinType.name })}}
        </div>
        <!--  充币记录  -->
        <div :class="['tag_left', 'cursor-pointer', tabIndex === 3 && 'tag_left_active']" @click.stop="tabIndex = 3">
          {{$t('coinBtnText[2]')}}
        </div>
        <!--  全部充币记录  -->
        <!--<i class="el-icon-info tab_info"></i>-->
      </div>
      <el-table
        width="100%"
        ref="table"
        @expand-change="expandChange"
        :data="tableData"
        :cell-style="{fontSize: '12px',borderBottom: 'none', color: '#41414c'}"
        :header-cell-style="{background:'#f8f8f8',color:'rgba(65, 65, 76, 0.6) !important',height: '40px', fontSize: '12px'}">
        <el-table-column
          prop="createTime"
          label-class-name="text-align-left text-weight-4"
          class-name="text-align-left text-weight-4"
          :label="$t('label[1]')"
          width="auto">
          <!--  充币时间  -->
          <template slot-scope="{row}">
            <p class="text-align-left">{{row.createTime | timeStampToDate}}</p>
          </template>
        </el-table-column>
        <el-table-column
          width="auto"
          prop="fcoinname"
          label-class-name="text-weight-4"
          class-name="text-weight-4"
          :label="$t('label[2]')">
          <!--  币种  -->
        </el-table-column>
        <el-table-column
          width="auto"
          prop="famount"
          label-class-name="text-weight-4"
          class-name="text-weight-4"
          :label="$t('label[3]')">
          <!--  充币数量  -->
          <template slot-scope="{row}">{{row.famount | toFixed(row.decimal)}}</template>
        </el-table-column>
        <el-table-column
          width="auto"
          label-class-name="text-align-right text-weight-4"
          class-name="text-align-right text-weight-4"
          :label="$t('label[4]')">
          <!--  状态  -->
          <template slot-scope="{row}">{{row.fstatus | typeStatus}}</template>
        </el-table-column>
        <el-table-column
          label-class-name="text-align-right text-weight-4"
          class-name="text-align-right text-weight-4"
          :label="$t('label[5]')">
          <!--    操作    -->
          <template slot-scope="scope">
            <div
              class="flex-justify-content-flex-end flex-align-items-center cursor-pointer text-color-blue"
              @click.stop="toggleRow(scope.row, scope.$index, tableData)">
              {{$t('coinBtnText[3]')}}
              <svg :class="['icon', 'table_icon']" :style="{transform: rotateIndex === scope.row.id ? 'rotate(270deg)' : 'rotate(90deg)'}"  aria-hidden="true">
                <use xlink:href="#icon-jinru" />
              </svg>
            </div>
            <!--    详情    -->
          </template>
        </el-table-column>
        <el-table-column
          width="1"
          type="expand">
          <template slot-scope="scope">
            <div class="form_layout">
              <div class="popper__arrow"></div>
              <div class="form_layout_content flex-justify-content-space-between">
                <p><!--地址：-->{{$t('coinBtnText[4]')}}：</p>
                <label class="text-size-12"><!--asdfasdfasdfasdf132354asdfadfadf-->{{scope.row.rechargeAddress}}</label>
              </div>
              <div class="form_layout_content flex-justify-content-space-between" v-if="scope.row.labelCoinAddress">
                <p>{{$t('coinBtnText[5]')}}：</p>
                <label class="text-size-12">{{scope.row.labelCoinAddress}}</label>
              </div>
              <div class="form_layout_content flex-justify-content-space-between" v-if="isShowTxid(scope.row.txid)">
                <p>Txid：</p>
                <p class="cursor-pointer" @click.stop="handleJumpPage(scope.row)">{{scope.row.txid}}</p>
              </div>
            </div>
          </template>
        </el-table-column>
        <template #empty>
          <empty />
        </template>
      </el-table>
      <el-pagination
        layout="prev, pager, next"
        class="margin-top-10"
        hide-on-single-page
        :total="pagination.total"
        :current-page.sync="pagination.pageIndex"
        :page-size="pagination.pageSize">
      </el-pagination>
    </div>
  </div>

  <el-dialog
    :title="$t('tips[0]')"
    :show-close="false"
    custom-class="custom-dialog"
    :visible.sync="dialogKnow">
    <div class="know-cont flex-justify-content-space-between">
      <div><i class="el-icon-warning" /></div>
      <div>{{$t('tips[2]',{name:currentCoin.coinType.name})}}</div>
    </div>
    <span slot="footer" class="flex-justify-content-space-between flex-align-items-center">
      <el-radio v-model="knowRadio" :label="$t('tips[1]')">{{$t('tips[1]')}}</el-radio>
      <el-button :type="buttonType" :disabled="!knowRadio" @click="dialogKnow = false">{{knowBtn}}</el-button>
    </span>
  </el-dialog>
</div>
</template>

<script>
import { mapState, QRCode } from '../../utils/common';
import { PagingDefaultConf, Regex } from '../../utils/constant';
import api from '../../api/asset';
import i18n from '../../setup/i18n-setup';

const codeData = {
  width: 250,
  height: 250,
  colorDark: '#000000',
  colorLight: '#ffffff',
  correctLevel: QRCode.CorrectLevel.H,
  render: 'table', // 默认使用了canvas，为了避免混乱这里时候用table
};
const qrCode = new QRCode(new Image(), codeData);
const tagQrCode = new QRCode(new Image(), codeData);

export default {
  name: 'recharge',
  data() {
    const { id } = this.$route.query;
    return {
      pagination: {
        ...PagingDefaultConf,
        total: 0,
      },
      rechargeAddress: '',
      tagAddress: '',
      rechargeQRCode: '',
      tagQRCode: '',
      coinSelect: Number(id),
      chainSelect: 'USDT-OMNI',
      coinLabel: '', // 充币标签
      tabIndex: 1, // tab index
      tableData: [],
      rotateIndex: null,
      dialogKnow: false,
      knowRadio: '',
    };
  },
  watch: {
    coinSelect: {
      handler(n, o) {
        if (n !== o) {
          this.rechargeAddress = ''; // 清除数据
          this.tagAddress = ''; // 清除数据
          this.tabIndex = 1; // 重置tabIndex
          this.chainSelect = 'USDT-OMNI'; // 默认选中USDT第一个链
          this.pagination = { ...PagingDefaultConf, total: 0 };
          this.getRechargeAddress();
          this.getCoinOperation();
        }
      },
      deep: true,
      immediate: true,
    },
    tabIndex: {
      handler(n, o) {
        if (n !== o) {
          this.pagination = { // 重置分页
            ...PagingDefaultConf,
            total: 0,
          };
          process.nextTick(this[n === 1 ? 'getCoinOperation' : 'getCoinOperationAll']);
          this.rotateIndex = null;
        }
      },
      deep: true,
      immediate: true,
    },
    chainSelect(n) {
      const { coinList, currentCoin } = this;
      const { coinType } = currentCoin;

      if (coinType.name !== 'USDT') return;
      this.rechargeAddress = ''; // 清除数据
      this.tagAddress = ''; // 清除数据
      switch (n) {
        case 'USDT-OMNI':
          this.getRechargeAddress(coinList.find(coin => coin.coinType.name === 'USDT')?.coinType?.id);
          break;
        case 'USDT-ERC20':
          this.getRechargeAddress(coinList.find(coin => coin.coinType.name === 'ETH')?.coinType?.id);
          break;
        default:
          break;
      }
    },
    'pagination.pageIndex': { // 监听分页变化请求数据
      handler(n, o) {
        if (n !== o) {
          if (this.tabIndex === 1) this.getCoinOperation();
          if (this.tabIndex === 3) this.getCoinOperationAll();
        }
      },
      deep: true,
      immediate: true,
    },
  },
  computed: {
    ...mapState(['coinList']),
    knowBtn() {
      return i18n.t('btnText[0]');
    },
    currentCoin() {
      const { coinSelect, coinList } = this;
      return coinList.find(coin => coin.coinType.id === coinSelect) || { setting: {}, coinType: {} };
    },
    rechargeInfo() {
      const { chainSelect, currentCoin } = this;
      const { coinType } = currentCoin;
      const rechargeInfo = coinType.rechargeInfo?.split('&&&') || [];

      return rechargeInfo[chainSelect === 'USDT-OMNI' ? 0 : 1];
    },
    coinChain() {
      // const { coinList } = this;
      return ['USDT-OMNI', 'USDT-ERC20'];
    },
    coinListArray() {
      const { coinList } = this;
      /* // usdt modify
      const usdtIdx = newCoinList.findIndex(({ coinType: { name } }) => name === 'USDT');
      if (usdtIdx !== -1) {
        const { coinType, setting } = newCoinList[usdtIdx];
        newCoinList.splice(usdtIdx, 1, { coinType: { ...coinType, name: 'USDT-OMNI' }, setting });
      }

      // usdt add
      const ethIdx = newCoinList.findIndex(({ coinType: { name } }) => name === 'ETH');
      if (ethIdx !== -1) {
        const { coinType, setting } = newCoinList[ethIdx];
        newCoinList.push({ coinType: { ...coinType, name: 'USDT-ERC20' }, setting });
      } */

      return JSON.parse(JSON.stringify(coinList));
    },
    buttonType() {
      return !this.knowRadio ? 'info' : 'success';
    },
  },
  methods: {
    toggleRow(row, index, tableData) { // 二级表格展示与否
      this.rotateIndex = row.id;
      tableData.forEach((item) => {
        if (row.id !== item.id) this.$refs.table.toggleRowExpansion(item, false);
      });
      this.$refs.table.toggleRowExpansion(row);
    },
    expandChange(row, expand) { // 监听表格行的关闭与开启
      this.rotateIndex = expand[0]?.id || null;
    },
    isShowTxid(value) { // 是否显示Txid
      if (value) return value.substr(1, 4) !== '平台互转';
      return false;
    },
    handleJumpPage({ fcoinname, blockUrl, txid }) { // 跳转到相应币种页面
      if (fcoinname === 'USDT') {
        const hasTxid = txid.substr(0, 2) === '0x';
        if (hasTxid && Regex.IS_URL.test(blockUrl)) window.open(`${blockUrl.split(',')[1]}${txid}`);

        if (!hasTxid && Regex.IS_URL.test(blockUrl)) window.open(`${blockUrl.split(',')[0]}${txid}`);
      }
      if (fcoinname !== 'USDT' && Regex.IS_URL.test(blockUrl)) window.open(`${blockUrl}${txid}`);
    },
    // handleClose() {},
    getRechargeAddress(coinId) {
      const { coinSelect } = this;
      api.getRechargeAddress(coinId || coinSelect).then(({ fadderess, labelCoinAddress }) => {
        this.rechargeAddress = fadderess;
        this.tagAddress = labelCoinAddress;
        qrCode.clear();
        tagQrCode.clear();
        if (fadderess) qrCode.makeCode(fadderess);
        if (labelCoinAddress) {
          this.dialogKnow = true;
          tagQrCode.makeCode(this.tagAddress);
        }
      });
    },
    /* getChainAddress(coinId) { // TODO:USDT多链临时
      api.getRechargeAddress(coinId).then(({ fadderess, labelCoinAddress }) => {
        this.rechargeAddress = fadderess;
        this.tagAddress = labelCoinAddress;
        qrCode.clear();
        tagQrCode.clear();
        if (fadderess) qrCode.makeCode(fadderess);
        if (labelCoinAddress) {
          this.dialogKnow = true;
          tagQrCode.makeCode(this.tagAddress);
        }
      });
    }, */
    getCoinOperation() {
      const { coinSelect: coinId, pagination: { pageIndex: pageNum, pageSize } } = this;
      api.coinOperation({
        coinId, pageNum, pageSize, type: 1,
      }).then(({ data, totalRows }) => {
        [this.tableData, this.pagination.total] = [data, totalRows];
      });
    },
    getCoinOperationAll() {
      const { pagination: { pageIndex: pageNum, pageSize } } = this;
      api.coinOperationAll({
        pageNum, pageSize, type: 1,
      }).then(({ data, totalRows }) => {
        [this.tableData, this.pagination.total] = [data, totalRows];
      });
    },
  },
  created() {
    // eslint-disable-next-line no-underscore-dangle
    qrCode._oDrawing._elImage.onload = (event) => {
      this.rechargeQRCode = event.target.src;
    };
    // eslint-disable-next-line no-underscore-dangle
    tagQrCode._oDrawing._elImage.onload = (event) => {
      this.tagQRCode = event.target.src;
    };
  },
  destroyed() {
    qrCode.clear();
    tagQrCode.clear();
  },
};
</script>

<style lang="scss" scoped>
  ::v-deep .el-dialog .el-button {
    width: 110px;
    height: 40px;
  }

  ::v-deep .el-dialog .el-button--success {
    width: 110px;
    height: 40px;
    background: #27c08b;

    &:hover{
      background-color: #32dba0;
      border: 0;
    }
  }

  .input_layout {

    p {
      margin-right: 20px;
      color: #999999;

      &:hover {
        color: #27c08b;
      }
    }
  }

  #recharge{
    padding-bottom: 123px;
  }
.coin {

  .coin_content {
    width: 71%;
    margin: 0 auto;
    .content_title {
      margin-top: 40px;
      margin-bottom: 10px;
      border-bottom: 1px solid #DDDDDD;
      padding-bottom: 10px;
      label {
        font-size: 16px;
        color: #41414C;;
      }
    }
    .content_layout {
      margin-top: 20px;
      display: flex;
      justify-content: space-between;
      .layout_left {
        width: 49%;
        display: flex;
        flex-direction: column;
        div {
          position: relative;
          margin-bottom: 10px;
        }
        .layout_info {
          width: 12px;
          height: 12px;
          color: #4EC549;
          margin-left: 10px;
        }
        label {
          font-size: 12px;
          color: #41414C;
          opacity: .6;
          margin-bottom: 10px;
        }
        .qrcode {
          top: 12px;
          right: 10px;
          position: absolute;
          width: 14px;
          height: 14px;
          background: seagreen;
        }
      }
    }
    .content_text {
      font-size: 12px;
      color: #999999;
      text-align: left;
      line-height: 2;
    }
    .content_table {
      margin-top: 60px;

      .table_tag {
        display: flex;
        flex-direction: row;
        align-items: center;
        font-size: 16px;
        color: #41414C;
        border-bottom: 1px solid #DDDDDD;
        .tag_left {
          height: 36px;
          line-height: 36px;
          text-align: center;
          margin-right: 20px;
        }
        .tag_left:nth-child(2){
          margin-right: 0;
        }
        .tag_left_active {
          border-bottom: 2px solid #27c08b;
        }
        .tab_info {
          width: 15px;
          height: 15px;
          color: #4EC549;
        }
      }
    }
  }
}

  .fa-qrcode{
    width: 14px;
    // transform: translateY(-50%);
    position: relative;
    top: 50%;
  }

  .address-qrCode{
    width: 160px;
    height: 160px;
    background-color: transparent;
  }

  /*.width-half{
    width: 49%;
  }*/

  ::v-deep .el-form-item__content{
    line-height: normal;
  }

  .el-table ::v-deep th.is-leaf {
    border-bottom: none;
  }

  .el-table:before{
    display: none;
  }

  .el-alert{
    height: 45px;
  }

  .coin-info{
    padding: 20px;
    background-color: #f8f8f8;
  }

  .height-40{
    height: 40px;
  }

  ::v-deep .el-table__expanded-cell {
    padding: 0;
    border-radius: 4px;
    border: 1px solid #ECECED;
  }
  ::v-deep .popper__arrow::before ,::v-deep .popper__arrow::after{
    content:"";
    width:0;
    height:0;
    position:absolute;
    right: 23px;
    top: -7px;
    border-radius: 2px;
    border-left:solid 7px transparent;
    border-bottom:solid 7px #8c8a8a;
    border-right:solid 7px transparent;
  }
  ::v-deep .popper__arrow::after{
    border-bottom:solid 7px white;
  }
  ::v-deep .el-dialog{
    border-radius: 6px;
    .el-dialog__body{
      padding-bottom: 0;
    }
    .el-button{
      padding: 9px 15px;
    }
    .el-radio__label{
      padding-left: 0;
    }
    .el-radio__input{
      margin-left: 5px;
    }
  }
.know-cont{
  background: white;
  width: 100%;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: justify;
  -ms-flex-pack: justify;
  justify-content: space-between;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  line-height: 24px;
  margin-bottom: 20px;
}

  .el-icon-warning:before{
    color: #fe6c6f;
    font-size:24px;
    margin-right: 10px;
  }
</style>
