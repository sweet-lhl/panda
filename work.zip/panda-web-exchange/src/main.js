
import '@babel/polyfill';
import Vue from 'vue';
import Element from 'element-ui';
import App from './App.vue';
import router from './setup/router-setup';
import i18n from './setup/i18n-setup';
import { setZenDeskStatus, setZendeskLanguage } from './setup/zenDesk-setup';
import store from './store';
import vueConfig from './plugins/vueConfig';
import mixins from './plugins/mixins';
import eject from './plugins/eject';
import filters from './plugins/filters';
// eslint-disable-next-line import/no-named-as-default
import components from './plugins/components';
import Empty from './components/Empty.vue';
import directive from './plugins/directive';
import './assets/styleSheet/global.css';
import './assets/styleSheet/custom.scss';
import './assets/styleSheet/resetElement.scss';
import './assets/styleSheet/publicCss.scss';
import 'element-ui/lib/theme-chalk/index.css';


Vue.use(vueConfig);
Vue.mixin(mixins);
Vue.use(filters);
Vue.use(eject);
Vue.use(components);
Vue.use(directive);
Vue.component('empty', Empty);

// eslint-disable-next-line vue-i18n/no-dynamic-keys
Vue.use(Element, { i18n: (key, value) => i18n.t(key, value) });

function* preExecute() {
  const targetNode = document.documentElement;

  yield store.dispatch('fetchWebSocketInfo'); // 完成请求socket配置接口后渲染
  yield new Promise((resolve) => {
    const observer = new MutationObserver((mutationsList) => { // DOM EVENT3, 处理Zendesk展示隐藏
      mutationsList.forEach(({ type, target }) => {
        if (type === 'attributes' && target === document.querySelector('iframe.zEWidget-launcher')) { // Zendesk-DOM
          resolve(target);
          observer.disconnect();
        }
      });
    });

    observer.observe(targetNode, {
      attributes: true,
      childList: true,
      subtree: true,
    });
  });
}
const task = preExecute();
task.next().value.then(() => new Vue({
  el: '#root',
  router,
  store,
  i18n,
  // components: { App },
  // template: '<App />', // https://cli.vuejs.org/config/#runtimecompiler
  beforeCreate() {
    task.next().value.then(() => {
      const { pathname } = window.location;
      if (pathname !== '/exchange' && pathname !== '/future') { // zendesk切换语言
        setZendeskLanguage(i18n.locale);
      } else {
        setZenDeskStatus(pathname !== '/exchange' && pathname !== '/future'); // zendesk的显示状态
      }
    });
  },
  data() {
    return { isShow: true };
  },
  watch: {
    '$i18n.locale': { // 监听语言变化
      handler(n, o) {
        if (n !== o) {
          this.isShow = false;
          this.$nextTick(() => { this.isShow = true; });
        }
      },
      deep: true,
      immediate: true,
    },
  },
  render(h) {
    return this.isShow ? h(App) : null; // 阻止render函数刷新就可刷新页面
  },
})); // socket config
