// DNS: 192.168.10.151
// eslint-disable-next-line import/no-cycle
import i18n from './setup/i18n-setup';

export default [
  /* {
    path: '/test',
    name: 'test',
    component: () => import(/!* webpackChunkName: "test" *!/ './views/Test.vue'),
    meta: { title: '测试' },
  }, */
  {
    path: '/',
    name: 'main',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "main" */ './views/Main.vue'),
    children: [
      {
        path: '',
        name: 'home',
        component: () => import(/* webpackChunkName: "home" */ './views/Home/Index.vue'),
        meta: { title: () => `${i18n.t('home')}` }, // 全球首家全面邀请制数字资产交易平台
      },
      {
        path: 'register',
        name: 'register',
        component: () => import(/* webpackChunkName: "register" */ './views/Register.vue'),
        meta: { title: () => `${i18n.t('register')} | Panda Global` }, // 注册
      },
      {
        path: 'registerSuccess',
        name: 'registerSuccess',
        component: () => import(/* webpackChunkName: "registerSuccess" */ './views/RegisterSuccess.vue'),
        // meta: { title: '注册成功 | Panda Global' },
      },
      {
        path: 'validateRegister/:type',
        name: 'validateRegister',
        component: () => import(/* webpackChunkName: "validateRegister" */ './views/ValidateRegister.vue'),
        // meta: { title: '注册 | Panda Global' },
      },
      {
        path: 'forgetPassword',
        name: 'forgetPassword',
        component: () => import(/* webpackChunkName: "forgetPassword" */ './views/ForgetPassword.vue'),
        meta: { title: () => `${i18n.t('forgetPassword')} | Panda Global` }, // 重置密码
      },
      {
        path: 'newPassword',
        name: 'newPassword',
        component: () => import(/* webpackChunkName: "newPassword" */ './views/NewPassword.vue'),
        meta: { title: () => `${i18n.t('newPassword')} | Panda Global` }, // 设置新密码
      },
      {
        path: 'login',
        name: 'login',
        component: () => import(/* webpackChunkName: "login" */ './views/Login.vue'),
        meta: { title: () => `${i18n.t('login')} | Panda Global` }, // 登录
      },
      {
        path: 'validateLogin/:type',
        name: 'validateLogin',
        component: () => import(/* webpackChunkName: "validateLogin" */ './views/ValidateLogin.vue'),
        // meta: { title: '登录 | Panda Global'  },
      },
      {
        path: 'inviteFriends', // 邀请好友页面
        name: 'inviteFriends',
        component: () => import(/* webpackChunkName: "inviteFriends" */ './views/NoviceSpree/InviteFriends.vue'),
        meta: { title: () => `${i18n.t('inviteFriends')} | Panda Global` }, // 邀请好友
      },
      { // 新手教程-比特币
        path: 'beginnerTutorial',
        name: 'beginnerTutorial',
        component: () => import(/* webpackChunkName: "beginnerTutorial" */ './views/Home/BeginnerTutorial.vue'),
        meta: { title: () => `${i18n.t('beginnerTutorial')} | Panda Global` }, // 新手营
      },
      /* { // 秒懂平台币
        path: 'platformCurrency',
        name: 'platformCurrency',
        component: () => import(/!* webpackChunkName: "platformCurrency" *!/ './views/Home/PlatformCurrency.vue'),
        meta: { title: () => `${i18n.t('platformCurrency')} | Panda Global` }, // 秒懂BAMB
      },
      { // 秒懂平台币
        path: 'votingCurrency',
        name: 'votingCurrency',
        component: () => import(/!* webpackChunkName: "platformCurrency" *!/ './views/VotingCurrency/Index.vue'),
        meta: { title: () => `${i18n.t('votingCurrency')} | Panda Global` }, // 投票上币
        children: [
          {
            path: '',
            name: 'voting',
            component: () => import(/!* webpackChunkName: "platformCurrency" *!/ './views/VotingCurrency/VotingCurrency.vue'),
          },
          {
            path: 'votingResults',
            name: 'votingResults',
            component: () => import(/!* webpackChunkName: "platformCurrency" *!/ './views/VotingCurrency/VotingResults.vue'),
          },
        ],
      }, */
      {
        path: 'userManagement',
        name: 'userManagement',
        component: () => import(/* webpackChunkName: "userManagement" */ './views/UserManagement/Index.vue'),
        meta: { title: () => `${i18n.t('userManagement')} | Panda Global` }, // 账户与安全
        children: [
          {
            path: '',
            name: 'accountSecurity',
            component: () => import(/* webpackChunkName: "accountSecurity" */ './views/UserManagement/AccountSecurity.vue'),
            meta: { title: () => `${i18n.t('userManagement')} | Panda Global` }, // 账户与安全
          },
          {
            path: 'bindGoogle',
            name: 'bindGoogle',
            component: () => import(/* webpackChunkName: "bindGoogle" */ './views/UserManagement/BindGoogle.vue'),
            meta: { title: () => `${i18n.t('bindGoogle')} | Panda Global` }, // 绑定谷歌验证
          },
          {
            path: 'changeGoogle',
            name: 'changeGoogle',
            component: () => import(/* webpackChunkName: "changeGoogle" */ './views/UserManagement/ChangeGoogle.vue'),
            meta: { title: () => `${i18n.t('bindGoogle')} | Panda Global` }, // 绑定谷歌验证
          },
          {
            path: 'loginHistory',
            name: 'loginHistory',
            component: () => import(/* webpackChunkName: "LoginHistory" */ './views/UserManagement/LoginHistory.vue'),
            meta: { title: () => `${i18n.t('loginHistory')} | Panda Global` }, // 登录历史
          },
          {
            path: 'editBasicsIdentity',
            name: 'editBasicsIdentity',
            component: () => import(/* webpackChunkName: "editBasicsIdentity" */ './views/IdentityAuthentication/EditBasicsIdentity.vue'),
            meta: { title: () => `${i18n.t('editBasicsIdentity')} | Panda Global` }, // 身份认证
          },
          {
            path: 'editSeniorIdentity',
            name: 'editSeniorIdentity',
            component: () => import(/* webpackChunkName: "editSeniorIdentity" */ './views/IdentityAuthentication/EditSeniorIdentity.vue'),
            meta: { title: () => `${i18n.t('editSeniorIdentity')} | Panda Global` }, // 高级身份认证
          },
          {
            path: 'basicsIdentityInfo',
            name: 'basicsIdentityInfo',
            component: () => import(/* webpackChunkName: "basicsIdentityInfo" */ './views/IdentityAuthentication/BasicsIdentityInfo.vue'),
            meta: { title: () => `${i18n.t('editBasicsIdentity')} | Panda Global` }, // 身份认证
          },
          {
            path: 'seniorIdentityInfo',
            name: 'seniorIdentityInfo',
            component: () => import(/* webpackChunkName: "seniorIdentityInfo" */ './views/IdentityAuthentication/SeniorIdentityInfo.vue'),
            // meta: { title: '高级身份认证 | Panda Global' },
          },
        ],
      },
      {
        path: 'exchange',
        name: 'exchange',
        component: () => import(/* webpackChunkName: "exchange" */ './views/Exchange/Index.vue'),
        meta: { title: () => `${i18n.t('exchange')} | Panda Global`, noFooter: true, redirection: ({ query: { id } }) => !!id || `/exchange?id=${localStorage.getItem('exchangeSymbol') || 35}` }, // 币币交易
      },
      /* {
        path: 'future',
        name: 'future',
        component: () => import(/!* webpackChunkName: "exchange" *!/ './views/ContractExchange/Index.vue'),
        meta: { title: () => `${i18n.t('future')} | Panda Global`, noFooter: true, redirection: ({ query: { id } }) => !!id || `/future?id=${localStorage.getItem('futureSymbol') || 'BTC-SWAP-USDT'}` }, // 合约交易
      }, */
      {
        path: 'markets',
        name: 'markets',
        component: () => import(/* webpackChunkName: "exchange" */ './views/Exchange/Markets.vue'),
        meta: { title: () => `${i18n.t('markets')} | Panda Global`, noFooter: true, redirection: ({ query: { id } }) => !!id || '/markets?id=35' }, // 币币交易
      },
      { // 币币订单
        path: 'coinOrder',
        name: 'coinOrder',
        component: () => import(/* webpackChunkName: "coinOrder" */ './views/Order/CoinOrder.vue'),
        meta: { title: () => `${i18n.t('coinOrder')} | Panda Global` }, // 订单管理
      },
      /*  { // 币币订单
        path: 'contractOrder',
        name: 'contractOrder',
        component: () => import(/!* webpackChunkName: "coinOrder" *!/ './views/Order/ContractOrder.vue'),
        meta: { title: () => `${i18n.t('contractOrder')} | Panda Global` }, // 订单管理
      }, */
      { // 资产管理
        path: 'assetManagement',
        name: 'assetManagement',
        component: () => import(/* webpackChunkName: "assetManagement" */ './views/AssetManagement/Index.vue'),
        children: [
          { // 资产管理主页面
            path: '',
            name: 'userAssets',
            component: () => import(/* webpackChunkName: "userAssets" */ './views/AssetManagement/UserAssets.vue'),
            meta: { title: () => `${i18n.t('userAssets')} | Panda Global` }, // 资产管理
          },
          { // 充币
            path: 'rechargeCoin',
            name: 'rechargeCoin',
            component: () => import(/* webpackChunkName: "rechargeCoin" */ './views/AssetManagement/RechargeCoin.vue'),
            meta: { title: () => `${i18n.t('rechargeCoin')} | Panda Global`, redirection: ({ query: { id } }) => !!id || '/assetManagement/rechargeCoin?id=9' }, // 充币
          },
          { // 资金记录
            path: 'recordAssets',
            name: 'recordAssets',
            component: () => import(/* webpackChunkName: "RecordAssets" */ './views/AssetManagement/RecordAssets.vue'),
            meta: { title: () => `${i18n.t('recordAssets')} | Panda Global` },
          },
          { // 提币
            path: 'withdrawCoin',
            name: 'withdrawCoin',
            component: () => import(/* webpackChunkName: "withdrawCoin" */ './views/AssetManagement/WithdrawCoin.vue'),
            meta: { title: () => `${i18n.t('withdrawCoin')} | Panda Global`, redirection: ({ query: { id } }) => !!id || '/assetManagement/withdrawCoin?id=9' }, // 提币
          },
        ],
      },
      { // 合约资产
        path: 'contract',
        name: 'contract',
        component: () => import(/* webpackChunkName: "contract" */ './views/ContractAssets/Index.vue'),
        children: [
          { // 合约账户
            path: 'assets',
            name: 'assets',
            component: () => import(/* webpackChunkName: "userAssets" */ './views/ContractAssets/ContractAssets.vue'),
            meta: { title: () => `${i18n.t('contractAssets')} | Panda Global` },
          },
          { // 财务记录
            path: 'record',
            name: 'record',
            component: () => import(/* webpackChunkName: "userAssets" */ './views/ContractAssets/FinancialRecords.vue'),
            meta: { title: () => `${i18n.t('financialRecords')} | Panda Global` },
          },
          { // 交割合约仓位档位
            path: 'position',
            name: 'position',
            component: () => import(/* webpackChunkName: "userAssets" */ './views/ContractAssets/ContractPositions.vue'),
            meta: { title: () => `${i18n.t('contractPositions')} | Panda Global` },
          },
        ],
      },
      {
        path: 'contractTransaction/:type',
        name: 'contractTransaction',
        component: () => import(/* webpackChunkName: "contractTransaction" */ './views/ContractTransaction/Index.vue'),
        meta: { title: `${i18n.t('exchange')} | Panda Global` },
      },
      {
        path: 'ipfs',
        name: 'ipfs',
        component: () => import(/* webpackChunkName: "ipfs" */ './views/Ipfs/Index.vue'),
        meta: { title: 'IPFS专区 | Panda Global' },
        children: [
          {
            name: 'ipfs',
            path: '',
            component: () => import(/* webpackChunkName: "ipfs-home" */ './views/Ipfs/Home.vue'),
          },
          {
            name: 'specialArea',
            path: 'specialArea',
            component: () => import(/* webpackChunkName: "specialArea" */ './views/Ipfs/SpecialArea.vue'),
            children: [
              {
                name: 'ipfs-buy',
                path: ':id(\\d+)',
                component: () => import(/* webpackChunkName: "ipfs-buy" */ './views/Ipfs/Buy.vue'),
              },
              {
                name: 'ipfs-from',
                path: 'order',
                component: () => import(/* webpackChunkName: "ipfs-order" */ './views/Ipfs/Order.vue'),
              },
              {
                name: 'ipfs-profit',
                path: 'profit',
                component: () => import(/* webpackChunkName: "ipfs-profit" */ './views/Ipfs/Profit.vue'),
              },
              {
                name: 'ipfs-introduce',
                path: 'introduce',
                component: () => import(/* webpackChunkName: "ipfs-introduce" */ './views/Ipfs/Introduce.vue'),
              },
            ],
          },
        ],
      },
      {
        path: 'launchpad',
        name: 'launchpad',
        component: () => import(/* webpackChunkName: "Launchpad" */ './views/Launchpad/Index.vue'),
        meta: { title: 'AKSO专区 | Panda Global' },
        children: [
          {
            name: 'launchpad',
            path: '',
            component: () => import(/* webpackChunkName: "launchpad-home" */ './views/Launchpad/Home.vue'),
          },
          {
            name: 'subscription',
            path: 'subscription',
            component: () => import(/* webpackChunkName: "Subscription" */ './views/Launchpad/Subscription.vue'),
          },
        ],
      }, {
        path: 'launchpadDetails/:id',
        name: 'launchpadDetails',
        component: () => import(/* webpackChunkName: "Launchpad" */ './views/Launchpad/LaunchpadDetails.vue'),
        meta: { title: 'AKSO活动详情 | Panda Global' },
      },
    ],

  },
];
