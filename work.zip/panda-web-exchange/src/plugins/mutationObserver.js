// 监听DOM元素变化情况
/**
* @target 监听目标源
* @type HTML属性
* @config Object{bool attributes, bool childList, bool subtree}
*
* @return Function(callback:(target, observer)) target为源，observer为当前MutationObserver实例
* */

export default (target, type, config = {
  attributes: true,
  childList: true,
  subtree: true,
}) => (mutationCallback) => {
  const observer = new MutationObserver(mutationsList => mutationsList.forEach(({ type: _type, target: _target }) => type === _type && mutationCallback(_target, observer)));
  observer.observe(target || document.documentElement, config);
};
