// localStorage 本地存储数据
const { localStorage: _localStorage } = window;

const isProduction = process.env.NODE_ENV === 'production';

function isUType(data) { // 受支持的数据类型
  const type = Object.prototype.toString.call(data);

  return type === '[object Object]' || type === '[object Array]';
}

class StorageDB { // transaction
  constructor(name) {
    this.dbName = name;

    if (!isProduction) { // 打印
      const response = JSON.parse(_localStorage[name] || null);
      console.log(`${name}-初始化数据成功`);
      console.table(JSON.parse(response));
    }
  }

  insert(key, data) {
    const { dbName: name } = this;
    const response = JSON.parse(_localStorage[name] || null) || {};

    if (!response[key]) response[key] = [];

    if (isUType(data)) {
      response[key].concat(data);
      _localStorage.setItem(name, JSON.stringify(response));
    }

    if (!isProduction) { // 打印
      console.log(`${key}-insert:`, data);
      console.table(response);
    }
  }

  read(key) {
    const { dbName: name } = this;
    const response = JSON.parse(_localStorage[name] || null);

    if (!response) return null;
    return response[key];
  }

  remove(key, conditionFunc) {
    const { dbName: name } = this;
    const response = JSON.parse(_localStorage[name] || null);
    if (!response) return;
    if (typeof conditionFunc === 'undefined') delete response[key];
    else {
      const idx = response[key].findIndex(item => conditionFunc(item));
      if (idx !== -1) response[key].splice(idx, 1);
    }

    _localStorage.setItem(name, JSON.stringify(response));

    if (!isProduction) { // 打印
      console.log(`${key}-remove:`);
      console.table(response);
    }
  }

  get clear() {
    const { dbName: name } = this;
    _localStorage.removeItem(name);

    if (!isProduction) { // 打印
      console.log(`${name}-clear`);
    }

    return null;
  }
}

export default StorageDB;
