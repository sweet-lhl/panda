<template>
<div id="table" :class="[isBorder && 'border-table']">
  <div class="table-header background-color-white text-color-black">
    <div :class="['table-header-item', `flex-justify-content-${align}`, isBorder && 'border-right-item']" v-for="(schema, key, index) in fields" :key="`table-header-item-${key}-${index}`">
      <span>{{schema.label}}</span>
      <div class="sort-box" v-if="schema.isSort">
        <!-- 排序支持 -->
        <svg xmlns="http://www.w3.org/2000/svg"
             viewBox="0 0 448 512"
             @click.stop="handleSort(key, 1)"
             :class="['fa-play', 'transform-rotate-270', key === sortKey && sortDescend === 1 && 'text-color-blue']">
          <path fill="currentColor" d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
        </svg>
        <svg xmlns="http://www.w3.org/2000/svg"
             viewBox="0 0 448 512"
             @click.stop="handleSort(key, -1)"
             :class="['fa-play', 'transform-rotate-90',  key === sortKey && sortDescend === -1 && 'text-color-blue']">
          <path fill="currentColor" d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
        </svg>
      </div>
    </div>
  </div>
  <div class="table-body">
    <div :class="['table-body-row', isStripe && 'table-body-stripe']" v-for="(value, index) in tableData" :key="`table-body-item-${index}`">
      <!--tr-->
      <div :class="['table-body-col', `flex-justify-content-${align}`,  isBorder && 'border-right-item']" v-for="(_, key, idx) in fields" :key="`table-body-item-${key}-${index}-${idx}`">
        <!--td-->
        <slot :name="key" :index="index" :data="value">
          <p>{{value[key]}}</p>
        </slot>
      </div>
    </div>
  </div>
  <div class="table-footer">
    <!-- 这里可以使用分页插件，也可以使用其他组件 -->
    <slot name="footer" :data="dataSource"></slot>
  </div>
</div>
</template>

<script>
export default {
  name: 'table',
  props: {
    dataSource: { type: Array, required: true }, // 数据源
    fields: { type: Object, required: true }, // schema.key文件解析
    isStripe: { type: Boolean, default: false }, // 是否包含奇（偶）数背景颜色差异化
    isBorder: { type: Boolean, default: false }, // 是否包含border
    isExpand: { type: Boolean, default: false }, // 是否可以展开
    align: { type: String, default: 'center' }, // 内容对齐方式
  },
  computed: {
    tableData() {
      const { dataSource, sortKey, sortDescend } = this;
      const newDataSource = JSON.parse(JSON.stringify(dataSource));
      return sortKey ? newDataSource.sort((old, cur) => (old[sortKey] - cur[sortKey]) * sortDescend) : newDataSource;
    },
  },
  data() {
    return {
      sortKey: null,
      sortDescend: 1,
    };
  },
  methods: {
    handleSort(key, descend) {
      [
        this.sortKey,
        this.sortDescend,
      ] = [
        key,
        descend,
      ];
    },
  },
};
</script>

<style scoped lang="scss">
  .transform-rotate-90{
    transform: rotate(90deg);
  }

  .transform-rotate-270{
    transform: rotate(270deg);
  }

  .sort-box{
    display: flex;
    flex-direction: column;
    position: relative;
    left: 5px;
    top: 3px;

    .fa-play{
      width: 5px;
      color: #73767a;
      cursor: pointer;

      &.text-color-blue {
        color: #2196F3;
      }
    }
  }

  .table-header, .table-body-row{
    display: flex;

    & > *{
      flex: 1;
      flex-shrink: 0;
    }
  }

  .table-header{
    border-bottom: medium solid #ebeef5;
  }

  .table-header-item, .table-body-col{
    display: flex;
    align-items: center;
    height: 60px;
  }

  .table-header-item{
    font-size: 12px;
    color: #41414C;
    font-weight: 500;
   }

  .table-body-col{
    font-size: 12px;
    color: #41414C;
    font-weight: 400;
  }

  .table-body-row{
    transition: background-color .25s ease;
    border-bottom: thin solid #ebeef5;

    &:hover{
      background-color: #F6FCF6 !important;
    }
  }

  #table{
    overflow: hidden;
  }

  .table-body-stripe{

    &:nth-child(n){
      background: #FAFAFD;
    }

    &:nth-child(2n + 1){
      background: #FFFFFF;
    }
  }

  .border-right-item{

    &:not(:last-child){
      border-right: thin solid #ebeef5;

    }
  }

  .border-table{
    border: thin solid #ebeef5;
  }
</style>
