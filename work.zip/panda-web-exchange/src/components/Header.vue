<i18n>
  zh-CN:
    title:
     - 登录
     - 注册
     - 资产
     - 退出登录
     - 平台公告
     - 社区合伙人
     - 订单
     - '币币账户(充币&提币)'
    btnText:
     - '查看更多'
    text:
     - '扫码下载 APP'
     - 'Android & iOS'
    optionText:
     - 账户和安全
     - 邀请好友
    ipfs:
      - 'IPFS 专区'
      - 'IPFS 算力交易'
      - 'IPFS 算力租赁'
      - 'FIL 期货'
    launchpad: 'Launchpad'
  en-US:
    title:
     - 'Log in'
     - 'Sign up'
     - 'Balances'
     - 'Sign Out'
     - 'Announcement'
     - 'Platform Partner'
     - 'Order'
     - 'Exchange account   (Deposit & withdrawal)'
    btnText:
     - 'View more'
    text:
     - 'Scan to Download App'
     - 'Android & iOS'
    optionText:
     - 'Account & Security'
     - 'Invite Friends'
    ipfs:
     - 'IPFS 专区'
     - 'IPFS 算力交易'
     - 'IPFS 算力租赁'
     - 'FIL 期货'
    launchpad: 'Launchpad'
  zh-TW:
    title:
     - '登錄'
     - '註冊'
     - '資產'
     - '退出登錄'
     - '平台公告'
     - '社區合夥人'
     - '訂單'
     - '幣幣賬戶(充幣&提幣)'
    btnText:
     - '查看更多'
    text:
     - '掃碼下載 APP'
     - 'Android & iOS'
    optionText:
     - '賬戶和安全'
     - '邀請好友'
    ipfs:
     - 'IPFS 专区'
     - 'IPFS 算力交易'
     - 'IPFS 算力租赁'
     - 'FIL 期货'
    launchpad: 'Launchpad'
  ko-KR:
    title:
     - '로그인'
     - '회원 가입'
     - '자산'
     - '로그 아웃'
     - '공지'
     - '플랫폼 파트너'
     - '주문서'
     - '코인 계좌 (충전 및 인출)'
    btnText:
     - '더보기'
    text:
     - '스캔 코드 다운로드 APP'
     - 'Android & iOS'
    optionText:
     - '계정보안'
     - '친구 초대'
    ipfs:
     - 'IPFS 专区'
     - 'IPFS 算力交易'
     - 'IPFS 算力租赁'
     - 'FIL 期货'
    launchpad: 'Launchpad'
</i18n>
<template>
  <div
    id="header"
    :class="['flex-justify-content-space-between', 'flex-align-items-center', isHomeHeader && `header_style_${isHomeHeader}`, localThemeName && `header-common-${localThemeName}`]">
    <div class="flex-align-items-center header-left">
      <div :class="['logo-box', 'background-reset', 'cursor-pointer', isContractHeader ? 'margin-right-23' : 'margin-right-63']" @click.stop="handleGoTo('/')"></div>
      <div class="flex-align-items-center navigation-box" v-if="!isContractHeader">
        <p v-for="(navigation, index) in navigations"
          :key="`navigation-${index}`"
          v-if="navigation.path"
          :class="['flex-align-items-center', 'navigation-item', 'text-size-14', ' cursor-pointer', index === 4 && 'new_desc',activePath.includes(navigation.path)&&'text-color-green']"
          @click.stop="handleGoTo(navigation.path, navigation.isExternal)">
          <!--          <i v-if="index === 3" class="iconfont header_icon_gao">&#xe63d;</i>-->
          <svg class="icon-zanwudingdan header-icon" aria-hidden="true" v-if="navigation.isHot">
            <!--🔥🔥🔥-->
            <use xlink:href="#icon-hot" />
          </svg>
          {{navigation.name}}
        </p>
        <div class="language-btn cursor-pointer-show position-relative navigation-item text-size-14 flex-align-items-center"
             v-if="!$i18n.locale.includes('US')"
             :class="[activePath.includes('ipfs')&&'text-color-green']">
          <h5 class="language-title text-size-14 text-weight-4 right-item">
            <svg class="icon-zanwudingdan header-icon" aria-hidden="true">
              <!--🔥🔥🔥-->
              <use xlink:href="#icon-hot" />
            </svg>
            {{$t('ipfs[0]')}}
            <i class="el-icon-arrow-down position-relative-left-5" />
          </h5>
          <ul class="language-group position-absolute display-none box-shadow" v-if="dropdownStatus">
            <li class="text-align-left" @click.stop="handleGoTo('/ipfs')">
              <svg class="icon ipfs-header-icon" aria-hidden="true">
                <use xlink:href="#icon-suanlijiaoyi" />
              </svg>{{$t('ipfs[1]')}}
            </li>
            <li class="text-align-left text-color-grey">
              <svg class="icon ipfs-header-icon" aria-hidden="true">
                <use xlink:href="#icon-suanlizulin" />
              </svg>{{$t('ipfs[2]')}}
              <!--<p class="text-color-grey padding-left-25">敬请期待</p>-->
            </li>
            <li class="text-align-left text-color-grey">
              <svg class="icon ipfs-header-icon" aria-hidden="true">
                <use xlink:href="#icon-qihuo" />
              </svg>{{$t('ipfs[3]')}}
            </li>
          </ul>
        </div>
      </div>
      <!--   合约币币交易Header   -->
      <ContractHeader v-if="isContractHeader" />
    </div>
    <div class="flex-justify-content-space-between header-right">
      <!-- 用户未登录 -->
      <div
        class="login-btn cursor-pointer"
        @click.stop="handleGoTo('/login')"
        v-if="!isLogin">
        {{$t('title[0]')}}
      </div>
      <!--   登录   -->
      <div
        class="register-btn cursor-pointer"
        @click.stop="handleGoTo('/register')"
        v-if="!isLogin">
        {{$t('title[1]')}}
      </div>
      <!--   注册   -->
      <!-- 用户已登录 -->
      <div class="assets-btn position-relative cursor-pointer-show" v-if="isLogin">
        <h5 class="assets-title text-size-14 text-weight-4 right-item" @click.stop="handleGoTo('/coinOrder')">
          {{$t('title[6]')}}
          <!--<i class="el-icon-arrow-down position-relative-left-5"></i>-->
        </h5>
        <!--<ul class="assets-group position-absolute display-none box-shadow" v-if="dropdownStatus">
          <li
            v-for="(order, index) in orderList"
            :key="`order-${index}`"
            class="text-align-left"
            @click.stop="order.show?handleGoTo(order.path):handleShowAreaDialog('Agreement',order.path)"
          >{{order.name}}</li>
        </ul>-->
      </div>
      <!--<div class="assets-btn position-relative cursor-pointer-show" v-if="isContractHeader && isLogin">
        <h5 class="assets-title text-size-14 text-weight-4 right-item">
          {{$t('title[6]')}}
          &lt;!&ndash;<i class="el-icon-arrow-down position-relative-left-5"></i>&ndash;&gt;
        </h5>
        <ul class="contract-group position-absolute display-none box-shadow" v-if="dropdownStatus">
          <li
            v-for="(order, index) in contractList"
            :key="`order-${index}`"
            class="text-align-left"
            @click.stop="handleGoTo(order.path)"
          >{{order.name}}</li>
        </ul>
      </div>-->
      <div class="assets-btn position-relative cursor-pointer-show" v-if="isLogin">
        <h5 class="assets-title text-size-14 text-weight-4 right-item" @click.stop="handleGoTo('/assetManagement')">
          {{$t('title[2]')}}
          <!--<i class="el-icon-arrow-down position-relative-left-5"></i>-->
        </h5>
        <ul class="position-absolute display-none box-shadow" v-if="dropdownStatus&&systemConfig.isShowFuturesAssets==1">
          <li
            v-for="(assets, index) in assetsList"
            :key="`assets-${index}`"
            class="text-align-left"
            @click.stop="assets.show?handleGoTo(assets.path):handleShowAreaDialog('Agreement',assets.path)">
            {{assets.name}}
          </li>
<!--          <el-divider class="divider-horizontal" />-->
<!--          <li-->
<!--            v-for="(order, index) in orderList"-->
<!--            :key="`order-${index}`"-->
<!--            class="text-align-left"-->
<!--            @click.stop="handleGoTo(order.path)"-->
<!--          >{{order.name}}</li>-->
        </ul>
      </div>
      <div class="cursor-pointer-show position-relative" v-if="isLogin">
        <h5 class="user-title text-size-14 text-weight-4 right-item">
          <!--          <i class="el-icon-user text-size-14 margin-right-5"/>-->
          <i class="icon font_family icon-yonghu2 header_user_icon margin-right-5" />
        </h5>
        <div
          class="header_user_list position-absolute display-none box-shadow"
          v-if="dropdownStatus">
          <div class="header_user text-size-14">
            <p>{{userInfo.floginname}}</p>
            <p class="text-size-12 user_uid_desc">UID:{{userInfo.fshowid}}</p>
          </div>
          <div v-if="dropdownStatus">
            <li
              v-for="(user, index) in userList"
              :key="`user-${index}`"
              class="text-align-left"
              @click.stop="handleGoTo(user.path)">
              {{user.name}}
            </li>
            <li
              key="user-loginout"
              class="text-align-left"
              @click.stop="handleLoginOut">
              {{$t('title[3]')}}
            </li>
            <!--   退出登录   -->
          </div>
        </div>
      </div>
      <div class="cursor-pointer-show position-relative">
        <h5 class="user-title text-size-14 text-weight-4 right-item">
          <i class="icon font_family icon-tixing-copy header_icon_placard cursor-pointer" />
        </h5>
        <div
          class="header_placard position-absolute text-size-12 text-color-black display-none box-shadow"
          v-if="dropdownStatus">
          <div class="header_placard_wrapper">
            <p class="placard_title text-color-black margin-bottom-10">{{$t('title[4]')}}</p>
            <!--   平台公告   -->
            <el-divider />
            <div
              class="flex-direction-column placard_layout"
              v-for="(notice, index) in noticeList"
              :key="`notice-${index}`"
              @click.stop="handleGoToNotice(notice.html_url)">
              <p class="text-size-14 cursor-pointer overflow-hidden white-space-nowrap text-overflow-ellipsis">{{notice.title}}</p>
              <div
                v-if="notice.created_at"
                class="flex-direction-row flex-align-items-center opacity-6 margin-top-4 margin-bottom-4 placard_layout_time">
                <span>{{notice.created_at | timeStampToDate('YYYY-MM-DD')}}</span>
                <span class="placard_layout_desc">
                  {{notice.created_at | timeStampToDate('HH:mm:ss')}}
                </span>
              </div>
              <el-divider />
            </div>
          </div>
          <div class="text-align-center placard_button">
            <a
              :href="`https://pandaexsupport.zendesk.com/hc/${language($i18n.locale)}/categories/360002124454-%E5%85%AC%E5%91%8A%E4%B8%AD%E5%BF%83`"
              target="_blank"
            >{{$t('btnText[0]')}}</a>
            <!--   查看更多   -->
          </div>
        </div>
      </div>
      <el-divider direction="vertical" class="header_line opacity-2"/>
      <div class="cursor-pointer-show position-relative">
        <h5 class="user-title text-size-14 text-weight-4 right-item">
          <i class="icon font_family icon-xiazai1 header_icon_download cursor-pointer" />
        </h5>
        <div
          class="position-absolute text-size-12 text-color-black display-none box-shadow header_popover"
          v-if="dropdownStatus">
          <div class="flex-justify-content-center flex-align-items-center header_download_wrapper">
            <div class="flex-justify-content-center wrapper_left">
              <div
                class="header_qr_code background-reset"
                :style="{backgroundImage:`url(${link})`}"></div>
            </div>
            <div class="flex-direction-column wrapper_right">
              <p>{{$t('text[0]')}}</p>
              <!--   扫码下载 APP   -->
              <p>{{$t('text[1]')}}</p>
              <!--   Android &amp; iOS   -->
              <el-button size="small" class="wrapper_button" type="primary">
                <a
                  class="text-decoration-line-none text-color-white"
                  :href="`https://pandaexsupport.zendesk.com/hc/${language($i18n.locale)}/articles/360037145754`"
                  target="_blank">
                  {{$t('btnText[0]')}}
                  <i class="el-icon-arrow-right el-icon--right" />
                </a>
                <!--   查看更多   -->
              </el-button>
            </div>
          </div>
        </div>
      </div>
      <!-- <div class="order-btn cursor-pointer-show position-relative">
        <h5 class="order-title text-size-14 text-weight-4 right-item">
          {{moneySelect}}
          <i class="el-icon-arrow-down position-relative-left-5" />
        </h5>
        <ul class="order-group position-absolute display-none box-shadow" v-if="dropdownStatus">
          <li
            v-for="(money, index) in moneyList"
            :key="`money-${index}`"
            class="text-align-left"
            @click.stop="updateMoneySelect(money);dropdownStatus = false"
          >{{money}}</li>
        </ul>
      </div>-->
      <div class="language-btn cursor-pointer-show position-relative">
        <h5 class="language-title text-size-14 text-weight-4 right-item">
          {{languages.find(lang=>lang.key === $i18n.locale).name}}
          <i class="el-icon-arrow-down position-relative-left-5" />
        </h5>
        <ul
          class="language-group position-absolute display-none box-shadow"
          v-show="dropdownStatus">
          <li
            v-for="(language, index) in languages"
            :key="`language-${index}`"
            class="text-align-left"
            @click.stop="handleSetLanguage(language.key)">
            {{language.name}}
          </li>
          <li
            id="google_translate_element"
            key="language-google-translate-element"
            class="text-align-center padding-left-0" />
        </ul>
      </div>
    </div>
    <Agreement ref="Agreement" :contractPath="contractPath" />
  </div>
</template>

<script>
import {
  mapState, cookies, mapActions, mapMutations, mapGetters, QRCode,
} from '../utils/common';
import api from '../api/apiModule_1';
import { setI18nLanguage } from '../setup/i18n-setup';
import { scrollMixin } from '../plugins/mixins';
import { TITLE } from '../utils/constant';
import ContractHeader from '../views/ContractExchange/ContractHeader.vue';
import Agreement from '../views/ContractExchange/Agreement.vue';

let timer;

const qrCode = new QRCode(new Image(), {
  width: 114,
  height: 114,
  colorDark: '#000000',
  colorLight: '#ffffff',
  correctLevel: QRCode.CorrectLevel.H,
  render: 'table', // 默认使用了canvas，为了避免混乱这里时候用table
});

export default {
  name: 'header',
  mixins: [scrollMixin],
  scrollEl: 'app',
  components: { ContractHeader, Agreement },
  computed: {
    ...mapState(['userInfo', 'moneyList', 'moneySelect', 'coinList', 'systemConfig']),
    ...mapState('exchange', ['tradeSummaryList']),
    ...mapGetters(['isLogin']),
    ...mapState('home', ['noticeList']),
    navigations() {
      return [
        {
          name: this.$t('markets'), // 币币交易
          path: '/markets',
          isExternal: false,
        },
        {
          name: this.$t('exchange'), // 币币交易
          path: '/exchange',
          isExternal: false,
        },
        /*  {
          name: this.$t('future'), // 合约
          path: '/future',
          isExternal: false,
        }, */
        {
          name: this.$t('otc'), // 法币交易
          path: process.env.VUE_APP_PANDAOTC,
          isExternal: true,
        },
        {
          name: this.$t('beginnerTutorial'), // 新手营
          path: '/beginnerTutorial',
          isExternal: false,
        },
        {
          name: this.$t('title[5]'), // 新手营
          path: `https://pandaexsupport.zendesk.com/hc/${this.language(this.$i18n.locale)}/articles/360043914414-%E7%86%8A%E7%8C%AB%E5%85%A8%E7%90%83%E7%AB%99%E5%85%B3%E4%BA%8E%E6%8B%9B%E5%8B%9F%E5%B9%B3%E5%8F%B0%E5%90%88%E4%BC%99%E4%BA%BA%E7%9A%84%E5%85%AC%E5%91%8A`,
          isExternal: true,
        },
        {
          name: this.$t('launchpad'), // 新手营
          path: '/launchpad',
          isExternal: false,
        },
        /* {
          name: this.$t('votingCurrency'), // 投票上币
          path: `https://pandaexsupport.zendesk.com/hc/${this.language(this.$i18n.locale)}/articles/360044755553`,
          isExternal: true,
        }, */
        /* {
          name: this.$t('platformCurrency'), // 秒懂BAMB
          path: '/platformCurrency',
          isExternal: false,
        },
        {
          name: this.$t('votingCurrency'), // 投票上币
          path: '/votingCurrency',
          isExternal: false,
        }, */
      ];
    },
    assetsList() {
      const { userInfo: { openFutures } } = this;
      return [{
        name: this.$t('title[7]'), // 我的资产
        path: '/assetManagement',
        show: true,
      }, {
        name: this.$t('contractAssets'), // 合约账户
        path: '/contract/assets',
        show: openFutures === 1,
      }, /* {
        name: this.$t('rechargeCoin'), // 充币
        path: '/assetManagement/rechargeCoin',
        show: true,
      }, {
        name: this.$t('withdrawCoin'), // 提币
        path: '/assetManagement/withdrawCoin',
        show: true,
      }, */
      ];
    },
    /*   orderList() {
      const { userInfo: { openFutures } } = this;
      return [
        { name: this.$t('transactionOrder'), path: '/coinOrder', show: true }, // 交易订单
         { name: this.$t('contractOrder'), path: '/contractOrder', show: openFutures === 1 },
      ];
    }, */
    contractList() { // 合约信息下拉列表
      return [
        { name: '交割/结算记录', path: '/ContractTransaction/DeliveryRecord' }, // 交割/结算记录
        { name: '强平订单', path: '/ContractTransaction/StrongOrder' }, // 强平订单
        { name: '风险准备金', path: '/ContractTransaction/RiskReserve' }, // 风险准备金
        { name: '交易数据', path: '/ContractTransaction/TransactionTata' }, // 交易数据
        { name: this.$t('contractPositions'), path: '/contract/position' }, // 交割合约仓位档位
      ];
    },
    userList() {
      return [
        { name: this.$t('optionText[0]'), path: '/userManagement' }, // 账户和安全
        { name: this.$t('optionText[1]'), path: '/inviteFriends' }, // 邀请好友
      ];
    },
    languages() {
      return [
        { name: this.$t('chinese'), key: 'zh-CN' }, // 简体中文
        { name: this.$t('traditionalChinese'), key: 'zh-TW' }, // 繁体中文
        { name: 'English', key: 'en-US' }, // 英文
        { name: this.$t('korean'), key: 'ko-KR' },
      ];
    },
    /* nickName() {
      return this.userInfo.floginname;
    }, */
    localThemeName() {
      const { path } = this.$route;

      if (path === '/exchange') return 'exchange';
      if (path === '/markets') return 'exchange';
      return null;
    },
    isHomeHeader() { // 判断是否是首页
      const { path } = this.$route;
      if (path === '/') return 'home';
      return null;
    },
    isContractHeader() { // 是否是合约交易页面
      const { path } = this.$route;
      return path === '/future';
    },
  },
  methods: {
    ...mapState(['userInfo']),
    ...mapActions(['fetchUserInfo', 'fetchCoinList']),
    ...mapMutations(['updateUserInfo', 'updateMoneySelect']),
    handleShowAreaDialog(target, path) { // 打开改变单位弹窗
      this.contractPath = path;
      this.$refs[target].handleDialogShow();
    },
    handleGoTo(path, isExternal) {
      this.dropdownStatus = false;
      const { tradeSummaryList, coinList } = this;
      const currentCoinId = coinList.find(({ coinType }) => coinType.name === 'BTC') ?.coinType ?.id;

      if (!path) return;
      if (isExternal) { // 外部跳转
        window.open(path);
        return;
      }
      if (path !== '/future') {
        this.activePath = path;
      }
      if (path === '/exchange' && localStorage.getItem('exchangeSymbol')) {
        this.$router.push(`/exchange?id=${localStorage.getItem('exchangeSymbol')}`);
        return;
      }
      switch (path) {
        case '/exchange':
          if (tradeSummaryList['BTC/USDT']) this.$router.push(`/exchange?id=${tradeSummaryList['BTC/USDT'].tradeId}`);
          break;
        case '/assetManagement/rechargeCoin':
          if (currentCoinId) this.$router.push(`/assetManagement/rechargeCoin?id=${currentCoinId}`);
          break;
        case '/assetManagement/withdrawCoin':
          if (currentCoinId) this.$router.push(`/assetManagement/withdrawCoin?id=${currentCoinId}`);
          break;
        default:
          this.$router.push(path);
          break;
      }
    },
    handleLoginOut() {
      const { userInfo } = this;
      api.loginOut()
        .then(() => {
          this.updateUserInfo({
            ...userInfo,
            floginname: null,
          });
          cookies.expire('token')
            .expire('ticket');
          this.$router.push('/');
        });
    },
    /* handleScroll(_, scrollTop) {
      const { clientHeight } = document.getElementById('header');
      this.isFixed = scrollTop >= clientHeight;
    }, */
    handleGoToNotice(path) { // 跳转到外部链接
      if (path) window.open(path);
    },
    handleSetLanguage(lang) {
      this.dropdownStatus = false;
      setI18nLanguage(lang);
      const { title } = this.$route.meta;
      window.document.title = typeof title === 'function' ? title() : title || TITLE; // 动态修改窗口标题
    },
  },
  watch: {
    isLogin: {
      handler(n, o) {
        if (n !== o && n) { // 登录的全局接口
          this.fetchCoinList();
        }
      },
      deep: true,
      immediate: true,
    },
    dropdownStatus(n, o) {
      if (n !== o && !n) {
        timer = setTimeout(() => {
          this.dropdownStatus = true;
          clearTimeout(timer);
        }, 1000);
      }
    },
  },
  created() {
    qrCode.makeCode(process.env.VUE_APP_DOWNLOAD); // ios生成二维码
    // eslint-disable-next-line no-underscore-dangle,no-undef
    qrCode._oDrawing._elImage.onload = (event) => {
      this.link = event.target.src;
    };
    if (cookies.get('token')) this.fetchUserInfo();
    // this.fetchMoneyList();
  },
  data() {
    return {
      isFixed: false,
      dropdownStatus: true, // 下拉框展示状态
      link: '', // 下载链接
      noticeIndex: 0,
      speed: 3,
      isShowPick: true,
      contractPath: '',
      activePath: '',
    };
  },
  destroyed() {
    clearTimeout(timer);
  },
  beforeDestroy() {
    qrCode.clear(); // 清除ios生成二维码
  },
  mounted() {
    const head = document.getElementsByTagName('head')[0];
    const script = document.createElement('script');
    const googleTranslateUrl = 'https://translate.google.cn/translate_a/element.js';
    script.setAttribute('src', `${googleTranslateUrl}?cb=googleTranslateElementInit`);
    head.appendChild(script);
    script.onload = () => {
      const observer = new MutationObserver((mutationsList) => { // DOM EVENT3, 处理Zendesk展示隐藏
        mutationsList.forEach(({ type, target }) => {
          if (type === 'attributes' && target === document.querySelector('iframe.goog-te-menu-frame')) { // Zendesk-DOM
            observer.disconnect(); // goog-te-gadget-icon
            const selectBtns = document.getElementById('google_translate_element').querySelectorAll('img');
            selectBtns.forEach(el => el.setAttribute('src', el.getAttribute('src').replace('https://www.google.com', 'https://www.google.cn')));
            // eslint-disable-next-line no-param-reassign
            target.onmouseout = (event) => { event.target.style.display = 'none'; };
          }
        });
      });

      observer.observe(document.documentElement, {
        attributes: true,
        childList: true,
        subtree: true,
      });
    };

    const path = document.location.pathname;
    if (path !== '/future') {
      this.activePath = path;
    }
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.header-icon {
  width: 15px;
  height: 14px;
  padding-right: 2px;
}

.ipfs-header-icon{
  width: 15px;
  height: 14px;
  margin-right: 10px;
}

.padding-left-0 {
  padding-left: 0 !important;
}

.box-shadow {
  box-shadow: 1px 1px 1px 1px rgba(0, 0, 0, 0.1);
}

.margin-bottom-18 {
  margin-bottom: 18px;
}

.header_user_icon {
  font-size: 18px;
}

.assets-group {
    width: 170px !important;
  left: -84px;
}

.contract-group {
  width: 160px !important;
  left: -104px;
}

.order-group {
  left: -60px;
}

.language-group {
  left: -32px;
}

.header_user_list {
  width: 210px;
  min-width: 210px !important;
  /*height: 235px;*/
  min-height: 192px !important;
  background-color: white;
  left: -180px;

  .header_user {
    height: 66px;
    background-size: cover;
    background-color: #f9f9f9;

    p {
      padding-top: 17px;
      padding-left: 10px;
    }

    .user_uid_desc {
      color: #54616f;
    }

    .margin-top-15 {
      margin-top: 15px;
    }
  }
  li {
    padding-left: 10px !important;
    width: 100%;
    list-style: none;
  }
}

.header_popover {
  // header 下载二维码
  padding: 10px !important;
  height: 126px;
  left: -224px;
  background: #ffffff;
  min-width: 260px;
}

.header_placard {
  // header 公告
  width: 384px;
  min-width: 384px !important;
  left: -350px;

  .header_placard_wrapper {
    margin: 20px 20px 0 20px;
  }
}

.header_balances {
  width: auto!important;
 /* min-width: 300px !important;*/
  left: -150px;
}

.placard_layout {
  padding: 6px 0;
  line-height: 20px;

  &:nth-child(2),
  &:nth-last-child(2) {
    padding-top: 0;
  }

  &:last-child {
    padding-top: 0;
  }

  p {
    width: 100%;
    font-weight: 400;

    &:hover {
      color: #1581f2;
    }
  }

  .placard_layout_line {
    margin-top: 10px;
  }

  .placard_layout_desc {
    margin-left: 20px;
  }
}

.placard_button {
  width: 100%;
  flex: 1;
  color: #1581f2;
  margin-top: 7px;
  margin-bottom: 12px;

  a {
    color: #1581f2;
    text-decoration: none;
    &:hover {
      text-decoration: underline;
    }
  }
}

.header_download_wrapper {
  width: 100%;
  height: 100%;
  padding: 20px 0;

  .wrapper_left {
    width: 100px;
    height: 100px;
    border: 1px solid #eeeeee;
    margin-right: 20px;
  }

  .wrapper_right {
    font-size: 15px;

    p {
      width: 110px;
      line-height: 18px;
    }
  }

  .wrapper_button {
    width: 108px;
    background: #27c08b;
    transition: all 0.25s ease-in-out;
    border: none;
    margin-top: 10px;

    &:hover {
      background: #2ed89d;
    }
  }
}

.header_qr_code {
  margin: 5px;
  width: 90px;
  height: 90px;
}

.header_icon_placard {
  font-size: 19px;
}

.header_icon_placard,
.header_icon_download {
  transition: color 0.25s ease-in-out;

  &:hover {
    color: #27c08b;
  }
}

.header_icon_download {
  font-size: 21px;
}

.header_icon_gao {
  width: 15px;
  height: 20px;
  margin-right: 5px;
  line-height: 23px;
}

.header_icon_out {
  width: 15px;
  height: 20px;
  margin-right: 5px;
}

.margin-left-30 {
  margin-left: 30px;
  &.header-common-exchange {
    // 头部主题功能
    background: #13252f;

    .border-radius-select {
      background: #13252f;
    }
  }
}
#header {
  height: 50px;
  font-size: 14px;
  color: #e0e0e7;
  background-color: rgba(27, 37, 44, 1);
  // background-image: url("../assets/images/header.png");
  padding: 0 20px;
  left: 0;
  right: 0;
  z-index: 2000;
  transition: background-color, top 0.25s ease-in-out;

  &.position-fixed {
    top: 0;
    background-color: rgba(27, 37, 44, 0.4);

    & + * {
      margin-top: 60px;
    }
  }

  &.header_style_home {
    background-color: rgba(#1b252c, 0.4);
  }

  &.header-common-exchange {
    // 头部主题功能
    background-color: #13252f;

    .border-radius-select {
      background-color: #13252f;
    }
  }
}

.header_line {
  margin-left: 0;
  height: 23px;
  background: #ffffff !important;
}

.new_desc {
  position: relative;

  &:hover {
    color: #27c08b;
  }

  &::after {
    position: absolute;
    /*// top: -10px;*/
    top: -10px;
    right: -22px;
    content: "";
    width: 22px;
    height: 16px;
    /*background-image: url("../assets/images/header_hot.png");*/
    background-color: transparent;
    background-repeat: no-repeat;
    background-attachment: inherit;
    background-position: center;
    background-origin: padding-box;
    background-clip: border-box;
    background-size: contain;
  }
}

.el-divider {
  background: #434345;
}

.logo-box {
  background-image: url("../assets/logo.png");
  width: 162px;
  height: 32px;
}

.margin-right-63 {
 margin-right: 63px;
}

.margin-right-23 {
  margin-right: 23px;
}

.navigation-item {
  transition: color 0.25s ease-in-out;

  &:hover {
    color: #27c08b;
  }

  &:not(:last-child) {
    margin-right: 30px;
  }
}

.right-item {
  transition: color 0.25s ease-in-out;

  &:hover {
    color: #27c08b;
  }
}

.fa-bell {
  width: 15px;
}

.header-left {
  padding-right: 30px;
}

.header-right {
  align-items: center;

  & > *:not(:last-child) {
    margin-right: 17px;
    cursor: pointer;
  }
}

.cursor-pointer-show {
  cursor: pointer;
  line-height: 0.5;

  .display-none {
    background-color: white;
    color: #1f1f1f;
    z-index: 2002;
    list-style-type: none;
    margin: 0;
    padding: 0;
    top: 70%;
    border-radius: 2px;
    text-align: left;

    li {
      line-height: 3;
      // border-bottom: thin solid #EEEEEE;
      padding: 0 20px;
      transition: background-color 0.25s ease;

      &:hover {
        background-color: #e8f0fb;
      }
    }
  }

  .el-icon-arrow-down {
    transition: transform 0.25s ease-in-out;
  }

  &:hover {
    .el-icon-arrow-down {
      transform: rotate(180deg);
    }

    .display-none {
      display: block;

      li {
        white-space:nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
    }
  }
}

.border-radius-select {
  background: #13252f;
  padding: 9px 20px;
  border-radius: 50px;
}

.position-relative-left-5 {
  position: relative;
  left: 5px;
}

.register-btn {
  border: thin solid #27c08b;
  padding: 6px 15px;
  border-radius: 1px;
  color: #27c08b;
  transition: background-color, color 0.25s ease-in-out;

  &:hover {
    background-color: #27c08b;
    color: white;
  }
}

.login-btn {
  transition: color 0.25s ease-in-out;
  color: #ffffff;

  &:hover {
    color: #27c08b;
  }
}

.text-color-green {
  color: #27c08b;
}

.el-divider--horizontal {
  background: #e8f0fb;
  margin: 1px 0;
}
.language-group {
  #google_translate_element {
    &:hover {
      &::v-deep .goog-te-gadget-simple {
        background-color: #e8f0fb;
      }
    }
  }

  ::v-deep .goog-te-gadget-simple {
    border-left: 0;
    border-top: 1px solid #e9f0fb;
    border-bottom: 0;
    border-right: 0;
    font-size: 10pt;
    display: inline-block;
    padding-top: 0;
  }
}
</style>
