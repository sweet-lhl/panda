<i18n>
  zh-CN:
   text:
    - 搜索
    - '---暂无相关数据---'
    - 请选择
  en-US:
   text:
    - 'Search'
    - '---No data---'
    - 'Please choose'
  zh-TW:
   text:
    - '搜索'
    - '---暫無相關數據---'
    - '請選擇'
  ko-KR:
   text:
    - '검색'
    - '---관련 데이터가 없습니다---'
    - '선택하세요'
</i18n>
<template>
  <div id="select" :class="['position-relative', optionStatus && 'active']" @click.stop="handleStopPropagation">
    <div :class="['flex-direction-column', 'flex-align-items-stretch','select-value', disabled ? 'cursor-none' : 'cursor-pointer', 'flex-justify-content-space-between', optionStatus && 'icon-up']"
         @click.stop="handleChangeOptionStatus">
      <div :class="['flex-align-items-center', 'select-value-header', selectLabel && 'height-half', 'user-select-none']">
          <span :class="['text-color-grey', 'select-value-header-content',optionStatus ? 'active' : 'text-size-12']">{{placeholder}}</span>
      </div>
      <div :class="['flex-align-items-center', 'select-value-footer', selectLabel && 'height-half']" v-if="selectLabel">
        <slot name="prefix"></slot>
        <span class="text-color-black margin-left-10">{{selectLabel}}</span>
      </div>
    </div>
    <transition name="custom-classes-transition" enter-active-class="animated fadeIn" mode="out-in">
      <div class="select-option position-absolute" v-if="optionStatus">
        <el-input v-model="searchValue" :placeholder="$t('text[0]')" prefix-icon="el-icon-search"/>
        <div class="select-option-scroll">
          <div v-for="(option, index) in selectOptions"
               :key="`select-option-${index}`"
               :class="['select-option-item', option.value === value  && 'active']"
               @click.stop="handleClick(option.value)">
            <slot name="option" :option="option">{{option.label}}</slot>
          </div>
        </div>
        <slot name="empty" v-if="!options.length"><p class="text-align-center text-color-grey">{{$t('text[1]')}}</p></slot>
      </div>
    </transition>
  </div>
</template>

<script>
import emitter from 'element-ui/src/mixins/emitter';

export default {
  name: 'select',
  mixins: [emitter],
  props: {
    value: {
      type: String,
      required: true,
    },
    placeholder: { type: String, default: '请选择' }, // 请选择
    options: { type: Array, required: true },
    disabled: { type: Boolean, default: false },
  },
  computed: {
    selectLabel() {
      const { value, options } = this;
      return options.find(option => option.value === value)?.label;
    },
    selectOptions() {
      const { options, searchValue } = this;
      return options.filter(option => new RegExp(searchValue, 'igm').test(option.label));
    },
  },
  data() {
    return {
      optionStatus: false,
      searchValue: '',
    };
  },
  methods: {
    handleClick(value) {
      this.$emit('input', value);
      this.dispatch('ElFormItem', 'el.form.change', value);
      this.$nextTick(() => {
        this.optionStatus = false;
      });
    },
    handleChangeOptionStatus() {
      this.optionStatus = !this.optionStatus;
    },
    handleCloseOptionPlan() {
      this.optionStatus = false;
      return false;
    },
    handleStopPropagation(event) {
      event.stopPropagation();
      return false;
    },
  },
  mounted() {
    return window.addEventListener
      ? document.addEventListener('click', this.handleCloseOptionPlan, false)
      : document.attachEvent('click', this.handleCloseOptionPlan, false);
  },
  destroyed() {
    return window.removeEventListener
      ? document.removeEventListener('click', this.handleCloseOptionPlan, false)
      : document.detachEvent('click', this.handleCloseOptionPlan, false);
  },
};
</script>

<style scoped lang="scss">
#select{
  height: 50px;
  padding: 0 20px;
  border: thin solid #DDDDDD;
  border-radius: 3px;

  &.active{
    border: thin solid #357ce1;
  }
}

.height-half{
  height: 50%;
  overflow: hidden;
}

.el-input{
  width: calc(100% - 40px);
  background-color: white;
  margin: 10px 20px;
}

  .select-value{
    height: 100%;
    z-index: 9;

    .select-value-header{
      color: #41414C;
      transition: transform .25s ease;

      .active{
        // transform: translateY(-6px) scale(.85);
        font-size: 12px;
      }
    }

    .select-value-footer{
      font-size: 12px;
      color: #41414C;
    }

    & > *{
        flex-shrink: 0;
        flex-grow: 1;
        line-height: 1;
      }

    &:after{
      content: "\e6df";
      font-family: element-icons;
      position: absolute;
      top: 0;
      right: 20px;
      font-size: 12px;
      color: #C0C4CC;
      transition: transform .25s ease;
    }

    &.icon-up{

      &::after{
        transform: rotate(180deg);
      }
    }
  }

  .select-option{
    top: 55px;
    left: 0;
    right: 0;
    border: thin solid #DDDDDD;
    border-radius: 3px;
    z-index: 20;
    background-color: white;
    box-shadow: 0 0 1px 0 rgba(8,31,64,.31), 0 4px 8px -2px rgba(8,31,64,.25);

    .select-option-scroll{
      min-height: 90px;
      max-height: 280px;
      overflow: auto;
      background-color: white;
    }

    .select-option-item{
      background-color: white;
      height: 40px;
      line-height: 40px;
      padding: 0 16px;
      font-size: 12px;
      cursor: pointer;
      color: black;
      transition: background-color .25s ease;

      &.active{
        background-color: #e8f0fb;
        color: #357ce1;
      }

      &:hover{
        background-color: #f8f9fa;
      }
    }

    ::v-deep .el-input__inner{
        padding-left: 30px !important;
    }
  }
</style>
