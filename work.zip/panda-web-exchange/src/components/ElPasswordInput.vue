<template>
  <el-input :placeholder="placeholder" :type="type" @change="handleChange" @focus="handleFocus" @blur="handleBlur" v-model="value">
    <template #suffix v-if="showPassword">
      <Icon :icon="type !== 'password' ? 'eye' : 'eye-slash'" @click.stop="checkPasswordIcon" class="cursor-pointer"/>
    </template>
  </el-input>
</template>

<script>
import emitter from 'element-ui/src/mixins/emitter';

export default {
  name: 'elPasswordInput',
  mixins: [emitter],
  props: {
    value: { type: String, default: '' },
    placeholder: { type: String },
    showPassword: { type: Boolean, default: true },
  },
  data() {
    return {
      type: 'password',
    };
  },
  methods: {
    handleChange(value) {
      this.$emit('input', value);
      this.dispatch('ElFormItem', 'el.form.input', [value]);
    },
    handleFocus(event) {
      this.$emit('focus', event);
      this.dispatch('ElFormItem', 'el.form.focus', [event.target.value]);
    },
    handleBlur(event) {
      this.$emit('blur', event);
      this.dispatch('ElFormItem', 'el.form.blur', [event.target.value]);
    },
    checkPasswordIcon() {
      const { type } = this.$data;
      this.type = type === 'text' ? 'password' : 'text';
    },
  },
};
</script>

<style scoped>

</style>
