<i18n>
  zh-CN:
    emptyText:
      - 暂无数据
  en-US:
    emptyText:
      - 'No Record'
  zh-TW:
    emptyText:
      - '暫無數據'
  ko-KR:
    emptyText:
      - '기록 없음'
</i18n>
<template>
  <div class="flex-direction-column flex-align-items-center empty">
    <svg class="icon empty-icon" aria-hidden="true">
      <use xlink:href="#icon-zanwushuju"></use>
    </svg>
    <span class="empty-desc">{{$t('emptyText[0]')}}</span>
  </div>
</template>

<script>
export default {
  name: 'Empty',
};
</script>

<style lang="scss" scoped>
  .empty {
    margin-top: 60px;
    margin-bottom: 30px;
  }

  .empty-icon {
    width: 30px;
    height: 30px;
  }

  .empty-desc {
    font-size: 12px;
    color: #C6C6C9;
    margin-top: 10px;
  }
</style>
