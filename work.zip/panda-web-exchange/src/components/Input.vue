<template>
<div id="input" :class="['cursor-text', 'position-relative', focusStatus && 'active', showPassword && 'password-controlled']">
  <input :id="id"
         v-model="inputValue"
         @input="handleInput"
         :class="['input-reset', 'position-absolute']"
         :type="inputType"
         @focus="handleFocus"
         :disabled="disabled"
         :autocomplete="autoComplete"
         @blur="handleBlur"
         @change="handleChange"/>
  <label :for="id" :class="['input-placeholder', 'text-color-grey', disabled && 'cursor-none', 'user-select-none', (focusStatus || value) && 'active']">
    <slot name="placeholder">{{placeholder}}</slot>
  </label>
  <Icon :icon="inputType !== 'password' ? 'eye' : 'eye-slash'" class="position-absolute" @click.stop="checkPasswordIcon" v-if="showPassword"/>
  <div class="input-suffix position-absolute text-size-12 cursor-pointer" v-if="$slots.suffix"><slot name="suffix"></slot></div>
</div>
</template>

<script>
import emitter from 'element-ui/src/mixins/emitter';

export default {
  name: 'Input',
  mixins: [emitter],
  props: {
    value: {
      type: String,
      required: true,
    },
    id: { type: String, required: true },
    autocomplete: { type: Boolean, default: false },
    type: { type: String, default: 'text' },
    placeholder: { type: String, default: '请输入' },
    disabled: { type: Boolean, default: false },
    showPassword: { type: Boolean, default: false },
  },
  computed: {
    autoComplete() {
      const { autocomplete } = this;
      return autocomplete ? 'no' : 'off';
    },
  },
  watch: {
    value(n, o) {
      if (n !== o) this.inputValue = n;
    },
    type(n, o) {
      if (n !== o) this.inputType = n;
    },
  },
  data() {
    return {
      focusStatus: false,
      inputValue: this.value,
      inputType: this.type,
    };
  },
  methods: {
    handleInput(event) {
      this.$emit('input', event.target.value);
      this.dispatch('ElFormItem', 'el.form.input', [this.value]);
    },
    handleFocus() {
      this.focusStatus = true;
    },
    handleBlur(event) {
      this.focusStatus = false;
      this.dispatch('ElFormItem', 'el.form.blur', [event.target.value]);
    },
    handleChange(event) {
      this.dispatch('ElFormItem', 'el.form.change', [event.target.value]);
    },
    checkPasswordIcon() {
      const { inputType } = this.$data;
      this.inputType = inputType === 'text' ? 'password' : 'text';
    },
    calcPaddingRight() {
      const inputEl = document.querySelector('.input-reset');
      const suffixEl = document.querySelector('.input-suffix');
      if (inputEl && suffixEl) inputEl.style.paddingRight = `${suffixEl.clientWidth}px`;
    },
  },
  mounted() {
    this.calcPaddingRight();
  },
};
</script>

<style scoped lang="scss">
  .icon {
    float: right;
    display: flex;
    line-height: 50px;
  }
  #input{
    height: 50px;
    border: thin solid #DDDDDD;
    padding: 0 10px;
    border-radius: 3px;
    overflow: hidden;
    box-sizing: border-box;
    line-height: 1.15;

    &.active{
      border: thin solid #357ce1;
    }
  }

  .input-placeholder{
    transition: transform .25s ease;
    font-size: 14px;
    display: inline-block;
    position: relative;
    top: 50%;
    z-index: 10;
    transform: translateY(-50%);
  }

  .input-reset{
    width: 100%;
    top: 0;
    right: 0;
    left: 0;
    bottom: 0;
    font-size: 14px;
    color: black;
    z-index: 10;
    height: 100%;
    padding-top: 20px!important;
  }

  label.active{
    transform: translate(-5px, -100%) scale(.85);
  }

  .password-controlled{ // 密码控件受控
    position: relative;

      .svg-inline--fa{
        top: 50%;
        bottom: 0;
        right: 5px;
        width: 20px;
        transform: translateY(-50%);
        cursor: pointer;
        z-index: 11;
        color: #999999
      }

    .input-reset{
      padding: 20px 25px 0 0 !important;
    }
  }

  .input-suffix{
    right: 0;
    padding: 5px;
    top: 50%;
    transform: translateY(-50%);
    z-index: 11;
  }
</style>
