<i18n>
  zh-CN:
    text:
      - '市场有风险，投资需谨慎'
      - '法币交易由合作伙伴 Lemon OTC 提供技术及服务支持'
      - 工具
      - 数字资产介绍
      - 服务
      - 费率
      - 常见问题
      - 新手指南
      - 熊猫生态
      - 支持
      - 上币申请
      - 关于我们
      - 联系我们
      - 条款说明
      - 用户协议
      - 隐私条款
      - 反洗钱政策
      - 法律声明
    hrefText:
      - '友情链接：'
      - '币小白'
      - '链安财经'
      - '星传媒'
      - '链茶馆'
      - '西瓜财经'
  en-US:
    text:
      - 'There are risks in the market, the investment need to be cautious.'
      - 'Fiat exchange are provided by partner Lemon OTC for technical and service support'
      - 'Tools'
      - 'Introduction of Digital Assets'
      - 'Service'
      - 'Fee Rate'
      - 'FAQ'
      - 'Beginner''s guide'
      - 'Panda ecology'
      - 'Support'
      - 'Apply to List'
      - 'About us'
      - 'Contact us'
      - 'Terms of Service'
      - 'User Agreement'
      - 'Privacy Policy'
      - 'AML Policy'
      - 'Legal Statement'
    hrefText:
      - 'Links：'
      - 'BIXIAOBAI'
      - 'LianAn'
      - 'Star Media'
      - 'LianChaguan'
      - 'Xigua Finance'
  zh-TW:
    text:
      - '市場有風險，投資需謹慎'
      - '法幣交易由合作夥伴 Lemon OTC 提供技術及服務支持'
      - '工具'
      - '數字資產介紹'
      - '服務'
      - '費率'
      - '常見問題'
      - '新手指南'
      - '熊貓生態'
      - '支持'
      - '上幣申請'
      - '關於我們'
      - '聯繫我們'
      - '條款說明'
      - '用戶協議'
      - '隱私條款'
      - '反洗錢政策'
      - '法律聲明'
    hrefText:
      - '友情链接：'
      - '币小白'
      - '链安财经'
      - '星传媒'
      - '链茶馆'
      - '西瓜财经'
  ko-KR:
    text:
      - '모든 투자는 시장 리스크를 동반하기 때문에 반드시 신중해야 합니다.'
      - '기술 및 서비스 지원을 위해 파트너 Lemon OTC에서 법적 통화 거래를 제공합니다.'
      - '도구 및 서비스'
      - '디지털 자산 소개'
      - '서비스'
      - '수수료 요율'
      - '자주 묻는 질문'
      - '초보자 가이드'
      - '팬더 생태'
      - '지원'
      - '코인 상장 신청'
      - '소개'
      - '연락주세요'
      - '약관 설명'
      - '이용 약관'
      - '개인정보처리방침'
      - '자금세탁 방지 정책'
      - '법률 성명'
    hrefText:
      - 'Links：'
      - 'BIXIAOBAI'
      - 'LianAn'
      - 'Star Media'
      - 'LianChaguan'
      - 'Xigua Finance'
</i18n>
<template>
<div id="footer" class="flex-direction-column flex-align-items-center">
  <div class="flex-justify-content-space-between footer_content">
    <div class="footer-left">
      <div class="logo-box background-reset"></div>
      <h3 class="text-color-white text-align-center text-size-17" />
      <p class="text-color-white text-align-left text-size-12 margin-left-3">&copy;2019-2020 Panda Global<label class="market_desc">{{$t('text[0]')}}</label></p>
      <div class="footer_icon">
        <el-popover
          placement="right"
          popper-class="wechart_popover"
          trigger="hover">
          <div class="wechat_qrcode background-reset" :style="{backgroundImage:`url(${qrLink})`}"></div>
          <div class="footer_icon_round" slot="reference">
            <svg class="icon footer_item" aria-hidden="true">
              <use xlink:href="#icon-weixin" />
            </svg>
          </div>
        </el-popover>
        <a href="mailto:support@panda.co">
          <div class="footer_icon_round">
            <svg class="icon footer_item email" aria-hidden="true">
              <use xlink:href="#icon-youxiang" />
            </svg>
          </div>
        </a>
       <!-- <a href="https://0.plus/PandaGlobalNice" target="_blank">
         <div class="footer_icon_round">
           <svg class="icon footer_item" aria-hidden="true">
             <use xlink:href="#icon-biyong" />
           </svg>
         </div>
       </a>
       <a href="https://weibo.com/7278522835" target="_blank">
         <div class="footer_icon_round">
           <svg class="icon footer_item" aria-hidden="true">
             <use xlink:href="#icon-weibo" />
           </svg>
         </div>
       </a>
       <a href="https://mobile.twitter.com/PandaglobalC" target="_blank">
         <div class="footer_icon_round">
           <svg class="icon footer_item" aria-hidden="true">
             <use xlink:href="#icon-tuite" />
           </svg>
         </div>
       </a> -->
     </div>
<!--      <p class="text-color-white text-align-left text-size-12 margin-top-30 opacity-3 line-height-18">{{$t('text[1]')}}</p>-->
    </div>
    <div class="flex-justify-content-space-around footer-right">
      <div class="footer-item">
        <p>{{$t('text[2]')}}</p>
        <!--  工具    -->
        <ul>
          <li>
            <a :href="`https://pandaexsupport.zendesk.com/hc/${language($i18n.locale)}/articles/360034697994-%E6%95%B0%E5%AD%97%E8%B5%84%E4%BA%A7%E4%BB%8B%E7%BB%8D`" target="_blank">{{$t('text[3]')}}</a>
            <!--  数字资产介绍    -->
          </li>
        </ul>
      </div>
      <div class="footer-item">
        <p>{{$t('text[4]')}}</p>
        <!--  服务    -->
        <ul>
          <li>
            <a :href="`https://pandaexsupport.zendesk.com/hc/${language($i18n.locale)}/articles/360035126274-%E4%BA%A4%E6%98%93%E8%B4%B9%E7%8E%87-%E5%85%85%E5%80%BC-%E6%8F%90%E7%8E%B0%E8%B4%B9%E7%8E%87%E5%85%AC%E7%A4%BA`" target="_blank">{{$t('text[5]')}}</a>
            <!--  费率    -->
          </li>
          <li>
            <a :href="`https://pandaexsupport.zendesk.com/hc/${language($i18n.locale)}/sections/360005094034-%E5%B8%B8%E8%A7%81%E9%97%AE%E9%A2%98`" target="_blank">{{$t('text[6]')}}</a>
            <!--  常见问题    -->
          </li>
          <li>
            <a :href="`https://pandaexsupport.zendesk.com/hc/${language($i18n.locale)}/sections/360005094094-%E6%96%B0%E6%89%8B%E6%8C%87%E5%8D%97`" target="_blank">{{$t('text[7]')}}</a>
            <!--  新手指南    -->
          </li>
<!--          <li>-->
<!--            <a :href="`https://pandaexsupport.zendesk.com/hc/${lang}/articles/360035864233`" target="_blank">{{$t('text[8]')}}</a>-->
<!--            &lt;!&ndash;  熊猫生态    &ndash;&gt;-->
<!--          </li>-->
        </ul>
      </div>
      <div class="footer-item">
        <p>{{$t('text[9]')}}</p>
        <!--  支持    -->
        <ul>
          <li>
            <a :href="`https://pandaexsupport.zendesk.com/hc/${language($i18n.locale)}/articles/360034886994-%E5%85%B3%E4%BA%8EPanda`" target="_blank">{{$t('text[11]')}}</a>
            <!--  关于我们    -->
          </li>
          <li>
            <a :href="`https://pandaexsupport.zendesk.com/hc/${language($i18n.locale)}/articles/360035210993-%E8%81%94%E7%B3%BB%E6%88%91%E4%BB%AC`" target="_blank">{{$t('text[12]')}}</a>
            <!--  联系我们    -->
          </li>
          <li>
            <a :href="`https://pandaexsupport.zendesk.com/hc/${language($i18n.locale)}/articles/360044755553`" target="_blank">{{$t('text[10]')}}</a>
            <!--  上币申请    -->
          </li>
        </ul>
      </div>
      <div class="footer-item">
        <p>{{$t('text[13]')}}</p>
        <!--  条款说明    -->
        <ul>
          <li>
            <a :href="`https://pandaexsupport.zendesk.com/hc/${language($i18n.locale)}/articles/360035211013-%E7%94%A8%E6%88%B7%E5%8D%8F%E8%AE%AE`" target="_blank">{{$t('text[14]')}}</a>
            <!--  用户协议    -->
          </li>
          <li>
            <a :href="`https://pandaexsupport.zendesk.com/hc/${language($i18n.locale)}/articles/360034698014-%E9%9A%90%E7%A7%81%E6%9D%A1%E6%AC%BE`" target="_blank">{{$t('text[15]')}}</a>
            <!--  隐私条款    -->
          </li>
          <li>
            <a :href="`https://pandaexsupport.zendesk.com/hc/${language($i18n.locale)}/articles/360036162013-%E5%8F%8D%E6%B4%97%E9%92%B1%E6%94%BF%E7%AD%96`" target="_blank">{{$t('text[16]')}}</a>
            <!--  反洗钱政策    -->
          </li>
          <li>
            <a :href="`https://pandaexsupport.zendesk.com/hc/${language($i18n.locale)}/articles/360035211033-%E6%B3%95%E5%BE%8B%E5%A3%B0%E6%98%8E`" target="_blank">{{$t('text[17]')}}</a>
            <!--  法律声明    -->
          </li>
        </ul>
      </div>
    </div>
  </div>
  <div class="flex-justify-content-flex-start flex-align-items-center footer_bottom" v-if="$route.name === 'home'">
    <p>{{$t('hrefText[0]')}}</p>
    <p class="margin-left-20">
      <a href="http://www.bixiaobai.com" target="_blank">{{$t('hrefText[1]')}}</a>
    </p>
    <p class="margin-left-20">
      <a href="http://www.lianan.pro" target="_blank">{{$t('hrefText[2]')}}</a>
    </p>
    <p class="margin-left-20">
      <a href="http://xcm24.com" target="_blank">{{$t('hrefText[3]')}}</a>
    </p>
    <p class="margin-left-20">
      <a href="http://www.lianchaguan.com" target="_blank">{{$t('hrefText[4]')}}</a>
    </p>
    <p class="margin-left-20">
      <a href="http://www.ok35.com" target="_blank">{{$t('hrefText[5]')}}</a>
    </p>
  </div>
</div>
</template>

<script>
import api from '../api/apiModule_1';
import { QRCode } from '../utils/common';

const qrCode = new QRCode(new Image(), {
  width: 114,
  height: 114,
  colorDark: '#000000',
  colorLight: '#ffffff',
  correctLevel: QRCode.CorrectLevel.H,
  render: 'table', // 默认使用了canvas，为了避免混乱这里时候用table
});

export default {
  name: 'footer',
  data() {
    return {
      tableData: [], // 数据列表
      qrLink: '',
      platform: 'WEB', // 默认平台
    };
  },
  methods: {
    fetchAppConfigInfo() { // 生产客服二维码
      return api.appConfigInfo().then((res) => {
        this.tableData = res;
        qrCode.makeCode(this.inquireLink?.url);
        // eslint-disable-next-line no-underscore-dangle,no-undef
        qrCode._oDrawing._elImage.onload = (event) => {
          this.qrLink = event.target.src;
        };
      });
    },
    /* handleClickZendesk() { // 投票上币链接跳转
      const lang = this.$i18n.locale;
      if (lang === 'zh-CN' || lang === 'zh-TW') window.open('http://pandaexchange.mikecrm.com/zMXu5gn');
      if (lang === 'en-US' || lang === 'ko-KR') window.open('http://pandaexchange.mikecrm.com/yFHEJ9W');
    }, */
  },
  computed: {
    inquireLink() { // 默认web平台客服二维码
      const { tableData } = this;
      return tableData.find(({ platform }) => platform === this.platform);
    },
  },
  created() {
    this.fetchAppConfigInfo();
  },
  beforeDestroy() {
    qrCode.clear(); // 清除ios生成二维码
  },
};
</script>

<style scoped lang="scss">
  .line-height-18 {
    line-height: 18px;
  }

  .wechat_qrcode {
    width: 100%;
    height: 100%;
  }
  #footer{
    width: 100%;
    background-color: #1b252c;
    padding: 70px 0;

    .footer_content {
      width: 1280px;
    }

    .footer-left {
      width: 40%;
      padding-left: 104px;
    }

    .footer-right {
      width: 60%;
      padding-right: 60px;
    }

    .market_desc {
      margin-left: 6px;
      color: #E0E0E7;
      opacity: .6;
      line-height: 18px;
    }

    .footer-item{
      color: white;
      p {
        color: #E0E0E7;
        margin-bottom: 12px;
        font-size: 12px;
        opacity: .6;
      }
      ul li a {
        color: white;
        font-size: 12px;
        text-decoration: none;
        cursor: pointer;
        &:hover {
          color: #27C08B;
        }
      }
    }
  }
  .footer_icon {
    margin-top: 30px;
    display: flex;
    flex-direction: row;
    .footer_icon_round {
      width: 26px;
      height: 26px;
      border-radius: 12px;
      text-align: center;
      line-height: 26px;
      margin-right: 8px;
      &:hover {
        background: #27C08B;
      }
    }
    .footer_item {
      width: 18px;
      height: 18px;
      fill: white;
      color: white;
      margin: 4px auto;

      &.wechat_icon {
        width: 21px;
        height: 21px;
      }

      &.email {
        width: 16px;
        height: 16px;
      }
    }
  }

.logo-box{
  background-image: url("../assets/logo.png");
  width: 150px;
  height: 56px;
}

  ul{
    margin: 0;
    padding: 0;

    li{
      list-style-type: none;
      padding: 12px 0;
      font-size: 12px;
      font-weight: 400;
    }
  }

  .text-size-17{
    font-size: 17px;
  }

  .margin-top-30{
    margin-top: 30px;
  }

  .footer_bottom {
    border-top: 1px solid #434F56;
    padding-top: 20px;
    margin-top: 60px;
    width: 1046px;
    margin-right: 20px;
    color: #93959C;
    font-size: 12px;

    a {
      color: #93959C;
      text-decoration: none;

      &:hover {
        color: #27c08b;
      }
    }
  }
</style>
