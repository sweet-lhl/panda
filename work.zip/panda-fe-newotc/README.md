# vue-cli3.0

> A Vue.js template

> Vue <- babel-preset-env

## Babel link

[:: -> 双冒号运算符](https://github.com/tc39/proposal-bind-operator)  
[@decorators -> class装饰器语法](https://github.com/wycats/javascript-decorators/blob/master/README.md)  
[do { true } -> do表达式](https://github.com/tc39/proposal-do-expressions)  
[obj?.foo?.bar?.baz -> 链式判断运算符](https://github.com/tc39/proposal-optional-chaining)  
[add(1, ?) -> 函数的部分执行](https://github.com/tc39/proposal-partial-application)  
[1 |> # + 1 -> 管道运算符](https://github.com/js-choi/proposal-smart-pipelines)  
