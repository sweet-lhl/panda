import http from '../plugins/http';

const key = '/api/v1';

const api = http[key] || http.instance(key); // api modules.test

class Service {
  api = api;

  OtcAdCreate(params) { // 新建广告
    return this.api.post('/otc/ad/create', params);
  }

  OtcAdPage(params) { // 分页获取广告
    return this.api.get('/otc/ad/page', { params });
  }

  OtcAdUpdate(params) { // 更新广告
    return this.api.post('/otc/ad/update', params);
  }

  OtcAdPutDown(params) { // 下架广告
    return this.api.post('/otc/ad/putDown', params);
  }

  OtcAdvertise(params) { // 获取广告列表
    return this.api.get('/otc/ad/listAdvertise', { params });
  }

  OtcStop(params) { // 停止接单
    return this.api.get('/otc/ad/stop', { params });
  }

  OtcBusinessStatistics(params) { // 商家数据统计
    return this.api.get('/otc/order/businessStatistics', { params, headers: { cache: true } });
  }

  OtcDownload(params) { // 导出订单
    return this.api.get('/otc/order/export', { params }); // download export
  }

  OtcAccount(params) { // 获取商家属性
    return this.api.get('/otc/account/getUserOtcAccount', { params, headers: { cache: true } });
  }

  userInfo(params) { // 获取用户详情
    return this.api.post('/user/info', params, { headers: { cache: true } });
  }

  otcGetFlashPrice(params) { // 获取币种最新价格
    // @param type (0-用户买单，1-用户卖单)
    return this.api.get('/otc/getFlashPrice', { params });
  }

  /* getLatestCoinPrice(type) {
    return this.api.get('/otc/getFlashPrice', { params: { type } });
  } */

  fetchFinancial(params) { // 资产详情
    return this.api.get('/otc/financial/all', { params, headers: { cache: true } });
  }

  coinAsset(params) { // 币币账户资产
    return this.api.get('/assets/coin/asset', { params });
  }

  financialTransfer(params) { // 资金互转
    return this.api.post('/otc/financial/transfer', params);
  }

  cancelTimes() { // 查询取消次数
    return this.api.get('/otc/order/cancelTimes', { headers: { cache: true } });
  }

  otcCreatePayment(params) { // 添加支付账号
    return this.api.post('/otc/createPayment', params);
  }

  otcUpdatePayment(params) { // 修改加支付账号
    return this.api.post('/otc/updatePayment', params);
  }

  otcQueryPayment(params) { // 获取用户支付信息
    return this.api.get('/otc/queryPayment', { params, headers: { cache: true } });
  }

  otcDeletePayment(params) { // 删除用户支付信息
    return this.api.get('/otc/deletePayment', { params });
  }

  checkRealAuth() { // 查询安全认证
    return this.api.get('/otc/checkRealAuth', { headers: { cache: true } });
  }

  getTradeAd(params) { // 获取匹配到的对手单
    return this.api.post('/otc/getAutoFlashTradeAd', params);
  }

  commitTransaction(params) { // 提交订单
    return this.api.post('/otc/order/createFlash', params);
  }

  getTradeCoinList() {
    return this.api.get('/otc/getOtcTradeCoin', { headers: { cache: true } });
  }

  otcOrderCurrent(params) { // 分页获取用户当前订单
    return this.api.post('/otc/order/current', params);
  }

  otcOrderHistory(params) { // 分页获取用户历史订单
    return this.api.post('/otc/order/history', params);
  }

  otcOrderQueryInfo(params) { // 获取订单信息
    return this.api.post('/otc/order/queryInfo', params);
  }

  otcCancelOrder(orderId) { // 取消订单
    return this.api.post('/otc/order/cancelOrder', { orderId });
  }

  modifyOrderStatus(params) { // 更新订单状态
    return this.api.post('/otc/order/update', params);
  }

  checkAppeal(orderId) { // 查询申诉进度
    return this.api.get('/otc/order/checkAppeal', { params: { orderId } });
  }

  createAppeal(params) { // 发起申诉
    return this.api.post('/otc/order/createAppeal', params);
  }

  appealUpload(params) { // 上传申诉图片
    return this.api.post('/otc/appeal/upload', params);
  }

  fetchBanner() { // 获取banner图片 [1：PC端Banner，2：APP端Banner，3：OTC端Banner]
    return this.api.get('/home/banner', { params: { type: 3 }, headers: { cache: true } });
  }

  zendeskSign(url) { // 获取Zendesk公告等信息
    return this.api.get('/zendesk/lemonSign', { params: { url }, headers: { cache: true } });
  }

  getLoginToken(params) { // 获取登录凭证
    return this.api.post('/user/getLoginToken', params);
  }

  sendLoginEmail(params) { // 发送登录邮件
    return this.api.post('/user/sendLoginEmail', params);
  }

  sendSms(params) { // 发送短信
    return this.api.post('/user/sendSms', params);
  }

  login(params) { // 登录
    return this.api.post('/user/login', params);
  }

  userLoginOut(params) { // 退出登录
    return this.api.post('user/loginOut', params);
  }

  addAutoReplyConfig(params) { // 增加自动回复配置
    return this.api.get('/otc/chat/addAutoReplyConfig', { params });
  }

  delAutoReplyConfig(params) { // 删除自动回复配置
    return this.api.get('/otc/chat/delAutoReplyConfig', { params });
  }

  getAutoReplyConfig(params) { // 查询自动回复配置
    return this.api.get('/otc/chat/getAutoReplyConfig', { params });
  }

  updateAutoReplyConfig(params) { // 更新自动回复内容
    return this.api.get('/otc/chat/updateAutoReplyConfig', { params });
  }

  listAutoReplyConfig(params) { // listAutoReplyConfig
    return this.api.get('/otc/chat/listAutoReplyConfig', { params });
  }

  getChatlist(params) { // 拉取消息
    return this.api.get('/otc/chat/list', { params });
  }

  sendChat(params) { // 发送消息
    return this.api.get('/otc/chat/send', { params });
  }

  uploadChat(params) { // 上传聊天图片
    return this.api.post('/otc/chat/upload', params);
  }
}

export default new Service();
