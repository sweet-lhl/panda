<template>
  <div id="bankCardManagement">
    <div class="bankCard-header d-flex align-center justify-space-between">
      <h5 class="bankCard-header-title text-weight-5 text-size-22">收款方式</h5>
      <v-btn class="bankcard-add text-size-12" tile outlined color="#F6C40F" x-small @click.stop="overlay = true">
        <v-icon left>mdi-plus</v-icon>
        <span>添加收款方式</span>
      </v-btn>
    </div>
    <p class="bankWarning-tips text-size-12">请务必使用您本人的实名账户，每种支付方式不能超过3个。</p>
    <div class="bankCard-footer">
      <ul class="bankCard-list margin-less" v-if="bankList.length">
        <li class="bankCard-list-item justify-space-between align-center list-style-none text-size-12 d-flex" v-for="(bank, idx) in bankList" :key="`bankList-item-${idx}`">
          <div class="bankCard-list-item-left d-flex align-center col-10 pa-0">
            <svg class="icon bank-image" aria-hidden="true">
              <use :xlink:href="`#${bank.fpayid===1?'iconzhifubao':bank.fpayid===2?'iconweixin':'iconyinhangka'}`"/>
            </svg>
            <span class="margin-left-11">{{bank.fpayid | paymentText}}</span>
            <span class="margin-left-10">CNY</span>
            <span class="margin-left-40">{{bank.fname}}</span>
            <span class="margin-left-40" v-if="bank.fpayid===0">{{bank.fbankname}}</span>
            <span class="margin-left-20" v-if="bank.fpayid===0">{{bank.fbranchinfo}}</span>
            <span class="margin-left-20" v-if="bank.fpayid===0">{{bank.faccount | numberBank}}</span>
            <span class="margin-left-20" v-else>{{bank.faccount}}</span>
          </div>
          <div class="bankCard-list-item-right">
            <v-btn text small color="primary" @click.stop="handleModifyBankcard(idx)">修改</v-btn>
            <v-btn text small color="error" @click.stop="handleDeleteBankcard(bank)">删除</v-btn>
          </div>
        </li>
      </ul>
      <div class="bankCard-less d-flex justify-center align-center flex-column" v-else>
        <svg class="icon bank-add cursor-pointer" aria-hidden="true">
          <use xlink:href="#iconzanwushoukuanfangshi1"/>
        </svg>
        <p class="text-size-12 d-inline-flex align-center margin-top-14">暂无收款方式,<v-btn class="pa-0" text small min-width="40px" color="primary" @click.stop="overlay = true">添加</v-btn></p>
      </div>
    </div>
    <AddBankCard :overlay.sync="overlay" :bankDetails.sync="bankActiveItem"/>
    <DeleteBankCard :overlay.sync="deleteOverlay" :id.sync="bankActiveId"/>
  </div>
</template>

<script>
import AddBankCard from './AddBankCard.vue';
import DeleteBankCard from './DeleteBankCard.vue';
import { mapState, mapActions } from '../../utils/common';

export default {
  name: 'bankCardManagement',
  components: {
    AddBankCard,
    DeleteBankCard,
  },
  filters: {
    paymentText(id) {
      switch (id) {
        case 0:
          return '银行卡转账';
        case 1:
          return '支付宝转账';
        case 2:
          return '微信转账';
        default:
          return '----';
      }
    },
  },
  computed: {
    ...mapState('accountSetting', ['bankList']),
  },
  data: () => ({
    overlay: false,
    deleteOverlay: false,
    bankActiveId: '', // 删除数据
    bankActiveItem: {}, // 修改数据
  }),
  methods: {
    ...mapActions('accountSetting', ['fetchBankList']),
    handleModifyBankcard(eq) {
      this.bankActiveItem = this.bankList[eq]; // 银行卡表单填充信息
      process.nextTick(() => { this.overlay = true; }); // 开启修改弹窗
    },
    handleDeleteBankcard(eq) {
      this.bankActiveId = eq?.fid;
      // this.bankList.splice(eq, 1);
      process.nextTick(() => { this.deleteOverlay = true; }); // 开启删除弹窗
    },
  },
  created() {
    this.fetchBankList();
  },
};
</script>

<style scoped lang="scss">
  #bankCardManagement{

    & > *:not(.v-overlay){
      max-width: 1180px;
      margin: 0 auto;
    }
  }

  .bankCard-header{
    padding: 40px 0 22px;

    .bankCard-header-title{
      color:rgba(40,40,45,1);
    }

    .bankcard-add{
      padding: 8px 20px;
      margin: 0;
      height: auto;
    }
  }

  .bankCard-footer{

    .bankCard-less{
      padding: 114px 0;
    }
  }

  .bankWarning-tips{
    color: #EEA30C;
    font-weight: 400;
    padding: 10px 9px;
    background-color: rgba(242, 193, 16, 0.08);
    border-top: thin solid #E6E8E0;
  }

  svg.bank-add{
    width: 64.24px;
    height: 64.24px;
  }

  .bankCard-list{
    padding: 10px 0;

    .bankCard-list-item{
      height: 46px;
      padding: 0 10px;
      border:thin solid rgba(230,236,243,1);
      border-radius: 2px;

      &:not(:first-child){
        margin-top: 10px;
      }

    }
  }
</style>
