<template>
  <v-overlay :value="overlay">
    <v-form
      ref="form"
      :class="{'cursor-none':isLoading}"
      lazy-validation
    >
      <div class="form-header d-flex justify-space-between align-center">
        <h5 class="text-size-16 text-weight-5">{{bankDetails.fid ?'修改':'添加'}}收款方式</h5>
        <v-btn
          icon
          @click.stop="$emit('update:overlay', false)"
        ><v-icon color="#484855">mdi-close</v-icon></v-btn>
      </div>

      <v-select
        :menu-props="{ offsetY: true }"
        v-model="formData.type.value"
        :rules="formData.type.rules"
        :items="collectionType"
        color="#f6c40f"
        label="类型"
        :placeholder="`${Boolean(bankDetails.fid)?'':'请选择收款类型'}`"
        :disabled="Boolean(bankDetails.fid)"
        outlined
        required
        light
      />
      <!--isBusiness=1 =>商家可编辑姓名-->
      <v-text-field
        v-model="formData.name.value"
        :rules="formData.name.rules"
        color="#f6c40f"
        label="实名姓名"
        placeholder="请输入姓名"
        outlined
        light
        :disabled="userInfo.isBusiness !== 1"
        required
      />

        <v-text-field
          v-if="type===0"
          v-model="formData.openBank.value"
          :rules="openBankRules"
          color="#f6c40f"
          label="开户银行"
          placeholder="请输入开户银行"
          outlined
          light
          required
        />


      <v-text-field
        v-if="type===0"
        v-model="formData.openBranch.value"
        :rules="formData.openBranch.rules"
        color="#f6c40f"
        label="开户支行(选填)"
        placeholder="请输入开户支行"
        light
        outlined
      />

      <v-text-field
        v-model="formData.account.value"
        :rules="formData.account.rules"
        color="#f6c40f"
        :type="type===0?'number':'text'"
        :label="`${typeText}账号`"
        :placeholder="`请输入${typeText}账号`"
        light
        outlined
        required
      />


      <div class="inputUpload" v-if="type!==0">
        <v-file-input
          color="#f6c40f"
          ref="inputUpload"
          v-model="formData.url.value"
          :rules="urlRules"
          accept="image/png, image/jpeg, image/bmp"
          prepend-icon=""
          :label="`收款二维码(${type===1?'选':'必'}填)`"
          multiple
          placeholder="请上传收款二维码"
          outlined
          :show-size="1024"
        >
          <template v-slot:selection="{ index, text }">
            <v-img
              :src="imagePreviews[index]"
              :alt="text"
              aspect-ratio="1"
              :max-width="50"
              class="lighten-2 cursor-pointer"
              @click.stop="handleImagePreview(imagePreviews[index])"
            />
          </template>
        </v-file-input>

          <svg
            role="button"
            class="icon bank-image cursor-pointer"
            aria-hidden="true"
            v-if="!formData.url.value.length"
            @click="$refs.inputUpload.$refs.input.click()"
          >
            <use xlink:href="#iconshangchuan" />
          </svg>
      </div>

      <InputPassword
        v-model="formData.password.value"
        :rules="formData.password.rules"
        label="资金密码"
        placeholder="请输入资金密码"
        type="password"
        light
        outlined
        required
      />

      <v-btn
        color="#F6C40F"
        @click.prevent="handleSubmit"
        block
        light
        :disabled="disabledType&&!bankDetails.fid"
        :loading="isLoading"
        depressed
      >{{disabledType&&!bankDetails.fid?'每种支付方式不能超过3个':`确认${bankDetails.fid ? '修改' : '添加' }`}}</v-btn>
    </v-form>
    <!-- 图片预览 -->
    <ImagePreview :uri="imagePreview" :overlay.sync="imagePreviewStatus"/>
  </v-overlay>
</template>

<script>
import InputPassword from '../../components/InputPassword.vue';
import { Regex } from '../../utils/constant';
import { mapState, mapActions, mapGetters } from '../../utils/common';
import api from '../../api/apiModule_1';
import ImagePreview from '../../components/ImagePreview.vue';

export default {
  name: 'addBankCard',
  props: {
    overlay: { type: Boolean, default: false },
    bankDetails: { type: Object, default: () => Object.create(null) },
  },
  components: { InputPassword, ImagePreview },
  data() {
    return {
      imagePreviews: [], // 文件预览图集合
      imagePreview: '', // 当前预览的图片链接
      isLoading: false,
      imagePreviewStatus: false, // 图片预览
      collectionType: [{ value: 0, text: '银行卡' }, { value: 1, text: '支付宝' }, { value: 2, text: '微信' }],
      formData: {
        type: { value: 0, rules: [] },
        url: { value: [] },
        name: { value: '', rules: [v => !!v || '姓名不能为空', v => (v?.length > 1 && v?.length < 6) || '姓名在2-5个字符之间'] },
        openBank: { value: '' },
        openBranch: { value: '', rules: [] },
        account: { value: '', rules: [v => !!v || `${this.typeText}账号不能为空`] },
        password: { value: '', rules: [v => !!v || '资金密码不能为空', v => !/\s+/.test(v) || '资金密码不能包含空格', v => Regex.PASSWORD.test(v) || '资金密码格式不正确'] /* 密码为8-20位字符，需包含数字、大写字母和小写字母 */},
      },
    };
  },
  methods: {
    ...mapActions('accountSetting', ['fetchBankList']),
    handleSubmit() {
      if (this.$refs.form.validate()) {
        const { formData, bankDetails: { fid }, type } = this;
        const subData = Object.entries(formData).reduce((acc, [key, { value }]) => acc.set(key, value), new Map());
        if (!subData.get('url').length && type === 2) {
          this.$toast('请上传收款二维码');
          return;
        }
        this.isLoading = true;
        Promise.all( // 上传图片
          subData.get('url').map(file => api.appealUpload({ file })),
        ).then(r => api[fid ? 'otcUpdatePayment' : 'otcCreatePayment'](Object.assign({
          type: subData.get('type'),
          url: r.map(({ url }) => url).join(),
          fname: subData.get('name'),
          account: subData.get('account'),
          tradepass: subData.get('password'),
          fbankname: subData.get('openBank'),
          fbranchinfo: subData.get('openBranch') || '',
        }, fid ? { fid } : undefined)).then(() => {
          this.isLoading = false;
          this.$toast(`${fid ? '修改' : '添加'}成功`);
          this.$emit('update:overlay', false);
        }).catch(() => {
          this.isLoading = false;
        })).catch(() => {
          this.isLoading = false;
        });
      }
    },
    handleImagePreview(uri) {
      [this.imagePreview, this.imagePreviewStatus] = [uri, true];
    },
  },
  computed: {
    ...mapState(['userInfo']),
    ...mapGetters('accountSetting', ['branchData', 'weChatData', 'cardData']),
    openBankRules() {
      return this.type === 0 ? [v => !!v || '开户银行不能为空'] : [];
    },
    disabledType() {
      // eslint-disable-next-line no-nested-ternary
      return this.type === 1 ? this.branchData.length > 2 : this.type === 2 ? this.weChatData.length > 2 : this.cardData.length > 2;
    },
    urlRules() {
      return this.type !== 0 ? [v => v.every(f => f.size < 5 * 1024 * 1024) || '收款二维码大小不能超过5M!'] : [];
    },
    type() {
      return this.formData.type.value;
    },
    typeText() {
      const { value } = this.formData.type;
      // eslint-disable-next-line no-nested-ternary
      return value === 1 ? '支付宝' : value === 2 ? '微信' : '银行卡';
    },
  },
  watch: {
    'formData.url.value': {
      handler(n, o) {
        if (n !== o) {
          this.imagePreviews = n.reduce((acc, file) => {
            const reader = new FileReader();
            reader.onload = ({ target: { result: imageUri } }) => { acc.push(imageUri); };
            reader.readAsDataURL(file);
            return acc;
          }, []);
        }
      },
      immediate: true,
      deep: true,
    },
    imagePreviewStatus(n, o) { // 关闭遮罩层时自动清除预览链接
      if (n !== o && !n) this.imagePreview = '';
    },
    type() {
        // eslint-disable-next-line no-unused-expressions
        this.$refs.form?.resetValidation(); // 重置表单
    },
    bankDetails: { // 用于修改时赋值
      handler(n, o) {
        if (n !== o) {
          const { formData } = this.$data;
          Object.entries(n).forEach(([key, value]) => {
            switch (key) {
              case 'fpayid':
                formData.type.value = value;
                break;
              case 'fname':
                formData.name.value = value;
                break;
              case 'faccount':
                formData.account.value = value;
                break;
              case 'tradepass':
                formData.password.value = value;
                break;
              case 'fbankname':
                formData.openBank.value = value;
                break;
              case 'fbranchinfo':
                formData.openBranch.value = value;
                break;
              default:
                break;
            }
          });
        }
      },
      deep: true,
      immediate: true,
    },
    overlay(n, o) {
      const { userInfo: { realName: fname }, $data: { formData } } = this;
      formData.name.value = fname;
      if (n !== o && !n) {
        this.fetchBankList(); // 更新银行卡列表
        // eslint-disable-next-line no-unused-expressions
        this.$refs.form?.reset(); // 重置表单
        this.formData.type.value = 0;
        this.$emit('update:bankDetails', Object.create(null)); // 重置银行卡详细信息
        // this.$emit('update:overlay', false); // 关闭弹窗
      }
    },
  },
};
</script>

<style scoped lang="scss">
  $borderColor: #EEEEEE;
  $textColor: #484855;

.v-form{
  width: 420px;
  background-color: white;
  padding: 25px 20px;

  .form-header{
    padding: 0 0 20px;
    border-bottom: thin solid $borderColor;
    color: $textColor;
  }
}
  ::v-deep button, ::v-deep input, ::v-deep optgroup, ::v-deep select, ::v-deep textarea{
    font-size: 14px;
  }
  ::v-deep .theme--dark.v-file-input .v-file-input__text--placeholder{
    font-size: 14px;
  }
  ::v-deep .theme--dark.v-label,::v-deep .theme--dark.v-icon,::v-deep .theme--dark.v-file-input .v-file-input__text--placeholder{
    color: rgba(0,0,0,.54);
  }
  ::v-deep .v-text-field__slot{
    cursor: pointer;
  }
  .inputUpload{
    position: relative;
    .bank-image{
      position: absolute;
      top: 13px;
      right: 12px;
      width: 25px;
      height: 25px;
    }
  }
</style>
