<template>
  <v-overlay :value="overlay">
    <v-form
      ref="form"
      lazy-validation
    >
      <div class="form-header d-flex justify-space-between align-center">
        <h5 class="text-size-16 text-weight-5">安全验证</h5>
        <v-btn
          icon
          @click.stop="$emit('update:overlay', false)"
        ><v-icon color="#484855">mdi-close</v-icon></v-btn>
      </div>

      <InputPassword
        v-model="formData.password.value"
        :rules="formData.password.rules"
        label="资金密码"
        placeholder="请输入资金密码"
        type="password"
        light
        outlined
        required
      />

      <v-btn
        color="#F6C40F"
        @click.prevent="handleSubmit"
        block
        light
        depressed
      >提交</v-btn>
    </v-form>
  </v-overlay>
</template>

<script>
import InputPassword from '../../components/InputPassword.vue';
import api from '../../api/apiModule_1';
import { mapActions } from '../../utils/common';
import { Regex } from '../../utils/constant';

export default {
  name: 'deleteBankCard',
  props: {
    overlay: {
      type: Boolean,
      default: false,
    },
    id: { type: [String, Number], required: true },
  },
  components: { InputPassword },
  data: () => ({
    formData: {
      password: { value: '', rules: [v => !!v || '资金密码不能为空', v => !/\s+/.test(v) || '资金密码不能包含空格', v => Regex.PASSWORD.test(v) || '资金密码格式不正确'] /* 密码为8-20位字符，需包含数字、大写字母和小写字母 */},
    },
  }),
  methods: {
    ...mapActions('accountSetting', ['fetchBankList']),
    handleSubmit() {
      if (this.$refs.form.validate()) {
        const { id: fid, formData: { password: { value: tradepass } } } = this;
        api.otcDeletePayment({ fid, tradepass }).then(() => this.$emit('update:overlay', false));
      }
    },
  },
  watch: {
    overlay(n, o) {
      if (n !== o && !n) {
        this.fetchBankList(); // 更新银行卡列表
        // eslint-disable-next-line no-unused-expressions
        this.$refs.form?.reset(); // 重置表单
        this.$emit('update:id', ''); // 重置银行卡详细信息
        // this.$emit('update:overlay', false); // 关闭弹窗
      }
    },
  },
};
</script>

<style scoped lang="scss">
  $borderColor: #EEEEEE;
  $textColor: #484855;

  .v-form{
    width: 420px;
    background-color: white;
    padding: 25px 20px;

    .form-header{
      padding: 0 0 20px;
      border-bottom: thin solid $borderColor;
      color: $textColor;
    }
  }
</style>
