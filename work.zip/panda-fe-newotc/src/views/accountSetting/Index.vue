<template>
  <div id="accountSetting">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'accountSetting',
};
</script>

<style scoped lang="scss">
#accountSetting{
  background: white;
}
</style>
