<template>
  <v-form
    id="sell"
    ref="form"
    lazy-validation
  >
    <p class="business-usdt text-right text-size-12">当前账户余额：{{financialAll.totalToUSDT | toFixed(6)}} USDT</p>
    <v-text-field
      id="sell-input"
      color="#f6c40f"
      :label="labelText"
      :placeholder="placeholderText"
      v-only-number:[digit]="amount"
      v-model="amount"
      :rules="amountRules"
      hide-details
      outlined
      autofocus
      type="text"
    >
      <template #append>
        <span class="unit-el">{{unit}}</span>
        <span class="padding-20">
          <svg class="icon checked margin-right-10" aria-hidden="true">
            <use xlink:href="#iconqiehuan"/>
          </svg>
          <i class="sell-input-append text-style-none cursor-pointer" @click.stop="handleTypeToggle">{{unitText}}</i>
        </span>
      </template>
    </v-text-field>
    <BankCard @onChange="handleBankChange"/>
    <p class="d-flex justify-space-between align-center text-size-12 sell-calc-details"><span>成交单价：</span><span>{{price}} CNY</span></p>
    <p class="d-flex justify-space-between align-center text-size-12 sell-calc-details line-35"><span>成交数量：</span><span>{{transactionCount | toFixed(6)}} USDT</span></p>
    <p class="d-flex justify-space-between align-center text-size-12 sell-calc-details margin-bottom-25"><span>成交总额：</span><span>{{transactionAmount | toFixed(2)}} CNY</span></p>
  </v-form>
</template>

<script>
import { calc, mapState, mapActions } from '../../utils/common';
import BankCard from './BankCard.vue';

const minAmount = 100;

export default {
  name: 'sell',
  data: () => ({
    amount: 100,
    type: 1, // 0-数量，1-金额
    bankValue: null,
  }),
  watch: {
    type(n, o) { // 重置表单验证
      if (n !== o) this.$refs.form.resetValidation();
    },
  },
  computed: {
    ...mapState('assets', ['financialAll']),
    unit() {
      const { type } = this.$data;
      switch (type) {
        case 0:
          return 'USDT';
        case 1:
          return 'CNY';
        default:
          return '---';
      }
    },
    amountRules() {
      const { type, price } = this;
      switch (type) {
        case 1:
          return [v => !!v || '下单金额不能为空', v => Number(v) >= minAmount || '最小下单金额为100 CNY'];
        case 0:
        {
          const minCount = calc(`${minAmount} ${price} /`).toFixed(7).slice(0, -1);
          return [v => !!v || '下单数量不能为空', v => Number(v) >= minCount || `最小下单数量为${minCount} USDT`];
        }
        default:
          return [];
      }
    },
    digit() {
      const { type } = this.$data;
      return type === 1 ? 2 : 8;
    },
    unitText() {
      const { type } = this.$data;
      switch (type) {
        case 0:
          return '按金额出售';
        case 1:
          return '按数量出售';
        default:
          return '---';
      }
    },
    labelText() {
      const { type } = this.$data;
      switch (type) {
        case 1:
          return '出售总金额';
        case 0:
          return '出售总数量';
        default:
          return '---';
      }
    },
    placeholderText() {
      const { type } = this.$data;
      switch (type) {
        case 1:
          return '请输入出售总金额';
        case 0:
          return '请输入出售总数量';
        default:
          return '---';
      }
    },
    transactionCount() { // 成交数量
      const { type, amount, price } = this;

      switch (type) {
        case 0: // 数量出售
          return amount;
        case 1: // 金额出售
          return calc(`${amount} ${price} /`);
        default:
          return '---';
      }
    },
    transactionAmount() { // 成交总金额
      const { type, amount, price } = this;

      switch (type) {
        case 0: // 数量出售
          return calc(`${amount} ${price} *`);
        case 1: // 金额出售
          return amount;
        default:
          return '---';
      }
    },
  },
  components: { BankCard },
  methods: {
    ...mapActions('assets', ['fetchFinancialAll']),
    handleTypeToggle() {
      const { type } = this.$data;
      this.type = typeof type === 'number' && type ? 0 : 1;
    },
    handleBankChange(value) {
      this.bankValue = value;
    },
    validate() {
      return this.$refs.form.validate();
    },
    formReset() {
      return this.$refs.form.reset();
    },
  },
  props: {
    price: { required: true, type: Number },
  },
  created() {
    this.fetchFinancialAll();
  },
};
</script>

<style scoped lang="scss">
  svg.checked{
    width: 12px;
    height: 12px;
  }

  #sell{
    padding-top: 35px;
    position: relative;
  }

  .unit-el{
    border-right: thin solid #BCC6D2;
    padding-right: 20px;
  }

  .padding-20{
    padding: 0 10px;
  }

  .sell-calc-details{
    color: #28282D;

    &>*:first-child{
      opacity: .6;
    }

    &>*:last-child{

    }

    &.line-35{
      padding: 35px 0;
    }

    &.margin-bottom-25{
      margin-bottom: 25px;
    }
  }

  .business-usdt{
    position: absolute;
    top: 5px;
    right: 0;
    clear: both;
    font-weight: 400;
  }
  ::v-deep .v-input--selection-controls .v-input__control{
    width: 100%;
  }
</style>
