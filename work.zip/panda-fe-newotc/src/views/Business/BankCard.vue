<template>
  <div id="bankCard">
    <v-radio-group v-model="bankValue" column class="bankCard-list" v-if="bankList.length" :loading="isLoading" row>
      <v-radio
        class="bankCard-item"
        v-for="(bank, idx) in bankList"
        :key="`business-bankItem-${idx}`"
        color="#F6C40F"
        small
        :value="bank.fid"
      >
        <template #label>
          <span class="margin-left-11 text-size-14 text-weight-5">{{bank.fpayid | paymentText}}</span>
          <span class="margin-left-40 text-size-12 text-weight-5">{{bank.fname}}</span>
          <span class="margin-left-40 text-size-12 text-weight-5">{{bank.fbankname}}</span>
          <!--<span class="margin-left-20 text-size-12 text-weight-5">{{bank.fbranchinfo}}</span>-->
          <span class="margin-left-20 text-size-12 text-weight-5">{{bank.faccount | numberBank}}</span>
        </template>
      </v-radio>
    </v-radio-group>
    <div class="bankCard-less d-flex align-center justify-space-between" v-else>
      <div class="bankCard-less-left d-flex align-center">
        <v-radio disabled color="#F6C40F" class="margin-right-10"/>
        <span class="bank-name text-size-14">银行卡</span>
        <i class="bank-subName text-size-12 text-style-none margin-left-20">暂未添加银行卡</i>
      </div>
      <div class="bankCard-less-right">
        <v-btn text small color="primary" class="text-right" to="/accountSetting/bankCardManagement">立刻添加银行卡</v-btn>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from '../../utils/common';

export default {
  name: 'bankCard',
  computed: {
    ...mapState('accountSetting', ['bankList']),
  },
  methods: {
    ...mapActions('accountSetting', ['fetchBankList']),
  },
  created() {
    this.fetchBankList().then(() => { [this.bankValue, this.isLoading] = [this.bankList[0]?.fid, false]; }); // 首次拉取付款信息默认
  },
  watch: {
    bankValue(n, o) {
      if (n !== o && n) this.$emit('onChange', n);
    },
  },
  data: () => ({
    bankValue: undefined,
    isLoading: true,
  }),
};
</script>

<style scoped lang="scss">
  $activeColor: rgba(246,196,15,1);

.bankCard-less{
  height: 40px;
  background-color: #efefef;
  padding-left: 20px;
  padding-right: 10px;
  border-radius: 2px;
  margin-bottom: 15px;
  position: relative;
  top: -10px;
}

  .link-color{
    color: #1581F2;
  }

  .bank-subName{
    color: #93939C;
  }

  .bank-name{
    color: #484855;

    /*&:before{
      content: "";
      width: 14px;
      height: 14px;
      border-radius: 100%;
      background-color: #E3E3E3;
      margin-right: 11px;
      display: inline-block;
    }*/
  }

  .bankCard-list{
    margin-top: 20px;

    .bankCard-item{
      background-color: #F9F9F9;
      margin-right: 0;
      width: 100%;
      height: 38px;
      border-radius: 1px;
      border: thin solid transparent;
      padding-left: 20px;

      &:not(:first-child){
        margin-top: 20px;
      }

      &.v-item--active{
        border:thin solid $activeColor;
        position: relative;

        &::after{
          content: "";
          border-color: transparent transparent $activeColor transparent;
          border-style: solid;
          border-width: 0 0 25px 25px;
          position: absolute;
          right: 0;
          bottom: 0;
          z-index: 1;
        }

        &::before{
          content: "";
          width: 10px;
          height: 7px;
          border-color: transparent transparent white white;
          border-style: solid;
          border-width: 0 0 2px 2px;
          position: absolute;
          right: 3px;
          bottom: 5px;
          z-index: 2;
          transform: rotate(-50deg);
        }
      }

      ::v-deep .v-label{
        // width: calc(100% - 24px);
        flex-grow: 1;
      }
    }
  }
</style>
