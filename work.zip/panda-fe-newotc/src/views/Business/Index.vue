<template>
  <div id="business">
    <div class="business-header">
      <h5 class="text-size-20 text-weight-5 business-title d-flex align-center justify-center">
        <svg class="icon cursor-pointer margin-right-20" aria-hidden="true">
          <use xlink:href="#iconjiandanjiaoyi"/>
        </svg>
        简单交易，一键买卖<span class="text-size-12 text-weight-4 business-subTitle">小额快速交易，单笔50000以下</span>
      </h5>
    </div>
    <div class="business-body">
      <div class="d-flex justify-space-between align-center border-bottom">
        <div class="business-tab-left text-size-16 d-flex">
          <span :class="['tab-buy', 'cursor-pointer', type === 'buy' && 'active']" @click.stop="$router.replace('/business/buy')">购买</span>
          <span :class="['tab-sell', 'margin-left-30', 'cursor-pointer', type === 'sell' && 'active']" @click.stop="$router.replace('/business/sell')">出售</span>
        </div>
        <div class="business-tab-right">
          <p class="text-size-12 text-weight-4 d-flex align-center">
            <svg class="icon tips margin-right-5" aria-hidden="true">
              <use xlink:href="#icontishi"/>
            </svg>
            <span>参考价:{{usdtPrice}}CNY/USDT</span>
          </p>
        </div>
      </div>
      <component :is="viewComponent" :price="usdtPrice||0" ref="customInput"/>
    </div>
    <div class="business-footer">
      <v-btn depressed large block color="#F6C40F" :disabled="submitDisabled" @click.stop="handleSubmit" :loading="isLoading">{{submitDisabled ? '今日取消次数已达上限，限制' : ''}}{{subButtonText}}&nbsp;USDT</v-btn>
    </div>
  </div>
</template>

<script>
import { mapActions, mapState } from '../../utils/common';
import api from '../../api/apiModule_1';
import Sell from './Sell.vue';
import Buy from './Buy.vue';

const name = 'business';
let timer;

export default {
  name,
  computed: {
    ...mapState(['cancelTimes', 'coinPrice', 'userInfo', 'tradeCoin']),
    ...mapState(name, ['realAuth']),
    ...mapState('accountSetting', ['bankList']),
    submitDisabled() { // 是否禁止点击买卖按钮【订单已取消三次触发】
      const { cancelTimes } = this;
      return cancelTimes > 3 && this.userInfo.isBusiness === 0;
    },
    usdtPrice() {
      const { coinPrice: { USDT }, type } = this;
      switch (type) {
        case 'buy':
          return USDT?.buyPrice;
        case 'sell':
          return USDT?.sellPrice;
        default:
          return '-.--';
      }
    },
    type() {
      const { $route: { params } } = this;
      return params.type;
    },
    viewComponent() {
      const { type } = this;
      return type.replace(/^\w/, w => w.toUpperCase());
    },
    subButtonText() {
      const { type } = this;
      switch (type) {
        case 'buy':
          return '购买';
        case 'sell':
          return '出售';
        default:
          return '---';
      }
    },
  },
  methods: {
    ...mapActions(['fetchCoinPrice', 'fetchCancelTimes', 'fetchTradeCoin']),
    ...mapActions(name, ['fetchRealAuth']),
    async handleSubmit() {
      await this.fetchRealAuth(); // 用户安全校验
      await this.fetchCancelTimes(); // 取消次数

      if (this.userInfo.country !== 'China') { // 用户国籍校验
        this.$toast('抱歉，目前只支持大陆用户进行OTC交易');
        return false;
      }

      const { realAuth: { isPhoneBind, isRealAuth, isTradePasswordSet } } = this;
      const realAuthMessage = do{
        if (!isPhoneBind) return '用户未绑定手机';
        if (!isRealAuth) return '用户未实名认证';
        if (!isTradePasswordSet) return '用户未设置资金密码';
        return null;
      };

      // eslint-disable-next-line no-unreachable
      if (realAuthMessage) { // 用户交易必要条件校验
        this.$alert({
          title: '温馨提示',
          message: realAuthMessage,
          confirmText: '前往设置',
          confirmCallback: () => window.location.assign(`${process.env.VUE_APP_PANDA_URL}/userManagement`),
        });
        return false;
      }

      const {
        type, $refs: { customInput }, bankList, tradeCoin,
      } = this;

      if (type === 'sell' && !bankList.length) {
        this.$alert({
          title: '温馨提示',
          message: '你尚未绑定收款方式，请先绑定收款方式',
          confirmText: '立即前往',
          cancelText: '暂不设置',
          confirmCallback: () => this.$router.push('/accountSetting/bankCardManagement'),
        });
        return false;
      }

      if (customInput.validate()) { // 校验用户输入合法性
        this.isLoading = true; // 开启loading，禁止再次点击
        const { type: rule, amount, bankValue: paymentId } = customInput;
        const postData = {
          [rule === '0' ? 'count' : 'amount']: amount,
          rule,
          type: Number(type === 'sell'),
        };

        api.getTradeAd(postData).then(({ fid: advertiseId, price }) => { // 匹配广告
          this.isLoading = false;
          if (!advertiseId) return; // 未匹配到广告

          this.$alert({
            title: '订单确认',
            message: type === 'buy'
              ? `<div id="order-confirm-message" class="text-size-12 line-height-2">
                        <p class="d-flex justify-space-between align-center"><span class="text-label">交易金额</span><span style="color:#F6C40F;" class="text-size-16 text-weight-6">${customInput.transactionAmount}&nbsp;CNY</span></p>
                        <p class="d-flex justify-space-between"><span class="text-label">成交数量</span><span class="text-value">${customInput.transactionCount.toFixed(7).slice(0, -1)}&nbsp;USDT</span></p>
                        <p class="d-flex justify-space-between"><span class="text-label">成交单价</span><span class="text-value">${price}&nbsp;CNY</span></p>
                    </div>`
              : `<div id="order-confirm-message" class="text-size-12 line-height-2">
                        <p class="d-flex justify-space-between align-center"><span class="text-label">交易金额</span><span style="color:#F6C40F;" class="text-size-16 text-weight-6">${customInput.transactionAmount}&nbsp;CNY</span></p>
                        <p class="d-flex justify-space-between"><span class="text-label">成交数量</span><span class="text-value">${customInput.transactionCount.toFixed(7).slice(0, -1)}&nbsp;USDT</span></p>
                        <p class="d-flex justify-space-between"><span class="text-label">成交单价</span><span class="text-value">${price}&nbsp;CNY</span></p>
                        <p class="d-flex justify-space-between"><span class="text-label">收款方式</span><span class="text-value"><u style="color:#F6C40F;">银行卡</u><u class="margin-left-20 text-value">${bankList.find(({ fid }) => customInput.bankValue === fid).faccount}</u></span></p>
                    </div>`,
            confirmText: '确认下单',
            confirmCallback: () => {
              const currencyId = tradeCoin.buy.find(({ coinName }) => coinName === 'CNY')?.fcoinid;
              const coinId = tradeCoin.buy.find(({ coinName }) => coinName === 'USDT')?.fcoinid;
              return api.commitTransaction(Object.assign({
                advertiseId,
                price,
                currencyId,
                coinId,
              },
              type === 'sell' ? { paymentId } : undefined,
              postData))
                .then(({ forderId: id }) => this.$router.push(`/order/${id}`));
            },
          });
        }).catch(() => { this.isLoading = false; });
      }
    },
  },
  created() {
    this.fetchTradeCoin(); // 平台支持的币种查询
  },
  destroyed() {
    clearInterval(timer);
  },
  // eslint-disable-next-line vue/no-unused-components
  components: { Sell, Buy },
  watch: {
    type: {
      handler(n, o) {
        if (n !== o) {
          const { fetchCoinPrice, type: _type } = this;
          const type = _type === 'sell' ? 1 : 0;

          fetchCoinPrice(type);
          timer = clearInterval(timer) || setInterval(() => fetchCoinPrice(type), 3000);
        }
      },
      deep: true,
      immediate: true,
    },
  },
  data: () => ({
    isLoading: false,
  }),
};
</script>

<style scoped lang="scss">
  #business{
    background-color: white;
  }

  .margin-left-30{
    margin-left: 30px;
  }

  .business-title {
    color: white;
    background-color: #09090A;
    height: 90px;

    svg.icon {
      width: 30px;
      height: 30px;
    }

    .business-subTitle {
      color: rgba(255, 255, 255, 0.6);
      margin-left: 37px;
      align-items: flex-end;
    }
  }

  .business-body {
    margin: 40px auto 0;

    &, &+.business-footer{
      width: 510px;
    }

    ::v-deep .v-input__slot{

      .v-input__append-inner {
        margin-top: 0;
        align-self: center;
      }
    }

    &+.business-footer{
      margin: 0 auto 188px;
    }

    .border-bottom {
      margin: 10px 0;
      border-bottom: thin solid #E6ECF3;

      .business-tab-left {
        color: rgba(40, 40, 45, 0.6);
        height: 100%;

        .tab-buy, .tab-sell{
          height: 100%;
          display: flex;
          justify-items: center;
          align-items: center;
          padding: 9px 7px;
        }

        .active {
          color: rgba(40, 40, 45, 1);
          font-weight: 500;
          position: relative;

          &::after{
            position: absolute;
            content: "";
            height: 2px;
            background-color: #F6C40F;
            left: 0;
            right: 0;
            width: 100%;
            bottom: 0;
          }
        }
      }

      .business-tab-right {
        color: rgba(40, 40, 45, 0.6);

        svg.tips {
          width: 13.94px;
          height: 13.94px;
        }
      }
    }
  }

  .business-footer{

    .theme--dark.v-btn.v-btn--disabled:not(.v-btn--flat):not(.v-btn--text):not(.v-btn--outlined){
      background-color: #F6C40F !important;
      color: white !important;
      opacity: .6;
      cursor: none;
    }
  }
</style>
