<template>
  <v-form
    id="buy"
    ref="form"
    lazy-validation
  >
    <v-text-field
      id="buy-input"
      color="#f6c40f"
      :label="labelText"
      :placeholder="placeholderText"
      v-only-number:[digit]="amount"
      v-model="amount"
      :rules="amountRules"
      outlined
      autofocus
      flat
    >
      <template #append>
        <span class="unit-el">{{unit}}</span>
        <span class="padding-20">
          <svg class="icon checked margin-right-10" aria-hidden="true">
            <use xlink:href="#iconqiehuan"/>
          </svg>
          <i class="sell-input-append text-style-none cursor-pointer" @click.stop="handleTypeToggle">{{unitText}}</i>
        </span>
      </template>
    </v-text-field>
    <p class="d-flex justify-space-between align-center text-size-12 buy-calc-details"><span>成交单价：</span><span>{{price}} CNY</span></p>
    <p class="d-flex justify-space-between align-center text-size-12 buy-calc-details line-35"><span>成交数量：</span><span>{{transactionCount | toFixed(6)}} USDT</span></p>
    <p class="d-flex justify-space-between align-center text-size-12 buy-calc-details margin-bottom-25"><span>成交总额：</span><span>{{transactionAmount | toFixed(2)}} CNY</span></p>
  </v-form>
</template>

<script>
import { calc } from '../../utils/common';

const minAmount = 100;

export default {
  name: 'buy',
  data: () => ({
    amount: 100,
    type: 1, // 0-数量，1-金额
  }),
  watch: {
    type(n, o) { // 重置表单验证
      if (n !== o) this.$refs.form.resetValidation();
    },
  },
  computed: {
    unit() {
      const { type } = this.$data;
      switch (type) {
        case 0:
          return 'USDT';
        case 1:
          return 'CNY';
        default:
          return '---';
      }
    },
    amountRules() {
      const { type, price } = this;
      switch (type) {
        case 1:
          return [v => !!v || '下单金额不能为空', v => Number(v) >= minAmount || '最小下单金额为100 CNY'];
        case 0:
        {
          const minCount = calc(`${minAmount} ${price} /`).toFixed(6).slice(0, -1);
          return [v => !!v || '下单数量不能为空', v => Number(v) >= minCount || `最小下单数量为${minCount} USDT`];
        }
        default:
          return [];
      }
    },
    digit() {
      const { type } = this.$data;
      return type === 1 ? 2 : 8;
    },
    unitText() {
      const { type } = this.$data;
      switch (type) {
        case 0:
          return '按金额购买';
        case 1:
          return '按数量购买';
        default:
          return '---';
      }
    },
    labelText() {
      const { type } = this.$data;
      switch (type) {
        case 1:
          return '购买总金额';
        case 0:
          return '购买总数量';
        default:
          return '---';
      }
    },
    placeholderText() {
      const { type } = this.$data;
      switch (type) {
        case 1:
          return '请输入购买总金额';
        case 0:
          return '请输入购买总数量';
        default:
          return '---';
      }
    },
    transactionCount() { // 成交数量
      const { type, amount, price } = this;

      switch (type) {
        case 0: // 数量出售
          return amount;
        case 1: // 金额出售
          return calc(`${amount} ${price} /`);
        default:
          return '---';
      }
    },
    transactionAmount() { // 成交总金额
      const { type, amount, price } = this;

      switch (type) {
        case 0: // 数量出售
          return calc(`${amount} ${price} *`);
        case 1: // 金额出售
          return amount;
        default:
          return '---';
      }
    },
  },
  methods: {
    handleTypeToggle() {
      const { type } = this.$data;
      this.type = typeof type === 'number' && type ? 0 : 1;
    },
    validate() {
      return this.$refs.form.validate();
    },
    formReset() {
      return this.$refs.form.reset();
    },
  },
  props: {
    price: { required: true, type: Number },
  },
};
</script>

<style scoped lang="scss">
svg.checked{
  width: 12px;
  height: 12px;
}

#buy{
  padding-top: 35px;
}

.unit-el{
  border-right: thin solid #BCC6D2;
  padding-right: 20px;
}

  .padding-20{
    padding: 0 10px;
  }

  .buy-calc-details{
    color: #28282D;

    &>*:first-child{
        opacity: .6;
    }

    &>*:last-child{

    }

    &.line-35{
      padding: 35px 0;
    }

    &.margin-bottom-25{
      margin-bottom: 25px;
    }
  }
</style>
