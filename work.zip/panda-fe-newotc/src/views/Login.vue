<template>
  <div id="login">
    <div class="login-wrap">
      <!--登录区域-->
      <div class="form-custom">
        <h5 class="form-title">欢迎登录</h5>
        <p class="alert-warning"><!--Lemon otc与Panda已达成战略合作关系，请放心登录。--></p>
        <v-form
          ref="form"
          lazy-validation
        >
          <v-text-field
            v-model="formData.account.value"
            :rules="formData.account.rules"
            color="#f6c40f"
            label="账号"
            placeholder="请输入邮箱或手机号"
            outlined
            required
          />
          <v-text-field
            v-model="formData.password.value"
            :rules="formData.password.rules"
            color="#f6c40f"
            label="密码"
            type="password"
            placeholder="请输入密码"
            outlined
            required
          />
          <v-btn block color="#F6C40F" dark x-large depressed @click.stop="dialogVisible = $refs.form.validate()">登录</v-btn>
        </v-form>
        <div class="d-flex justify-md-space-between mt-2">
          <v-btn class="pa-0" text small min-width="40px" color="primary" @click.stop="forgetPassword">忘记密码？</v-btn>
          <div>
            <span class="text-size-12">还没有账号?</span>
            <v-btn class="pa-0" text small min-width="40px" color="primary" @click.stop="handleGotoRegister">注册</v-btn>
          </div>
        </div>
      </div>
    </div>
    <v-dialog
      v-model="dialogVisible"
      max-width="420"
    >
      <!--阿里验证区域-->
      <v-card>
        <v-card-title class="justify-space-between align-center">
          <span>验证</span>
          <v-icon @click.stop="dialogVisible = false">mdi-close</v-icon>
        </v-card-title>
        <v-card-text><div id="validate" class="nc-container"/></v-card-text>
      </v-card>
    </v-dialog>

    <v-dialog
      v-model="secVisible"
      max-width="420"
    >
      <!--验证码区域-->
      <v-card>
        <v-card-title class="justify-space-between align-center">
          <span>{{accountTypeLabel}}验证</span>
          <v-icon @click.stop="secVisible = false">mdi-close</v-icon>
        </v-card-title>
        <v-card-text>
          <v-form
            ref="secForm"
            lazy-validation
          >
            <p class="text-color-grey text-size-12 margin-bottom-10">请输入您的{{accountTypeLabel}} {{nch5Data.bindStatus.googleBind ? '' : formData.account.value}} 验证码</p>
            <v-text-field
              v-model="formData.code.value"
              :rules="formData.code.rules"
              height="42px"
              color="#f6c40f"
              label="验证码"
              placeholder="请输入验证码"
              single-line
              outlined
              required
            >
              <template #append v-if="!nch5Data.bindStatus.googleBind">
                <span :class="[sendStatus ? 'text-color-grey' : 'cursor-pointer', 'text-color-link', 'text-size-12','mt-2']" @click.stop="handleSendCode">{{btnText}}</span>
              </template>
            </v-text-field>
            <p class="text-center text-color-grey text-size-12" v-if="isEmail && !nch5Data.bindStatus.googleBind">*邮箱验证码可能被判定为垃圾邮件，请注意查收。</p>
            <v-btn block color="#F6C40F" dark x-large depressed @click.stop="handleSubmit" :loading="isLoading">确认</v-btn>
          </v-form>
        </v-card-text>
      </v-card>
    </v-dialog>
  </div>
</template>

<script>
import { Regex } from '../utils/constant';
import { cookies, mapActions } from '../utils/common';
import nch5 from '../plugins/nch5';
import api from '../api/apiModule_1';

let validateObj;
let timer;

export default {
  name: 'login',
  data: () => ({
    isLoading: false, // 登陆中
    dialogVisible: false, // 阿里滑块
    secVisible: false, // 短信|邮箱验证码
    sendStatus: false,
    btnText: '发送验证码',
    formData: {
      account: { value: '', rules: [v => !!v || '账号不能为空', v => Regex.ACCOUNT.test(v) || '账号输入不合法'] },
      password: { value: '', rules: [v => !!v || '密码不能为空', v => !/\s+/.test(v) || '密码中不能包含空格', v => Regex.PASSWORD.test(v) || '密码为8-20位字符，需包含数字、大写字母和小写字母'] },
      code: { value: '', rules: [v => !!v || '验证码不能为空', v => v?.length === 6 || '验证码长度不对'] },
    },
    nch5Data: { bindStatus: { googleBind: false } }, // 阿里滑块后获取的整理最终数据
  }),
  computed: {
    accountTypeLabel() {
      const { account: { value: account } } = this.formData;
      const { bindStatus: { googleBind } } = this.nch5Data;
      switch (true) {
        case googleBind:
          return '谷歌';
        case Regex.EMAIL.test(account):
          return '邮箱';
        case Regex.CHINA_PHONE.test(account) || Regex.PHONE.test(account):
          return '手机';
        default:
          return '---';
      }
    },
    isEmail() {
      const { account: { value: account } } = this.formData;
      return Regex.EMAIL.test(account);
    },
  },
  watch: {
    dialogVisible(n, o) {
      if (n !== o) {
        if (n) {
          this.$nextTick(() => {
            const { formData: { account: { value: loginName }, password: { value: password } } } = this;
            validateObj = nch5('validate', {
              success: (data) => {
                api.login({
                  loginName, // = 登录账户
                  password, // = 密码
                  platform: 3,
                  ...data,
                }).then(({
                  emailBind, googleBind, phoneBind, ticket,
                }) => {
                  [this.nch5Data, this.dialogVisible] = [{ ticket, account: loginName, bindStatus: { emailBind, googleBind, phoneBind } }, false];
                  this.$nextTick(() => { this.secVisible = true; }); // 开启验证码输入框
                }).catch(() => {
                  this.dialogVisible = false;
                });
              },
              // eslint-disable-next-line no-console
              error(e) { console.error(e); },
            });
          });
        } else {
            // eslint-disable-next-line no-unused-expressions
            validateObj?.reset();
        }
      }
    },
  },
  methods: {
    ...mapActions(['fetchUserInfo']),
    handleGotoRegister() {
      window.open(`${process.env.VUE_APP_PANDA_URL}/register`);
    },
    forgetPassword() {
      window.open('https://www.panda.co/forgetPassword');
    },
    handleSendCode() {
      const { ticket, bindStatus: { googleBind } } = this.$data.nch5Data;
      if (googleBind || this.sendStatus) return;
      this.sendStatus = true;
      const func = this.isEmail ? 'sendLoginEmail' : 'sendSms';
      if (func) {
        api[func](this.isEmail ? {
          ticket,
        } : {
          type: 127, //  = 127
          ticket,
        }).then(() => {
          let count = 60;
          timer = setInterval(() => {
            if (count > 0) this.btnText = `${count -= 1}S后重新发送`;
            else { this.sendStatus = false; this.btnText = '重新发送'; clearInterval(timer); }
          }, 1000);
        }).catch(() => { this.sendStatus = false; });
      }
    },
    handleSubmit() {
      if (!this.$refs.secForm.validate() || this.isLoading) return;
      const { formData: { code: { value: code } }, nch5Data: { ticket } } = this.$data;
      this.isLoading = true;
      api.getLoginToken({ ticket, code }).then((token) => {
        cookies.set('token', token);
        [this.isLoading] = [false, this.$refs.form.reset(), this.$refs.secForm.reset(), this.$nextTick(this.fetchUserInfo)];
        this.$router.push('/');
      }).catch(() => { this.isLoading = false; });
    },
  },
  destroyed() {
    clearInterval(timer);
  },
};
</script>

<style scoped lang="scss">
  #login {
    background-color: #18181A;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .text-color-grey{
    color: rgba(40, 40, 45, 0.6) !important;
  }

  .text-color-link{
    color: #1581F2;
  }

  .margin-bottom-10{
    margin-bottom: 10px;
  }

  .login-wrap {

    .form-custom {
      padding: 20px 20px 40px;
      width: 400px;
      background-color: $white-color;
      border-radius: 5px;

      .form-title{
        color: #28282D;
        font-size: 18px;
      }

      .alert-warning{
        /*background-color: rgba(242, 193, 16, 0.08);
        color: #EEA30C;*/
        font-size: 12px;
        padding: 9px 0 9px 10px;
        margin: 15px 0;
      }
    }
  }

  .v-dialog{
    .v-card__title{
      position: relative;

      &::after{
        position: absolute;
        content: "";
        left: 16px;
        right: 16px;
        bottom:  0;
        background-color: #EEEEEE;
        height: 2px;
      }

    }

    .v-card__text{
      padding: 33px 16px;
    }
  }
</style>
