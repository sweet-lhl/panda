<template>
  <div id="merchant">
    <div class="merchant-tab">
      <div class="merchant-wrap">
        <div>OTC管理</div>
        <v-tabs
          dark
          v-model="type"
          color="#F6C40F"
          height="38px"
          background-color="#09090A">
          <v-tab>发布商品</v-tab>
          <v-tab>交易数据</v-tab>
          <v-tab>商品管理</v-tab>
          <v-tab>自动回复设置</v-tab>
        </v-tabs>
      </div>
    </div>
    <div class="merchant-wrap">
      <component :is="switchTab"/>
    </div>
  </div>
</template>

<script>
import Release from './Release.vue';
import Transaction from './Transaction.vue';
import Administration from './Administration.vue';
import ChatReply from './ChatReply.vue';

export default {
  name: 'merchant',
  data() {
    const { $route: { params: { type } } } = this;
    return {
      type: do{
        if (type === 'release') return 0; // 发布商品
        if (type === 'transaction') return 1;// 交易数据
        if (type === 'chatReply') return 3;// 新增回复设置
        return 2;// 商品管理
      },
    };
  },
  components: {
    // eslint-disable-next-line vue/no-unused-components
    Release, Transaction, Administration, ChatReply,
  },
  computed: {
    switchTab() {
      const { type } = this;
      switch (type) {
        case 0:
          this.$router.replace('/merchant/release');
          return 'Release';// 发布商品
        case 1:
          this.$router.replace('/merchant/transaction');
          return 'Transaction';// 交易数据
        case 2:
          this.$router.replace('/merchant/administration');
          return 'Administration';// 商品管理
        default:
          this.$router.replace('/merchant/chatReply');
          return 'ChatReply';// 新增回复设置
      }
    },
  },
};
</script>

<style lang="scss" scoped>
  #merchant{
    background-color: #ffffff;
  }
  .merchant-tab {
    background-color: #09090A;
  }

  .merchant-wrap {
    width: 90%;
    max-width: 1180px;
    min-width: 1068px;
    margin: 0 auto;
     &:first-child {
       div{
         &:first-child{
           font-size:22px;
           font-family:PingFangSC-Medium,PingFang SC;
           font-weight:500;
           color:rgba(255,255,255,1);
           padding-top: 30px;
           padding-bottom: 28px;
         }
       }
     }
  }
</style>
