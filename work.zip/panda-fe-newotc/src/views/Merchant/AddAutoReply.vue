<template>
  <v-overlay :value="overlay" dark color="rgba(40, 40, 45, 1)">
    <div id="release">
      <div class="form-header d-flex justify-space-between align-center">
        <h5 class="text-size-16 text-weight-5">{{form.id ? '编辑' : '新增' }}自动回复</h5>
        <v-btn icon @click.stop="$emit('update:overlay', false)">
          <v-icon color="#484855">mdi-close</v-icon>
        </v-btn>
      </div>
      <div class="release-border">
        <v-form ref="form" v-model="valid" light lazy-validation>
          <v-row>
            <v-col cols="3">
              <v-subheader>交易类型：</v-subheader>
            </v-col>
            <v-col cols="4">
              <v-checkbox
                v-model="form.type"
                :rules="[v => !!v || '请选择交易类型']"
                color="#F6C40F"
                label="买入"
                value="0"
                :disabled="!!form.id"
                light
              ></v-checkbox>
            </v-col>
            <v-col cols="4">
              <v-checkbox
                v-model="form.type"
                color="#F6C40F"
                :rules="[v => !!v || '']"
                label="卖出"
                value="1"
                :disabled="!!form.id"
                light
              ></v-checkbox>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="3">
              <v-subheader>交易币种：</v-subheader>
            </v-col>
            <v-col cols="8">
              <v-checkbox
                input-value="true"
                :rules="[v => !!v || '请选择交易币种']"
                color="#F6C40F"
                label="USDT"
                :disabled="!!form.id"
                light
              ></v-checkbox>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="3">
              <v-subheader>结算货币：</v-subheader>
            </v-col>
            <v-col cols="8">
              <v-checkbox
                input-value="true"
                :rules="[v => !!v || '请选择结算货币']"
                color="#F6C40F"
                :disabled="!!form.id"
                label="CNY"
                light
              ></v-checkbox>
            </v-col>
          </v-row>
         <!-- <v-row>
            <v-col cols="3">
              <v-subheader>支付方式：</v-subheader>
            </v-col>
            <v-col cols="3">
              <v-checkbox
                :rules="[v => !!v || '请选择支付方式']"
                color="#F6C40F"
                v-model="form.fpayid"
                value="1"
                :disabled="!!form.id"
                label="支付宝"
                light
              ></v-checkbox>
            </v-col>

            <v-col cols="3">
              <v-checkbox
                :rules="[v => !!v || '请选择支付方式']"
                color="#F6C40F"
                v-model="form.fpayid"
                value="2"
                :disabled="!!form.id"
                label="微信"
                light
              ></v-checkbox>
            </v-col>
            <v-col cols="3">
              <v-checkbox
                input-value="0"
                :rules="[v => !!v || '请选择支付方式']"
                color="#F6C40F"
                v-model="form.fpayid"
                value="0"
                :disabled="!!form.id"
                label="银行卡"
                light
              ></v-checkbox>
            </v-col>
          </v-row>-->
          <v-row>
            <v-col cols="12">
              <v-subheader>自动回复：</v-subheader>
              <v-textarea
                outlined
                v-model="form.content"
                :dark="false"
                :loading="subLoading"
                :disabled="subLoading"
                :rules="[v => !!v || '请填写自动回复']"
                light
                maxlength="50"
                :counter="50"
              ></v-textarea>
            </v-col>
          </v-row>
          <v-row v-if="form.id">
            <v-col cols="3">
              <v-subheader>交易密码：</v-subheader>
            </v-col>
            <v-col cols="8">
              <InputPassword
                v-model="form.password"
                :rules="password.rules"
                placeholder="请输入资金密码"
                type="password"
                light
                required
              />
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="12">
              <v-btn color="#F6C40F" @click.prevent="handleSubmit" block light depressed>
                {{form.id ? '提交' : '添加' }}
                <template v-slot:loader>
                  <span>提交中...</span>
                </template>
              </v-btn>
            </v-col>
          </v-row>
        </v-form>
      </div>
    </div>
  </v-overlay>
</template>

<script>
import { Regex } from '../../utils/constant';
import api from '../../api/apiModule_1';
import InputPassword from '../../components/InputPassword.vue';

export default {
  name: 'addReplyCard',
  props: {
    overlay: { type: Boolean, default: false },
    replyDetails: { type: Object, default: () => Object.create(null) },
  },
  data: () => ({
    loader: null,
    valid: true,
    subLoading: null,
    form: {
      type: 0, // 买卖类型，0-卖单，1-买单
      // fpayid: '1', // 支付类型：0-银行卡，1-支付宝，2-微信
      content: '',
    },
    password: {
      rules: [v => !!v || '资金密码不能为空', v => !/\s+/.test(v) || '资金密码不能包含空格', v => Regex.PASSWORD.test(v) || '资金密码格式不正确'], /* 密码为8-20位字符，需包含数字、大写字母和小写字母 */
    },
  }),
  components: { InputPassword },
  methods: {
    handleSubmit() {
      if (this.$refs.form.validate()) {
        [this.loader, this.subLoading] = ['subLoading', true];
        api[this.form.id ? 'updateAutoReplyConfig' : 'addAutoReplyConfig'](this.form).then(() => {
          [this.loader, this.subLoading] = [null, false];
          this.$toast(`${this.form.id ? '修改' : '新增'}成功!`);
          this.$emit('update:overlay', false);
        }).catch(() => {
          [this.loader, this.subLoading] = [null, false];
        });
      }
    },
  },
  watch: {
    replyDetails: { // 用于修改时赋值
      handler(n, o) {
        if (n !== o && n.id) {
          const data = JSON.parse(JSON.stringify(n));
          this.$data.form = data;
          this.$data.form.type = String(data.type);
          /* this.$data.form.fpayid = String(data.fpayid); */
        }
      },
      deep: true,
      immediate: true,
    },
    overlay(n, o) {
      if (n !== o && !n) {
        this.form = {
          type: 0, // 买卖类型，0-卖单，1-买单
          // fpayid: '1', // 支付类型：0-银行卡，1-支付宝，2-微信
          content: '',
        };
        // eslint-disable-next-line no-unused-expressions
      }
    },
  },
};
</script>

<style scoped lang="scss">
$borderColor: #eeeeee;
$textColor: #484855;

#release {
  width: 420px;
  background-color: white;
  padding: 15px 20px;

  .form-header {
    // padding: 0 0 20px;
    border-bottom: thin solid $borderColor;
    color: $textColor;
  }

  .release-border {
    // margin: 40px 0;
    // padding: 28px 40px;
    // border:1px solid rgba(230,236,243,1);
    border-radius: 2px;
    color: $textColor;
  }
  .row {
    align-items: center;
    font-size: 14px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: rgba(40, 40, 45, 1);
    line-height: 14px;
  }
  .v-subheader,
  .v-label {
    font-size: 14px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: rgba(40, 40, 45, 1);
    line-height: 14px;
    padding: 0;
  }
  // .v-input--selection-controls {
  //   margin-top: 10px;
  // }
  .no-data-image {
    width: 10px;
    height: 10px;
    margin-left: 5px;
  }
  .col {
    padding: 0 12px !important;
  }
}
</style>
