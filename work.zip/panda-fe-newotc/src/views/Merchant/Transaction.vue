<template>
  <div id="Transaction">
    <div class="margin-top-30">
      <Statistics />
      <!--<div class="d-flex justify-space-between">
        <div class="tab-transaction">
          <v-tabs
          v-model="getOrderStatus"
          color="#28282D"
          height="40px"
          slider-color="#F6C40F">
          <v-tab v-for="x in orderStatus">{{x.name}}</v-tab>
        </v-tabs>
        </div>

        <v-switch
          hideDetails
          readonly
          :input-value="stoporder"
          @click.stop="overlay=true"
          color="#F6C40F"
          class="ma-4"
          label="停止接单"
        />
      </div>-->
      <v-tabs
        v-model="getOrderStatus"
        color="#28282D"
        height="40px"
        slider-color="#F6C40F">
        <v-tab v-for="x in orderStatus" :key="x.id">{{x.name}}</v-tab>
      </v-tabs>
      <div class="transaction-screen" v-if="queryType===4||queryType===5">
        <div class="d-flex align-content-center align-center">
          <div class="screen-text">订单号</div>
          <div class="mb-3">
            <v-text-field
              color="#f6c40f"
              v-model="orderId"
              label="请输入订单号"
              type="number"
              height="28px"
              solo
              dense
              outlined
              single-line
              clearable
            ></v-text-field>
          </div>

          <div class="screen-text">交易类型</div>
          <div class="input-width-100 mb-3">
            <v-select
              :menu-props="{ offsetY: true }"
              v-model="type"
              :items="orderType"
              item-text="name"
              item-value="id"
              label="请选择交易类型"
              solo
              dense
              outlined
              single-line
            ></v-select>
          </div>

          <div class="screen-text">时间范围</div>
          <div class="input-width-140">
            <v-menu
              v-model="begin"
              :close-on-content-click="false"
              transition="scale-transition"
              offset-y
              min-width="290px"
            >
              <template v-slot:activator="{ on }">
                <v-text-field
                  color="#f6c40f"
                  v-model="begindate"
                  label="开始时间"
                  hideDetails
                  readonly
                  dense
                  outlined
                  single-line
                  clearable
                  v-on="on"
                ></v-text-field>
              </template>
              <v-date-picker
                v-model="begindate"
                no-title
                :first-day-of-week="0"
                locale="zh-cn"
                scrollable
                @input="begin = false"
              ></v-date-picker>
            </v-menu>
          </div>

          <div class="screen-text division">-</div>
          <div class="input-width-140">
            <v-menu
              v-model="end"
              :close-on-content-click="false"
              transition="scale-transition"
              offset-y
              min-width="290px"
            >
              <template v-slot:activator="{ on }">
                <v-text-field
                  color="#f6c40f"
                  v-model="enddate"
                  label="结束时间"
                  hideDetails
                  readonly
                  dense
                  outlined
                  single-line
                  clearable
                  v-on="on"
                ></v-text-field>
              </template>
              <v-date-picker
                v-model="enddate"
                no-title
                :first-day-of-week="0"
                locale="zh-cn"
                scrollable
                @input="end = false"
              ></v-date-picker>
            </v-menu>
          </div>

          <div class="margin-left-20">
            <v-btn color="#F6C40F"
                   width="60px"
                   height="28px"
                   small
                   depressed
                   @click="handleSubmit">
              搜索
            </v-btn>
          </div>
        </div>

      </div>
    </div>

    <v-data-table
      :headers="tabHeaders"
      :items="orderTable"
      :page.sync="pagination.pageIndex"
      :items-per-page="pagination.pageSize"
      class="tabulation-footer"
      hide-default-footer
      :loading="isLoading"
      loading-text="数据加载中..."
    >
      <template #item.fcreatetime="{ item }">
        {{item.fcreatetime | timeStampToDate}}
      </template>

      <template #item.fstatus="{ item }">
        {{item.fstatus | orderStatusText}}
      </template>

      <template #item.fprice="{ item }">
        {{item.fprice | toFixed(2)}}
      </template>

      <template #item.fcount="{ item }">
        {{item.fcount | toFixed(8)}}
      </template>

      <template #item.famount="{ item }">
        {{item.famount | toFixed(2)}}
      </template>

      <template #item.forderid="{ item }">
        <span :class="[item.ftype === 1 ? 'background-color-black' : 'background-color-yellow', 'order-type']">{{item.ftypeString | orderTypeText }}</span>
        <span class="text-size-14 pl-2 cursor-pointer" @click.stop="$router.push(`/order/${item.forderid}`)">{{item.forderid}}</span>
      </template>

      <template v-slot:no-data>
        <svg class="icon no-data-image cursor-pointer" aria-hidden="true">
          <use xlink:href="#iconzanwudingdan"/>
        </svg>
        <p class="no-data-text">暂无订单</p>
      </template>

      <template #footer v-if="totalRows>pagination.pageSize">
        <v-pagination v-model="pagination.pageIndex" :length="pagination.total" :total-visible="9" color="#F0BC02" class="justify-end padding-top-20 padding-bottom-20"/>
      </template>
    </v-data-table>


    <!--停止接单-->
    <v-overlay :value="overlay">
      <v-form
        ref="form"
        lazy-validation
      >
        <div class="form-header d-flex justify-space-between align-center">
          <h5 class="text-size-16 text-weight-5">资金密码</h5>
          <v-btn
            icon
            @click.stop="overlay=false"
          ><v-icon color="#484855">mdi-close</v-icon></v-btn>
        </div>

        <InputPassword
          v-model="formOverlay.tradePwd.value"
          :rules="formOverlay.tradePwd.rules"
          label="资金密码"
          placeholder="请输入资金密码"
          type="password"
          light
          outlined
          required
        />

        <v-btn
          color="#F6C40F"
          @click.prevent="fetchOtcStop"
          block
          light
          depressed
        >提交</v-btn>
      </v-form>
    </v-overlay>
  </div>
</template>

<script>
import api from '../../api/apiModule_1';
import { PagingDefaultConf, Regex } from '../../utils/constant';
import InputPassword from '../../components/InputPassword.vue';
import Statistics from './Statistics.vue';

export default {
  name: 'Transaction',
  data() {
    return {
      date: new Date().toISOString().substr(0, 10),
      pagination: { ...PagingDefaultConf },
      begindate: '',
      begin: false,
      enddate: '',
      end: false,
      orderStatus: [{ id: 1, name: '全部' }, { id: 100, name: '进行中' }, { id: 6, name: '申诉中' }, { id: 4, name: '已完成' }, { id: 5, name: '已取消' }], // 进行中id暂时写死100
      tabHeaders: [
        { text: '订单号', value: 'forderid', sortable: false },
        {
          text: '时间', value: 'fcreatetime', sortable: false, align: 'right',
        },
        {
          text: '交易对象', value: 'username', sortable: false, align: 'right',
        },
        {
          text: '单价', value: 'fprice', sortable: false, align: 'right',
        },
        {
          text: '数量', value: 'fcount', sortable: false, align: 'right',
        },
        {
          text: '总价', value: 'famount', sortable: false, align: 'right',
        },
        {
          text: '状态', value: 'fstatus', sortable: false, align: 'right',
        },
      ],
      getOrderStatus: 1, // 根据此值 获取queryType值
      queryType: 100,
      orderId: '',
      type: 3,
      orderType: [{ id: 3, name: '全部' }, { id: 0, name: '购买' }, { id: 1, name: '出售' }],
      orderTable: [],
      isLoading: false,
      formOverlay: {
        tradePwd: { value: '', rules: [v => !!v || '资金密码不能为空', v => !/\s+/.test(v) || '资金密码不能包含空格', v => Regex.PASSWORD.test(v) || '资金密码格式不正确'] /* 密码为8-20位字符，需包含数字、大写字母和小写字母 */},
      },
      overlay: false,
      stoporder: 0,
      totalRows: 0,
    };
  },
  components: {
    InputPassword,
    Statistics,
  },
  created() {
    this.fetchOtcAccount();
  },
  methods: {
    fetchOtcStop() {
      if (this.$refs.form.validate()) {
        const { formOverlay: { tradePwd: { value: tradePwd } } } = this;
        api.OtcStop({ tradePwd }).then(() => {
          [this.overlay] = [false, this.$refs.form?.reset()];
          this.stoporder = this.stoporder ? 0 : 1;
        }).catch(this.$refs.form?.reset);
      }
    },
    fetchOtcAccount() {
      api.OtcAccount().then((data) => {
        this.stoporder = data.stoporder;
      });
    },
    fetchOrderList() {
      const {
        pagination: { pageIndex: pageNum, pageSize }, type,
      } = this;
      let {
        begindate, enddate, queryType, orderId,
      } = this;
      if (begindate === null) begindate = '';
      if (enddate === null) enddate = '';
      if (orderId === null) orderId = '';
      const [start, end] = [new Date(begindate).getTime() / 1000, new Date(enddate).getTime() / 1000];

      if (begindate && enddate && start > end) {
        this.$toast('开始时间不能大于结束时间');
        return;
      }
      this.isLoading = true;
      let otcOrder = 'otcOrderHistory';
      if (queryType === 100) { // 进行中 -全部
        [queryType, otcOrder] = [1, 'otcOrderCurrent'];
      }
      if (queryType === 6) { // 申诉中
        otcOrder = 'otcOrderCurrent';
      }
      const params = {
        isBusiness: 1, pageNum, pageSize, queryType, orderId, type, begindate, enddate,
      };

      // eslint-disable-next-line consistent-return
      return api[otcOrder](params)
        .then(({ totalRows, totalPages: total, data }) => {
          [this.orderTable, this.pagination.total, this.isLoading, this.totalRows] = [data, total, false, totalRows];
        }).catch(() => { this.isLoading = false; });
    },
    handleClear() {
      [this.orderId, this.begindate, this.enddate] = ['', '', ''];
    },
    handleSubmit() {
      this.pagination.pageIndex = 1;
      this.fetchOrderList();
    },
  },

  watch: {
    'pagination.pageIndex': {
      handler(n, o) {
        if (n !== o) this.fetchOrderList();
      },
      deep: true,
      immediate: true,
    },
    getOrderStatus(n, o) {
      this.queryType = this.orderStatus[n].id;
      this.pagination.pageIndex = 1;
      this.handleClear();
      if (n !== o) this.fetchOrderList();
    },
  },
};
</script>

<style lang="scss" scoped>
  ::v-deep .v-slide-group__content,.transaction-screen {
    border-bottom: 1px solid rgba(230, 236, 243, 1);
  }
  .transaction-screen{
    padding: 20px 0;
  }
  .screen-text{
    font-size:12px;
    line-height: 28px;
    margin-right: 10px;
    font-family:PingFangSC-Regular,PingFang SC;
    font-weight:400;
    color:rgba(40,40,45,1);
    margin-left: 32px;
    &:first-child{
      margin-left: 0;
    }
  }

  ::v-deep .v-text-field.v-text-field--solo .v-input__control {
    min-height: 28px;
    height: 28px;
  }
  ::v-deep .v-input, ::v-deep .v-label{
    font-size: 12px;
  }
  ::v-deep .theme--light.v-messages{
    border: 1px solid rgba(230, 236, 243, 1);
  }
  ::v-deep .v-text-field.v-text-field--enclosed .v-text-field__details{
    margin: 10px 0;
    padding: 4px 15px;
  }
  .row{
    align-items: center;
    justify-items: center;
  }
  .v-data-table{
    margin-bottom: 40px;

    svg.no-data-image{
      width: 65px;
      height: 65px;
      margin-top: 111px;
      border-radius: 50%;
    }

    ::v-deep td{
      font-size: 12px;
    }

    .no-data-text{
      color: rgba(40, 40, 45, 0.6);
      font-size:12px;
      font-weight: 400;
      margin: 15px 0 111px;
    }

    .background-color-black{
      background-color: #28282D;
      color: white;
    }

    .background-color-yellow{
      background-color: #F6C40F;
      color: #28282D;
    }

    .order-type{
      margin-right: 5px;
      padding: 2px;
      border-radius: 1px;
    }
  }
  .division{
    margin: 0 10px;
  }
  .input-width-100{
    width: 100px;
  }
  .input-width-140{
    width: 140px;
  }
  ::v-deep .ma-4{
    margin: 2px!important;
  }
  .tab-transaction{
    width: 90%;
  }

  ::v-deep .v-slide-group__content {
    border-bottom: 1px solid rgba(230, 236, 243, 1);
  }
  $borderColor: #EEEEEE;
  $textColor: #484855;
  .v-form{
    width: 420px;
    background-color: white;
    padding: 25px 20px;

    .form-header{
      margin: 0 0 20px;
      border-bottom: thin solid $borderColor;
      color: $textColor;
    }
    ::v-deep .theme--light.v-messages{
      border: none;
    }
  }
  ::v-deep .v-text-field.v-text-field--solo:not(.v-text-field--solo-flat)>.v-input__control>.v-input__slot{
    box-shadow: none;
  }
</style>
