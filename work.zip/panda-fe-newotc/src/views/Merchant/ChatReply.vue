<template>
  <div id="ChatReply">
    <div class="margin-top-30">
      <v-btn color="#F6C40F" @click="overlay=true" depressed>+ 新增自动回复</v-btn>
    </div>
    <v-data-table
      :headers="tabHeaders"
      :items="orderTable"
      :page.sync="pagination.pageIndex"
      :items-per-page="pagination.pageSize"
      @page-count="pagination.total = $event"
      class="tabulation-footer margin-top-10"
      hide-default-footer
      :loading="isLoading"
      loading-text="数据加载中..."
    >
      <template #item.fcreatetime="{ item }">{{item.fcreatetime | timeStampToDate}}</template>

      <template #item.fstatus="{ item }">{{item.fstatus | orderStatusText}}</template>

     <!-- <template #item.fpayid="{ item }">
        <svg class="icon bank-image" aria-hidden="true">
          <use :xlink:href="`#${item.fpayid===1?'iconzhifubao':item.fpayid===2?'iconweixin':'iconyinhangka'}`"/>
        </svg>
      </template>-->

      <template #item.forderid="{ item }">
        <span
          :class="[item.ftype === 1 ? 'background-color-black' : 'background-color-yellow', 'order-type']"
        >{{item.ftypeString | orderTypeText }}</span>
        <v-btn text small color="#28282D" :to="`/order/${item.forderid}`">{{item.forderid}}</v-btn>
      </template>
      <template #item.action="{ item}">
        <!--操作-->
        <v-btn text small color="#1581F2" class="pa-0" @click="handleOverlay(item)">编辑</v-btn>
        <v-btn text small color="#1581F2" class="pa-0" @click="handleDeleteBankcard(item.id)">删除</v-btn>
      </template>
      <template #item.status="{ item: { status: status, id: id }}">
        <v-switch
          hideDetails
          readonly
          :input-value="status===1"
          @click.stop="handleUpdateAutoReply(id, status)"
          color="#F6C40F"
          :class="['ma-4']"
          label
        />
      </template>
      <template #no-data>
        <svg class="icon no-data-image cursor-pointer" aria-hidden="true">
          <use xlink:href="#iconzanwudingdan" />
        </svg>
        <p class="no-data-text">暂无自动回复</p>
      </template>

      <template #footer v-if="pagination.total>1">
        <v-pagination
          v-model="pagination.pageIndex"
          :length="pagination.total"
          :total-visible="9"
          color="#F0BC02"
          class="justify-end padding-top-20 padding-bottom-20"
        />
      </template>
    </v-data-table>
    <AddAutoReply
      :overlay.sync="overlay"
      :replyDetails.sync="replyActiveItem"
      @update:overlay="handleSubmit"
    ></AddAutoReply>
    <DelAutoReply
      :overlay.sync="deleteOverlay"
      :updateData.sync="updateData"
      :callBack.sync="callBack"
      @update:overlay="handleSubmitOne"
    />
  </div>
</template>

<script>
import api from '../../api/apiModule_1';
import AddAutoReply from './AddAutoReply.vue';
import DelAutoReply from './DelAutoReply.vue';
import { PagingDefaultConf } from '../../utils/constant';

export default {
  name: 'ChatReply',
  components: {
    AddAutoReply,
    DelAutoReply,
  },
  data() {
    return {
      date: new Date().toISOString().substr(0, 10),
      pagination: { ...PagingDefaultConf },
      beginDate: null,
      begin: false,
      endDate: null,
      overlay: false,
      bankDetails: '',
      end: false,
      replyActiveItem: {},
      tabHeaders: [
        { text: '币种', value: 'tradeCoinIdString', sortable: false },
        {
          text: '结算币种', value: 'settleCoinIdString', sortable: false, align: 'right',
        },
        {
          text: '交易类型', value: 'typeString', sortable: false, align: 'right',
        },
        /* {
          text: '支付方式', value: 'fpayid', sortable: false, align: 'center',
        }, */
        {
          text: '自动回复文案', value: 'content', sortable: false, align: 'right', width: 300,
        },
        {
          text: '操作', value: 'action', sortable: false, align: 'right',
        },
        {
          text: '开关', value: 'status', sortable: false, align: 'center',
        },
      ],
      getOrderStatus: 1, // 根据此值 获取queryType值
      queryType: 100,
      orderId: '',
      type: 3,
      orderType: [{ id: 3, name: '全部' }, { id: 0, name: '购买' }, { id: 1, name: '出售' }],
      orderTable: [],
      isLoading: false,
      deleteOverlay: false,
      updateData: {},
      callBack: '',
    };
  },
  methods: {
    handleClear() {
      [this.orderId, this.beginDate, this.endDate] = ['', null, null];
    },
    handleSubmitOne(value) {
      if (!value) return;
      this.handleSubmit();
      this.deleteOverlay = false;
      if (this.callBack === 'delAutoReplyConfig') {
        this.$toast('删除成功！');
      } else {
        this.$toast(`自动回复${this.updateData.status === 0 || this.updateData.status === '0' ? '关闭' : '开启'}成功!`);
      }
    },
    handleSubmit() {
      this.pagination.pageIndex = 1;
      this.fetchOrderList();
    },
    fetchOrderList() {
      this.isLoading = true;
      const { pagination: { pageIndex: pageNum, pageSize } } = this;
      const params = {
        page: pageNum,
        number: pageSize,
      };
      return api.listAutoReplyConfig(params)
        .then(({ totalCount, data }) => {
          [this.orderTable, this.pagination.total, this.isLoading] = [data, Math.ceil(totalCount / pageSize), false];
        }).catch(() => { this.isLoading = false; });
    },
    handleOverlay(row) {
      [this.overlay, this.replyActiveItem] = [true, JSON.parse(JSON.stringify(row))];
    },
    handleDeleteBankcard(id) {
      this.updateData = { id };
      this.callBack = 'delAutoReplyConfig';
      // this.bankList.splice(eq, 1);
      process.nextTick(() => { this.deleteOverlay = true; }); // 开启删除弹窗
    },
    handleUpdateAutoReply(id, status) {
      this.updateData = { id, status: status === 0 || status === '0' ? 1 : 0 };
      this.callBack = 'updateAutoReplyConfig';
      // this.bankList.splice(eq, 1);
      process.nextTick(() => { this.deleteOverlay = true; }); // 开启删除弹窗
    },
  },

  watch: {
    'pagination.pageIndex': {
      handler(n, o) {
        if (n !== o) this.fetchOrderList();
      },
      deep: true,
      immediate: true,
    },
  },
};
</script>

<style lang="scss" scoped>
::v-deep .v-slide-group__content,
.transaction-screen {
  border-bottom: 1px solid rgba(230, 236, 243, 1);
}
.transaction-screen {
  padding: 20px 0;
}
.screen-text {
  font-size: 12px;
  line-height: 28px;
  margin-right: 10px;
  font-family: PingFangSC-Regular, PingFang SC;
  font-weight: 400;
  color: rgba(40, 40, 45, 1);
  margin-left: 32px;
  &:first-child {
    margin-left: 0;
  }
}

::v-deep .v-text-field.v-text-field--solo .v-input__control {
  min-height: 28px;
  height: 28px;
}
::v-deep .v-input,
::v-deep .v-label {
  font-size: 12px;
}
// ::v-deep .theme--light.v-messages {
//   border: 1px solid rgba(230, 236, 243, 1);
// }
::v-deep .v-text-field.v-text-field--enclosed .v-text-field__details {
  margin: 4px 0;
  padding: 0 15px;
}

.v-input--selection-controls.v-input {
  justify-content: center;
}
.row {
  align-items: center;
  justify-items: center;
}
.v-data-table {
  margin-bottom: 40px;

  svg.no-data-image {
    width: 65px;
    height: 65px;
    margin-top: 111px;
  }

  ::v-deep td {
    font-size: 12px;
  }

  .no-data-text {
    color: rgba(40, 40, 45, 0.6);
    font-size: 12px;
    font-weight: 400;
    margin: 15px 0 111px;
  }

  .background-color-black {
    background-color: #28282d;
    color: white;
  }

  .background-color-yellow {
    background-color: #f6c40f;
    color: #28282d;
  }

  .order-type {
    margin-right: 5px;
    padding: 2px;
    border-radius: 1px;
  }
}
.division {
  margin: 0 10px;
}
.input-width-100 {
  width: 100px;
}
.input-width-140 {
  width: 140px;
}
</style>
