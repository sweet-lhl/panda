<template>
  <div id="Administration">
   <div class="margin-top-30 d-flex justify-md-space-between">
     <div class="col-xl-10 pr-0">
       <v-tabs
         v-model="getTabStatus"
         color="#28282D"
         height="40px"
         slider-color="#F6C40F">
         <v-tab v-for="x in tabStatus" :key="x.id">{{x.name}}{{status===x.id&&totalRows?`(${totalRows})`:''}}</v-tab>
       </v-tabs>
     </div>
     <div class="col-3 text-center pl-0" v-if="coinPrice.USDT">
       <p class="coinPrice text-size-14 pt-2">市场价格：买{{coinPrice.USDT.sellPrice | toFixed(2)}} CNY，卖{{coinPrice.USDT.buyPrice | toFixed(2)}} CNY</p>
     </div>
   </div>
    <v-data-table
      :headers="tabHeaders"
      :items="orderTable"
      :page.sync="pagination.pageIndex"
      :items-per-page="pagination.pageSize"
      class="tabulation-footer"
      hide-default-footer
      :loading="isLoading"
      loading-text="数据加载中..."
    >
      <template #item.fcreatetime="{ item }">
        {{item.fcreatetime | timeStampToDate}}
      </template>

      <template #item.fstatus="{ item }">
        {{item.fstatus | orderStatusText}}
      </template>

      <template #item.ftypeString="{ item }">
        <span>{{item.ftype?'买入':'卖出' }}</span>
      </template>

      <template #item.quantity="{ item }">
        <p>{{item.famount | toFixed(8)}} /</p>
        <p>{{item.fleftcount | toFixed(8)}}</p>
      </template>

      <template #item.limit="{ item }">
        <span>{{item.fminnum | toFixed(2)}}-{{item.fmaxnum | toFixed(2)}}</span>
      </template>

      <template #item.fprice="{ item }">
        <span>{{item.fprice | toFixed(2)}}</span>
      </template>

      <template #item.currentPrice="{ item }">
        <span>{{item.currentPrice | toFixed(2)}}</span>
      </template>

      <template #item.premiumRatio="{ item }">
        <span>{{(item.premiumRatio * 100) | toFixed(2) }}%</span>
      </template>

      <template #item.minPrice="{ item }">
        <span v-if="item.minPrice">{{item.minPrice | toFixed(2)}}</span>
        <span v-else>无</span>
      </template>

      <template #item.bank="{ item:{fOtcAdevertisePaymentMappings:payment} }">
        <v-menu
          transition="slide-y-transition"
          bottom
          open-on-hover
          close-on-content-click
          offset-y
          nudge-left="50px"
          nudge-top="-1px"
          v-for="x in payment"
        >
          <template v-slot:activator="{ on }">
           <!-- 银行卡
            <svg class="icon icontishi1" aria-hidden="true" v-on="on">
              <use xlink:href="#icontishi1"/>
            </svg>-->
            <svg class="icon bank-image mr-3" aria-hidden="true" v-on="on" v-if="x&&x.fOtcPayment">
              <use :xlink:href="`#${x.fOtcPayment.fpayid===1?'iconzhifubao':x.fOtcPayment.fpayid===2?'iconweixin':'iconyinhangka'}`"/>
            </svg>
          </template>
          <div class="payment pa-5" v-if="x&&x.fOtcPayment">
            <p>{{x.fOtcPayment.fname}}</p>
            <p class="pt-3 pb-3" v-if="x.fOtcPayment.fpayid===0">{{x.fOtcPayment.faccount | numberBank}}</p>
            <p class="pt-3 pb-3" v-else>{{x.fOtcPayment.faccount}}</p>
            <p v-if="x.fOtcPayment.fpayid===0">{{x.fOtcPayment.fbankname}}</p>
          </div>
        </v-menu>
      </template>

      <template #item.action="{ item: { fstatus: status, fid: id }}"><!--操作-->
        <v-btn class="pa-0" text small color="#1581F2" @click="handleOverlay(id, operationType = 0)" :disabled="status === 2 ||status === 0">下架</v-btn>
      </template>

      <template #item.auto="{ item: { fstatus: status, fid: id }}"><!--自动-->
        <v-switch
          hideDetails
          readonly
          :input-value="status===8"
          @click.stop="handleOverlay(id, 8, operationType = 1)"
          color="#F6C40F"
          :class="['mt-2 mb-2 pl-8', (status === 8 || status === 2) && 'cursor-none']"
          />
      </template>

      <template #item.manual="{ item: { fstatus: status, fid: id }}"><!--手动-->
        <v-switch
          hideDetails
          readonly
          :input-value="status===9"
          @click.stop="handleOverlay(id, 9, operationType = 1)"
          color="#F6C40F"
          :class="['mt-2 mb-2 pl-8', (status === 9 || status === 2) && 'cursor-none']"
        />
      </template>

      <template #no-data>
        <svg class="icon no-data-image cursor-pointer" aria-hidden="true">
          <use xlink:href="#iconzanwudingdan"/>
        </svg>
        <p class="no-data-text">暂无订单</p>
      </template>

      <template #footer v-if="totalRows>pagination.pageSize">
        <v-pagination v-model="pagination.pageIndex" :length="pagination.total" :total-visible="9" color="#F0BC02" class="justify-end padding-top-20 padding-bottom-20"/>
      </template>
    </v-data-table>


    <v-overlay :value="overlay">
      <v-form
        ref="form"
        lazy-validation
      >
        <div class="form-header d-flex justify-space-between align-center">
          <h5 class="text-size-16 text-weight-5">{{operationType?'确认变更价格':'确认下架商品'}}</h5>
          <v-btn
            icon
            @click.stop="overlay=false"
          ><v-icon color="#484855">mdi-close</v-icon></v-btn>
        </div>

        <InputPassword
          v-model="formOverlay.tradePwd.value"
          :rules="formOverlay.tradePwd.rules"
          label="资金密码"
          placeholder="请输入资金密码"
          type="password"
          light
          outlined
          required
        />

        <v-btn
          color="#F6C40F"
          @click.prevent="handleSubmit"
          block
          light
          depressed
          :loading="loading"
        >提交</v-btn>
      </v-form>
    </v-overlay>
  </div>
</template>

<script>
import api from '../../api/apiModule_1';
import { PagingDefaultConf, Regex } from '../../utils/constant';
import InputPassword from '../../components/InputPassword.vue';
import { mapActions, mapState } from '../../utils/common';

export default {
  name: 'Administration',
  data() {
    return {
      pagination: { ...PagingDefaultConf },
      tabStatus: [{ id: 1, name: '出售中' }, { id: 0, name: '审核中' }, { id: 2, name: '已下架' }],
      tabHeaders: [
        {
          text: '币种', value: 'fcoinName', sortable: false, align: 'center',
        },
        {
          text: '交易类型', value: 'ftypeString', sortable: false, align: 'right',
        },
        {
          text: '时间', value: 'fcreatetime', sortable: false, align: 'right',
        },
        {
          text: '数量', value: 'quantity', sortable: false, align: 'right',
        },
        {
          text: '限额', value: 'limit', sortable: false, align: 'right',
        },
        {
          text: '手动价格', value: 'fprice', sortable: false, align: 'right',
        },
        {
          text: '溢价后价格', value: 'currentPrice', sortable: false, align: 'right',
        },
        /* {
          text: '溢价率', value: 'premiumRatio', sortable: false, align: 'center',
        },
        {
          text: '风控价格', value: 'minPrice', sortable: false, align: 'center',
        }, */
        {
          text: '支付方式', value: 'bank', sortable: false, align: 'right',
        },
        {
          text: '操作', value: 'action', sortable: false, align: 'right',
        },
        {
          text: '自动价格', value: 'auto', sortable: false, align: 'center',
        },
        {
          text: '手动价格', value: 'manual', sortable: false, align: 'center',
        },
      ],
      getTabStatus: 0, // 根据此值 获取queryType值
      status: 1,
      orderTable: [],
      isLoading: false,
      operationType: 0, // 0-下架，1-切换价格
      switchStatus: 0, // 切换价格
      operationId: '', // 操作ID
      formOverlay: {
        tradePwd: { value: '', rules: [v => !!v || '资金密码不能为空', v => !/\s+/.test(v) || '资金密码不能包含空格', v => Regex.PASSWORD.test(v) || '资金密码格式不正确'] /* 密码为8-20位字符，需包含数字、大写字母和小写字母 */},
      },
      overlay: false,
      loading: false,
      totalRows: 0,
    };
  },
  components: {
    InputPassword,
  },
  computed: {
    ...mapState(['tradeCoin', 'coinPrice']),
    activeDate() {
      const { operationId, orderTable } = this;
      return orderTable.find(({ fid }) => fid === operationId) || {};
    },
  },
  created() {
    this.fetchCoinPrice();
  },
  methods: {
    ...mapActions(['fetchTradeCoin', 'fetchCoinPrice']),
    fetchOtcAdPage() {
      this.isLoading = true;
      const { pagination: { pageIndex: pageNum, pageSize }, status } = this;
      const params = { pageNum, pageSize, status };

      return api.OtcAdPage(params)
        .then(({ totalRows, totalPages: total, data }) => {
          [this.orderTable, this.pagination.total, this.isLoading, this.totalRows] = [data, total, false, totalRows];
        }).catch(() => { this.isLoading = false; });
    },
    handleOverlay(fid, switchStatus) {
      [this.operationId, this.overlay, this.switchStatus] = [fid, true, switchStatus];
    },
    handleSubmit() {
      if (this.$refs.form.validate()) {
        const {
          operationId: fid, operationType, formOverlay: { tradePwd: { value: tradePwd } },
        } = this;
        this.loading = true;
        api[operationType ? 'OtcAdUpdate' : 'OtcAdPutDown']({ // 切换价格模式 ||下架广告
          fid,
          status: this.switchStatus,
          tradePwd,
        }).then(() => {
          this.$toast(operationType ? `价格模式更新为${this.switchStatus === 8 ? '自动价格' : '手动价格'}` : '下架成功');
          this.fetchOtcAdPage();
          [this.overlay, this.loading] = [false, false, this.$refs.form?.reset()];
        }).catch(() => {
          [this.loading] = [false, this.$refs.form?.reset()];
        });
      }
    },
  },
  watch: {
    'pagination.pageIndex': {
      handler(n, o) {
        if (n !== o) this.fetchOtcAdPage();
      },
      deep: true,
      immediate: true,
    },
    status(n, o) {
      const currentPrice = {
        text: '溢价后价格', value: 'currentPrice', sortable: false, align: 'center',
      };
      if (n === 1 && n !== o) {
        this.tabHeaders.splice(6, 0, currentPrice);
      } else {
        const index = this.tabHeaders.findIndex(item => item.value === 'currentPrice');
        if (index !== -1) {
          this.tabHeaders.splice(index, 1);
        }
      }
    },
    getTabStatus(n, o) {
      this.status = this.tabStatus[n].id;
      this.pagination.pageIndex = 1;
      this.totalRows = 0;
      if (n !== o) this.fetchOtcAdPage();
    },
  },
};
</script>

<style lang="scss" scoped>
  ::v-deep .v-slide-group__content {
    border-bottom: 1px solid rgba(230, 236, 243, 1);
  }
  $borderColor: #EEEEEE;
  $textColor: #484855;

  .v-form{
    width: 420px;
    background-color: white;
    padding: 25px 20px;

    .form-header{
      padding: 0 0 20px;
      border-bottom: thin solid $borderColor;
      color: $textColor;
    }
  }
  .v-data-table{
    margin-bottom: 40px;

    svg.no-data-image{
      width: 65px;
      height: 65px;
      margin-top: 111px;
      border-radius: 50%;
    }

    ::v-deep td{
      font-size: 12px;
    }

    .no-data-text{
      color: rgba(40, 40, 45, 0.6);
      font-size:12px;
      font-weight: 400;
      margin: 15px 0 111px;
    }

    .background-color-black{
      background-color: #28282D;
      color: white;
    }

    .background-color-yellow{
      background-color: #F6C40F;
      color: #28282D;
    }

    .order-type{
      margin-right: 5px;
      padding: 2px;
      border-radius: 1px;
    }
  }
  .icontishi1{
    width: 12px;
    height: 12px;
    margin-left: 5px;
  }
  ::v-deep .v-data-table td, .v-data-table th{
    padding: 0 5px;
  }
  .payment{
    font-size:12px;
    font-family:PingFangSC-Regular,PingFang SC;
    font-weight:400;
    color:rgba(72,72,85,1);
    background:rgba(255,255,255,1);
    box-shadow:0 4px 12px 0 rgba(0,0,0,0.08);
    border-radius:4px;
  }
  .coinPrice{
    height: 100%;
    border-bottom: 1px solid #e6ecf3;
  }
</style>
