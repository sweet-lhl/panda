<template>
    <div id="release">
      <div class="release-border ">
        <v-form
          ref="form"
          v-model="valid"
          lazy-validation
        >

          <v-row>
            <v-col cols="2">
              <v-subheader>交易类型：</v-subheader>
            </v-col>
            <v-col cols="1" class="pb-0">
              <v-checkbox
                v-model="form.type"
                value="1"
                :rules="[v => !!v || '请选择类型']"
                color="#F6C40F"
                label="买入"
                :disabled="businesstype===1"
              ></v-checkbox>
            </v-col>
            <v-col cols="2" class="pb-0">
              <v-checkbox
                v-model="form.type"
                value="0"
                color="#F6C40F"
                label="卖出"
                :disabled="businesstype===0"
              ></v-checkbox>
            </v-col>
          <!--  <v-col cols="4">
              <v-subheader>（*买入与卖出只能发布1单）</v-subheader>
            </v-col>-->
          </v-row>
          <v-row>
            <v-col cols="2" class="pb-0">
              <v-subheader>交易币种：</v-subheader>
            </v-col>
            <v-col cols="1">
              <v-checkbox
                v-model="currId"
                input-value="true"
                :rules="[v => !!v || '请选择币种']"
                color="#F6C40F"
                label="USDT"
                hideDetails
              ></v-checkbox>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="2" class="pb-0">
              <v-subheader>结算货币：</v-subheader>
            </v-col>
            <v-col cols="1">
              <v-checkbox
                v-model="currId"
                input-value="true"
                :rules="[v => !!v || '请选择']"
                color="#F6C40F"
                label="CNY"
                hideDetails
              ></v-checkbox>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="2">
              <v-subheader>数量：</v-subheader>
            </v-col>
            <v-col cols="3">
              <v-text-field
                type="number"
                color="#f6c40f"
                v-model="form.amount"
                v-only-number:8="form.amount"
                ref="amountInput"
                @input="handlelimitInput('amount')"
                label="请输入交易数量"
                min="0"
                :rules="[v => !!v || '请输入交易数量', v => v > 0 || '数量必须大于0', v => !Number(form.type) && (v <= Number(this.totalToUSDT) || '最大限额已超过资产总值')]"
                single-line
                suffix="USDT"
              ></v-text-field>
            </v-col>
            <v-col cols="4">
              <v-subheader class="text-size-12">库存：{{totalToUSDT}} USDT</v-subheader>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="2">
              <v-subheader>手动价格：</v-subheader>
            </v-col>
            <v-col cols="3">
              <v-text-field
                v-model="form.price"
                v-only-number:2="form.price"
                color="#f6c40f"
                ref="priceInput"
                @input="handlelimitInput('price')"
                label="请输入单价"
                min="0"
                :rules="[v => !!v || '请输入单价', v => v > 0 || '单价必须大于0']"
                single-line
                suffix="CNY"
              ></v-text-field>
            </v-col>
            <v-col cols="4">
              <v-subheader class="text-size-12">市场价：{{usdtPrice}} CNY</v-subheader>
            </v-col>
          </v-row>

          <!--由于业务需要暂时注释-->
          <!--<v-row>
            <v-col cols="2">
              <v-subheader>浮动价格：</v-subheader>
            </v-col>
            <v-col cols="10">
              <v-subheader class="pa-0">
                <b class="font-weight-bold">溢价设置</b>
                （注意：您的报价为浮动价格，实际交易价格将以用户下单时的价格为准
                <a href="https://lemonotc.zendesk.com/hc/zh-cn/articles/360040085414-浮动价格说明" target="_blank"> 关于浮动价格的说明</a>）
              </v-subheader>
              <v-subheader class="pa-0 mt-4 mb-4">
                当前价格：{{currentPrice}} CNY &nbsp;&nbsp;&nbsp; 市场平均价：{{usdtPrice}} CNY
              </v-subheader>

              <div>
                <v-card-text class="col-8 pa-0">
                  <v-row>
                    <v-col class="d-flex pl-0">
                      <div class="col-9">
                        <v-slider
                          :value="form.slider"
                          @change="value=>form.slider=value"
                          class="align-center"
                          :color="color"
                          step="0.01"
                          max="10"
                          min="-10"
                          hide-details
                          thumb-label="always"
                        >
                          <template v-slot:prepend>-10</template>
                          <template v-slot:append>10</template>
                        </v-slider>
                        <v-subheader class="pa-0 mt-4 mb-4">
                          计价公式：{{usdtPrice}} CNY * {{premiumRate}}
                        </v-subheader>
                      </div>

                      <div class="col-4">
                        <v-text-field
                          type="number"
                          color="#f6c40f"
                          v-model="form.slider"
                          v-only-number:2="form.slider"
                          ref="sliderInput"
                          @input="handlelimitInput('slider')"
                          max="10"
                          min="-10"
                          class="mt-0 pt-0 ml-5"
                          :rules="[v => v >= -10 || '最小值不得小于 -10%',v => v <= 10 || '最大值不得大于 10%']"
                          single-line
                          suffix="%"
                        ></v-text-field>
                        <v-subheader class="pa-0 mt-4 mb-4 ml-5">
                          (价率仅到小数点后2位)
                        </v-subheader>
                      </div>
                    </v-col>
                  </v-row>
                </v-card-text>

              </div>

              <v-subheader class="pa-0 mt-4 mb-4">
                <b class="font-weight-bold mr-1 text-red">风控价格</b>
                <b class="font-weight-bold">可接受最{{Number(form.type)?'高':'低'}}单价</b>
                <v-tooltip bottom dark max-width="300px">
                  <template v-slot:activator="{ on }">
                    <svg class="icon icontishi1" aria-hidden="true" v-on="on">
                      <use xlink:href="#icontishi1"/>
                    </svg>
                  </template>
                  <p>该设置可帮助您在价格剧烈波动时保持稳定的报价，比如设置最低为200，而市场价处于200以下，您的广告依旧以200的价格展示</p>
                </v-tooltip>
                （留空，则不设置）
              </v-subheader>
              <div class="col-3 pa-0">
                <v-text-field
                  color="#f6c40f"
                  v-model="form.minPrice"
                  v-only-number:2="form.minPrice"
                  ref="minPriceInput"
                  @input="handlelimitInput('minPrice')"
                  :label="`最${Number(form.type)?'高':'低'}单价`"
                  min="0"
                ></v-text-field>
              </div>
            </v-col>
          </v-row>-->

          <v-row>
            <v-col cols="2">
              <v-subheader>交易限额：</v-subheader>
            </v-col>
            <v-col cols="3">
              <v-text-field
                color="#f6c40f"
                v-model="form.minnum"
                v-only-number:2="form.minnum"
                ref="minnumInput"
                @input="handlelimitInput('minnum')"
                label="最小限额"
                min="100"
                :rules="[v => !!v || '请输入交易最小限额', v => v >= 100 || '最小值不得小于 100 CNY']"
                single-line
                suffix="CNY"
              ></v-text-field>
            </v-col>
            <v-col cols="3" offset-md="1">
                <v-text-field
                  color="#f6c40f"
                  v-model="form.maxnum"
                  v-only-number:2="form.maxnum"
                  ref="maxnumInput"
                  @input="handlelimitInput('maxnum')"
                  label="最大限额"
                  min="100"
                  :rules="maxnumRules"
                  single-line
                  suffix="CNY"
                ></v-text-field>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="2"></v-col>
            <v-subheader class="text-size-12">*此处为您限制对方单笔交易最小及最大的数值，单位为CNY，最小值不得小于 100 CNY</v-subheader>
          </v-row>
          <v-row align="start">
            <v-col cols="2" class="margin-top-10">
              <v-subheader>支付方式：</v-subheader>
            </v-col>
            <v-col v-if="bankList.length" cols="10" class="pt-0 pr-0 pb-0">
              <v-row v-if="branchData.length">
                <v-col cols="1" class="pa-0">
                  <v-subheader class="pt-0 pr-0 pb-0">支付宝：</v-subheader>
                </v-col>
                <v-col cols="3"  class="pb-0 pt-1" v-for="(x,i) in branchData" :key="x.fid">
                  <v-checkbox
                    v-model="branchDataRadio"
                    :value="x.fid"
                    :key="x.faccount"
                    color="#F6C40F"
                    :label="x.faccount"
                    :rules="i===0?branchRules:[]"
                  ></v-checkbox>
                </v-col>
              </v-row>
              <v-row v-if="weChatData.length">
                <v-col cols="1" class="pa-0">
                  <v-subheader class="pt-0 pr-0 pb-0">微信：</v-subheader>
                </v-col>
                <v-col cols="3"  class="pb-0 pt-1" v-for="(x,i) in weChatData" :key="x.fid">
                  <v-checkbox
                    v-model="weChatDataRadio"
                    :value="x.fid"
                    :key="x.faccount"
                    color="#F6C40F"
                    :label="x.faccount"
                    :rules="i===0?branchRules:[]"
                  ></v-checkbox>
                </v-col>
              </v-row>
              <v-row v-if="cardData.length">
                <v-col cols="1" class="pa-0">
                  <v-subheader class="pt-0 pr-0 pb-0">银行卡：</v-subheader>
                </v-col>
                <v-col cols="3"  class="pb-0 pt-1" v-for="(x,i) in cardData" :key="x.fid">
                  <v-checkbox
                    v-model="cardDataRadio"
                    :value="x.fid"
                    :key="x.faccount"
                    color="#F6C40F"
                    :label="x.faccount"
                    :rules="i===0?branchRules:[]"
                  ></v-checkbox>
                </v-col>
              </v-row>
            </v-col>
            <v-col cols="2" v-else>
              <v-btn color="#F6C40F" depressed :to="'/accountSetting/bankCardManagement'">添加银行卡</v-btn>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="2"></v-col>
            <v-col cols="10" class="pt-0 pb-0 d-flex align-center">
              <v-checkbox
                color="#F6C40F"
                label="阅读并同意"
                class="mt-0"
                :rules="[v => !!v || '请阅读并同意']"
              ></v-checkbox>
              <span class="service text-size-14 pt-2">《<a href="https://lemonotc.zendesk.com/hc/zh-cn/articles/360039834574-广告方服务协议" target="_blank">广告方服务协议</a>》</span>
              <span class="service text-size-14 pt-2">《<a href="https://lemonotc.zendesk.com/hc/zh-cn/articles/360041102493--%E5%B9%BF%E5%91%8A%E6%96%B9%E7%A7%AF%E5%88%86%E7%AE%A1%E7%90%86%E5%88%B6%E5%BA%A6-" target="_blank">广告方积分管理制度</a>》</span>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="2"></v-col>
            <v-col cols="2">
              <v-btn color="#F6C40F"
                     depressed
                     :loading="subLoading"
                     :disabled="subLoading"
                     @click="validate">
                发布商品
                  <svg class="icon no-data-image" aria-hidden="true">
                   <use xlink:href="#iconfabushangpin"/>
                  </svg>
                <template v-slot:loader>
                  <span>提交中...</span>
                </template>
              </v-btn>
            </v-col>
          </v-row>

        </v-form>
      </div>
    </div>
</template>

<script>
import api from '../../api/apiModule_1';
import {
  mapActions, mapState, mapGetters, calc,
} from '../../utils/common';
import { filters } from '../../plugins/filters';

export default {
  name: 'release',
  data: () => ({
    valid: true,
    currId: true,
    form: {
      type: '1', // 买卖类型，0-卖单，1-买单
      coinId: '', // 币种ID
      currencyId: '', // 法币ID
      amount: '', // 数量
      price: '', // 价格
      minnum: '', // 最小限额
      maxnum: '', // 单笔交易最大限额
      payments: [], // 支付类型ID数字
      premiumRatio: '', // 溢价比率，可为负
      minPrice: '', // 最低单价
      slider: 0,
    },
    branchDataRadio: '',
    weChatDataRadio: '',
    cardDataRadio: '',
    loader: null,
    subLoading: false,
    businesstype: 2, // 0-只能下买单，1-只能下卖单，2-能下买卖单
  }),
  watch: {
    businesstype() {
      /*   if (this.businesstype === 0) {
        this.form.type = '1';
      } else */ if (this.businesstype === 1) {
        this.form.type = '0';
      }
    },
  },
  computed: {
    ...mapState('assets', ['financialAll']),
    ...mapState('accountSetting', ['bankList']),
    ...mapGetters('accountSetting', ['branchData', 'weChatData', 'cardData']),
    ...mapState(['tradeCoin', 'coinPrice']),
    branchRules() {
      const { branchDataRadio, weChatDataRadio, cardDataRadio } = this;
      // eslint-disable-next-line vue/no-side-effects-in-computed-properties
      this.form.payments = [branchDataRadio, weChatDataRadio, cardDataRadio].filter(num => num && num);
      return !branchDataRadio && !weChatDataRadio && !cardDataRadio ? [v => !!v || '未选择支付方式'] : [];
    },
    totalToUSDT() {
      const [userOtcWallet] = this.financialAll.userOtcWallet;
      return filters.toFixed(Number(userOtcWallet?.total), 8);
    },
    maxnumRules() { // 最大限额验证
      const amount = calc(`${this.currentPrice} ${this.form.amount} *`).toFixed(3).slice(0, -1);
      if (Number(amount)) {
        // eslint-disable-next-line vue/no-side-effects-in-computed-properties
        this.form.maxnum = amount;
      }
      return [v => !!v || '请输入交易最大限额', v => v >= 100 || '最大限额不得小于 100 CNY', v => v <= Number(amount) || `最大限额不得超过 ${amount} CNY`];
    },
    premiumRate() { // 溢价率
      const { slider } = this.form;
      // eslint-disable-next-line vue/no-side-effects-in-computed-properties
      this.form.premiumRatio = calc(`${Number(slider)} 100 /`);
      return calc(`1 ${this.form.premiumRatio} +`);
    },
    currentPrice() { // 当前价格
      return calc(`${this.usdtPrice} ${this.premiumRate} *`).toFixed(3).slice(0, -1);
    },
    usdtPrice() {
      const { coinPrice: { USDT }, form: { type } } = this;
      return Number(type) ? USDT?.sellPrice.toFixed(3).slice(0, -1) : USDT?.buyPrice.toFixed(3).slice(0, -1);// 商家低价买入，高价卖出（基于原来的买卖价取反）
    },
    color() {
      const { slider } = this.form;
      if (slider < -15) return 'red';
      if (slider < -5) return 'green';
      if (slider < 5) return '#F6C40F';
      if (slider < 15) return 'orange';
      return 'red';
    },
  },
  created() {
    this.fetchTradeCoin(); // 平台支持的币种查询
    this.fetchFinancialAll();
    this.fetchBankList();
    this.fetchCoinPrice();
    this.fetchOtcAccount();
  },
  methods: {
    ...mapActions('assets', ['fetchFinancialAll']),
    ...mapActions('accountSetting', ['fetchBankList']),
    ...mapActions(['fetchTradeCoin', 'fetchCoinPrice']),
    fetchOtcAccount() {
      api.OtcAccount().then((data) => {
        this.businesstype = data.businesstype;
      });
    },
    handlelimitInput(target) {
      this.$nextTick(() => {
        this.$refs[`${target}Input`].lazyValue = this.form[target];
      });
    },
    getCurrencyId() {
      const { tradeCoin } = this;
      this.form.currencyId = tradeCoin.buy.find(({ coinName }) => coinName === 'CNY')?.fcoinid;
      this.form.coinId = tradeCoin.buy.find(({ coinName }) => coinName === 'USDT')?.fcoinid;
    },
    validate() {
      if (!this.bankList.length) {
        this.$alert({
          title: '温馨提示',
          message: '你尚未绑定收款方式，请先绑定收款方式',
          confirmText: '立即前往',
          cancelText: '暂不设置',
          confirmCallback: () => this.$router.push('/accountSetting/bankCardManagement'),
        });
        return;
      }
      if (this.$refs.form.validate()) {
        [this.loader, this.subLoading] = ['subLoading', true];
        this.getCurrencyId();
        api.OtcAdCreate(this.form).then(() => {
          [this.loader, this.subLoading] = [null, false];
          // this.$toast(`${this.form.type?'买入':'卖出'}成功`);
          this.$toast('发布成功');
          this.$refs.form.reset();// 清除列表数据
          this.$nextTick(() => {
            [this.form.slider, this.form.minPrice, this.currId] = [0, '', true];// 初始默认数据
          });
        }).catch(() => {
          [this.loader, this.subLoading] = [null, false];
        });
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.release-border{
  margin: 40px 0;
  padding: 28px 40px;
  border:1px solid rgba(230,236,243,1);
  border-radius: 2px;
}
.row{
  align-items: center;
}
.v-subheader{
  height: 12px;
}
.v-input--selection-controls{
  margin-top: 10px;
}
  .no-data-image{
    width: 10px;
    height: 10px;
    margin-left: 5px;
  }
.icontishi1{
    width: 12px;
    height: 12px;
    margin-left: 5px;
  }
  .text-red{
    color: red;
  }
  .service{
    margin-top: -24px;
  }
::v-deep .v-label, ::v-deep .v-subheader, ::v-deep .v-input, ::v-deep .v-icon.v-icon{
  font-size: 14px;
  font-weight:400;
}
::v-deep .v-subheader.text-size-12,::v-deep .v-btn.v-size--default, ::v-deep .v-btn.v-size--large{
  font-size: 12px;
}
::v-deep .v-icon.v-icon{
  font-size: 18px;
}
::v-deep .v-input--selection-controls__input{
  width: 18px;
  height: 18px;
}
::v-deep .v-input--selection-controls__ripple{
  left: -15px;
}
::v-deep .v-input--selection-controls:not(.v-input--hide-details) .v-input__slot{
  margin-bottom: 3px;
}
</style>
