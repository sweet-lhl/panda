<template>
  <v-dialog v-model="dialog" persistent max-width="500" id="capital-password-verification">
    <v-form
      ref="form"
      lazy-validation
    >
      <v-card>
        <v-card-title class="justify-space-between">
          <span>账单下载</span>
          <v-icon class="cursor-pointer" @click="dialog=false">mdi-close</v-icon>
        </v-card-title>
        <div class="d-flex align-content-center align-center margin-top-20 padding-bottom-20">

          <div class="margin-left-15">
            <v-btn color="#41414C"
                   class="input-width-90"
                   height="39px"
                   small
                   text
                   outlined
                   depressed>
              已完成订单
            </v-btn>
          </div>

          <div class="input-width-110 margin-left-15">
            <v-menu
              v-model="begin"
              :close-on-content-click="false"
              transition="scale-transition"
              offset-y
              min-width="290px"
            >
              <template v-slot:activator="{ on }">
                <v-text-field
                  color="#f6c40f"
                  v-model="begindate"
                  label="开始时间"
                  hideDetails
                  readonly
                  dense
                  outlined
                  single-line
                  clearable
                  v-on="on"
                ></v-text-field>
              </template>
              <v-date-picker
                v-model="begindate"
                no-title
                :first-day-of-week="0"
                locale="zh-cn"
                scrollable
                @input="begin = false"
              ></v-date-picker>
            </v-menu>
          </div>

          <div class="input-width-110 margin-left-15">
            <v-menu
              v-model="end"
              :close-on-content-click="false"
              transition="scale-transition"
              offset-y
              min-width="290px"
            >
              <template v-slot:activator="{ on }">
                <v-text-field
                  color="#f6c40f"
                  v-model="enddate"
                  label="结束时间"
                  hideDetails
                  readonly
                  dense
                  outlined
                  single-line
                  clearable
                  v-on="on"
                ></v-text-field>
              </template>
              <v-date-picker
                v-model="enddate"
                no-title
                :first-day-of-week="0"
                locale="zh-cn"
                scrollable
                @input="end = false"
              ></v-date-picker>
            </v-menu>
          </div>

          <div class="margin-left-15">
            <v-btn color="#F6C40F"
                   class="input-width-90"
                   height="39px"
                   small
                   depressed
                   :loading="isLoading"
                   @click="OtcDownload">
              立即下载
            </v-btn>
          </div>
        </div>
      </v-card>
    </v-form>
  </v-dialog>
</template>

<script>

import api from '../../api/apiModule_1';

export default {
  name: 'BillDownload',
  data: () => ({
    isLoading: false,
    dialog: false,
    begindate: '',
    begin: false,
    enddate: '',
    end: false,
  }),
  methods: {
    OtcDownload() {
      let { begindate, enddate } = this;
      if (begindate === null) begindate = '';
      if (enddate === null) enddate = '';
      const [start, end] = [new Date(begindate).getTime() / 1000, new Date(enddate).getTime() / 1000];

      if (begindate && enddate && start > end) {
        this.$toast('开始时间不能大于结束时间');
        return;
      }
      this.isLoading = true;
      api.OtcDownload({ begindate, enddate })
        .then((data) => {
          [this.dialog, this.isLoading] = [false, false];
          window.location.href = `${window.location.origin}/${data}`;
        }).catch(() => { this.isLoading = false; });
    },
  },
  watch: {
    dialog(n, o) {
      if (n !== o && !n) this.$nextTick(this.$refs.form.reset); // 重置表单
    },
  },
};
</script>

<style scoped lang="scss">

  .v-card__title{
    position: relative;

    &::after{
      content: "";
      position: absolute;
      bottom: 0;
      height: 1px;
      left: 16px;
      right: 16px;
      background-color: #EEEEEE;
    }

    &+.v-card__subtitle{
      margin-top: 0;
      color: #DC5449;
      font-size: 14px;
      font-weight:500;
      padding: 19px 16px;
    }
  }
  .input-width-90{
    width: 90px;
  }
  .input-width-110{
    width: 120px;
  }
  ::v-deep .v-size--small{
    color: white;
  }
  ::v-deep .v-btn__content ,::v-deep .v-label,::v-deep .v-input{
    font-size: 12px;
  }
  ::v-deep .v-text-field--outlined .v-input__slot{
    border-radius: 2px;
  }
</style>
