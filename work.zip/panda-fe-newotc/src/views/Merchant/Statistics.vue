<template>
  <div id="Statistics">
    <div class="exhibition">
      <div class="d-flex justify-md-space-between">
        <p class="text-size-20">我的交易数据</p>
        <v-btn color="#1581F2"
               text
               small
               depressed
               @click.stop="confirmDownload">
          <svg class="icon iconzhangdanxiazai" aria-hidden="true">
            <use xlink:href="#iconzhangdanxiazai"/>
          </svg>
          账单下载
        </v-btn>
      </div>
      <div class="margin-top-30 margin-bottom-30">
        <ul class="pl-0 flex-auto">
          <li>
            <p>今日买入</p>
            <p class="text-size-20 margin-top-13">{{business.todayBuy | toFixed(8)}} USDT</p>
          </li>
          <li>
            <p>今日卖出</p>
            <p class="text-size-20 margin-top-13">{{business.todaySell | toFixed(8)}} USDT</p>
          </li>
          <li>
            <p>账户余额</p>
            <p class="text-size-20 margin-top-13">{{business.accountBalances | toFixed(8)}} USDT</p>
          </li>
          <li>
            <p>保证金</p>
            <p class="text-size-20 margin-top-13">{{business.bond | toFixed(8)}} USDT</p>
          </li>
        </ul>
      </div>
      <div class="margin-bottom-30 exhibition-footer">
        <ul class="pl-0 flex-auto text-center">
          <li>
            <p>总成单量</p>
            <p class="text-size-12 margin-top-15">{{business.totalSingular}}</p>
          </li>
          <li>
            <p>30日成单</p>
            <p class="text-size-12 margin-top-15">{{business.thirtySingular}}</p>
          </li>
          <li>
            <p>30日完成率</p>
            <p class="text-size-12 margin-top-15">{{business.thirtyCompletionRate | toFixed(2)}}%</p>
          </li>
          <li>
            <p>买单完成率</p>
            <p class="text-size-12 margin-top-15">{{business.buyCompletionRate | toFixed(2)}}%</p>
          </li>
          <li>
            <p>平均放行（分钟）</p>
            <p class="text-size-12 margin-top-15">{{average | toFixed(2)}}</p>
          </li>
        </ul>
      </div>
    </div>
    <BillDownload ref="billDownload"/>
  </div>

</template>

<script>
import api from '../../api/apiModule_1';
import BillDownload from './BillDownload.vue';

let timerBusiness = null;

export default {
  name: 'Statistics',
  data() {
    return {
      business: '',
    };
  },
  computed: {
    average() {
      const { avgPass = 0 } = this.business;
      /* // eslint-disable-next-line radix
      let h = parseInt(avgPass / 3600);
      // eslint-disable-next-line radix,no-mixed-operators
      let m = parseInt(avgPass / 60 % 60);
      // eslint-disable-next-line radix
      let s = parseInt(avgPass % 60);
      h = h > 9 ? h : `0${h}`;
      m = m > 9 ? m : `0${m}`;
      s = s > 9 ? s : `0${s}`;
      return `${h}:${m}:${s}`; */
      return avgPass / 60;
    },
  },
  components: {
    BillDownload,
  },
  created() {
    this.fetchOtcBusinessStatistics();
    clearInterval(timerBusiness);
    timerBusiness = setInterval(() => {
      this.fetchOtcBusinessStatistics();
    }, 10000);
  },
  methods: {
    fetchOtcBusinessStatistics() {
      api.OtcBusinessStatistics().then((data) => {
        this.business = data;
      }).catch();
    },
    confirmDownload() { // 确认下载
      this.$refs.billDownload.dialog = true;
    },
  },
  destroyed() {
    clearInterval(timerBusiness);
  },
};
</script>

<style lang="scss" scoped>
  .exhibition{
    font-family:PingFangSC-Semibold,PingFang SC;
    font-weight:600;
    color:rgba(40,40,45,1);
  }
  .iconzhangdanxiazai{
    width: 12px;
    height: 15px;
    margin-right: 6px;
  }
  li{
    list-style: none;
  *:first-child{
    color:rgba(147,151,156,1);
    font-size: 12px;
    font-family:PingFangSC-Regular,PingFang SC;
  }
  }
  .exhibition-footer{
    background:rgba(249,249,249,1);
    padding: 20px 0;
  li{
    color:rgba(40,40,45,1);
  *:first-child{
    font-family:PingFangSC-Regular,PingFang SC;
    font-weight:400;
  }
  *:nth-child(2){
    font-family:PingFangSC-Semibold,PingFang SC;
    font-weight:600;
  }
  }
  }
</style>
