<template>
  <div id="banner" :class="[indicator === 'up' && 'active']" :style="{top: `${translateY}px`}">
    <div class="banner-list">
      <div
        class="background-reset cursor-pointer"
        v-for="(banner, idx) in bannerList"
        :key="`banner-item-${idx}`"
        :style="{backgroundImage: `url(${banner.imgUrl})`}"
        @click.stop="handleGoTo(banner.linkUrl)"
      ></div>
    </div>
    <div class="banner-btn">
      <v-icon color="#070707" :class="[indicator === 'down' && 'active']" @click.stop="handleIndicatorChange">mdi-chevron-up</v-icon>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from '../../utils/common';

export default {
  name: 'banner',
  data: () => ({
    indicator: 'down',
    bannerImages: [],
  }),
  computed: {
    ...mapState('home', ['bannerList']),
    translateY() {
      const itemHeight = 195;
      const { length: len } = this.bannerList;
      return -(itemHeight * (len - 1) + (itemHeight / 2));
    },
  },
  created() {
    this.fetchBannerList();
  },
  methods: {
    ...mapActions('home', ['fetchBannerList']),
    handleIndicatorChange() {
      const { indicator } = this.$data;
      this.indicator = indicator === 'down' ? 'up' : 'down';
    },
    handleGoTo(uri) {
      window.open(uri);
    },
  },
};
</script>

<style scoped lang="scss">
#banner{
  background-color: $black-color;
  padding: 0 37px 28px;
  position: absolute;
  right: 2.8em;
  transition: top $transition-time ease-in-out;

  &.active{ top:0 !important; }

  .banner-list{
    &>*{
      width: 346px;
      height: 195px;
      border-radius: 5px;

      &:not(:first-child){
        margin-top: 20px;
      }
    }
  }

  .banner-btn{

    .v-icon{
      background-color: #F0D402;
      border-radius: 100%;
      margin: 30px 0 0 50%;
      transform: translateX(-50%);
      cursor: pointer;
      transition: transform $transition-time ease-in-out;

      &.active{
        transform: translateX(-50%) rotate(180deg);
      }
    }
  }

}
</style>
