<template>
  <div id="platformIntroduction" v-once>
    <div class="otc-width">
      <h1 class="platformIntroduction-title text-center text-weight-4">值得信任的数字货币交易平台</h1>
      <p class="platformIntroduction-des text-center text-weight-4 margin-top-10">即刻享受极速安全的交易体验，平均单笔订单在3分钟内成交</p>
      <ul class="platform-more d-flex padding-less justify-space-between">
        <li class="platform-item list-style-none">
          <div class="platform-image">
            <svg class="icon platform-image" aria-hidden="true">
              <use xlink:href="#iconfabijiaoyi"/>
            </svg>
          </div>
          <h5 class="platform-item-title text-weight-5 text-size-15">法币如何购买数字货币？</h5>
          <p class="platform-item-des text-size-12 text-weight-4 margin-top-20 line-height-2">Lemootc 上线USDT加密数字货币资产，支持法币实时交易，如何购买USDT？</p>
          <div class="platform-item-btn text-size-12 text-weight-4 margin-top-26">
            <span @click.stop="handleGoto('https://lemonotc.zendesk.com/hc/zh-cn/articles/360034088174')">查看详情</span>
          </div>
        </li>
        <li class="platform-item list-style-none">
          <div class="platform-image">
            <svg class="icon platform-image" aria-hidden="true">
              <use xlink:href="#iconbibijiaoyi"/>
            </svg>
          </div>
          <h5 class="platform-item-title text-weight-5 text-size-15">如何进行数字货币之间的交易？</h5>
          <p class="platform-item-des text-size-12 text-weight-4 margin-top-20 line-height-2">打开资产，OTC资产划转至币币资产，币币交易中可进行优质资产交易。</p>
          <div class="platform-item-btn text-size-12 text-weight-4 margin-top-26">
            <span @click.stop="handleGoto('https://www.panda.co/exchange?id=1')">前往交易</span>
          </div>
        </li>
        <li class="platform-item list-style-none">
          <div class="platform-image">
            <svg class="icon platform-image" aria-hidden="true">
              <use xlink:href="#iconchengweishangjia"/>
            </svg>
          </div>
          <h5 class="platform-item-title text-weight-5 text-size-15">全球商家招募？</h5>
          <p class="platform-item-des text-size-12 text-weight-4 margin-top-20 line-height-2">商家标识：认证商家拥有专属标识，增强信任度； 订单推送服务：精准匹配用户订单； 一对一专属服务：7*24小时为您服务；</p>
          <div class="platform-item-btn text-size-12 text-weight-4 margin-top-26">
            <span @click.stop="handleGoto('http://pandaexchange.mikecrm.com/schIaB2')">立刻成为商家</span>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  name: 'platformIntroduction',
  // functional: true,
  methods: {
    handleGoto(uri) {
      window.open(uri);
    },
  },
};
</script>

<style scoped lang="scss">
  #platformIntroduction{
    background-color: #fcfcfc;
    padding: 94px 0 139px;
  }

  .platform-more{
    margin: 120px 0 0;

    .platform-item{
      width: 256px;
      text-align: center;

      .platform-item-btn{

        & > span{
          border-radius:2px;
          display: inline-block;
          padding: 9px 26px;
          border:thin solid $black-color;
          cursor: pointer;
          transition: all $transition-time ease;

          &:hover{
            border-color: $yellow-color;
            background-color: $yellow-color;
          }
        }
      }
    }
  }
  .platform-item-des{
    min-height: 85px;
  }

  svg.platform-image{
      width: 160px;
      height: 100px;
    }
</style>
