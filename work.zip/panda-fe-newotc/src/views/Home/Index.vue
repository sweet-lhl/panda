<template>
  <div id="home">
    <Purchase/>
    <PlatformIntroduction/>
    <Download/>
    <Footer/>
  </div>
</template>

<script>
import PlatformIntroduction from './PlatformIntroduction.vue';
import Purchase from './Purchase.vue';
import Download from './Download.vue';
import Footer from './Footer.vue';

export default {
  name: 'home',
  components: {
    PlatformIntroduction, Purchase, Download, Footer,
  },
};
</script>

<style scoped>
#home{
  position: relative;
}
</style>
