<template>
  <div id="download">
    <div class="otc-width">
      <div class="d-flex justify-space-between">
        <div class="download-left">
          <h1 class="text-color-white text-size-42 text-weight-4 padding-left-50 max-width-600">随时随地，一键开启OTC交易</h1>
          <p class="text-color-grey text-size-16 text-weight-4 padding-left-50 line-height-2 margin-top-30 max-width-600">下载 LemonOTC 合作伙伴 Panda Global APP，随时随地轻松开启OTC对数字货币交易。</p>
          <div class="download-plan d-flex justify-space-between margin-top-72">
            <div>
              <div class="align-center d-flex margin-top-20">
                <svg class="icon width-30" aria-hidden="true">
                  <use xlink:href="#iconiOS"/>
                </svg>
                <span class="margin-left-18">iOS 下载</span>
              </div>
              <div class="align-center d-flex margin-top-54">
                <svg class="icon width-30" aria-hidden="true">
                  <use xlink:href="#iconandroid"/>
                </svg>
                <span class="margin-left-18">Android 下载</span>
              </div>
            </div>
            <div class="qrCode-plan">
              <div class="qrCode-box background-reset" :style="{backgroundImage: `url(${downloadUri})`}"></div>
              <p class="text-center text-color-black margin-top-20">Android & iOS扫码下载</p>
            </div>
          </div>
        </div>
        <div class="download-right background-reset"></div>
      </div>
    </div>

  </div>
</template>

<script>
import { QRCode } from '../../utils/common';

const qrCode = new QRCode(new Image(), {
  width: 143,
  height: 143,
  colorDark: '#000000',
  colorLight: '#ffffff',
  correctLevel: QRCode.CorrectLevel.H,
  render: 'table', // 默认使用了canvas，为了避免混乱这里时候用table
});

export default {
  name: 'download',
  created() {
    qrCode.makeCode(process.env.VUE_APP_DOWNLOAD); // ios生成二维码
    // eslint-disable-next-line no-underscore-dangle,no-undef
    qrCode._oDrawing._elImage.onload = ({ target: { src: downloadUri } }) => {
      this.downloadUri = downloadUri;
    };
  },
  beforeDestroy() {
    qrCode.clear(); // 清除ios生成二维码
  },
  data: () => ({
    downloadUri: '',
  }),
};
</script>

<style scoped lang="scss">
  #download {
    padding: 162px 0 102px;
    background-color: #121315;

    .download-left{
      padding: 60px 0;
    }

    .download-right{
      background-image: url("../../assets/images/home-download.png");
      width: 500px;
      height: 600px;
      flex-basis: 500px;
    }
  }

  .margin-top-72{
    margin-top: 72px;
  }

  .text-size-42{
    font-size: 42px;
  }

/*  .padding-left-50{
    padding-left: 50px;
  }*/

  .text-color-white{
    color: $white-color
  }

  .text-color-grey{
    color: $grey-color;
  }

  .margin-top-54{
    margin-top: 54px;
  }

  .max-width-600{
    max-width: 546px;
  }

  .download-plan{
    position: relative;
    width: 596px;
    background-color: #F6C40F;
    padding: 38px 110px 37px 0;
    border-bottom-right-radius: 5px;
    border-top-right-radius: 5px;

    svg.icon{
      padding: 10px;
      background-color: $black-color;
      width: 48px;
      height: 48px;
      border-radius: 100%;
    }
  }
  .download-plan::after{
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    left: -100%;
    width: 100%;
    background-color: #F6C40F;
  }

  .qrCode-box{
    width: 157px;
    height: 157px;
    border: 7px solid #FFE736;
    background-color: $white-color;
  }
</style>
