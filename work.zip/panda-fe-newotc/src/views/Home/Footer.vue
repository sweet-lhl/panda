<template>
  <div id="footer" v-once>
    <div class="otc-width">
      <div class="d-flex justify-space-between align-center">
        <div class="logo-box">
          <div class="logo-box">
            <svg class="icon logo-image" aria-hidden="true">
              <use xlink:href="#iconlogo"/>
            </svg>
          </div>
          <p class="contact-box text-size-14 text-color-grey text-weight-4">
            <span>官方邮箱: support@lemonotc.com</span>
            <span class="margin-left-40">战略合作伙伴：Panda Global</span>
          </p>
          <p class="agreement-box text-color-grey text-weight-4 text-size-14 margin-top-30">
            <span class="text-left cursor-pointer" @click.stop="handleGoto('https://lemonotc.zendesk.com/hc/zh-cn/articles/360034047034-隐私政策')">用户协议</span>
            <span class="text-center cursor-pointer" @click.stop="handleGoto('https://lemonotc.zendesk.com/hc/zh-cn/categories/360002160994-帮助中心')">常见问题</span>
            <span class="text-right cursor-pointer" @click.stop="handleGoto('https://lemonotc.zendesk.com/hc/zh-cn/articles/360034812094-关于lemon-OTC')">关于我们</span>
          </p>
          <p class="details-box text-size-14 margin-top-67">Lemon OTC为优质的OTC服务商，请放心使用。</p>
        </div>
        <div class="register-box">
          <p class="text-color-white text-size-42">注册账号，开启交易</p>
          <h5 class="register-des margin-top-30 margin-bottom-30">下载Panda Global APP，随时随地轻松开启OTC对数字货币交易。</h5>
          <v-row justify="space-between" no-gutters>
            <v-col class="register-input">
              <v-text-field
                label="请输入您的邮箱或手机号"
                color="#f6c40f"
                solo
                v-model="account"
              ></v-text-field>
            </v-col>
            <v-col class="register-btn">
              <v-btn depressed large color="#F6C40F" @click.stop="handleGotoRegister">立即注册</v-btn>
            </v-col>
          </v-row>
        </div>
      </div>
      <p class="margin-top-95 text-size-14 footer-text text-center">Copyright &copy; 2019-2020 LEMON OTC TECHNOLOGY LTD</p>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Footer', // VUE_APP_PANDA_URL
  methods: {
    handleGotoRegister() {
      const { VUE_APP_PANDA_URL } = process.env;
      const { account } = this.$data;
      window.location.assign(`${VUE_APP_PANDA_URL}/register?account=${account}`);
    },
    handleGoto(uri) {
      window.open(uri);
    },
  },
  data: () => ({
    account: '',
  }),
};
</script>

<style scoped lang="scss">
  #footer {
    background-color: $black-color;
    padding: 149px 0 40px;
  }

  .text-color-grey{
    color: #CDCDCD;
  }

  .text-color-white{
    color: $white-color;
  }

  .text-size-42{
    font-size: 42px;
  }

  .margin-top-95 {
    margin-top: 95px;
  }

  .margin-top-67{
    margin-top: 67px;
  }

  .footer-text {
    color: rgba(255, 255, 255, 0.31);
  }

  .logo-box {
    margin-top: 17px;

    .logo-image {
      width: 168px;
      height: 44.4px;
    }

    .contact-box{
      margin-top: 28px;
    }

    .agreement-box{

      & > *{
        display: inline-block;
        width: 83px;

        &:nth-child(2){
          border-left: thin solid #CDCDCD;
          border-right: thin solid #CDCDCD;
        }
      }
    }

    .details-box{
      color: rgba(255, 255, 255, 0.41);
    }
  }

  .register-box{

    .register-des{
      color: rgba(255, 255, 255, 0.8);
    }

    .register-input{
      width: 77%;
      flex-basis: 77%;

      ::v-deep .v-text-field__details{
        display: none;
      }

      ::v-deep .v-input__slot{
        margin-bottom: 0;
      }
    }

    .register-btn{
      width: calc(23% - 6px);
      flex-basis: calc(23% - 6px);
      margin-left: 6px;

      button{
        min-height: 100%;
        min-width: 100%;
      }
    }
  }

  .margin-left-40{
    margin-left: 40px;
  }
</style>
