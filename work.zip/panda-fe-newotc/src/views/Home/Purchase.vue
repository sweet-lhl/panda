<template>
  <div id="purchase">
    <div id="three-animate">
      <canvas id="universe"></canvas>
    </div>
    <div class="otc-width">
      <h1 class="text-size-42 text-color-white">数字货币OTC场外交易，极速成交</h1>
      <p class="text-color-grey text-size-16 margin-top-20">即刻享受极速安全的交易体验，平均单笔订单在3分钟内成交</p>
      <div class="buy-block">
        <!--<p class="text-size-12 text-color-grey margin-top-51 margin-bottom-11 d-flex align-center">
          <svg class="icon tips" aria-hidden="true">
            <use xlink:href="#icontishi"/>
          </svg>
          <span class="margin-left-5 text-size-12">参考价:{{usdtPrice}}CNY/USDT</span>
        </p>
        <v-row justify="space-between" no-gutters>
          <v-col class="sell-select">
            <v-select
              :items="operates"
              label="操作"
              v-model="operate"
              solo
            ></v-select>
          </v-col>
          &lt;!&ndash; <v-spacer/> &ndash;&gt;
          <v-col class="sell-input">
            <v-text-field
              label="请输入购买总金额"
              color="#f6c40f"
              v-only-number:2="amount"
              v-model="amount"
              solo
            >
              <template #append><span class="sell-input-append">CNY</span></template>
            </v-text-field>
          </v-col>
        </v-row>-->
        <v-row class="margin-top-7" no-gutters>
          <v-btn color="#F6C40F" block large depressed :to="`merchantList/${operate}`">{{subButtonText}}&nbsp;&nbsp;USDT</v-btn>
        </v-row>
      </div>
      <div class="notice-block">
        <h5 class="flex-align-center">
          <svg class="icon text-size-30" aria-hidden="true">
            <use xlink:href="#icongonggao"/>
          </svg>
          <span class="margin-left-15 text-size-16 text-color-white">公告</span>
        </h5>
        <ul class="notice-list margin-less padding-top-25">
          <li v-for="(notice,idx) in noticeList" :key="`notice-item-${idx}`" class="text-size-14 text-color-grey cursor-pointer" @click.stop="handleGoto(notice.html_url)">{{notice.title || notice.name}}</li>
          <li key="notice-more" class="text-size-14 text-color-grey cursor-pointer" @click.stop="handleGoto('https://lemonotc.zendesk.com/hc/zh-cn')">加载更多&nbsp;>></li>
        </ul>
      </div>

      <Banner/>
    </div>
  </div>
</template>

<script>
import { mapActions, mapState } from '../../utils/common';
import Banner from './Banner.vue';

const starDensity = 0.216;
const speedCoeff = 0.05;
let width;
let height;
let starCount;
// eslint-disable-next-line no-unused-vars
let circleRadius;
// eslint-disable-next-line no-unused-vars
let circleCenter;
let universe;
let first = true;
const giantColor = '180,184,240';
const starColor = '226,225,142';
const cometColor = '226,225,224';
const stars = [];

function getProbability(percents) {
  return ((Math.floor(Math.random() * 1000) + 1) < percents * 10);
}
function getRandInterval(min, max) {
  return (Math.random() * (max - min) + min);
}

class Star {
  reset() {
    this.giant = getProbability(3);
    this.comet = this.giant || first ? false : getProbability(10);
    this.x = getRandInterval(0, width - 10);
    this.y = getRandInterval(0, height);
    this.r = getRandInterval(1.1, 2.6);
    this.dx = getRandInterval(speedCoeff, 6 * speedCoeff) + (this.comet + 1 - 1) * speedCoeff * getRandInterval(50, 120) + speedCoeff * 2;
    this.dy = -getRandInterval(speedCoeff, 6 * speedCoeff) - (this.comet + 1 - 1) * speedCoeff * getRandInterval(50, 120);
    this.fadingOut = null;
    this.fadingIn = true;
    this.opacity = 0;
    this.opacityTresh = getRandInterval(0.2, 1 - (this.comet + 1 - 1) * 0.4);
    this.do = getRandInterval(0.0005, 0.002) + (this.comet + 1 - 1) * 0.001;
  }

  fadeIn() {
    if (this.fadingIn) {
      this.fadingIn = !(this.opacity > this.opacityTresh);
      this.opacity += this.do;
    }
  }

  fadeOut() {
    if (this.fadingOut) {
      this.fadingOut = !(this.opacity < 0);
      this.opacity -= this.do / 2;
      if (this.x > width || this.y < 0) {
        this.fadingOut = false;
        this.reset();
      }
    }
  }

  draw() {
    universe.beginPath();

    if (this.giant) {
      universe.fillStyle = `rgba(${giantColor},${this.opacity})`;
      universe.arc(this.x, this.y, 2, 0, 2 * Math.PI, false);
    } else if (this.comet) {
      universe.fillStyle = `rgba(${cometColor},${this.opacity})`;
      universe.arc(this.x, this.y, 1.5, 0, 2 * Math.PI, false);

      // comet tail
      // eslint-disable-next-line no-plusplus
      for (let i = 0; i < 30; i++) {
        universe.fillStyle = `rgba(${cometColor},${this.opacity - (this.opacity / 20) * i})`;
        universe.rect(this.x - this.dx / 4 * i, this.y - this.dy / 4 * i - 2, 2, 2);
        universe.fill();
      }
    } else {
      universe.fillStyle = `rgba(${starColor},${this.opacity})`;
      universe.rect(this.x, this.y, this.r, this.r);
    }

    universe.closePath();
    universe.fill();
  }

  move() {
    this.x += this.dx;
    this.y += this.dy;
    if (this.fadingOut === false) {
      this.reset();
    }
    if (this.x > width - (width / 4) || this.y < 0) {
      this.fadingOut = true;
    }
  }

    first = process.nextTick(() => {
      first = false;
    })
}

/* const OPERATES = [
  {
    text: '购买',
    value: 'buy',
  }, {
    text: '出售',
    value: 'sell',
  },
]; */

export default {
  name: 'purchase',
  components: {
    Banner,
  },
  computed: {
    ...mapState(['coinPrice']),
    ...mapState('home', ['noticeList']),
    /* usdtPrice() {
      const { coinPrice: { USDT }, operate } = this;
      switch (operate) {
        case 'buy':
          return USDT?.buyPrice;
        case 'sell':
          return USDT?.sellPrice;
        default:
          return '-.--';
      }
    }, */
    subButtonText() {
      const { operate } = this.$data;
      switch (operate) {
        case 'buy':
          return '购买';
        case 'sell':
          return '出售';
        default:
          return '---';
      }
    },
  },
  data: () => ({
    // operates: OPERATES,
    operate: 'buy',
    amount: 100,
  }),
  methods: {
    // ...mapActions(['fetchCoinPrice']),
    ...mapActions('home', ['fetchNoticeList']),
    handleGoto(uri) {
      window.open(uri);
    },
    windowResizeHandler() {
      width = window.innerWidth;
      height = window.innerHeight;
      starCount = width * starDensity;
      circleRadius = (width > height ? height / 2 : width / 2);
      circleCenter = {
        x: width / 2,
        y: height / 2,
      };
      const canva = document.getElementById('universe');
      canva.setAttribute('width', width);
      canva.setAttribute('height', height);
    },
    draw() {
      universe.clearRect(0, 0, width, height);

      const starsLength = stars.length;

      // eslint-disable-next-line no-plusplus
      for (let i = 0; i < starsLength; i++) {
        const star = stars[i];
        star.move();
        star.fadeIn();
        star.fadeOut();
        star.draw();
      }

      window.requestAnimationFrame(this.draw);
    },
    createUniverse() {
      const canva = document.getElementById('universe');
      universe = canva.getContext('2d');
      // eslint-disable-next-line no-plusplus
      for (let i = 0; i < starCount; i++) {
        stars[i] = new Star();
        stars[i].reset();
      }

      this.draw();
    },
  },
  watch: {
    /* operate: {
      handler(n, o) {
        if (n !== o) {
          const { operate, fetchCoinPrice } = this;
          const type = operate === 'sell' ? 1 : 0;

          fetchCoinPrice(type);
          timer = clearInterval(timer) || setInterval(() => fetchCoinPrice(type), 3000);
        }
      },
      deep: true,
      immediate: true,
    }, */
  },
  destroyed() {
    first = true;
    this.createUniverse = '';
    this.draw = () => {};
  },
  created() {
    this.fetchNoticeList();
    window.requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame
          || window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;
  },
  mounted() {
    process.nextTick(() => {
      this.windowResizeHandler();
      this.createUniverse();
      window.addEventListener('resize', this.windowResizeHandler, false);
    });
  },
};
</script>

<style scoped lang="scss">
  #purchase{
    padding: 95px 0 88px;
    background-color: black;
    position: relative;

    #three-animate{
      position: absolute;
      left: 0;
      right: 0;
      bottom: 0;
      top: 0;
      z-index: 0;
      #universe {
        width: 100%;
        height: 100%;
      }
    }

    .otc-width{
      position: relative;
    }
  }
  .flex-align-center{
    display: flex;
    align-items: center;
    justify-content: flex-start;
  }

  .text-color-grey {
    color: $grey-color;
  }

  .text-color-white {
    color: $white-color;
  }

  .text-size-42 {
    font-size: 42px;
  }

  .buy-block {
    max-width: 572px;

    .margin-bottom-11{
      margin-bottom: 11px;
    }

    svg.tips{
      width: 13.94px;
      height: 13.94px;
    }

    ::v-deep .v-text-field__details{
      display: none;
    }

    .buy-input-box {
      display: flex;
      justify-content: space-between;
    }

    .sell-input-append {
      color: #93939C;
      border-left: thin solid #98A5B3;
      padding: 0 19px;
    }

    .sell-select {
      width: 20%;
      flex-basis: 20%;
      flex-grow: 0;
    }

    .sell-input {
      width: 78%;
      flex-basis: 78%;
      flex-grow: 0;
    }

    .margin-top-7{
      margin-top: 60px;
    }

    .margin-top-51{
      margin-top: 51px;
    }
  }

  .notice-block{
    margin-top: 80px;

    svg.text-size-30{
      width: 30px;
      height: 23.37px;
    }

    .notice-list{
      padding-left: 0;

      li{
        list-style: none;
        &:not(:first-child){
          margin-top: 25px;
        }
      }
    }
  }
</style>
