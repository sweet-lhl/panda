<template>
  <v-dialog v-model="dialog" persistent max-width="650">
    <v-form
      ref="form"
      lazy-validation
    >
      <v-card>
        <v-card-title class="justify-space-between">
          <span>请选择收款方式</span>
        </v-card-title>
        <v-card-text>
        <v-radio-group v-model="branchDataRadio" column class="bankCard-list mt-8" v-if="branchData.length" row>
          <v-radio
            class="bankCard-item"
            v-for="(bank, idx) in branchData"
            :key="`business-bankItem-${idx}`"
            color="#F6C40F"
            small
            @click="branchDataHander(bank.fid,'branchDataRadio')"
            :value="bank.fid"
          >
            <template #label>
              <svg class="icon bank-image margin-left-20" aria-hidden="true">
                <use xlink:href="#iconzhifubao"/>
              </svg>
              <span class="margin-left-40 text-size-12 text-weight-5">{{bank.fname}}</span>
              <span class="margin-left-20 text-size-12 text-weight-5">{{bank.faccount}}</span>
            </template>
          </v-radio>
        </v-radio-group>
          <v-radio-group v-model="weChatDataRadio" column class="bankCard-list" v-if="weChatData.length" row>
            <v-radio
              class="bankCard-item"
              v-for="(bank, idx) in weChatData"
              :key="`business-bankItem-${idx}`"
              color="#F6C40F"
              small
              @click="branchDataHander(bank.fid,'weChatDataRadio')"
              :value="bank.fid"
            >
              <template #label>
                <svg class="icon bank-image margin-left-20" aria-hidden="true">
                  <use xlink:href="#iconweixin"/>
                </svg>
                <span class="margin-left-40 text-size-12 text-weight-5">{{bank.fname}}</span>
                <span class="margin-left-20 text-size-12 text-weight-5">{{bank.faccount}}</span>
              </template>
            </v-radio>
          </v-radio-group>
          <v-radio-group v-model="cardDataRadio" column class="bankCard-list" v-if="cardData.length" row>
            <v-radio
              class="bankCard-item"
              v-for="(bank, idx) in cardData"
              :key="`business-bankItem-${idx}`"
              color="#F6C40F"
              small
              @click="branchDataHander(bank.fid,'cardDataRadio')"
              :value="bank.fid"
            >
              <template #label>
                <!--<span class="margin-left-11 text-size-14 text-weight-5">{{bank.fpayid | paymentText}}</span>-->
                <svg class="icon bank-image margin-left-20" aria-hidden="true">
                  <use xlink:href="#iconyinhangka"/>
                </svg>
                <span class="margin-left-40 text-size-12 text-weight-5">{{bank.fname}}</span>
                <span class="margin-left-40 text-size-12 text-weight-5">{{bank.fbankname}}</span>
                <span class="margin-left-20 text-size-12 text-weight-5">{{bank.faccount | numberBank}}</span>
              </template>
            </v-radio>
          </v-radio-group>
        </v-card-text>
        <v-card-actions class="justify-end">
          <v-btn text small color="#93939C" @click="dialog=false">取消</v-btn>
          <v-btn color="#F6C40F" :disabled="!branchDataRadio&&!weChatDataRadio&&!cardDataRadio" depressed small @click="handleSubmit(),dialog=false">确认</v-btn>
        </v-card-actions>
      </v-card>
    </v-form>
  </v-dialog>
</template>

<script>

import { /* mapState, */ mapGetters } from '../../utils/common';

export default {
  name: 'ChoiceBank',
  props: {
    handleSubmit: { type: Function, required: true },
  },
  data: () => ({
    dialog: false,
    /* bankValue: undefined, */
    branchDataRadio: undefined,
    weChatDataRadio: undefined,
    cardDataRadio: undefined,
  }),
  methods: {
    branchDataHander(value, target) {
      if (value === this[target]) this[target] = undefined;
      else this[target] = value;
    },
  },
  computed: {
    /* ...mapState('accountSetting', ['bankList']), */
    ...mapGetters('accountSetting', ['branchData', 'weChatData', 'cardData']),
    branchRules() {
      const { branchDataRadio, weChatDataRadio, cardDataRadio } = this;
      return [branchDataRadio, weChatDataRadio, cardDataRadio].filter(num => num && num);
    },
  },
  watch: {
    branchRules(n, o) {
      if (n !== o && n) this.$emit('onChange', n);
    },
  /*  bankList: { // 申诉中
      handler() {
        this.bankValue = this.bankList[0]?.fid;
      },
      deep: true,
      immediate: true,
    }, */
  },
};
</script>

<style scoped lang="scss">
  .background-color-white{
    ::v-deep .v-label{
      background-color: white;
    }
  }

  .checkbox-size-small{
    margin-top: 0;

    ::v-deep .v-input--selection-controls__input{
      width: 16px;
      height: 16px;

      & + label{
        font-size:12px;
        font-weight:400;
      }
    }
  }

  .v-card__title{
    position: relative;

    &::after{
      content: "";
      position: absolute;
      bottom: 0;
      height: 1px;
      left: 16px;
      right: 16px;
      background-color: #EEEEEE;
    }

    &+.v-card__subtitle{
      margin-top: 0;
      color: #DC5449;
      font-size: 14px;
      font-weight:500;
      padding: 19px 16px;
    }
  }

  .v-card__actions{
    border-top: thin solid #EEEEEE;
    margin: 0 16px;
    padding: 17px 0;
  }
  $activeColor: rgba(246,196,15,1);

  .bankCard-less{
    height: 40px;
    background-color: #efefef;
    padding-left: 20px;
    padding-right: 10px;
    border-radius: 2px;
    margin-bottom: 15px;
    position: relative;
    top: -10px;
  }

  .link-color{
    color: #1581F2;
  }

  .bank-subName{
    color: #93939C;
  }

  .bank-name{
    color: #484855;

    /*&:before{
      content: "";
      width: 14px;
      height: 14px;
      border-radius: 100%;
      background-color: #E3E3E3;
      margin-right: 11px;
      display: inline-block;
    }*/
  }

  .bankCard-list{
    margin-top: 5px;

    .bankCard-item{
      background-color: #F9F9F9;
      margin-right: 0;
      width: 100%;
      height: 38px;
      border-radius: 1px;
      border: thin solid transparent;
      padding-left: 20px;

      &:not(:first-child){
        margin-top: 20px;
      }

      &.v-item--active{
        border:thin solid $activeColor;
        position: relative;

        &::after{
          content: "";
          border-color: transparent transparent $activeColor transparent;
          border-style: solid;
          border-width: 0 0 25px 25px;
          position: absolute;
          right: 0;
          bottom: 0;
          z-index: 1;
        }

        &::before{
          content: "";
          width: 10px;
          height: 7px;
          border-color: transparent transparent white white;
          border-style: solid;
          border-width: 0 0 2px 2px;
          position: absolute;
          right: 3px;
          bottom: 5px;
          z-index: 2;
          transform: rotate(-50deg);
        }
      }

      ::v-deep .v-label{
        // width: calc(100% - 24px);
        flex-grow: 1;
      }
    }
  }
  ::v-deep .v-input__control{
    width: 100%;
  }
</style>
