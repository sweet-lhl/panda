<template>
  <td :colspan="headers.length" class="box-expand">
    <v-form
      id="sell"
      ref="form"
      lazy-validation
    >
      <div class="d-flex space-between padding-bottom-20 padding-top-20 align-start">
        <div class="space-between sell-left">
          <div class="flex-width inline-block">
            <span class="vertical-align-middle list-head" :style="{backgroundColor:expanded.color}">{{expanded.nickName&&expanded.nickName.substr(0,1)}}</span>
            <div class="vertical-align-middle">
              <v-btn text small color="#1581F2">{{expanded.nickName}} <!--({{expanded.thirtySingular}} | {{expanded.thirtyCompletionRate | toFixed(2)}}%)--></v-btn>
              <p class="margin-left-14">数量：{{expanded.fleftcount | divisionMoney(6)}} USDT</p>
            </div>
          </div>
          <div class="flex-width">
            <v-btn text small color="#f6c40f">{{expanded.fprice | toFixed(2)}} CNY</v-btn>
            <p class="margin-left-14">{{expanded.fminnum | divisionMoney}} - {{expanded.fmaxnum | divisionMoney}} CNY</p>
          </div>
        </div>
        <div class="text-align-right sell-right inline-block mt-1">
          <div class="buy-input">
            <v-text-field
              height="34px"
              label="出售金额"
              color="#f6c40f"
              placeholder=""
              ref="amountInput"
              v-only-number:2="form.amount"
              v-model="form.amount"
              @input="getCount('amount')"
              @focus="isAmountAll=true"
              @blur="isAmountAll=false"
              :rules="[v => !!v || '下单金额不能为空', v => Number(v) >= this.minAmount || '最小下单金额为100 CNY', v => Number(v) <= expanded.fmaxnum || `下单金额不能超过${expanded.fmaxnum} CNY`]"
              single-line
              outlined
              flat
            >
              <template #append>
                <span class="unit-el" :class="isAmountAll&&isAll?'cursor-pointer':'cursor-none'" @click="handleSellClickAllAmount">{{isAmountAll&&isAll?'全部':'CNY'}}</span>
              </template>
            </v-text-field>
          </div>
          <span class="padding-20">
              <svg class="icon checked margin-right-10 margin-left-10" aria-hidden="true">
                <use xlink:href="#iconqiehuan"/>
              </svg>
            </span>
          <div class="buy-input margin-right-10">
            <v-text-field
              height="34px"
              label="出售数量"
              color="#f6c40f"
              placeholder=""
              ref="countInput"
              v-only-number:6="form.count"
              v-model="form.count"
              @input="getAmount('count')"
              @focus="isCountAll=true"
              @blur="isCountAll=false"
              :rules="countRules"
              single-line
              outlined
              flat
            >
              <template #append>
                <span class="unit-el" :class="isCountAll&&isAll?'cursor-pointer':'cursor-none'" @click="handleSellClickAllCount">{{isCountAll&&isAll?'全部':'USDT'}}</span>
              </template>
            </v-text-field>
          </div>

         <!-- <div class="sell-tradePwd margin-right-10">
            <v-text-field
              height="34px"
              label="资金密码"
              color="#f6c40f"
              type="password"
              v-model="form.tradePwd.value"
              :rules="form.tradePwd.rules"
              outlined
              flat
            >
            </v-text-field>
          </div>-->
          <v-btn small depressed color="#F6C40F" class="margin-right-10 mb-1" @click.stop="sellAdopt">出售</v-btn>
          <v-btn small depressed class="margin-right-5 mb-1" @click="clearExpanded">取消</v-btn>
        </div>
      </div>
    </v-form>
    <div class="space-between padding-bottom-20 padding-left-24">
      <div class="flex-width margin-left-24">
        <!--<span class="color-yellow margin-left-4 margin-right-10">银行卡</span>-->
        <template v-if="expanded.fOtcPayments.length">
          <span class="margin-right-10" v-for="x in expanded.fOtcPayments">
            <svg class="icon bank-image" aria-hidden="true">
               <use :xlink:href="`#${x.fpayid===1?'iconzhifubao':x.fpayid===2?'iconweixin':'iconyinhangka'}`"/>
            </svg>
          </span>
        </template>
      </div>
      <div class="text-align-right flex-width">买方付款时间为15分钟</div>
    </div>

    <ChoiceBank ref="ChoiceBank" :handleSubmit="handleSubmit" @onChange="handleBankChange"/>
  </td>
</template>

<script>
import { calc, mapState } from '../../utils/common';
import { Regex } from '../../utils/constant';
import ChoiceBank from './ChoiceBank.vue';
import { filters } from '../../plugins/filters';

export default {
  name: 'sell',
  props: {
    headers: { type: Array, required: true },
    expanded: { type: [Object, Array], required: true },
    clearExpanded: { type: Function, required: true },
    handleSubmit: { type: Function, required: true },
    verification: { type: Function, required: true },
    totalToUSDT: { type: [Number, String], required: true },
  },
  data() {
    return {
      form: {
        amount: '',
        count: '',
        tradePwd: { value: '', rules: [v => !!v || '资金密码不能为空', v => !/\s+/.test(v) || '资金密码不能包含空格', v => Regex.PASSWORD.test(v) || '资金密码格式不正确'] /* 密码为8-20位字符，需包含数字、大写字母和小写字母 */},
      },
      bankValue: undefined,
      isAmountAll: false,
      isCountAll: false,
      isAll: true, // 是否显示全部按钮
      minAmount: 100,
    };
  },
  watch: {
    /* 'form.amount': function () {
      const { form: { amount } } = this;
      this.isAll = Number(this.contrastAmount) !== Number(filters.toFixed(amount, 2));
      // console.log(fmaxnum, amount, fmaxnum !== amount, this.isAll);
    }, */
    'form.amount': {
      handler(n, o) {
        if (n !== o) {
          const { form: { amount } } = this;
          this.isAll = Number(this.contrastAmount) !== Number(filters.toFixed(amount, 2));
        }
      },
      deep: true,
      immediate: true,
    },
  },
  components: { ChoiceBank },
  computed: {
    ...mapState('accountSetting', ['bankList']),
    ...mapState(['cancelTimes', 'userInfo']),
    countRules() {
      const minCount = filters.toFixed(calc(`${this.minAmount} ${this.expanded.fprice} /`));
      const totalToUSDT = filters.toFixed(this.totalToUSDT);
      return [v => !!v || '下单数量不能为空', v => Number(v) >= minCount || `最小下单数量为${minCount} USDT`, v => Number(v) <= totalToUSDT || `账户剩余数量为${totalToUSDT} USDT`];
    },
    contrastAmount() { // 计算能出售的最大金额
      const { fprice, fleftcount, fmaxnum } = this.expanded;
      const businessAmount = Number(calc(`${Number(fleftcount)} ${Number(fprice)} *`));// 商家剩余数量转化后的金额
      const myAmount = Number(calc(`${Number(this.totalToUSDT)} ${Number(fprice)} *`));// 自身账户剩余数量转化后的金额
      const first = businessAmount > myAmount ? myAmount : businessAmount;// 商家与自身取最小值
      const second = fmaxnum > first ? first : fmaxnum;// 与最大区间取最小值
      return filters.toFixed(second, 2);// 商家与自身取最小值
    },
  },
  methods: {
    handlelimitInput(target) {
      this.$nextTick(() => {
        this.$refs[`${target}Input`].lazyValue = this.form[target];
      });
    },
    handleSellClickAllCount() { // 计算能出售的最大数量
      const { fprice } = this.expanded;
      this.form.amount = this.contrastAmount;
      const count = Number(calc(`${Number(this.contrastAmount)} ${Number(fprice)} /`));// 可卖出的最大数量
      this.form.count = filters.toFixed(count);
      this.isAll = false;
    },
    handleSellClickAllAmount() {
      this.form.amount = this.contrastAmount;
      this.getCount();
      this.isAll = false;
    },
    getCount(target) {
      const { form: { amount }, expanded: { fprice } } = this;
      this.form.count = filters.toFixed(calc(`${Number(amount)} ${Number(fprice)} /`));
      if (target) {
        this.handlelimitInput(target);
      }
    },
    getAmount(target) {
      const { form: { count }, expanded: { fprice } } = this;
      this.form.amount = filters.toFixed(calc(`${Number(count)} ${Number(fprice)} *`), 2);
      if (target) {
        this.handlelimitInput(target);
      }
    },
    validate() {
      return this.$refs.form.validate();
    },
    sellAdopt() { // 出售
      if (this.validate()) {
        if (this.verification()) { // 验证不通过
          return;
        }
        this.$refs.ChoiceBank.dialog = true;
      }
    },
    handleBankChange(value) {
      this.bankValue = value;
    },
  },
};
</script>

<style scoped lang="scss">
  .v-data-table{
    .list-head{
      display: inline-block;
      width: 38px;
      height: 38px;
      line-height: 38px;
      text-align: center;
      border-radius: 50%;
      color: #FFFFFF;
    }
  }
  svg.tips {
    width: 12px;
    height: 12px;
    vertical-align: middle;
  }
  .transaction{
    padding: 0!important;
  }
  .color-yellow{
    color: #EEA30C;
  }
  ::v-deep .v-data-table__expanded__row{
    display: none;
  }
  svg.checked{
    width: 12px;
    height: 12px;
  }
  .space-between {
    display: flex;
    overflow: hidden;
    width: 100%;
    justify-content: space-between;
    align-items: center;
    flex-shrink: 0;
    flex-grow: 0;
  }
  .flex-width{
    width: 50%;
    flex-basis: 50%;
  }
  .buy-input{
    width: 160px;
  }
  .sell-tradePwd{
    width: 140px;
  }
  .unit-el{
    font-size: 12px;
    display: inline-block;
    width: 24px;
  }
  ::v-deep .v-label{
    font-size: 12px;
  }
  .inline-block>*{
    display: inline-block;
  }
  .vertical-align-middle{
    vertical-align: middle;
  }
  .text-align-right{
    text-align: right;
  }
  ::v-deep .v-text-field.v-text-field--enclosed .v-input__append-inner{
    margin-top: 12px;
  }
  ::v-deep .v-text-field--outlined .v-label{
    top: 8px;
  }
  ::v-deep .v-text-field--outlined>.v-input__control>.v-input__slot{
    min-height: 20px;
  }
  .box-expand{
    /* border-radius: 8px;*/
    background:rgba(255,255,255,1);
    box-shadow:0 4px 12px 0 rgba(228,228,235,0.5);
    /* border: 1px solid rgba(0,0,0,.12);*/
  }
.sell-left{
  width: 38%;
  flex-basis: 38%;
}
  .sell-right{
    width: 62%;
    flex-basis: 62%;
  }
</style>
