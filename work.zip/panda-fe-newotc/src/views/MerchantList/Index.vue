<template>
  <div id="merchant">
    <div class="merchant-tab">
      <div class="merchant-wrap">
        <div>自选交易</div>
        <v-tabs
          dark
          v-model="type"
          color="#F6C40F"
          height="38px"
          background-color="#09090A">
          <v-tab>购买</v-tab>
          <v-tab>出售</v-tab>
        </v-tabs>
      </div>
    </div>
    <div class="merchant-wrap">

      <v-data-table
        :headers="tabHeaders"
        :items="orderTable"
        :page.sync="pagination.pageIndex"
        :items-per-page="pagination.pageSize"
        class="tabulation-footer"
        hide-default-footer
        :loading="isLoading"
        loading-text="数据加载中..."
        :expanded.sync="expanded"
        item-key="fid"
        single-expand
        show-expand
      >
        <template #item.fleftcount="{ item }">
          {{item.fleftcount | divisionMoney(6)}} USDT
        </template>

        <template #item.fmaxnum="{ item }">
          {{item.fminnum | divisionMoney}} - {{item.fmaxnum | divisionMoney}} CNY
        </template>

        <template #item.nickName="{ item }">
          <span class="list-head" :style="{backgroundColor:item.color}">{{item.nickName&&item.nickName.substr(0,1)}}</span>
          <v-btn text small color="#1581F2">{{item.nickName}} <!--({{item.thirtySingular}} | {{item.thirtyCompletionRate | toFixed(2)}}%)--></v-btn>
        </template>

        <template #item.fprice="{ item }">
          <span class="color-yellow">{{item.fprice | toFixed(2)}} CNY</span>
        </template>

        <template #item.fOtcPayments="{ item }">
          <!--<span class="color-yellow">银行卡</span>-->
          <span class="margin-right-10" v-for="x in item.fOtcPayments">
            <svg class="icon bank-image" aria-hidden="true">
              <use :xlink:href="`#${x.fpayid===1?'iconzhifubao':x.fpayid===2?'iconweixin':'iconyinhangka'}`"/>
            </svg>
          </span>
        </template>

        <template v-slot:item.data-table-expand="{ item }">
          <v-btn width="118px" small depressed color="#F6C40F" @click="handleExpanded(item)">{{type?'出售':'购买'}} USDT</v-btn>
        </template>

        <template v-slot:expanded-item="{ headers, item }">
          <component
            :is="switchTab"
            :headers="headers"
            :expanded="item"
            :clearExpanded="clearExpanded"
            :handleSubmit="handleSubmit"
            :verification="verification"
            :totalToUSDT="financialAll.totalToUSDT||0"
            ref="customInput"/>
        </template>

        <template #no-data>
          <svg class="icon no-data-image cursor-pointer" aria-hidden="true">
            <use xlink:href="#iconzanwudingdan"/>
          </svg>
          <p class="no-data-text">暂无{{type?'出售':'购买'}}列表</p>
        </template>

        <template #header.data-table-expand>
          <!--<v-tooltip top color="white">
            <template v-slot:activator="{ on }">
              <svg class="tips margin-right-5 cursor-pointer" aria-hidden="true" v-on="on">
                <use xlink:href="#icontishi"/>
              </svg>
            </template>
            <v-btn text>广告方可能对广告设置了交易限制，登录后您将无法看到受限广告。</v-btn>
          </v-tooltip>-->
          <p class="transaction-heade">
            <v-btn text small height="19px" min-width="25px" class="transaction">交易</v-btn>
            <v-btn text small height="19px" color="#EEA30C">0手续费</v-btn>
          </p>
        </template>

        <!--<template #header.nickName>
          广告方（30日成单 | 30日完成率）
        </template>-->

        <template #footer v-if="totalCount>pagination.pageSize">
          <v-pagination v-model="pagination.pageIndex" :length="pagination.total" :total-visible="9" color="#F0BC02" class="justify-end padding-top-20 padding-bottom-20"/>
        </template>

      </v-data-table>

    </div>

  </div>
</template>

<script>
import Buy from './Buy.vue';
import Sell from './Sell.vue';
import api from '../../api/apiModule_1';
import { PagingDefaultConf } from '../../utils/constant';
import { mapActions, mapState, cookies } from '../../utils/common';
import { filters } from '../../plugins/filters';

const name = 'business';
let fetchListLimer = null;
export default {
  name: 'merchant',
  data() {
    const { $route: { params: { type } } } = this;
    return {
      type: do{
        if (type === 'buy') return 0; // 购买列表
        if (type === 'sell') return 1;// 出售列表
        return 0;
      },
      pagination: { ...PagingDefaultConf },
      tabHeaders: [
        {
          text: '广告方', value: 'nickName', sortable: false, align: 'left',
        },
        {
          text: '数量', value: 'fleftcount', sortable: false, align: 'right',
        },
        {
          text: '限额', value: 'fmaxnum', sortable: false, align: 'right',
        },
        {
          text: '单价', value: 'fprice', sortable: false, align: 'right',
        },
        {
          text: '支付方式', value: 'fOtcPayments', sortable: false, align: 'right',
        },
        {
          text: '', value: 'data-table-expand', sortable: false, align: 'right',
        },
      ],
      expanded: [],
      orderTable: [],
      isLoading: false,
      totalCount: 0,
    };
  },
  // eslint-disable-next-line vue/no-unused-components
  components: { Buy, Sell },
  created() {
    if (cookies.get('token')) {
      this.fetchRealAuth(); // 身份完成验证
      this.fetchCancelTimes(); // 取消次数
      this.fetchFinancialAll(); // 账户余额
      this.fetchBankList(); // 银行卡列表
    }
    this.setIntervalList();
  },
  methods: {
    ...mapActions(['fetchCancelTimes']),
    ...mapActions(name, ['fetchRealAuth']),
    ...mapActions('assets', ['fetchFinancialAll']),
    ...mapActions('accountSetting', ['fetchBankList']),
    setIntervalList() {
      clearInterval(fetchListLimer);
      fetchListLimer = setInterval(() => {
        this.fetchList();
      }, 30000);
    },
    handleExpanded(expanded) {
      this.expanded = [];
      process.nextTick(() => {
        this.expanded.push(expanded);
        if (!cookies.get('token')) { // 未登录
          this.$router.push('/login');
        }
        clearInterval(fetchListLimer);// 展开时关闭定时器
      });
    },
    verification() { // 下单验证
      if (this.userInfo.country !== 'China') { // 用户国籍校验
        this.$toast('抱歉，目前只支持人民币进行法币交易');
        return true;
      }

      if (this.submitDisabled) { // 今日取消次数已达上限
        this.$toast('抱歉，今日取消次数已达上限');
        return true;
      }

      const { realAuth: { isPhoneBind, isRealAuth, isTradePasswordSet } } = this;
      const realAuthMessage = do{
        if (!isPhoneBind) return '用户未绑定手机';
        if (!isRealAuth) return '用户未实名认证';
        if (!isTradePasswordSet) return '用户未设置资金密码';
        return null;
      };

      // eslint-disable-next-line no-unreachable
      if (realAuthMessage) { // 用户交易必要条件校验
        this.$alert({
          title: '温馨提示',
          message: `<div id="order-confirm-message" class="text-size-12 line-height-2">
                        <p class="d-flex justify-space-between text-size-14"><span class="text-label">手机号</span>
                           ${isPhoneBind ? '<span class="text-value color-yellow">已绑定</span>' : '<span class="text-value">未绑定</span>'}
                        </p>
                        <p class="d-flex justify-space-between text-size-14"><span class="text-label">身份认证</span>
                           ${isRealAuth ? '<span class="text-value color-yellow">已认证</span>' : '<span class="text-value">未认证</span>'}
                        </p>
                        <p class="d-flex justify-space-between text-size-14"><span class="text-label">资金密码</span>
                           ${isTradePasswordSet ? '<span class="text-value color-yellow">已设置</span>' : '<span class="text-value">未设置</span>'}
                        </p>
                    </div>`,
          confirmText: '前往设置',
          confirmCallback: () => window.location.assign(`${process.env.VUE_APP_PANDA_URL}/userManagement`),
        });
        return true;
      }

      const { type, bankList } = this;
      if (type && Number(this.financialAll.totalToUSDT) < 20) { // 余额小于20U
        this.$alert({
          title: '温馨提示',
          message: '当前余额小于20U，出售前需要将币划转至法币账户，是否划转？',
          confirmText: '划转',
          cancelText: '取消',
          confirmCallback: () => this.$router.push('/assets'),
        });
        return true;
      }
      if (type && !bankList.length) {
        this.$alert({
          title: '温馨提示',
          message: '你尚未绑定收款方式，请先绑定收款方式',
          confirmText: '立即前往',
          cancelText: '暂不设置',
          confirmCallback: () => this.$router.push('/accountSetting/bankCardManagement'),
        });
        return true;
      }
      return false;
    },
    async handleSubmit() {
      if (this.verification()) { // 验证不通过
        return;
      }
      const { $refs: { customInput }, bankList } = this;
      if (customInput.validate()) { // 校验用户输入合法性
        // this.isLoading = true; // 开启loading，禁止再次点击
        // eslint-disable-next-line no-shadow
        const { type } = this;
        const {
          form: { amount, count },
          expanded: {
            fid: advertiseId, fprice: price, fcurrency: currencyId, fcoinid: coinId,
          },
          bankValue: paymentId,
        } = customInput;
        const postData = {
          rule: 0,
          type,
          amount,
          count,
          advertiseId,
          price,
          currencyId,
          coinId,
        };
        /* const { fpayid } = type ? bankList.find(({ fid }) => customInput.bankValue[0] === fid) : ''; */
        const html = type && customInput.bankValue.reduce((acc, value) => {
          const { fpayid } = bankList.find(({ fid }) => value === fid);
          // eslint-disable-next-line no-return-assign
          return acc += `<svg class="icon bank-image margin-left-5 mt-2" aria-hidden="true">
                           <use xlink:href="#${fpayid === 1 ? 'iconzhifubao' : fpayid === 2 ? 'iconweixin' : 'iconyinhangka'}"/>
                         </svg>`;
        }, '');
        /* console.log(html); */
        this.$alert({
          title: '订单确认',
          message: `<div id="order-confirm-message" class="text-size-12 line-height-2">
                        <p class="d-flex justify-space-between align-center"><span class="text-label">交易金额</span><span style="color:#F6C40F;" class="text-size-16 text-weight-6">${amount}&nbsp;CNY</span></p>
                        <p class="d-flex justify-space-between"><span class="text-label">成交数量</span><span class="text-value">${count}&nbsp;USDT</span></p>
                        <p class="d-flex justify-space-between"><span class="text-label">成交单价</span><span class="text-value">${filters.toFixed(Number(price), 2)}&nbsp;CNY</span></p>
                         ${type ? `<p class="d-flex justify-space-between">
                                  <span class="text-label">收款方式</span>
                                  <span class="text-value">
                                    ${html}
                                  </span></p>` : ''}
                    </div>`,
          confirmText: '确认下单',
          cancelCallback: () => { this.isLoading = false; },
          confirmCallback: () => {
            this.clearExpanded();
            return api.commitTransaction(Object.assign(postData,
              type ? { paymentId: paymentId.join() } : undefined))
              .then(({ forderId: id }) => this.$router.push(`/order/${id}`));
          },
        });
      }
    },
    fetchList() {
      const {
        pagination: { pageIndex: pageNum, pageSize }, type,
      } = this;
      this.isLoading = true;
      return api.OtcAdvertise({
        type, pageNum, pageSize,
      }).then(({ totalCount, totalPages: total, data }) => {
        [this.orderTable, this.pagination.total, this.isLoading, this.totalCount] = [data, total, false, totalCount];
      }).catch(() => { this.isLoading = false; });
    },
    clearExpanded() {
      this.expanded = [];
      this.setIntervalList();// 未展开时 重新开启定时器
    },
  },
  watch: {
    'pagination.pageIndex': {
      handler(n, o) {
        if (n !== o) this.fetchList();
      },
      deep: true,
      immediate: true,
    },
    type(n, o) {
      this.pagination.pageIndex = 1;
      if (n !== o) {
        this.fetchList();
        this.clearExpanded();
      }
    },
  },
  computed: {
    ...mapState(['cancelTimes', 'userInfo']),
    ...mapState(name, ['realAuth']),
    ...mapState('accountSetting', ['bankList']),
    ...mapState('assets', ['financialAll']),
    submitDisabled() { // 是否禁止点击买卖按钮【订单已取消三次触发】
      const { cancelTimes } = this;
      return cancelTimes > 3 && this.userInfo.isBusiness === 0;
    },
    switchTab() {
      const { type } = this;
      switch (type) {
        case 0:
          this.$router.replace('/merchantList/buy');
          return 'Buy';// 购买
        case 1:
          this.$router.replace('/merchantList/sell');
          return 'Sell';// 出售
        default:
          this.$router.replace('/merchantList/buy');
          return 'Buy';// 购买
      }
    },
  },
  destroyed() {
    clearInterval(fetchListLimer);
  },
};
</script>

<style lang="scss" scoped>
  #merchant{
    background-color: #ffffff;
  }
  .merchant-tab {
    background-color: #09090A;
  }

  .merchant-wrap {
    width: 90%;
    max-width: 1180px;
    min-width: 1068px;
    margin: 0 auto;
     &:first-child {
       div{
         &:first-child{
           font-size:22px;
           font-family:PingFangSC-Medium,PingFang SC;
           font-weight:500;
           color:rgba(255,255,255,1);
           padding-top: 30px;
           padding-bottom: 28px;
         }
       }
     }
  }


  .v-data-table{
    margin-bottom: 40px;

    svg.no-data-image{
      width: 65px;
      height: 65px;
      margin-top: 111px;
      border-radius: 50%;
    }

    ::v-deep td{
      font-size: 12px;
      height: 88px;
    }

    .no-data-text{
      color: rgba(40, 40, 45, 0.6);
      font-size:12px;
      font-weight: 400;
      margin: 15px 0 111px;
    }

    .list-head{
      display: inline-block;
      width: 38px;
      height: 38px;
      line-height: 38px;
      text-align: center;
      border-radius: 50%;
      color: #FFFFFF;
    }
  }
  svg.tips {
    width: 12px;
    height: 12px;
    vertical-align: middle;
  }
  .transaction{
    padding: 0!important;
  }
  .color-yellow{
    color: #EEA30C;
  }
  ::v-deep .v-data-table__expanded__row{
    display: none;
  }
  ::v-deep .theme--light.v-data-table thead tr:last-child th ,::v-deep .theme--light.v-data-table tbody tr:not(:last-child) td:last-child, .theme--light.v-data-table tbody tr:not(:last-child) td:not(.v-data-table__mobile-row){
    border-bottom: thin solid #E6ECF3;
  }
  ::v-deep  .theme--light.v-data-table tbody tr:not(:last-child) td:not(.v-data-table__mobile-row), .theme--light.v-data-table thead tr:last-child th{
    border-bottom: thin solid #E6ECF3;
  }
  .transaction-heade{
    width: 150px;
  }
</style>
