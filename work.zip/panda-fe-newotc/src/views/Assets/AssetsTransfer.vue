<template>
  <v-dialog
    id="assetsTransfer"
    v-model="dialog"
    max-width="470"
  >
    <v-card>
      <v-form
        ref="form"
        lazy-validation
      >
      <v-card-title class="align-center justify-space-between">
        <p class="text-uppercase">资产划转</p>
        <v-btn
          icon
          @click.stop="dialog=false"
        >
          <v-icon color="#484855">mdi-close</v-icon>
        </v-btn>
      </v-card-title>
      <!--<v-spacer>---上间距---</v-spacer>-->
      <v-divider class="mx-4"/>
      <!--<v-card-subtitle>---警告信息---</v-card-subtitle>-->
      <v-card-text>
        <v-spacer class="margin-top-10"/>
        <v-select
          :menu-props="{ offsetY: true }"
          v-model="formData.coinType.value"
          :items="coinTypes"
          :rules="formData.coinType.rules"
          label="币种"
          placeholder="请选择币种"
          outlined
          required
        ></v-select>
        <v-row no-gutters justify="space-between">
          <v-col cols="5">
            <v-text-field
              color="#f6c40f"
              class="flex-column"
              :label="`从${type?'币币':'OTC'}账户`"
              outlined
              disabled
            >
              <template #prepend><p class="text-size-12 margin-bottom-10">余额:
                <em class="blue--text text-style-none" v-if="type">{{coinAsset.total | toFixed(8)}}</em>
                <em class="blue--text text-style-none" v-else>{{usdtAssets.total | toFixed(8)}}</em>
                USDT</p></template>
            </v-text-field>
          </v-col>
          <v-col cols="2" class="pl-1 d-flex align-center justify-center" @click="getType">
            <v-btn text icon color="rgb(246, 196, 15)" class="btn-ma">
              <svg class="icon iconqiehuan1" aria-hidden="true">
                <use xlink:href="#iconqiehuan1"/>
              </svg>
            </v-btn>
          </v-col>
          <v-col cols="5">
            <v-text-field
              color="#f6c40f"
              class="flex-column"
              :label="`到${type?'OTC':'币币'}账户`"
              outlined
              disabled
            >
              <template #prepend><p class="text-size-12 margin-bottom-10">余额:
                <em class="blue--text text-style-none"  v-if="type">{{usdtAssets.total | toFixed(8)}}</em>
                <em class="blue--text text-style-none" v-else>{{coinAsset.total | toFixed(8)}}</em>
                USDT</p></template>
            </v-text-field>
          </v-col>
        </v-row>

        <v-text-field
          label="数量"
          color="#f6c40f"
          placeholder="请输入数量"
          type="number"
          v-model="formData.amount.value"
          :rules="formData.amount.rules"
          outlined
        >
          <template #append><v-btn text small color="blue" @click.stop="formData.amount.value=amountTotal">全部划转</v-btn></template>
        </v-text-field>

      </v-card-text>

      <v-card-actions class="pl-4 pr-4">
        <v-btn
          color="#F6C40F"
          depressed
          block
          large
          @click.stop="handleSubmit"
          :loading="isLoading"
        >
          确认
        </v-btn>
        <v-spacer></v-spacer>
      </v-card-actions>
      </v-form>
    </v-card>
  </v-dialog>
</template>

<script>
import { mapState, mapActions } from '../../utils/common';
import api from '../../api/apiModule_1';
import { filters } from '../../plugins/filters';

export default {
  name: 'assetsTransfer',
  data() {
    return {
      dialog: false,
      isLoading: false,
      formData: {
        amount: { value: '', rules: [v => !!v || '划转数量不能为空', v => v > 0 || '划转数量必须大于0', v => v <= Number(this.amountTotal) || '划转数量已超过资产总值'] },
        coinType: { value: '', rules: [v => !!v || '必须选择一个划转币种'] },
      },
      type: 0,
    };
  },
  computed: {
    ...mapState('assets', ['financialAll', 'coinAsset']),
    amountTotal() {
      const { type, usdtAssets: { total: usdt }, coinAsset: { total: coin } } = this;
      return type ? filters.toFixed(coin) : filters.toFixed(usdt);
    },
    usdtAssets() {
      const { userOtcWallet = [] } = this.financialAll;
      return userOtcWallet.find(({ fcoinName }) => fcoinName === 'USDT') || { total: 0 };
    },
    coinTypes() {
      const { userOtcWallet } = this.financialAll;
      return userOtcWallet.map(({ coinId: value, fcoinName: text }) => ({ value, text }));
    },
  },
  watch: {
    dialog: {
      handler(n, o) {
        if (n !== o) {
          // eslint-disable-next-line no-unused-expressions
          if (!n) this.$refs.form?.reset();
          if (n) {
            this.fetchFinancialAll();
            this.fetchCoinAsset();
          }
          process.nextTick(() => {
            this.formData.coinType.value = this.usdtAssets.coinId;
          });
        }
      },
      deep: true,
      immediate: true,
    },
    usdtAssets(n, o) {
      if (n?.coinId !== o?.coinId) this.formData.coinType.value = n.coinId;
    },
  },
  methods: {
    ...mapActions('assets', ['fetchCoinAsset', 'fetchFinancialAll']),
    getType() {
      this.type = this.type ? 0 : 1;
      this.formData.amount.value = '';
      this.$refs.form.reset();
      process.nextTick(() => {
        this.formData.coinType.value = this.usdtAssets.coinId;
      });
    },
    handleSubmit() {
      if (!this.$refs.form.validate() || this.isLoading) return;
      this.isLoading = true;

      const { formData: { amount: { value: amount } }, usdtAssets: { coinId } } = this;
      api.financialTransfer({
        amount,
        coinId,
        type: this.type,
      }).then(() => {
        [this.isLoading, this.dialog] = new Array(2).fill(false);
        this.$toast(`划转成功${this.type ? '' : '，请到Panda币币账户查看'}`);
      }).catch(() => { this.isLoading = false; });
    },
  },
};
</script>

<style scoped lang="scss">
.margin-bottom-10{
  margin-bottom: 10px;
}
  .v-input{

    ::v-deep .v-input__prepend-outer{
        margin-top: 0;
    }
  }
  .v-card__actions{
    position: relative;
    top: -20px;
  }
  .iconqiehuan1{
    width: 25px;
    height: 30px;
  }
  .btn-ma{
    margin-top: -5px;
    border-radius: 50%;
  }
</style>
