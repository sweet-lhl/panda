<template>
  <div id="assets">
    <div class="otc-width">
      <div class="assets-header d-flex justify-space-between align-center">
        <h5 class="assets-title text-wight-5">我的资产</h5>
        <p class="assets-subTitle text-size-12 text-weight-4">
          <span class="assets-subTitle-label">总资产折合：</span>
          <span class="assets-subTitle-value">{{financialAll.totalToBTC | toFixed(8)}} BTC ≈ {{financialAll.totalToCNY | toFixed(2)}} CNY</span></p>
      </div>
      <ul class="assets-body">
        <li class="assets-body-header text-size-12 flex-auto">
          <span class="text-left">币种</span>
          <span class="text-right">总额</span>
          <span class="text-right">冻结资产</span>
          <span class="text-right">可用资产</span>
          <span class="text-right">BTC估值</span>
          <span class="text-right"><span class="pr-3">操作</span></span>
        </li>
        <li class="assets-body-item text-size-12 flex-auto" v-for="(wallet, idx) in financialAll.userOtcWallet" :key="`wallet-${idx}`">
          <span class="text-left">{{wallet.fcoinName}}</span>
          <span class="text-right">{{(Number(wallet.total) + Number(wallet.frozen)) | toFixed(wallet.amountDecimal)}}</span>
          <span class="text-right">{{wallet.frozen | toFixed(wallet.amountDecimal)}}</span>
          <span class="text-right">{{wallet.total | toFixed(wallet.amountDecimal)}}</span>
          <span class="text-right">{{wallet.totalToBTC | toFixed(wallet.amountDecimal)}}</span>
          <span class="text-right"><v-btn text small color="#1581F2" @click.stop="$refs.assetsTransfer.dialog = true">划转</v-btn></span>
        </li>
      </ul>
    </div>
    <AssetsTransfer ref="assetsTransfer"/>
  </div>
</template>

<script>
import { mapState, mapActions } from '../../utils/common';
import AssetsTransfer from './AssetsTransfer.vue';

export default {
  name: 'assets',
  computed: {
    ...mapState('assets', ['financialAll']),
  },
  methods: {
    ...mapActions('assets', ['fetchFinancialAll']),
  },
  created() {
    this.fetchFinancialAll();
  },
  components: { AssetsTransfer },
};
</script>

<style scoped lang="scss">

  .assets-header{
    margin: 40px 0 19px;
  }

  .assets-title{
    color: #28282D;
    font-size: 22px;
  }

  .assets-subTitle{
    color: #28282D;

    .assets-subTitle-label{
      opacity: 0.6;
    }

    .assets-subTitle-value{

    }
  }

  .link-color{
    color: #1581F2
  }

  .assets-body{
    border-top: thin solid #E6ECF3;
    padding: 20px 0;

    .assets-body-header{
      color: rgba(40, 40, 45, 0.6);
      font-weight:400;
    }

    .assets-body-item{
      color: #28282D;
      font-weight:400;
      padding: 20px 0;
    }
  }
  .flex-auto {
    display: flex;

    & > *{
      flex: 2;
    }
    & > *:last-child{
      flex: 1;
    }
  };
</style>
