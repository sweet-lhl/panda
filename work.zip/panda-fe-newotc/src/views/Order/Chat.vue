<template>
  <!-- sse,vue -->
  <v-card id="chat" width="300" class="margin-left-40" outlined>
    <v-card-title class="chart-header align-center justify-space-between">
      <v-tooltip light bottom>
        <template v-slot:activator="{ on }">
          <div
            v-on="on"
            :class="['border-radius-100', onLine ===1 && 'active', 'indicator-online','cursor-pointer']"
            :style="{'background': colours[userInfo.fid=== orderInfo.fbussinessid ? orderInfo.fuserid%8 :orderInfo.fbussinessid%8]}"
          >{{orderInfo.otherSideNickName ? orderInfo.otherSideNickName.slice(0,1):''}}</div>
        </template>
        <span>{{onLine ===1 ?'用户在线': '用户离线'}}</span>
      </v-tooltip>

      <div class="d-flex flex-column flex-grow-1 padding-left-20 padding-right-20">
        <p class="chart-header-title">{{orderInfo.otherSideNickName}}</p>
        <p class="chart-header-subtitle"></p>
      </div>
      <!-- <v-btn depressed small fab color="teal" dark @click.stop="$toast('电话功能尚未开通')">
        <v-icon>mdi-phone-forward</v-icon>
      </v-btn>-->
    </v-card-title>
    <!-- <v-card-subtitle class="padding-less" v-if="!chatOnline">
      <v-alert type="warning"><v-btn depressed text @click.stop="handleReconnect">链接已断开，点击重新连接</v-btn></v-alert>
    </v-card-subtitle>-->
    <v-divider />

    <v-card-text
      id="chat-scroll"
      :class="['overflow-y-auto',orderInfo.fstatus !==0 ?'height360':'height415']"
      v-scroll:#scroll-target="handleScroll"
    >
      <v-list>
        <!--<v-subheader>list-title</v-subheader>-->
        <v-list-item :inactive="true" :class="['flex-row','justify-center']" v-if="total>20 ">
          <span class="cursor-pointer load" @click="loadClick">加载更多</span>
        </v-list-item>
        <v-list-item
          v-for="(message, idx) in messages"
          :key="`message-item-${idx}`"
          :inactive="true"
          :class="[message.isSelf ? 'flex-row-reverse' : 'flex-row', message.isSelf ? 'justify-end' : 'justify-start']"
        >
          <v-list-item-avatar
            v-if="[1, 2].includes(message.type)"
            :class="['chart-avatar', 'text-size-18', 'align-self-start', message.isSelf ? 'margin-left-10' : 'margin-right-10', message.isSelf && 'margin-right-0']"
            :style="{'background': colours[message.userId%8]}"
          >
            <v-img :src="url" v-if="message.source===1"></v-img>
            <span>{{message.avatar}}</span>
          </v-list-item-avatar>

          <v-list-item-content :class="[message.isSelf ? 'text-right' : 'text-left']">
            <template v-if="message.type === 1">
              <div
                class="chart-system text-left"
                :class="[message.isSelf ? 'justify-end' : 'justify-start']"
              >
                <span class="chart-message text-size-12">{{message.text}}</span>
              </div>
              <v-list-item-action-text
                class="chart-time"
              >{{message.time | timeStampToDate('HH:mm:ss')}}</v-list-item-action-text>
            </template>
            <template v-else-if="message.type === 0" class="text-center">
              <!-- <v-list-item-subtitle class="text-center"> -->

              <div class="chart-system">
                <div>
                  {{message.text}}&nbsp;&nbsp;
                  <span
                    class="text-size-12"
                  >{{message.time | timeStampToDate('HH:mm:ss')}}</span>
                </div>
              </div>

              <!-- </v-list-item-subtitle> -->
            </template>
            <template v-else-if="message.type === 2">
              <v-img
                :src="`${message.text}`"
                @click="dialogURL=message.text,dialog=true"
                aspect-ratio="2"
                width="300"
              />
              <v-list-item-action-text
                class="chart-time"
              >{{message.time | timeStampToDate('HH:mm:ss')}}</v-list-item-action-text>
            </template>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-card-text>

    <v-divider />
    <v-card-actions>
      <v-form
        ref="form"
        class="justify-space-between d-flex"
        style="align-items: center"
        lazy-validation
      >
        <v-text-field
          :loading="textLoading"
          id="message-text"
          :persistent-hint="true"
          background-color="rgba(0, 0, 0, 0)"
          @keydown.enter.stop.prevent="handleSendMessage"
          placeholder="请输入文字，回车键发送"
          hide-details
        >
          <!-- <svg
            role="button"
            class="icon bank-image"
            slot="append"
            aria-hidden="true"
            @click="$refs.inputUpload.$refs.input.click()"
          >
            <use xlink:href="#iconfasongtupian" />
          <v-file-input
            v-show="false"
            slot="append"
            ref="inputUpload"
            accept="image/png, image/jpeg, image/bmp"
            placeholder="请选择图片"
            prepend-icon="mdi-camera"
            class="hidden-input flex-grow-0"
            id="message-file"
            :loading="imagesLoading"
            @change="handleSendImage"
            hide-details
          />

          <v-menu open-on-hover top offset-y slot="append">
            <template v-slot:activator="{ on }">
              <svg role="button" v-on="on" class="icon bank-image" aria-hidden="true">
                <use xlink:href="#iconbianjie" />
              </svg>
            </template>

            <v-list>
              <v-list-item v-for="(item, index) in items" :key="index">
                <v-list-item-title>{{ item.title }}</v-list-item-title>
              </v-list-item>
            </v-list>
          </v-menu>-->
        </v-text-field>
        <svg
          role="button"
          class="icon bank-image"
          aria-hidden="true"
          @click="$refs.inputUpload.$refs.input.click()"
        >
          <use xlink:href="#iconfasongtupian" />
        </svg>
        <v-file-input
          v-show="false"
          ref="inputUpload"
          accept="image/png, image/jpeg, image/bmp"
          placeholder="请选择图片"
          prepend-icon="mdi-camera"
          class="hidden-input flex-grow-0"
          id="message-file"
          :loading="imagesLoading"
          @change="handleSendImage"
          hide-details
        />

        <v-menu open-on-hover top offset-y>
          <template v-slot:activator="{ on }">
            <svg role="button" v-on="on" class="icon bank-image" aria-hidden="true">
              <use xlink:href="#iconbianjie" />
            </svg>
          </template>

          <v-list>
            <v-list-item v-for="(item, index) in items" dense :key="index">
              <v-list-item-title
                class="cursor-pointer text-size-12"
                @click="sendChat(item.title)"
              >{{ item.title }}</v-list-item-title>
            </v-list-item>
          </v-list>
        </v-menu>
      </v-form>
    </v-card-actions>
    <v-dialog v-model="dialog" :transition="false">
      <div class="dialog-close" @click="dialog=false">
        <v-btn text icon color="white" x-large>
          <v-icon>mdi-close</v-icon>
        </v-btn>
      </div>

      <v-row align="center" justify="center">
        <v-img :src="dialogURL" aspect-ratio="1" max-width="600px" contain class></v-img>
      </v-row>
    </v-dialog>
  </v-card>
</template>

<script>

import api from '../../api/apiModule_1';
import { mapState } from '../../utils/common';

let source;
export default {
  name: 'chatName', // 需求地址：http://192.168.10.204:8090/pages/viewpage.action?pageId=5018004
  created() {
    // this.eventSourceInit();
  },
  props: {
    orderInfo: {
      type: Object,
      required: true,
      default: () => ({}),
    },
  },
  computed: {
    ...mapState(['userInfo']),
  },
  mounted() {
    // console.log(this.$refs.inputUpload.$refs.input.click());
    // console.log(this.$refs.inputUpload.$el.click());
    this.initData();
  },
  data: () => ({
    imagesLoading: false,
    textLoading: false,
    chatOnline: true,
    chatLoading: true,
    onLine: 0,
    dialogURL: '',
    dialog: false,
    total: 0,
    url: 'https://pd-prod.oss-cn-shanghai.aliyuncs.com/files/kefu.png',
    timer: null,
    id: 0,
    colours: ['#45BAA5', '#8785A2', '#E05C74', '#F38181', '#4797B1', '#ACA8FF', '#3F72AF', '#F08A5D',
    ],
    items: [
      { title: '我已付款,请及时放币,谢谢。' },
      { title: '您好，付款秒放币，谢谢。' },
      { title: '您好，我未收到您的付款，如付款请截图，谢谢。' },
    ],
    messages: [
    ],
  }),
  methods: {
    init() {
      api.getChatlist({
        orderId: this.$route.params.id,
        id: this.id,
      }).then(({ onLine, list }) => {
        [this.onLine] = [onLine];
        if (list && list.length > 0) {
          this.id = list[list.length - 1].id;
          this.messages = this.messages.concat(list);
          this.messagesRoll();
        }
      });
    },
    loadClick() {
      api.getChatlist({
        orderId: this.$route.params.id,
        id: this.messages[0].id,
        sort: 'old',
      }).then(({ onLine, list, total }) => {
        [this.onLine, this.total] = [onLine, total];
        if (list && list.length > 0) {
          this.messages = list.concat(this.messages);
          // if (list.length < 20) { this.isMore = false; }
        }
      });
    },
    initData() {
      api.getChatlist({
        orderId: this.$route.params.id,
        id: this.id,
      }).then(({ onLine, list, total }) => {
        [this.onLine, this.total] = [onLine, total];
        if (list && list.length > 0) {
          this.id = list[list.length - 1].id;
          this.messages = list;
          this.messagesRoll();
        }
      });
      this.timer = setInterval(() => {
        this.init();
      }, 1300);
    },
    handleReconnect() {
      this.chatLoading = true;
      this.eventSourceInit(source ?.close());
    },
    handleScroll(e) {
      if (e.target.scrollTop <= 20) { // 请求历史数据

      }
    },
    handleSendImage(file) {
      if (file && file.size > 0) {
        if (file.size > (3 * 1024 * 1024)) {
          this.$toast('图片大小不能超过3M!');
          return;
        }
        this.imagesLoading = true;
        api.uploadChat({ file, orderId: this.$route.params.id, type: 2 }).then((url) => {
          this.sendChat(url, 2);
        });
      }
    },
    handleSendMessage({ target: { value } }) {
      // .click();
      if (!value) return;
      this.textLoading = true;
      // this.messages.push({
      //   text: value, time: new Date().getTime(), isSelf: true, type: 0, avatar: '我',
      // });
      this.sendChat(value);
    },
    sendChat(value, type = 1) {
      api.sendChat({
        orderId: this.$route.params.id,
        type,
        msg: value,
      }).then(() => {
        [this.textLoading] = [false, this.$refs.form.reset()];
      });
      [this.textLoading] = [false, this.$refs.form.reset()];
    },
    messagesRoll() {
      this.$nextTick(() => {
        const el = document.getElementById('chat-scroll');
        if (el) el.scrollTop = 999999;
      });
    },
  },
  beforeDestroy() {
    clearInterval(this.timer);
  },
};
</script>

<style scoped lang="scss">
.indicator-online {
  background: rgba(70, 62, 161, 1);
  border-radius: 100%;
  width: 38px;
  height: 38px;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  color: white;
  font-weight: bold;
  &::after {
    width: 20%;
    height: 20%;
    border-radius: 100%;
    content: "";
    background-color: #484855;
    border: thin solid white;
    position: absolute;
    bottom: 1px;
    right: 1px;
  }

  &.active::after {
    background-color: #27c08b;
  }
}

.v-input.hidden-input {
  ::v-deep .v-input__prepend-outer {
    margin: 0 0 0 10px;
  }

  ::v-deep .v-input__control {
    display: none;
  }
}

.padding-20 {
  padding: 20px;
}
.margin-left-40 {
  margin-left: 40px;
}

.v-alert.warning {
  border-radius: 0;
}

.v-application .grey.lighten-2 {
  background-color: rgba(0, 0, 0, 0) !important;
  border-color: rgba(0, 0, 0, 0) !important;
}
::v-deep .v-dialog {
  box-shadow: none;
  .dialog-close {
    width: 100px;
    position: absolute;
    right: 150px;
    // top: -20%;
  }
}
::v-deep .v-image__image--cover {
  background-size: 100%;
}
.chart-header {
  height: 98px;
  padding: 30px 20px !important;
  // border: 1px solid rgba(230, 236, 243, 1);
  .chart-header-title {
    font-size: 14px;
    line-height: 20px;
  }
  .chart-header-subtitle {
    font-weight: 400;
    color: rgba(147, 147, 156, 1);
    font-size: 12px;
    line-height: 18px;
  }
}
.v-list-item__content {
  word-wrap: break-word;
  word-break: break-all;
}
.v-list-item {
  min-height: 24px;
}
.chart-system {
  display: flex;
  justify-content: center;
  font-size: 12px;
  font-weight: 400;
  color: rgba(147, 147, 156, 1);
  line-height: 18px;
}
#chat-scroll {
  padding: 10px 4px;
  // max-height: 420px
  &.height360 {
    height: 360px;
  }
  &.height415 {
    height: 415px;
  }
}
::-webkit-scrollbar {
  width: 3px;
  background-color: rgba(35, 45, 59, 1);
}

/*定义滚动条轨道 内阴影+圆角*/
::-webkit-scrollbar-track {
  // box-shadow: inset 0 0 0px rgba(81, 101, 126, 1);
  // border-radius: 10px;
  width: 3px;
  background-color: #ffffff;
}

/*定义滑块 内阴影+圆角*/
::-webkit-scrollbar-thumb {
  // border-radius: 10px;
  // background: rgba(35, 45, 59, 1);
  border-radius: 1px;
  width: 3px;
  // box-shadow: inset 0 0 0px rgba(35, 45, 59, 1);
  background-color: #d3d3d3;
}
.load {
  font-size: 12px;
  font-family: PingFangSC-Regular, PingFang SC;
  font-weight: 400;
  color: rgba(21, 129, 242, 1);
  line-height: 12px;
}
.chart-avatar {
  background: rgba(245, 166, 35, 1);
  color: white;
  font-weight: bold;
  &.margin-right-0 {
    margin-right: 0;
  }
  &.margin-right-10 {
    margin-right: 10px !important;
    background: rgba(70, 62, 161, 1);
  }
}

.chart-message {
  // white-space: normal;
  font-size: 12px;
  font-family: PingFangSC-Regular, PingFang SC;
  font-weight: 400;
  color: rgba(72, 72, 85, 1);
  line-height: 20px;
  background: #eaeaea;
  border-radius: 4px;
  padding: 4px 8px;
  min-height: 32px;
}
.text-center {
  font-size: 12px;
  font-family: PingFangSC-Regular, PingFang SC;
  font-weight: 400;
  color: rgba(147, 147, 156, 1);
  line-height: 12px;
}
.chart-time {
  padding-top: 8px;
  font-size: 12px;
  color: rgba(147, 147, 156, 1);
  line-height: 12px;
}

.v-form {
  width: 100%;
}
#chat {
  .v-card__actions {
    padding: 0;
    .v-text-field {
      padding: 0;
      margin: 0;
      height: 40px;
      font-size: 12px;
      color: rgba(147, 147, 156, 1);
      ::v-deep .v-input__slot {
        padding: 0 20px;
        height: 40px;
      }
      ::v-deep .v-input__append-inner {
        padding: 5px 0 5px 4px;
        :first-child {
          margin-right: 5px;
        }
      }
    }
  }
  ::v-deep .v-input__slot:before {
    border-color: rgba(0, 0, 0, 0) !important;
  }
  .bank-image {
    width: 20px;
    height: 20px;
    margin-right: 10px;
    cursor: pointer;
  }
}
</style>
