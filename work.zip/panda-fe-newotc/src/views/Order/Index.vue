<template><router-view/></template>

<script>
export default {
  name: 'order',
};
</script>
