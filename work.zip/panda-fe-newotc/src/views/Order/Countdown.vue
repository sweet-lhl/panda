<template>
  <div class="text-color-yellow" id="countdown" v-if="countdownTime !== null">
    <span class="countdown-item-minute">{{countdownTime[0] | numberStr}}</span>
    <span class="margin-left-5 margin-right-5 text-weight-9">:</span>
    <span class="countdown-item-seconds">{{countdownTime[1] | numberStr}}</span>
  </div>
</template>

<script>
import { filters } from '../../plugins/filters';

let timer;

export default {
  name: 'countdown',
  props: {
    orderDetails: { type: Object, required: true },
    status: { type: Number, required: true },
    createTime: { type: Number, required: true },
    // isBuy: { type: Boolean, required: true },
    // isSell: { type: Boolean, required: true },
  },
  computed: {
    timeDiffObj() {
      const {
        nowDate, createTime, status, orderWaitTime,
      } = this;

      if (status === 0 && filters.timeDuration(nowDate, createTime, 'minutes') < orderWaitTime) {
        return filters.timeDuration(nowDate, createTime);
      }

      return null;
    },
    countdownTime() {
      const { timeDiffObj, orderWaitTime } = this;
      return !timeDiffObj ? timeDiffObj : [orderWaitTime - timeDiffObj.minutes - 1, 60 - timeDiffObj.seconds - 1];
    },
  },
  data: () => ({
    nowDate: new Date().getTime(),
    orderWaitTime: Number(process.env.VUE_APP_ORDER_WAIT_TIME), // 倒计时时长[单位:分钟]
  }),
  mounted() {
    timer = setInterval(() => { this.nowDate += 1000; }, 1000); // 模拟时间运行
  },
  destroyed() {
    if (timer) clearInterval(timer);
  },
  watch: {
    countdownTime: { // 通知父组件倒计时状态及详细值
      handler(n, o) {
        if (n !== o) this.$emit('onChange', n);
      },
      deep: true,
      immediate: true, // 首次未变更也将通知
    },
  },
};
</script>

<style scoped>
  .text-color-yellow{
    color: #EEA30C;
  }

  .countdown-item-minute,.countdown-item-seconds{
    border-radius:2px;
    border:2px solid rgba(238,163,12,1);
    font-weight: 600;
    padding: 4px 5px;
  }
</style>
