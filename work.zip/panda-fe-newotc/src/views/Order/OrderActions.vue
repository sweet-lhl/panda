<template>
  <v-card-actions class="d-flex flex-column align-end" id="orderActions">
    <template v-if="status === 0">
      <v-btn depressed color="#F6C40F" @click.stop="$emit('orderPayConfirm')" v-if="isBuy">我已完成转账，下一步</v-btn>
      <v-btn depressed color="#F6C40F" @click.stop="$emit('confirmAdopt')" v-else-if="isSell" :disabled="countTime !== null">确认收款并放行</v-btn>
      <v-btn text color="#1581F2" x-small class="margin-top-10" @click.stop="$emit('cancel')" v-if="isBuy">取消订单</v-btn>
    </template>
    <template v-else-if="status === 1">
      <v-btn depressed color="#F6C40F" @click.stop="$emit('confirmAdopt')" v-if="isSell">确认收款并放行</v-btn>
    </template>
    <template v-else-if="status === 4">
      <v-btn depressed color="#F6C40F" @click.stop="$emit('confirmAdopt')" v-if="isSell" :disabled="appealAction !== 'SECOND_ACTION'">确认收款并放行</v-btn>
    </template>
  </v-card-actions>
</template>

<script>
export default {
  name: 'orderActions',
  props: {
    status: { type: Number, required: true },
    isBuy: { type: Boolean, required: true },
    isSell: { type: Boolean, required: true },
    countTime: {
      required: true,
      validator: value => value?.constructor === Array.prototype.constructor || value === null,
    },
    appealAction: { type: String, default: 'NONE_ACTION' },
  },
};
</script>

<style scoped lang="scss">
  .v-card__actions{

    .v-btn--depressed{
      padding: 14px 30px;
      height: auto;
    }
  }
</style>
