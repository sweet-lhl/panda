<template>
  <div id="tabulation">
    <div class="tabulation-header d-flex justify-space-between align-center">
      <h5 class="text-size-22 text-color-black">我的订单</h5>
      <div>
        <span class="text-size-12 text-color-grey mr-2">状态:</span>
        <v-menu offset-y>
          <template #activator="{on ,value}">
            <v-btn
              color="#28282D"
              text
              outlined
              v-on="on"
              small
            >{{typeText}}<v-icon right dark color="#28282D" :class="[value && 'active']">mdi-chevron-down</v-icon></v-btn>
          </template>
          <v-list>
            <v-list-item
              v-for="({text, value}, idx) in orderTypes"
              :key="`order-type-${idx}`"
              @click="orderType = value"
            ><v-list-item-title class="text-weight-4 text-size-14">{{ text }}</v-list-item-title></v-list-item>
          </v-list>
        </v-menu>
      </div>
    </div>
    <v-data-table
      :headers="tabHeaders"
      :items="orderTable"
      :page.sync="pagination.pageIndex"
      :items-per-page="pagination.pageSize"
      class="tabulation-footer"
      hide-default-footer
      :loading="isLoading"
      loading-text="数据加载中..."
    >
      <template #item.fcreatetime="{ item }">
        {{item.fcreatetime | timeStampToDate}}
      </template>

      <template #item.fstatus="{ item }">
        {{item.fstatus | orderStatusText}}
      </template>

      <template #item.fcount="{ item }">
        {{item.fcount | toFixed(8)}}
      </template>

      <template #item.famount="{ item }">
        {{item.famount | toFixed(2)}}
      </template>

      <template #item.fprice="{ item }">
        {{item.fprice | toFixed(2)}}
      </template>

      <template #item.forderid="{ item }">
        <span :class="[item.ftypeString === 'otc.order.success.type1' ? 'background-color-black' : 'background-color-yellow', 'order-type']">{{item.ftypeString | orderTypeText }}</span>
        <span class="text-size-14 pl-2 cursor-pointer" @click.stop="$router.push(`/order/${item.forderid}`)">{{item.forderid}}</span>
      </template>

      <template #no-data>
        <svg class="icon no-data-image cursor-pointer" aria-hidden="true">
          <use xlink:href="#iconzanwudingdan"/>
        </svg>
        <p class="no-data-text">暂无订单</p>
      </template>

      <template #footer v-if="totalRows>pagination.pageSize">
        <v-pagination v-model="pagination.pageIndex" :length="pagination.total" :total-visible="9" color="#F0BC02" class="justify-end padding-top-20 padding-bottom-20"/>
      </template>
    </v-data-table>
  </div>
</template>

<script>
import api from '../../api/apiModule_1';
import { PagingDefaultConf } from '../../utils/constant';

export default {
  name: 'tabulation',
  data: () => ({
    pagination: { ...PagingDefaultConf },
    orderTypes: [
      { text: '全部', value: 2 },
      { text: '进行中', value: 0 },
      { text: '已完成', value: 1 },
      { text: '已取消', value: -1 },
    ],
    tabHeaders: [
      { text: '订单号', value: 'forderid', sortable: false },
      {
        text: '状态', value: 'fstatus', sortable: false, align: 'right',
      },
      {
        text: '总价', value: 'famount', sortable: false, align: 'right',
      },
      {
        text: '单价', value: 'fprice', sortable: false, align: 'right',
      },
      {
        text: '交易数量', value: 'fcount', sortable: false, align: 'right',
      },
      {
        text: '交易对象', value: 'username', sortable: false, align: 'right',
      },
      {
        text: '时间', value: 'fcreatetime', sortable: false, align: 'right',
      },
    ],
    orderType: 0,
    orderTable: [],
    isLoading: false,
    totalRows: '',
  }),
  computed: {
    typeText() {
      const { orderTypes, orderType } = this.$data;
      return orderTypes.find(({ value }) => value === orderType)?.text;
    },
  },
  methods: {
    fetchOrderList() {
      this.isLoading = true;

      const { pagination: { pageIndex: pageNum, pageSize }, orderType } = this;
      const params = {
        isBusiness: 0,
        pageNum,
        pageSize,
        queryType: do{
          if (orderType === 2) return 1;
          if (orderType === 0) return 1;
          if (orderType === 1) return 4;
          if (orderType === -1) return 5;
        },
      };

      return api[orderType === 0 ? 'otcOrderCurrent' : 'otcOrderHistory'](params)
        .then(({ totalRows, totalPages: total, data }) => {
          [this.orderTable, this.pagination.total, this.isLoading, this.totalRows] = [data, total, false, totalRows];
        }).catch(() => { this.isLoading = false; });
    },
  },
  watch: {
    'pagination.pageIndex': {
      handler(n, o) {
        if (n !== o) this.fetchOrderList();
      },
      deep: true,
      immediate: true,
    },
    orderType(n, o) {
      if (n !== o) {
        this.pagination.pageIndex = 1;
        this.fetchOrderList();
      }
    },
  },
};
</script>

<style scoped lang="scss">
  $blackColor: #28282D;
  $greyColor: rgba(40, 40, 45, 0.6);

  .text-color-black{
    color: $blackColor;
  }

  .text-color-grey{
    color: $greyColor;
  }

  .tabulation-header{
    padding: 40px 0 19px;
    border-bottom: thin solid #E6ECF3;

    &, &+*{
      max-width: 1180px;
      margin: 0 auto;
    }

    .mdi-chevron-down.active{ transform: rotate(180deg) }
  }

  .v-data-table{
    margin-bottom: 40px;

    svg.no-data-image{
      width: 65px;
      height: 65px;
      margin-top: 111px;
      border-radius: 50%;
    }

    ::v-deep td{
      font-size: 12px;
    }

    .no-data-text{
      color: rgba(40, 40, 45, 0.6);
      font-size:12px;
      font-weight: 400;
      margin: 15px 0 111px;
    }

    .background-color-black{
      background-color: #28282D;
      color: white;
    }

    .background-color-yellow{
      background-color: #F6C40F;
      color: #28282D;
    }

    .order-type{
      margin-right: 5px;
      padding: 2px;
      border-radius: 1px;
    }
  }
</style>
