<template>
  <div id="orderConfirmBtn" v-if="countTime === null && isShow">
    <template v-if="isBuy">
      <!-- 买单 -->
      <template v-if="status === 1">
        <v-btn text small color="primary" @click.stop="$emit('cancel')">取消交易</v-btn>
        <span>/</span>
        <v-btn text small color="#EEA30C" :disabled="countdownTime !== null" :to="`/appeal/${orderId}`">
          提交申诉
          <template v-if="countdownTime !== null">({{countdownTime[0] | numberStr}}:{{countdownTime[1] | numberStr}})</template>
        </v-btn>
      </template>
      <v-btn text small color="primary" :to="`/merchantList/${isSell ? 'sell' : 'buy'}`" v-else-if="status === 3">重新下单</v-btn>
      <v-btn text small v-else-if="status===4 && appealAction === 'NONE_ACTION'" class="cursor-none">平台客服会尽快处理，请耐心等待</v-btn>
      <v-btn text small color="primary" @click.stop="$emit('cancel')" v-else-if="status===4 && appealAction === 'SECOND_ACTION'">取消订单</v-btn>
    </template>
    <template v-if="isSell">
      <!-- 卖单 -->
      <v-btn text small color="primary" :to="`/appeal/${orderId}`" v-if="status===1" :disabled="countdownTime !== null">
        <span class="text-color-grey">需要客服介入？</span>
        提交申诉
        <template v-if="countdownTime !== null">({{countdownTime[0] | numberStr}}:{{countdownTime[1] | numberStr}})</template>
      </v-btn>
      <v-btn text small v-else-if="status===4 && appealAction === 'NONE_ACTION'" class="cursor-none">平台客服会尽快处理，请耐心等待</v-btn>
      <v-btn text small color="primary" :to="`/merchantList/${isSell ? 'sell' : 'buy'}`" v-else-if="status===2">再卖一笔</v-btn>
    </template>
  </div>
</template>

<script>
import { filters } from '../../plugins/filters';
import { mapState } from '../../utils/common';

let timer;

export default {
  name: 'orderConfirmBtn',
  props: {
    countTime: {
      required: true,
      validator: value => value?.constructor === Array.prototype.constructor || value === null,
    },
    isBuy: { type: Boolean, required: true },
    isSell: { type: Boolean, required: true },
    status: { type: Number, required: true },
    appealAction: { type: String, default: 'NONE_ACTION' },
    payTime: { type: Number, required: true },
  },
  computed: {
    ...mapState(['userInfo']),
    isShow() {
      const {
        isBuy, isSell, status,
      } = this;
      if (isBuy) return [1, 3, 4].includes(status);
      if (isSell) return [1, 2, 4].includes(status);
      return false;
    },
    orderId() {
      const { id } = this.$route.params;
      return id;
    },
    timeDiffObj() {
      const {
        nowDate, payTime, status, orderWaitTime,
      } = this;

      if (status === 1 && filters.timeDuration(nowDate, payTime, 'minutes') < orderWaitTime) {
        return filters.timeDuration(nowDate, payTime);
      }

      return null;
    },
    countdownTime() {
      const { timeDiffObj, orderWaitTime } = this;
      return !timeDiffObj ? timeDiffObj : [orderWaitTime - timeDiffObj.minutes - 1, 60 - timeDiffObj.seconds - 1];
    },
  },
  data: () => ({
    nowDate: new Date().getTime(),
    orderWaitTime: Number(process.env.VUE_APP_ORDER_APPEAL_TIME), // 提交申诉 倒计时时长[单位:分钟]
  }),
  mounted() {
    timer = setInterval(() => { this.nowDate += 1000; }, 1000); // 模拟时间运行
  },
  destroyed() {
    if (timer) clearInterval(timer);
  },
};
</script>

<style scoped lang="scss">
.text-color-black{
  color: #484855;
}

  .text-color-grey{
    color: #93939C;
  }
</style>
