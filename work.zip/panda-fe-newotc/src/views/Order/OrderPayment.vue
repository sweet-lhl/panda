<template>
  <div id="orderPayment" v-if="payments">
    <template v-if="status === 3">
      <!-- 隐藏 -->
      <div class="bank-info d-flex align-center justify-center flex-column">
        <svg class="icon eye-image" aria-hidden="true">
          <use xlink:href="#iconbukechakan"/>
        </svg>
        <p class="order-status-text text-size-12 text-weight-4">订单已关闭，不可查看</p>
      </div>
    </template>
    <template v-else>
      <div class="bankList">
        <div class="bank-info d-flex align-center justify-space-between">
          <div class="d-flex align-center">
            <svg class="icon bank-image" aria-hidden="true">
              <use :xlink:href="`#${activePayid.fpayid === 1 ? 'iconzhifubao' : activePayid.fpayid === 2 ? 'iconweixin' : 'iconyinhangka'}`"/>
            </svg>
            <span class="margin-left-40">{{activePayid.fname}}</span>
            <span class="text-color-yellow pl-1 cursor-pointer" @click="handleCopyText(activePayid.fname)">
              <svg class="icon pt-1 fuzhi-image" aria-hidden="true">
                <use xlink:href="#iconfuzhi"/>
              </svg>
            </span>
            <span class="margin-left-20" v-if="activePayid.fpayid === 0">{{activePayid.faccount | numberBank}}</span>
            <span class="margin-left-20" v-else>{{activePayid.faccount}}</span>
            <span class="text-color-yellow pl-1 cursor-pointer" @click="handleCopyText(activePayid.faccount)">
              <svg class="icon pt-1 fuzhi-image" aria-hidden="true">
                <use xlink:href="#iconfuzhi"/>
              </svg>
            </span>
            <span class="margin-left-20" v-if="activePayid.fpayid === 0">{{activePayid.fbankname}}</span>
            <span class="margin-left-20" v-if="activePayid.fpayid === 0">{{activePayid.fbranchinfo}}</span>
          </div>
          <div class="qrCode d-flex align-center cursor-pointer" v-if="activePayid.fpayid !== 0 && activePayid.fqrcodeaddress">
            <v-menu
              transition="slide-y-transition"
              bottom
              open-on-hover
              close-on-content-click
              offset-y
              nudge-left="50px"
              nudge-top="-10px"
            >
              <template v-slot:activator="{ on }">
                <svg class="bank-image" aria-hidden="true" v-on="on">
                  <use xlink:href="#iconerweima"/>
                </svg>
                <p class="ml-1" v-on="on">二维码</p>
              </template>
              <div class="payment pa-5">
                <img style="width: 100%" :src="activePayid.fqrcodeaddress" alt="">
              </div>
            </v-menu>

          </div>
        </div>
        <div class="selectType" v-if="payments.length>1">
          <v-menu offset-y>
            <template #activator="{on ,value}">
              <v-btn
                color="#28282D"
                text
                v-on="on"
                small
              >{{fpayid===0?'银行卡':fpayid===1?'支付宝':fpayid===2?'微信':(isBuy?'切换支付方式':'查看更多')}}<v-icon right dark color="#28282D" :class="[value && 'active']">mdi-chevron-down</v-icon></v-btn>
            </template>
            <v-list v-if="payments.length">
              <v-list-item
                v-for="(x, idx) in payments"
                :key="`order-type-${idx}`"
                @click="activePay(x)"
              ><v-list-item-title class="text-weight-4 text-size-14">{{ x.fpayid===0?'银行卡':x.fpayid===1?'支付宝':'微信' }}</v-list-item-title></v-list-item>
            </v-list>
          </v-menu>
        </div>

      </div>
    </template>
  </div>
</template>

<script>
import event from '../../utils/eventEmitter';

export default {
  name: 'orderPayment',
  data() {
    return {
      activePayid: {},
      fpayid: '',
    };
  },
  computed: {
  },
  watch: {
    payments: {
      handler(n, o) {
        if ((n !== o && n && this.fpayid === '') || n.length !== o.length) {
          // eslint-disable-next-line prefer-destructuring
          this.activePayid = this.payments[0] || {};
          event.emit('updatePaymentId', this.activePayid.fid);
        }
      },
      deep: true,
      immediate: true,
    },
  },
  mounted() {
    event.on('updateFpayid', (e) => {
      this.fpayid = e;
    });
  },
  methods: {
    activePay(target) {
      this.activePayid = target;
      this.fpayid = target.fpayid;
      event.emit('updatePaymentId', target.fid);
    },
  },
  props: {
    payments: { type: Array, required: true },
    status: { type: Number, required: true },
    isBuy: { type: Boolean, default: false },
  },
};
</script>

<style scoped lang="scss">
  .bank-info{
    border: thin dashed rgba(230,236,243,1);
    padding: 26px 20px;

    & > *:first-child{
        font-size:12px;
        color:rgba(245,166,35,1);
      }

    & > *{
        font-size:14px;
        font-weight:500;
        color:rgba(72,72,85,1);
      }
  }

  svg.eye-image{
    width: 60px;
    height: 60px;
  }

  .order-status-text{
    color: rgba(40, 40, 45, 0.31);
    margin-top: 10px;
  }
  .text-color-yellow{
    color: #f6c40f;
  }
  .fuzhi-image{
    width: 17px;
    height: 17px;
  }
  .bankList{
    position: relative;
  }
  .selectType{
    position: absolute;
    top: -15px;
    right: 0;
    background-color: white;
    .mdi-chevron-down.active{ transform: rotate(180deg) }
  }
  .qrCode{
    font-size:12px;
    font-family:PingFangSC-Regular,PingFang SC;
    font-weight:400;
    color:rgba(21,129,242,1);
    .bank-image{
      width: 14px;
      height: 14px;
    }
  }
  .payment{
    width: 200px;
    /*height: 150px;*/
    background:rgba(255,255,255,1);
    box-shadow:0 4px 12px 0 rgba(0,0,0,0.08);
    border-radius:4px;
  }
</style>
