<template>
  <div id="order-details">
  <div class="details-box">
    <v-card width="660" outlined title :loading="isLoading">
      <v-card-title class="justify-space-between">
        <div class="align-center d-flex text-size-16">
          <svg class="icon usdt-image cursor-pointer margin-right-5" aria-hidden="true">
            <use xlink:href="#iconUSDT" />
          </svg>
          {{orderTypeLabel}}&nbsp;&nbsp;USDT
        </div>
        <ul class="d-flex align-center">
          <li class="list-style-none text-size-12 text-color-grey">数量：{{orderInfo.fcount}} USDT</li>
          <li class="list-style-none margin-left-5">
            <v-tooltip top color="white" content-class="elevation-6">
              <template v-slot:activator="{ on }">
                <v-icon color="#F8D141" x-small v-on="on" dark class="cursor-pointer pb-1">mdi-lock</v-icon>
              </template>
              <span class="clock-tips">
                <span>资产已由平台锁定</span>
                <span v-if="isBuy">，请尽快付款给卖家</span>
              </span>
            </v-tooltip>
          </li>
          <li
            class="list-style-none text-color-grey text-size-12 margin-left-20"
          >单价：{{orderInfo.fprice}}&nbsp;&nbsp;CNY/USDT</li>
        </ul>
      </v-card-title>
      <OrderWarningText
        :status="status"
        :is-sell="isSell"
        :is-buy="isBuy"
        :buyUserName="buyUserName"
        :payments="otcOrder.fOtcPayments||[]"
      />
      <v-card-text>
        <div class="align-center d-flex margin-bottom-20">
          <span class="flex-grow-0 text-size-12">{{payNameText}}</span>
          <v-divider class="flex-grow-1" />
        </div>
        <OrderPayment
          :payments="otcOrder.fOtcPayments||[]"
          :status="status"
          :is-buy="isBuy"/>
        <p
          class="text-size-12 margin-top-10"
          v-if="isBuy && status !== 3"
        >*转帐时请勿使用微信转银行卡的支付方式进行支付，请勿备注类似 BTC、USDT、Lemon OTC 等信息，否则商家可拒收。</p>
        <div class="countdown-plan d-flex justify-space-between align-center margin-top-20">
          <div>
            <OrderStatusText
              :status="status"
              :is-buy="isBuy"
              :is-sell="isSell"
              :type="otcOrder.ftype||0"
              :buy-user-name="otcOrder.username"
              :appealAction="appealInfo.action"
              :countTime="countTime"
              :createTime="createTime"
            />
            <h1 content="CNY" class="text-size-22 amount-text text-color-yellow">
              {{orderInfo.famount}}
              <span class="text-size-12 margin-left-5">CNY</span>
            </h1>
          </div>
          <OrderConfirmBtn
            :is-buy="isBuy"
            :is-sell="isSell"
            :countTime="countTime"
            @cancel="handleCancelOrder"
            :appealAction="appealInfo.action"
            :payTime="payTime"
            :status="status"
          />
          <Countdown
            :orderDetails="otcOrder"
            @onChange="countTime = arguments[0]"
            :createTime="createTime"
            :status="status"
          />
        </div>
      </v-card-text>
      <OrderActions
        @cancel="handleCancelOrder"
        :status="status"
        :countTime="countTime"
        :is-buy="isBuy"
        :is-sell="isSell"
        :appealAction="appealInfo.action"
        @orderPayConfirm="orderPayConfirm"
        @confirmAdopt="confirmAdopt"
      />
    </v-card>
    <CapitalPassword ref="capitalPassword"/>
    <ConfirmPayment ref="confirmPayment" :payments="otcOrder.fOtcPayments||[]"/>
    <Chat :orderInfo="otcOrder" />
  </div>
  </div>
</template>

<script>
import api from '../../api/apiModule_1';
import { mapState, mapActions } from '../../utils/common';
import CapitalPassword from './CapitalPassword.vue';
import ConfirmPayment from './ConfirmPayment.vue';
import OrderStatusText from './OrderStatusText.vue';
import OrderWarningText from './OrderWarningText.vue';
import OrderPayment from './OrderPayment.vue';
import OrderConfirmBtn from './OrderConfirmBtn.vue';
import OrderActions from './OrderActions.vue';
import Countdown from './Countdown.vue';
import Chat from './Chat.vue';

let orderInfoTimer = null;
export default {
  name: 'orderDetails',
  data: () => ({
    orderInfo: {}, // 订单详情
    appealInfo: {}, // 申诉详情
    countTime: null, // 倒计时
    isLoading: true,
  }),
  /*  watch: {
    status: { // 申诉中
      handler(n, o) {
        if (n !== o && n === 4) { // 时时更新申诉状态
          const { id: orderId } = this.$route.params;
          api.checkAppeal(orderId).then((r) => { this.appealInfo = r; });
        }
      },
      deep: true,
      immediate: true,
    },
  }, */
  computed: {
    ...mapState(['userInfo', 'cancelTimes']),
    otcOrder() {
      const { orderInfo: { otcOrder = {} } } = this.$data;
      return otcOrder;
    },
    buyUserName() {
      const { otcOrder: { username: userName } } = this;
      return userName || '';
    },
    isBuy() { // 买单
      const { otcOrder: { ftypeString: type } } = this;
      return type === 'otc.order.success.type0';
    },
    isSell() { // 卖单
      const { otcOrder: { ftypeString: type } } = this;
      return type === 'otc.order.success.type1';
    },
    status() {
      const { fstatus } = this.otcOrder;
      return fstatus || 0;
    },
    createTime() { // 创建订单时间
      const { fcreatetime, fpaytime, fstatus } = this.otcOrder;
      return (fstatus ? fpaytime : fcreatetime) || 0;
    },
    payTime() { // 支付时间
      const { fpaytime } = this.otcOrder;
      return fpaytime || 0;
    },
    orderTypeLabel() {
      const { isBuy, isSell } = this;
      switch (true) {
        case isBuy:
          return '购买';
        case isSell:
          return '出售';
        default:
          return '---';
      }
    },
    payNameText() {
      const { isBuy, isSell } = this;
      switch (true) {
        case isBuy:
          return '卖家收款方式';
        case isSell:
          return '您的收款方式';
        default:
          return '---';
      }
    },
  },
  created() {
    this.fetchOrderInfo();
    clearInterval(orderInfoTimer);
    orderInfoTimer = setInterval(() => {
      this.fetchOrderInfo();
    }, 5000);
  },
  methods: {
    ...mapActions(['fetchCancelTimes']),
    handleCancelOrder() { // 取消订单
      const { otcOrder: { fstatus: orderStatus, forderid: orderId }, cancelTimes } = this;
      const message = do{
        if (cancelTimes === 3) return '你的取消次数即将到达当日上限，确认取消后你今日将无法进行买入。';
        // if (orderStatus === 0) return '你确认取消订单吗？';
        if (orderStatus === 1) return '请确认是否向商家付款，否则资产将不可找回。';
        return '你确认取消订单吗？';
      };
      // eslint-disable-next-line no-unreachable
      if (message) {
        this.$alert({
          confirmText: '确认取消',
          cancelText: '我再想想',
          title: '取消订单',
          message,
          confirmCallback: () => api.otcCancelOrder(orderId).then(() => {
            this.$toast('取消订单成功');
            this.fetchCancelTimes(); // 更新取消次数
            this.fetchOrderInfo(); // 更新订单详情
          }),
        });
      }
    },
    fetchOrderInfo() { // 查询订单详情
      const { id: orderId } = this.$route.params;
      api.otcOrderQueryInfo({ orderId }).then((r) => {
        [this.orderInfo, this.isLoading] = [r, false];
        const { otcOrder: { fstatus } } = r;
        if (fstatus === 2 || fstatus === 3) { // 完成和取消订单时 清除定时器
          clearInterval(orderInfoTimer);
        }
        if (fstatus === 4) { // 时时更新申诉状态
          api.checkAppeal(orderId).then((data) => { this.appealInfo = data; });
        }
      }).catch(() => { this.isLoading = false; });
    },
    orderPayConfirm() { // 确认订单支付
      this.$refs.confirmPayment.dialog = true;
    },
    confirmAdopt() { // 确认放行
      this.$refs.capitalPassword.dialog = true;
    },
  },
  components: {
    OrderStatusText, Countdown, OrderWarningText, OrderPayment, OrderConfirmBtn, OrderActions, CapitalPassword, Chat, ConfirmPayment,
  },
  destroyed() {
    clearInterval(orderInfoTimer);
  },
};
</script>

<style scoped lang="scss">
.text-color-grey {
  color: rgba(40, 40, 45, 0.6);
}

.text-color-black {
  color: #28282d;
}

#order-details {
  padding: 40px 0 99px;

  .details-box {
    display: flex;
    justify-content: center;
    margin: 0 auto;
    // min-height: 500px;
  }
}
.usdt-image {
  width: 24px;
  height: 24px;
}

.clock-tips {
  color: #484855;
  font-size: 12px;
  font-weight: 400;
}

// v-divider
.v-card__text {
  .v-divider {
    margin-left: 15px;
  }
}

.countdown-plan {
  border-top: thin solid #e6ecf3;
  background-color: #f9f9f9;
  padding: 23px 20px;
}

.text-color-yellow {
  color: #eea30c;
}
</style>
