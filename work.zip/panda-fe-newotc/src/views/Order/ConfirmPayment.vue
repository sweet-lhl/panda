<template>
  <v-dialog v-model="dialog" persistent max-width="420" id="capital-password-verification">
    <v-form
      ref="form"
      lazy-validation
    >
      <v-card>
        <v-card-title class="justify-space-between">
          <span>确认支付</span>
          <v-icon class="cursor-pointer" @click="dialog=false">mdi-close</v-icon>
        </v-card-title>
        <v-card-subtitle>恶意点击付款账号会被冻结。</v-card-subtitle>
        <v-checkbox
          v-model="confirmAgree"
          hide-details
          color="#F6C40F"
          class="checkbox-size-small padding-left-14"
          :label="`我已使用${typeText}进行打款`"
        />
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn text small color="#93939C" @click="dialog=false">取消</v-btn>
          <v-btn color="#F6C40F" depressed small @click="handleSubmit" :loading="isLoading" :disabled="!confirmAgree">我已付款</v-btn>
        </v-card-actions>
      </v-card>
    </v-form>
  </v-dialog>
</template>

<script>
import api from '../../api/apiModule_1';
import event from '../../utils/eventEmitter';

export default {
  name: 'ConfirmPayment',
  data: () => ({
    isLoading: false,
    dialog: false,
    confirmAgree: false,
    paymentId: '',
  }),
  props: {
    payments: { type: Array, required: true },
  },
  methods: {
    handleSubmit() { // 确认支付
      if (this.$refs.form.validate()) {
        const { id: orderId } = this.$route.params;

        this.isLoading = true;
        api.modifyOrderStatus({ orderId, paymentId: this.paymentId, fstatus: 1 /* 下一个状态: 1 */ }).then(() => {
          [this.dialog, this.isLoading] = [false, false, this.$parent.fetchOrderInfo()];
          event.emit('updateFpayid', '');
        }).catch(() => { this.isLoading = false; });
      }
    },
  },
  computed: {
    typeText() {
      const { payments, paymentId } = this;
      const { fpayid } = payments.find(({ fid }) => paymentId === fid) || {};
      // eslint-disable-next-line no-nested-ternary
      return fpayid === 0 ? '银行卡' : fpayid === 1 ? '支付宝' : '微信';
    },
  },
  mounted() {
    event.on('updatePaymentId', (e) => {
      this.paymentId = e;
    });
  },
  watch: {
    dialog(n, o) {
      if (n !== o && !n) this.$nextTick(this.$refs.form.reset); // 重置表单
    },
  },
};
</script>

<style scoped lang="scss">
  .background-color-white{
    ::v-deep .v-label{
      background-color: white;
    }
  }

  .checkbox-size-small{
    margin-top: 0;

    ::v-deep .v-input--selection-controls__input{
      width: 16px;
      height: 16px;

      & + label{
        font-size:12px;
        font-weight:400;
      }
    }
  }

  .v-card__title{
    position: relative;

    &::after{
      content: "";
      position: absolute;
      bottom: 0;
      height: 1px;
      left: 16px;
      right: 16px;
      background-color: #EEEEEE;
    }

    &+.v-card__subtitle{
      margin-top: 0;
      color: #DC5449;
      font-size: 14px;
      font-weight:500;
      padding: 19px 16px;
    }
  }

  .v-card__actions{
    margin: 0 16px;
    padding: 17px 0;
  }

</style>
