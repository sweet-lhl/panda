<template>
  <v-card-subtitle id="orderWarningText">
    <v-alert color="rgba(238, 163, 12, 0.09)" height="45" class="padding-less">
      <svg class="icon icontishi1" aria-hidden="true">
        <use xlink:href="#icontishi1"/>
      </svg>
      <template v-if="isBuy">
        <span v-if="status === 2">订单已完成。</span>
        <span v-else-if="status === 3"> 订单已关闭，请勿再向对方付款。</span>
        <span v-else>平台不支持自动扣款，请使用您本人（{{userInfo.realName}}）的{{typeText}}向以下账户自行转账。</span>
      </template>
      <template v-if="isSell">
        <span v-if="status === 2">订单已完成。</span>
        <span v-else-if="status === 3">订单已关闭。</span>
        <span v-else>买家（实名：{{buyUserName}}）正在向您转账。</span>
      </template>
    </v-alert>

  </v-card-subtitle>
</template>

<script>
import { mapState } from '../../utils/common';
import event from '../../utils/eventEmitter';

export default {
  name: 'orderWarningText',
  data: () => ({
    paymentId: '',
  }),
  props: {
    status: {
      type: Number,
      required: true,
    },
    isBuy: { type: Boolean, required: true },
    isSell: { type: Boolean, required: true },
    buyUserName: { type: String, required: true },
    payments: { type: Array, required: true },
  },
  computed: {
    ...mapState(['userInfo']),
    typeText() {
      const { payments, paymentId } = this;
      const { fpayid } = payments.find(({ fid }) => paymentId === fid) || {};
      // eslint-disable-next-line no-nested-ternary
      return fpayid === 0 ? '银行卡' : fpayid === 1 ? '支付宝' : '微信';
    },
    /* userName() {
              const { realName = '' } = this.userInfo;
              return realName.replace(/[\S\s]*(?=\S)/, '*');
              // return realName.replace(/[\S\s](?=\S)/g, '*'); // 适用于展示真实长短的字符串
            }, */
  },
  mounted() {
    event.on('updatePaymentId', (e) => {
      this.paymentId = e;
    });
  },
};
</script>

<style scoped lang="scss">
  .v-card__subtitle {
    margin-top: 1px;

    .v-alert {
      border-top: thin solid #E6ECF3;
      display: flex;
      align-items: center;
      text-indent: 10px;

      ::v-deep .v-alert__content {
        font-size: 12px;
        font-weight: 400;
        color: rgba(238, 163, 12, 1);
      }
    }
  }

  .icontishi1 {
    width: 12px;
    height: 12px;
    margin-top: 5px;
    margin-right: 5px;
  }
</style>
