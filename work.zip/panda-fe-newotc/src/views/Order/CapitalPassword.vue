<template>
  <!--资金密码验证-->
  <v-dialog v-model="dialog" persistent max-width="420" id="capital-password-verification">
    <!--<template #activator="{ on }">
      <v-btn color="primary" dark v-on="on">Open Dialog</v-btn>
    </template>-->
    <v-form
      ref="form"
      lazy-validation
    >
    <v-card>
      <v-card-title class="justify-space-between">
        <span>确认收款</span>
        <v-icon class="cursor-pointer" @click="dialog=false">mdi-close</v-icon>
      </v-card-title>
      <v-card-subtitle>请务必登录网上银行或第三方支付账号以确认收到该笔款项</v-card-subtitle>
      <v-card-text>
        <InputPassword
          class="background-color-white"
          v-model="password.value"
          :rules="password.rules"
          label="资金密码"
          placeholder="请输入资金密码"
          type="password"
          light
          outlined
          required
        />
      </v-card-text>
      <v-card-actions class="justify-space-between align-center">
        <!--<v-spacer></v-spacer>-->
        <v-checkbox
          v-model="confirmAgree"
          hide-details
          color="#F6C40F"
          class="checkbox-size-small"
          label="我确认已登录收款账户，并核对收款无误"
        />
        <v-btn color="#F6C40F" depressed small @click="handleSubmit" :loading="isLoading" :disabled="!confirmAgree">确认放行</v-btn>
      </v-card-actions>
    </v-card>
    </v-form>
  </v-dialog>
</template>

<script>
import { Regex } from '../../utils/constant';
import InputPassword from '../../components/InputPassword.vue';
import api from '../../api/apiModule_1';
import event from '../../utils/eventEmitter';

export default {
  name: 'capitalPasswordVerification',
  components: { InputPassword },
  data: () => ({
    isLoading: false,
    dialog: false,
    confirmAgree: false,
    paymentId: '',
    password: {
      value: '',
      rules: [v => !!v || '资金密码不能为空', v => !/\s+/.test(v) || '资金密码不能包含空格', v => Regex.PASSWORD.test(v) || '资金密码格式不正确'], /* 密码为8-20位字符，需包含数字、大写字母和小写字母 */
    },
  }),
  methods: {
    handleSubmit() { // 确认收到付款，放行币
      if (this.$refs.form.validate()) {
        const { password: { value: tradepassword }, confirmAgree, paymentId } = this.$data;
        const { id: orderId } = this.$route.params;

        if (!confirmAgree) {
          this.$alert('请确认已登录收款账户，并核对收款无误');
          return;
        }

        this.isLoading = true;
        api.modifyOrderStatus({
          tradepassword, orderId, fstatus: 2, paymentId,
        }).then(() => {
          [this.dialog, this.isLoading] = [false, false, this.$parent.fetchOrderInfo()];
          event.emit('updateFpayid', '');
        }).catch(() => { this.isLoading = false; });
      }
    },
  },
  mounted() {
    event.on('updatePaymentId', (e) => {
      this.paymentId = e;
    });
  },
  watch: {
    dialog(n, o) {
      if (n !== o && !n) this.$nextTick(this.$refs.form.reset); // 重置表单
    },
  },
};
</script>

<style scoped lang="scss">
  .background-color-white{
    ::v-deep .v-label{
      background-color: white;
    }
  }

  .checkbox-size-small{
    margin-top: 0;

    ::v-deep .v-input--selection-controls__input{
      width: 16px;
      height: 16px;

      & + label{
        font-size:12px;
        font-weight:400;
      }
    }
  }

  .v-card__title{
    position: relative;

    &::after{
      content: "";
      position: absolute;
      bottom: 0;
      height: 1px;
      left: 16px;
      right: 16px;
      background-color: #EEEEEE;
    }

    &+.v-card__subtitle{
      margin-top: 0;
      color: #DC5449;
      font-size: 14px;
      font-weight:500;
      padding: 19px 16px;
    }
  }

  .v-card__actions{
    border-top: thin solid #EEEEEE;
    margin: 0 16px;
    padding: 17px 0;
  }

</style>
