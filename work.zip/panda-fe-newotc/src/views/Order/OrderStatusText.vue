<template>
  <div id="orderStatusText">
    <template v-if="status === 0">
      <h5 class="text-size-14 margin-bottom-15 text-color-black" v-if="isBuy">待转账，请向对方账户转账</h5>
      <h5 class="text-size-14 margin-bottom-15 text-color-black" v-else-if="isSell && countTime !== null && hasCountdownTime">买家正在转账，还未收到？<span class="text-size-12 text-color-grey">(订单还剩 00:{{handleRepair(countTime[0])}}:{{handleRepair(countTime[1])}} 取消，资产将回到您的账户)</span></h5>
      <h5 class="text-size-14 margin-bottom-15 text-color-black" v-else-if="isSell && countTime !== null">买家正在转账<span class="text-size-12 text-color-grey">(98.6%的卖家会在5分钟内收到转账)</span></h5>
    </template>
    <template v-else-if="status === 1">
      <h5 class="text-size-14 margin-bottom-15 text-color-black" v-if="isBuy"><span class="text-size-12 text-color-grey">资产即将到账(98.6%的买家会在5分钟内收到资产)</span></h5>
      <h5 class="text-size-14 margin-bottom-15 text-color-black" v-else-if="isSell">对方已标记付款，请确认收款并及时放币</h5>
    </template>
    <template v-else-if="status === 2">
      <h5 class="text-size-14 margin-bottom-15 text-color-black d-flex align-center" v-if="isBuy">
        订单已完成<span class="text-size-12 text-color-grey order-center ml-4">
        <span>您可以</span> <v-btn text small color="primary" class="text-right pa-0" to="/assets">查看资产</v-btn>
        <span>或</span><v-btn text small color="primary" class="text-right pa-0" to="/assets">立即划转</v-btn>
        <span>至币币账户交易，</span><v-btn text small color="primary" class="text-right pa-0" :to="`/merchantList/${isSell ? 'sell' : 'buy'}`">再来一单</v-btn></span>
      </h5>
      <h5 class="text-size-14 margin-bottom-15 text-color-black" v-else-if="isSell">交易成功</h5>
    </template>
    <template v-else-if="status === 3">
      <h5 class="text-size-14 margin-bottom-15 text-color-black" v-if="isBuy">订单已取消</h5>
      <h5 class="text-size-14 margin-bottom-15 text-color-black" v-else-if="isSell">订单已被买家取消</h5>
    </template>
    <template v-else-if="status === 4">
      <h5 class="text-size-14 margin-bottom-15 text-color-black" v-if="isBuy && appealAction === 'NONE_ACTION'">申诉中</h5>
      <h5 class="text-size-14 margin-bottom-15 text-color-black" v-else-if="isBuy && appealAction === 'FIRST_ACTION'">
        卖家已发起申诉
        <v-btn text small color="#F5A623" :to="`/appeal/${orderId}`"><span class="text-color-black">若您付款成功，请点击：</span>举证</v-btn>
      </h5>
      <h5 class="text-size-14 margin-bottom-15 text-color-black" v-else-if="isBuy && appealAction === 'SECOND_ACTION'">
        申诉中
        <span class="text-size-12 text-color-grey">平台客服已介入，判断结果：<em class="text-color-yellow text-style-none">您未付款，请取消订单。</em>如有疑问请联系客服</span>
      </h5>
      <h5 class="text-size-14 margin-bottom-15 text-color-black" v-else-if="isSell && appealAction === 'NONE_ACTION'">申诉中</h5>
      <h5 class="text-size-14 margin-bottom-15 text-color-black" v-else-if="isSell && appealAction === 'SECOND_ACTION'">
        申诉中
        <p class="text-size-12 text-color-grey">平台客服已介入，判断结果：<em class="text-color-yellow text-style-none">对方已如实付款，请点击放行。</em>如有疑问请联系客服</p>
      </h5>
      <h5 class="text-size-14 margin-bottom-15 text-color-black" v-else-if="isSell && appealAction === 'FIRST_ACTION'">
        买家已发起申诉
        <v-btn text small color="#F5A623" :to="`/appeal/${orderId}`"><span class="text-color-black">若您未收到转款，请点击：</span>举证</v-btn>
      </h5>
    </template>
  </div>
</template>

<script>
import { filters } from '../../plugins/filters';
import { mapState } from '../../utils/common';

let timer;

export default {
  name: 'orderStatusText',
  props: {
    status: {
      type: Number,
      required: true,
    },
    isBuy: {
      type: Boolean,
      default: false,
    },
    isSell: {
      type: Boolean,
      default: false,
    },
    type: {
      type: Number,
      required: true,
    },
    appealAction: {
      type: String,
      default: 'NONE_ACTION',
    },
    countTime: {
      required: true,
      validator: value => value?.constructor === Array.prototype.constructor || value === null,
    },
    createTime: {
      type: Number,
      required: true,
    },
  },
  computed: {
    ...mapState(['userInfo']),
    hasCountdownTime() {
      const {
        nowDate, createTime, status,
      } = this;

      return status === 0 && filters.timeDuration(nowDate, createTime, 'minutes') > 5;
    },
    orderId() {
      const { id: orderId } = this.$route.params;
      return orderId;
    },
  },
  data: () => ({
    nowDate: new Date().getTime(),
  }),
  mounted() {
    timer = setInterval(() => { this.nowDate += 1000; }, 1000); // 模拟时间运行
  },
  methods: {
    handleRepair(m) {
      return m > 9 ? m : `0${m}`;
    },
  },
  destroyed() {
    if (timer) clearInterval(timer);
  },
};
</script>

<style scoped>
  .text-color-grey{
    color: rgba(40, 40, 45, 0.6);
  }

  .text-color-black{
    color: #28282D;
  }

  .text-color-yellow{
    color: #F5A623;
  }
  .order-center>*{
    vertical-align: middle;
  }
</style>
