<template>
  <v-app id="lemon-otc-app">
    <!-- Sizes your content based upon application components -->
    <v-content>
      <!-- Provides the application the proper gutter -->
      <v-container fluid class="padding-less">
        <Header/>
        <!-- If using vue-router -->
        <router-view></router-view>
        <Footer v-if="$route.name !== 'home'"/>
      </v-container>
    </v-content>
    <Toast/>
    <Alert/>
  </v-app>
</template>
<script>
import { mapState /* , mapGetters, mapActions */} from '../utils/common';
import { components } from '../plugins/components';

const {
  Header, Footer, Toast, Alert,
} = components;

export default {
  name: 'lemonOtc',
  components: {
    Header, Footer, Toast, Alert,
  },
  computed: {
    ...mapState(['msg']),
  },
  filters: {},
  mounted() {

  },
  methods: {},
};
</script>
<style scoped>
.container{
  min-height: 100%;
  display: flex;
  align-items: stretch;
  flex-direction: column;
  justify-content: space-between;
}
</style>
