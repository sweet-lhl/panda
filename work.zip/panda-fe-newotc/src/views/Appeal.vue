<template>
  <div id="appeal">
    <v-form
      id="sell"
      ref="form"
      :class="{'cursor-none':isSubmit}"
      lazy-validation
    >
      <h5 class="appeal-title">申诉</h5>
      <v-select
        color="#f6c40f"
        :items="appealTypes"
        :menu-props="{ offsetY: true }"
        v-model="formData.appealType.value"
        :rules="formData.appealType.rules"
        label="申诉类型"
        placeholder="请选择申诉类型"
        outlined
      />
      <v-text-field
        label="手机号码"
        placeholder="请输入手机号码"
        color="#f6c40f"
        v-model="formData.phone.value"
        :rules="formData.phone.rules"
        outlined
        type="text"
      />
      <div class="inputUpload">
        <v-file-input
          color="#f6c40f"
          ref="inputUpload"
          v-model="formData.images.value"
          :rules="formData.images.rules"
          accept="image/png, image/jpeg, image/bmp"
          prepend-icon
          label="截图"
          multiple
          placeholder="请上传截图"
          outlined
          :show-size="1024"
        >
          <template v-slot:selection="{ index, text }">
            <v-img
              :src="imagePreviews[index]"
              :alt="text"
              aspect-ratio="1"
              :max-width="50"
              class="lighten-2 cursor-pointer"
              @click.stop="handleImagePreview(imagePreviews[index])"
            />
          </template>
        </v-file-input>
        <svg
          role="button"
          class="icon bank-image cursor-pointer"
          aria-hidden="true"
          v-if="!formData.images.value.length"
          @click="$refs.inputUpload.$refs.input.click()"
        >
          <use xlink:href="#iconshangchuan" />
        </svg>
      </div>

      <v-textarea
        color="#f6c40f"
        outlined
        auto-grow
        :counter="50"
        placeholder="请填写您的申诉理由"
        label="申诉理由"
        v-model="formData.describe.value"
        :rules="formData.describe.rules"
      />
      <v-btn color="#F6C40F" block large depressed @click.stop="handleSubmit" :loading="isSubmit">提交申诉</v-btn>
      <p v-if="isSell" class="margin-top-20 text-size-12 text-color-grey">*提起申诉后资产将会冻结，申诉专员将介入本次交易，直至申诉结束。恶意申诉属于扰乱平台正常运营秩序的行为，情节严重将冻结账户。</p>
    </v-form>
    <!-- ... loading ... -->
    <v-overlay
      absolute
      :value="isLoading"
    >
      <v-card-text>
        <v-progress-linear
          class="margin-top-10"
          color="#F6C40F"
          height="6"
          indeterminate
          rounded
          absolute
        />
      </v-card-text>
    </v-overlay>
    <!-- 图片预览 -->
    <ImagePreview :uri="imagePreview" :overlay.sync="imagePreviewStatus"/>
  </div>
</template>

<script>
import api from '../api/apiModule_1';
import { mapState } from '../utils/common';
import { Regex } from '../utils/constant';
import ImagePreview from '../components/ImagePreview.vue';

export default {
  name: 'appeal',
  data: () => ({
    isLoading: false, // 请求订单中
    isSubmit: false, // 数据提交中
    imagePreviewStatus: false, // 图片预览
    formData: {
      appealType: { value: 0, rules: [] },
      phone: { value: '', rules: [v => !!v || '必须填写手机号', v => Regex.CHINA_PHONE.test(v) || '手机号输入不合法'] },
      describe: { value: '', rules: [v => !!v || '申诉理由不能为空', v => v.length <= 50 || '申诉理由不能超过50个字'] },
      images: { value: [], rules: [v => !!v || '请上传截图', v => v.every(f => f.size < 5 * 1024 * 1024) || '截图大小不能超过5M!'] },
    },
    imagePreviews: [], // 文件预览图集合
    imagePreview: '', // 当前预览的图片链接
    orderInfo: {}, // 订单详情
  }),
  computed: {
    ...mapState(['userInfo']),
    orderId() {
      const { id: orderId } = this.$route.params;
      return orderId;
    },
    otcOrder() {
      const { otcOrder = {} } = this.orderInfo;
      return otcOrder;
    },
    isBuy() { // 买单
      const {
        otcOrder: { ftype: type, fuserid: orderUserId, fbussinessid: orderBussinessId },
        userInfo: { fid: userId },
      } = this;
      return (orderUserId === userId && type === 0) || (orderBussinessId === userId && type === 1);
    },
    isSell() { // 卖单
      const {
        otcOrder: { ftype: type, fuserid: orderUserId, fbussinessid: orderBussinessId },
        userInfo: { fid: userId },
      } = this;
      return (orderUserId === userId && type === 1) || (orderBussinessId === userId && type === 0);
    },
    appealTypes() {
      let appealType;
      const { isBuy, isSell } = this;
      const appealTypes = [
        { value: 2, text: '对方无应答' },
        { value: 3, text: '对方有欺诈行为' },
        { value: 4, text: '其他' },
      ];

      if (isBuy) appealType = { value: 1, text: '对方未放行' };
      if (isSell) appealType = { value: 0, text: '对方未付款' };

      appealTypes.splice(0, 0, appealType);
      return appealTypes;
    },
  },
  watch: {
    'formData.images.value': {
      handler(n, o) {
        if (n !== o) {
          this.imagePreviews = n.reduce((acc, file) => {
            const reader = new FileReader();
            reader.onload = ({ target: { result: imageUri } }) => { acc.push(imageUri); };
            reader.readAsDataURL(file);
            return acc;
          }, []);
        }
      },
      immediate: true,
      deep: true,
    },
    imagePreviewStatus(n, o) { // 关闭遮罩层时自动清除预览链接
      if (n !== o && !n) this.imagePreview = '';
    },
  },
  methods: {
    handleSubmit() {
      if (!this.$refs.form.validate()) return;

      this.isSubmit = true;
      const {
        otcOrder: { forderid: orderId },
        formData: {
          describe: { value: fappealdes }, phone: { value: fphone }, appealType: { value: ftype }, images: { value: imageAdd },
        },
      } = this;

      Promise.all( // 上传图片
        imageAdd.map(file => api.appealUpload({ file })),
      ).then(r => api.createAppeal({ // 提交申诉数据
        orderId, ftype, fappealdes, fphone, imageAdd: r.map(({ url }) => url).join(),
      }).then(() => this.$router.back())
        .catch(() => { this.isSubmit = false; }))
        .catch(() => { this.isSubmit = false; });
    },
    fetchOrderInfo() { // 查询订单详情
      this.isLoading = true;
      const { id: orderId } = this.$route.params;

      api.otcOrderQueryInfo({ orderId }).then((r) => {
        [this.orderInfo, this.isLoading] = [r, false];
      }).catch(() => { this.isLoading = false; });
    },
    handleImagePreview(uri) {
      [this.imagePreview, this.imagePreviewStatus] = [uri, true];
    },
  },
  created() {
    this.fetchOrderInfo();
  },
  components: { ImagePreview },
};
</script>

<style scoped lang="scss">
  .text-color-grey{
    color: #93939C;
  }

  #appeal{
    width: 510px;
    margin: 0 auto;

    .v-form{
      margin: 30px 0 80px;

      .appeal-title{
        font-size:20px;
        color: #28282D;
        font-weight:500;
        padding: 10px 0;
        border-bottom: thin solid #E6ECF3;
        margin-bottom: 30px;
      }
    }
  }
  .inputUpload{
    position: relative;
    .bank-image{
      position: absolute;
      top: 13px;
      right: 12px;
      width: 25px;
      height: 25px;
    }
  }
  ::v-deep .v-text-field__slot{
    cursor: pointer;
  }
</style>
