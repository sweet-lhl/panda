<template>
  <v-snackbar
    v-model="isShow"
    top
    :timeout="3000"
    @input="handleChange"
  >
    <span v-if="msg">{{ msg }}</span>
    <v-btn
      color="rgb(246, 196, 15)"
      text
      @click="isShow = false"
    >
      关闭
    </v-btn>
  </v-snackbar>
</template>

<script>
import event from '../utils/eventEmitter';

export default {
  name: 'toast',
  data() {
    return {
      isShow: false,
      msg: '',
    };
  },
  created() {
    event.on('toast', (msg) => {
      [this.msg, this.isShow] = [msg, Boolean(msg)];
    });
  },
  methods: {
    handleChange() {
      this.msg = '';
    },
  },
};
</script>

<style scoped lang="scss">
  #toast {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: transparent;
    display: flex;
    justify-content: center;
    align-items: flex-end;
    font-size: 20px;
    z-index: 999999;

    .msg-box{
      color:#ffffff;
      display: inline-block;
      background: black;
      border-radius: 2px;
      font-size: 1.5em;
      padding: 10px 20px;
      position: relative;
      top: -250px;
    }
  }
</style>
