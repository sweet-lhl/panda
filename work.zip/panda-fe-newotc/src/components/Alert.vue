<template>
  <v-dialog
    v-model="isShow"
    width="420"
    :persistent="persistent"
    :loading="isLoading"
  >
    <v-card>
      <v-card-title class="headline text-size-16">{{title}}</v-card-title>

      <v-card-text><div v-html="message" class="alert-message"></div></v-card-text>
      <!--<v-divider></v-divider>-->
      <v-card-actions>
        <v-spacer></v-spacer>
        <v-btn text small color="#93939C" @click="handleCancel">{{btnText.cancel}}</v-btn>
        <v-btn
          color="#F6C40F"
          small
          depressed
          tile
          :loading="isLoading"
          @click="handleConfirm"
        >{{btnText.confirm}}</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import event from '../utils/eventEmitter';

export default {
  name: 'alert',
  data() {
    return {
      isShow: false,
      isLoading: false,
      persistent: true,
      message: '',
      title: '提示',
      btnText: {
        confirm: '确认',
        cancel: '取消',
      },
      callback: {
        confirm: null, // promise
        cancel: null,
      },
    };
  },
  created() {
    event.on('alert', (opt) => {
      if (typeof opt === 'string') { // only string
        [this.message, this.isShow] = [opt, true];
        return;
      }

      const { // must object
        confirmText, cancelText, message, cancelCallback, confirmCallback, title, persistent,
      } = opt;

      if (confirmText) this.btnText.confirm = confirmText;
      if (cancelText) this.btnText.cancel = cancelText;
      if (title) this.title = title;
      if (persistent) this.persistent = persistent;
      if (message) this.message = message;
      if (cancelCallback) this.callback.cancel = cancelCallback;
      if (confirmCallback) this.callback.confirm = confirmCallback;

      this.isShow = true;
    });
  },
  methods: {
    handleCancel() {
      const { callback: { cancel } } = this;
      [this.isShow] = [
        false,
        cancel && cancel(),
      ];
    },
    handleConfirm() {
      const { callback: { confirm } } = this;

      if (typeof confirm !== 'function') {
        this.isShow = false;
        return;
      }

      this.isLoading = true;
      confirm()
        .then(() => { [this.isShow, this.isLoading] = new Array(2).fill(false); })
        .catch(() => { this.isLoading = false; });
    },
  },
  watch: {
    isShow(n, o) {
      if (n !== o && !n) {
        this.$nextTick(() => { // 重置组件数据
          [
            this.message,
            this.title,
            this.btnText,
            this.callback,
            this.isLoading,
          ] = [
            '',
            '提示',
            {
              confirm: '确认',
              cancel: '取消',
            },
            {
              confirm: null,
              cancel: null,
            },
            false];
        });
      }
    },
  },
};
</script>

<style scoped lang="scss">
  .v-card__title{
    position: relative;
    color: #484855;

    &.text-size-16{
      font-size: 16px !important;
    }

    &::after{
      content: "";
      height: 2px;
      background-color: #EEEEEE;
      width: calc(100% - (24px * 2));
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      margin: 0 auto;
    }
  }

  .v-card__text{
    padding: 19px 24px 20px !important;
  }

  .v-card__actions{
    padding: 20px;
  }
  ::v-deep .v-dialog{
    box-shadow:none;
  }
</style>
