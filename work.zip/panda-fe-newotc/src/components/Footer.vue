<template>
  <div class="foote">
    <div class="app-footer">
      <div class="d-flex justify-space-between">
        <div>
          <div class="logo-box">
            <svg class="icon logo-image" aria-hidden="true">
              <use xlink:href="#iconlogo"/>
            </svg>
          </div>
          <p class="plat-concat margin-top-20">
            <span>官方邮箱: support@lemonotc.com</span>
            <!--<span class="margin-left-40">战略合作伙伴：Panda Global</span>-->
          </p>
          <p class="plat-details text-size-14 margin-top-20">Lemon OTC为优质的OTC服务商，请放心使用</p>
        </div>
        <div>
          <p class="agreement text-size-14 text-wight-4">
            <span class="text-left cursor-pointer" @click.stop="handleGoto('https://lemonotc.zendesk.com/hc/zh-cn/articles/360034047034-隐私政策')">用户协议</span>
            <span class="text-center cursor-pointer" @click.stop="handleGoto('https://lemonotc.zendesk.com/hc/zh-cn/categories/360002160994-帮助中心')">常见问题</span>
            <span class="text-right cursor-pointer" @click.stop="handleGoto('https://lemonotc.zendesk.com/hc/zh-cn/articles/360034812094-关于lemon-OTC')">关于我们</span>
          </p>
        </div>
      </div>
      <p class="copy-box text-size-14 margin-top-50 text-center">Copyright &copy; 2019-2020 LEMON OTC TECHNOLOGY LTD</p>
    </div>
  </div>

</template>

<script>
export default {
  name: 'Footer',
  methods: {
    handleGoto(uri) {
      window.open(uri);
    },
  },
};
</script>

<style scoped lang="scss">
  .margin-top-50{
    margin-top: 50px;
  }

  .margin-left-40{
    margin-left: 40px;
  }
.foote{
  background-color: #060606;
}
  .app-footer{
    flex-shrink: 0;
    flex-grow: 0;
    padding: 87px 50px 20px;
    width: 1280px;
    margin: auto;
    .logo-image{
      width: 168px;
      height: 44.4px;
    }

    .agreement{
      color: #CDCDCD;
      margin-top: 69px;

      & > *{
        display: inline-block;
        width: 83px;

        &:nth-child(2){
          border-left: thin solid #CDCDCD;
          border-right: thin solid #CDCDCD;
        }
      }

    }

    .plat-details{
      color: rgba(255, 255, 255, 0.41);
    }

    .plat-concat{
      color: #CDCDCD;
    }

    .copy-box{
      color: rgba(255, 255, 255, 0.31)
    }
  }
</style>
