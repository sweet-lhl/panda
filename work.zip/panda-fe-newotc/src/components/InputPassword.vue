<template>
  <v-text-field
    color="#f6c40f"
    :value="value"
    :append-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'"
    :rules="rules"
    :type="showPassword ? 'text' : 'password'"
    :label="label"
    :hint="hint"
    :counter="counter"
    :outlined="outlined"
    :placeholder="placeholder"
    :light="light"
    :dark="dark"
    :solo="solo"
    @input="$emit('input', arguments[0])"
    @click:append="toggleShowPassword"
  ><slot/></v-text-field>
</template>

<script>
export default {
  name: 'inputPassword',
  props: ['rules', 'label', 'hint', 'counter', 'value', 'outlined', 'placeholder', 'light', 'dark', 'solo'],
  methods: {
    toggleShowPassword() { this.showPassword = !this.showPassword; },
  },
  data: () => ({
    showPassword: false,
  }),
};
</script>

<style scoped>

</style>
