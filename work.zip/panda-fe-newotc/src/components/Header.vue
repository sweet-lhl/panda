<template>
  <!--<v-app-bar app absolute color="transparent">
    &lt;!&ndash; &ndash;&gt;
    <v-row justify="space-between" align="center">
      <v-col cols="2">
        <v-img
          src="https://pd-web-prod.oss-cn-hangzhou.aliyuncs.com/pandaotc/img/logo.67626e60.png"
          aspect-ratio="4"
          width="118"
        ></v-img>
      </v-col>
      <v-col cols="4">
        <v-btn text small>Normal</v-btn>
        <v-btn text small>Normal</v-btn>
        <v-btn text small>Normal</v-btn>
        <v-btn text small>Normal</v-btn>
      </v-col>
      <v-col cols="6" class="justify-end d-flex">
        <v-btn small outlined color="#F0D402" class="mx-2">登</v-btn>
        <v-btn small color="#F0D402" class="mx-2">注册</v-btn>
        <v-btn text small class="mx-2">公告</v-btn>
        <v-btn text small class="mx-2">语言切换</v-btn>
      </v-col>
    </v-row>
  </v-app-bar>-->
  <div :class="['app-header', $route.name === 'home' && 'absolute-0']">
    <div class="left">
      <div class="logo-box margin-top-2" @click.stop="$router.push('/')">
        <svg class="icon logo-image cursor-pointer mt-1" aria-hidden="true">
          <use xlink:href="#iconlogo"/>
        </svg>
      </div>
      <ul class="margin-less padding-less navigation">
        <li v-for="({uri, name, isExternal}, idx) in dataUrl"
            :key="`navigator-left-${idx}`"
            @click.stop="handleGoto(uri, isExternal)"
            :class="{active:$route.path.includes('merchantList/')&&!isExternal}"
            class="text-size-14 text-weight-5 cursor-pointer">{{name}}
        </li>

        <li @click.stop="handleGoto('/merchant/transaction')"
            v-if="userInfo && userInfo.isBusiness === 1"
            :class="{active:$route.path.includes('merchant/')}"
            class="text-size-14 text-weight-5 cursor-pointer">
          <span class="business-going">商家中心</span>
        </li>
      </ul>
    </div>
    <ul class="right padding-less margin-less">
      <template v-if="!isLogin">
        <li class="text-size-14 text-weight-5 cursor-pointer login-btn"
            @click.stop="handleGoto('/login')">登录
        </li>
        <li class="text-size-14 text-weight-5 cursor-pointer register-btn"
            @click.stop="handleGotoRegister">注册
        </li>
      </template>
      <template v-else>
        <li class="text-size-14 text-weight-5 cursor-pointer" @click.stop="handleGoto('/assets')">
          资产
        </li>
        <li class="text-size-14 text-weight-5 cursor-pointer" @click.stop="handleGoto('/order')">
          订单
        </li>
     <!--   <li class="cursor-pointer" @click.stop="handleGoto('/accountSetting/bankCardManagement')">
          <v-icon color="#C4C4D5">mdi-account</v-icon>
        </li>-->

        <li class="text-size-14 text-weight-5 cursor-pointer">
          <v-menu
            transition="slide-y-transition"
            bottom
            open-on-hover
            close-on-content-click
            offset-y
            nudge-left="50px"
            nudge-top="-10px"
          >
            <template v-slot:activator="{ on }">
              <span v-on="on"><v-icon color="#C4C4D5">mdi-account</v-icon></span>
            </template>
            <v-list>
              <v-list-item key="lang-item-1"  @click.stop="handleGoto('/accountSetting/bankCardManagement')"><v-list-item-title>{{userInfo.fnickname}}</v-list-item-title></v-list-item>
              <v-list-item key="lang-item-2"  @click.stop="handleVerifyAccount"><v-list-item-title>账户与安全</v-list-item-title></v-list-item>
              <v-list-item key="lang-item-3"  @click.stop="handleGoto('/accountSetting/bankCardManagement')"><v-list-item-title>法币设置</v-list-item-title></v-list-item>
              <v-list-item key="lang-item-4"   @click.stop="logout"><v-list-item-title>退出登录</v-list-item-title></v-list-item>
            </v-list>
          </v-menu>
        </li>
      </template>
      <li
        class="text-size-14 text-weight-5 cursor-pointer"
        @click.stop="windowOpen('https://lemonotc.zendesk.com/hc/zh-cn/categories/360002160974-%E5%85%AC%E5%91%8A%E4%B8%AD%E5%BF%83')">
        公告
      </li>
      <li class="text-size-14 text-weight-5 cursor-pointer">
        <v-menu offset-y>
          <template #activator="{ on }">
            <span v-on="on">{{languages.find(({value}) => value === language).key}}</span>
          </template>
          <v-list>
            <v-list-item
              v-for="({value, key}, idx) in languages"
              :key="`lang-item-${idx}`"
              @click="language = value"
            >
              <v-list-item-title>{{ key }}</v-list-item-title>
            </v-list-item>
          </v-list>
        </v-menu>
      </li>
    </ul>
  </div>
</template>

<script>
import {
  mapState, mapActions, mapGetters, cookies,
} from '../utils/common';

import api from '../api/apiModule_1';

export default {
  name: 'Header',
  computed: {
    ...mapState(['userInfo']),
    ...mapGetters(['isLogin']),
    title() {
      return this.$route.meta.title;
    },
  },
  methods: {
    ...mapActions(['fetchUserInfo', 'clearUserInfo']),
    logout() { // 退出登录
      cookies.expire('token');
      api.userLoginOut().then(() => {
        this.$toast('退出成功');
        this.clearUserInfo();
        this.$router.push('/');
      });
    },
    handleGoto(uri, isExternal = false) {
      if (isExternal && uri) window.open(uri);
      if (!isExternal && uri) this.$router.push(uri);
    },
    handleGotoRegister() {
      window.open(`${process.env.VUE_APP_PANDA_URL}/register`);
    },
    handleVerifyAccount() { // 验证用户账户安全
      window.open(`${process.env.VUE_APP_PANDA_URL}/userManagement`);
    },
    windowOpen(uri) {
      window.open(uri);
    },
  },
  data: () => ({
    dataUrl: [{
      name: 'OTC交易',
      uri: '/merchantList/buy',
      isExternal: false,
    }, {
      name: '币币交易',
      uri: process.env.VUE_APP_PANDA_EXCHANGE_PAGE,
      isExternal: true,
    }, /* {
      name: '合约交易',
      uri: process.env.VUE_APP_PANDA_FUTURE_PAGE,
      isExternal: true,
    }, */ {
      name: '帮助中心',
      uri: 'https://lemonotc.zendesk.com/hc/zh-cn/categories/360002160994-%E5%B8%AE%E5%8A%A9%E4%B8%AD%E5%BF%83',
      isExternal: true,
    }],
    languages: [{ key: '简体中文', value: 'zh-CN' }],
    language: 'zh-CN',
    operation: [{

    }],
  }),
  watch: {
    /* isLogin: {
              handler(n, o) {
                // TODO:登录后执行
              },
              deep: true,
              immediate: true,
            }, */
  },
  created() {
    if (cookies.get('token')) this.fetchUserInfo();
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
  $fullHeight: 50px;

  .app-header {
    display: flex;
    height: $fullHeight;
    overflow: hidden;
    width: 100%;
    justify-content: space-between;
    align-items: center;
    padding-left: 20px;
    padding-right: 20px;
    background-color: $black-color;
    flex-shrink: 0;
    flex-grow: 0;

    &.absolute-0 {
      position: absolute;
      top: 0;
      right: 0;
      left: 0;
      z-index: 1;
      background-color: rgba(6, 6, 6, .45);
    }

    .left {
      height: 100%;
      display: flex;
      justify-content: center;
      align-items: center;

      /*.logo-box {
        background-image: url("https://pd-web-prod.oss-cn-hangzhou.aliyuncs.com/pandaotc/img/logo.67626e60.png");
        width: 118px;
        height: 100%;
        display: inline-block;
      }*/

      .logo-image {
        width: 122px;
        height: 26px;
      }

      .navigation {
        display: inline-block;
        list-style: none;
        height: 100%;

        li {
          position: relative;
          height: 100%;
          display: inline-block;
          margin-left: 20px;
          color: $grey-color;
          line-height: $fullHeight;
          transition: color $transition-time ease-in-out;

          &::after {
            content: "";
            width: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-bottom: 0;
            height: 2px;
            margin: 0 auto;
            position: absolute;
            background-color: $yellow-color;
            transition: width $transition-time ease-in-out;
          }

          &:hover,&.active {
            color: $yellow-color;

            &::after {
              width: 100%;
            }
          }
        }
      }

    }

    .right {
      display: inline-block;
      list-style: none;

      .login-btn, .register-btn {
        border-radius: 3px;
        padding: 7px 16px;
      }

      .login-btn {
        border: thin solid $yellow-color;
        color: $yellow-color;
        background-color: transparent;
      }

      .register-btn {
        border: none;
        background-color: $yellow-color;
        color: $black-color;
        margin-right: 60px;
      }

      li {
        color: $grey-color;
        display: inline-block;
        margin-right: 20px;
      }
    }
  }

  .business-going {
    display: inline-block;
    height: 25px;
    width: 76px;
    background-color: #0091FF;
    color: #ffffff;
    border-radius: 3px;
    text-align: center;
    line-height: 25px;
  }
</style>
