<template>
  <div class="flex-direction-column flex-align-items-center server-wrapper">
    <div class="server-img background-reset"></div>
    <p class="server-title">停服维护公告</p>
    <div class="server-content">
      <p>尊敬的用户：</p>
      <p class="text-indent-16 margin-top-12">为了提升服务质量，进一步优化您的交易体验，Lemon OTC将于2020年5月8日05:00（GMT+8）起进行系统维护升级，在此期间，我们将暂停网站访问。届时币币交易、合约交易、OTC交易将暂停相关服务。系统维护升级预计持续3个小时左右，如提前完成会提早开放服务。维护范围包括WEB、APP、H5服务。
        维护期间，您暂时无法进行下单交易、撤单、划转等相关操作。</p>
      <p class="text-indent-16 margin-top-12">Lemon OTC会一如既往地保障您储存在Lemon OTC的数字资产的安全，非常感谢您的理解与支持。给您带来的不便，敬请谅解！</p>
      <p class="text-indent-16 margin-top-12">我们将在维护完成后第一时间发布公告通知。您也可以咨询在线客服(<a class="server-link" href="mailto:support@lemonotc.com">support@lemonotc.com</a>)等方式关注最新进展。Lemon OTC将不断为您提供更优秀的产品和更优质的服务。</p>
      <P class="margin-top-12 text-align-right">Lemon OTC团队</p>
      <P class="text-align-right">2020年5月8日</P>
    </div>
    <div class="server-footer text-align-center">
<!--      <p class="text-size-14">如您有任何疑问， 请<label class="text-color-yellow">wait a moment</label></p>-->
      <P class="text-size-12 margin-top-14">Copyright © 2019-2020 LEMON OTC TECHNOLOGY LTD</P>
    </div>
  </div>
</template>

<script>

export default {
  name: 'ServicePaused',
  methods: {
    handleShowZendesk() {
      window.$zopim.livechat.window.show();
    },
  },
};
</script>

<style scoped lang="scss">
  .server-wrapper {
    height: 100%;
    width: 100%;
    background: #191F2D;
    color: #c5ccdd;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  .server-img {
    margin-top: 30px;
    width: 210px;
    height: 210px;
    background-image: url("../assets/images/stop-server.png");
    margin-bottom: 25px;
  }

  .server-title {
    font-size: 20px;
  }

  .server-footer {
    margin-top: 60px;
  }

  .text-align-center {
    text-align: center;
  }

  .text-align-right {
    text-align: right;
  }

  .cursor-pointer {
    cursor: pointer;
  }

  .margin-top-12 {
    margin-top: 12px;
  }

  .server-content {
    margin-top: 28px;
    width: 640px;
    line-height: 20px;
    font-size: 14px;
    text-align:justify;
    text-justify:inter-ideograph;
  }

  .text-indent-16 {
    text-indent: 16px;
  }

  .text-size-12 {
    font-size: 12px;
  }

  .text-size-14 {
    font-size: 14px;
  }

  .text-color-yellow {
    color: #F5C40E;
  }

  .server-link {
    color: #1581F2;
  }
</style>
