<template>
  <v-overlay :value="overlay">
    <v-row align="center" justify="center">
      <v-img
        :src="uri"
        aspect-ratio="1"
        class="lighten-2"
        width="500"
      />
    </v-row>
    <v-row align="center" justify="center" class="margin-top-20">
      <v-btn
        icon
        @click.stop="$emit('update:overlay', false)"
      >
        <v-icon>mdi-close</v-icon>
      </v-btn>
    </v-row>
  </v-overlay>
</template>

<script>
export default {
  name: 'imagePreview',
  props: {
    overlay: { type: Boolean, default: false },
    uri: { type: String, required: true },
  },
};
</script>

<style scoped>

</style>
