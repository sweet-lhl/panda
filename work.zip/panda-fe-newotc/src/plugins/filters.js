// time stamp
import { moment } from '../utils/common';

export const filters = {
  timeStampToDate(timeStamp, reg = 'YYYY.MM.DD HH:mm:ss') { // 时间戳转时间
    if (!timeStamp) return '...';
    return moment(timeStamp).format(reg);
  },
  timeDuration(start, end, key) { // 时间周期，支持单独获取一个key的时间周期
    const momentDiff = moment(start).diff(moment(end), key, true);
    const timeDuration = moment.duration(momentDiff);
    return key ? momentDiff : {
      years: timeDuration.get('years'),
      months: timeDuration.get('months'),
      weeks: timeDuration.get('weeks'),
      days: timeDuration.get('days'),
      hours: timeDuration.get('hours'),
      minutes: timeDuration.get('minutes'),
      seconds: timeDuration.get('seconds'),
      milliseconds: timeDuration.get('milliseconds'),
    };
  },
  attrSort(array, attr, rev = 1) { // 数组排序，支持对象key键值排序
  /* eslint no-nested-ternary: 0 */
    return array.sort((a, b) => {
      const [old, cur] = [
        a.constructor === Object ? a[attr] : a,
        b.constructor === Object ? b[attr] : b,
      ];
      return (old - cur) * rev;
    });
  },
  numberStr(number) {
    const numberStr = Number.prototype.toString.call(number);
    return numberStr.length > 1 ? numberStr : `0${numberStr}`;
  },
  /* toFixed(amount = 0, fix = 8) { // 保留小数
    // return String(amount).match(new RegExp(`^\\d+(?:\\.\\d{0,${fix}})?`))[0] || 0;用此方法 不会保留指定小数位数
    return Number(amount).toFixed(Number(fix) + 1).slice(0, -1);用此方法 "1000000099.000652000000000000"此数字会出问题
  }, */
  getFullNum(num) {
    // 处理非数字
    // eslint-disable-next-line no-restricted-globals
    if (isNaN(num)) { return num; }
    // 处理不需要转换的数字
    const str = `${num}`;
    if (!/e/i.test(str)) { return num; }

    return (num).toFixed(18).replace(/\.?0+$/, '');
  },
  toFixed(amount = 0, fix = 6) { // 保留小数
    const mount = Number(amount);
    const amountArr = String(filters.getFullNum(mount)).split('.');
    const newAmount = amountArr.length > 1 ? `0.${amountArr[1].substr(0, fix)}` : mount;
    const isPlus = amountArr.length > 1 && amountArr[0] === '-0' ? '-' : '';
    const data = fix ? Number(newAmount).toFixed(fix + 1).slice(0, -1) : Number(newAmount);
    return amountArr.length > 1 ? `${isPlus}${Number(amountArr[0])}.${data.split('.')[1]}` : data;
  },
  numberBank(value) { // 银行卡分割
    if (value) {
      return value.toString().replace(/ /g, '').replace(/\D/g, '').replace(/....(?!$)/g, '$& ');
    }
    return '';
  },
  strIntercept(str, length = 3) { // 过滤中间信息，不予展示
    const newStr = String(str);
    const prefix = newStr.match(new RegExp(`^[\\s\\S]{${length}}`));
    const suffix = newStr.match(new RegExp(`[\\s\\S]{${length}}$`));
    return `${prefix}****${suffix}`;
  },
  divisionMoney(str, fix = 2) { // 分割金额，默认保留两位小数
    // eslint-disable-next-line no-useless-escape,no-param-reassign
    str = `${parseFloat((`${str}`).replace(/[^\d\.-]/g, '')).toFixed(fix)}`;
    const l = str.split('.')[0].split('').reverse();
    const r = str.split('.')[1];
    let t = '';
    for (let i = 0; i < l.length; i += 1) {
      t += l[i] + ((i + 1) % 3 === 0 && (i + 1) !== l.length ? ',' : '');
    }
    return `${t.split('').reverse().join('')}.${r}`;
  },
  flowsGroup(flows, attr, key = 'day') { // 数据分组处理
    return this.attrSort(flows, attr, -1).reduce((acc, cur) => {
      const lastFlows = acc.slice(-1).flat();
      const lastFlow = lastFlows.slice(-1)[0] || {};
      /* [isoWeek[1-7],week[7-6]] */
      const condition = moment(lastFlow[attr]).isSame(cur[attr], key); // 按照时间进行分组
      if (condition) {
        acc.splice(-1, 1, lastFlows.concat(cur));
        return acc;
      }
      return [...acc, [cur]];
    }, []);
  },
  orderStatusText(value) {
    switch (value) { // 状态0-等待付款，1-已付款，2-已完成，3-已取消，4-申诉中，5-申诉完成
      case 0:
        return '等待付款';
      case 1:
        return '已付款';
      case 2:
        return '已完成';
      case 3:
        return '已取消';
      case 4:
        return '申诉中';
      case 5:
        return '申诉完成';
      default:
        return '---';
    }
  },
  orderTypeText(value) {
    switch (value) { // 0-买，1-卖【这个字段与当前用户是否是卖家相关】，前端取ftypeString字段进行判断
      case 'otc.order.success.type0':
        return '买';
      case 'otc.order.success.type1':
        return '卖';
      default:
        return '---';
    }
  },
  paymentText(id) {
    switch (id) {
      case 0:
        return '银行卡';
      case 1:
        return '支付宝';
      case 2:
        return '微信';
      default:
        return '----';
    }
  },
};

const install = Vue => Object.entries(filters).forEach(([key, func]) => Vue.filter(key, func));

// !!window && window.Vue && install(window.Vue) // auto install

export default {
  filters,
  install,
};
