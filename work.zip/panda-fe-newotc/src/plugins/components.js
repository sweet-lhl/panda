const templateModule = require.context('../components', false, /^(?!index).+\.vue$/);

export const components = templateModule.keys().reduce((acc, key) => { // custom component
  const component = templateModule(key).default;

  return component ? {
    ...acc,
    [component.name.replace(/^\w/, w => w.toUpperCase())]: component,
  } : acc;
}, {});

const templates = { // global component

};

export default {
  install: Vue => Object.entries(templates)
    .forEach(([name, component]) => Vue.component(name, component)),
};
