import os from 'os';
import i18n from '../setup/i18n-setup';
import {
  cookies, http, isPlatform, md5, moment, toast,
} from '../utils/common';
import { typeOf } from '../utils';
import router from '../setup/router-setup';
import {
  decrypt, encrypt, generateIv, generateKey,
} from '../utils/aes_128_cbc';

const packageConf = require('../../package.json');

let isSign;


const xhrDefaultConfig = {
  headers: {
    OS: JSON.stringify({
      platform: os.platform(),
      totalmem: os.totalmem(),
      freemem: os.freemem(),
      endianness: os.endianness(),
      arch: os.arch(),
      tmpdir: os.tmpdir(),
      type: os.type(),
    }),
    'Content-Type': 'application/json;charset=UTF-8',
    'Cache-Control': 'no-cache',
    // 'User-Agent': os.release(),
    DEVICESOURCE: 'web',
    Accept: 'application/json',
  },
  // timeout: 1000,
};

function httpInit(instance) {
  // 请求拦截器中用于判断数据是否存在以及过期 未过期直接返回
  instance.interceptors.request.use(config => ({
    ...config,
    headers: {
      ...xhrDefaultConfig.headers,
      deviceID: md5(`${navigator.userAgent}${cookies.get('token')}`),
      token: cookies.get('token'),
      'X-B3-Traceid': moment().valueOf() * 1000, // Traceid
      'X-B3-Spanid': moment().valueOf() * 1000,
      language: i18n.locale,
      platform: isPlatform(),
      version: packageConf.version,
    },
    transformRequest: [
      // Do whatever you want to transform the data
      (data = {}/* , headers */) => {
        const cryptoKey = generateKey(config.url);
        const cryptoIv = generateIv(cryptoKey);
        // eslint-disable-next-line no-nested-ternary
        return ((
          (config.url.includes('upload') && typeOf(data) === 'object') || isSign || typeOf(isSign) === 'undefined')
          ? Object.entries(data).reduce((acc, cur) => acc.append(...cur) || acc, new FormData())
          : typeOf(data) === 'formData' ? data : encrypt(cryptoKey, cryptoIv, data)
        );
        /* (typeOf(data) === 'object' ? Object.entries(data).reduce((acc, cur) => acc.append(...cur) || acc, new FormData()) : data) */
      },
    ],
  }), (error) => {
    toast(error.message);
    return Promise.reject(error);
  });

  instance.interceptors.response.use((/* response */{ data = {}, headers: { issign }, config: { url } }) => {
    // Do something with response data
    isSign = issign === 'false';

    const cryptoKey = generateKey(url);
    const cryptoIv = generateIv(cryptoKey);

    const newData = isSign ? data : decrypt(cryptoKey, cryptoIv, data);

    if (typeOf(newData) !== 'object') return newData;
    switch (newData?.code) {
      case 400000: // 去登录
        toast('请登录');
        cookies.expire('token');
        router.push('/login'); // 原生登录
        return Promise.reject(new Error(`${newData.code} 登录超时`));
      case 0: // 正常
        return newData.data;
      /* case '100007':
        return data; // 账户已经存在 */
      default:
        try {
          toast(newData.msg || newData.message);
          return Promise.reject(new Error(newData.msg || newData.message));
        } catch (error) {
          return newData;
        }
    }
  }, (error) => {
    const { response = {}, __CANCEL__ } = error;
    if (!__CANCEL__) toast(response.message || response.data.message);
    throw new Error(response);
  });

  return instance;
}

export default typeof Proxy === 'undefined' ? {
  instance: (uri) => {
    const { baseURL = uri, timeout } = xhrDefaultConfig;
    return httpInit(http.create({
      baseURL,
      timeout,
    }));
  },
} : new Proxy(Object.create(null),
  {
    get(target, key) {
      if (key === 'instance') return null;
      const { baseURL = key, timeout } = xhrDefaultConfig;
      return httpInit(http.create({
        baseURL,
        timeout,
      }));
    },
  });
