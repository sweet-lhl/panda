export default [
  /* {
    path: '/test',
    name: 'test',
    component: () => import(/!* webpackChunkName: "test" *!/ './views/Test.vue'),
    meta: { title: '测试' },
  }, */
  {
    path: '/',
    name: 'main',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "main" */ './views/Main.vue'),
    children: [
      {
        path: '',
        name: 'home',
        component: () => import(/* webpackChunkName: "home" */ './views/Home/Index.vue'),
        meta: { title: '首页' },
      },
      {
        path: 'login',
        name: 'login',
        component: () => import(/* webpackChunkName: "login" */ './views/Login.vue'),
        meta: { title: '登录' },
      },
      {
        path: 'assets',
        name: 'assets',
        component: () => import(/* webpackChunkName: "assets" */ './views/Assets/Index.vue'),
        meta: { title: '我的资产' },
      },
      {
        path: 'business/:type',
        name: 'business',
        component: () => import(/* webpackChunkName: "business" */ './views/Business/Index.vue'),
        meta: { title: '一键买卖' },
      },
      {
        path: 'accountSetting',
        name: 'accountSetting',
        component: () => import(/* webpackChunkName: "accountSetting" */ './views/accountSetting/Index.vue'),
        meta: { title: '账户设置' },
        children: [
          {
            path: 'bankCardManagement',
            name: 'bankCardManagement',
            component: () => import(/* webpackChunkName: "bankCardManagement" */ './views/accountSetting/BankCardManagement.vue'),
            meta: { title: '银行卡管理' },
          },
        ],
      },
      {
        path: 'merchant/:type',
        name: 'merchant',
        component: () => import(/* webpackChunkName: "merchant" */ './views/Merchant/Index.vue'),
        meta: { title: 'OTC管理' },
      },
      {
        path: 'merchantList/:type',
        name: 'merchantList',
        component: () => import(/* webpackChunkName: "merchantList" */ './views/MerchantList/Index.vue'),
        meta: { title: 'OTC商家列表' },
      },
      {
        path: 'order',
        name: 'order',
        component: () => import(/* webpackChunkName: "order" */ './views/accountSetting/Index.vue'),
        meta: { title: '订单管理' },
        children: [
          {
            path: '',
            name: 'orderManagement',
            component: () => import(/* webpackChunkName: "orderManagement" */ './views/Order/Tabulation.vue'),
            meta: { title: '订单管理' },
          },
          {
            path: ':id',
            name: 'orderDetails',
            component: () => import(/* webpackChunkName: "orderDetails" */ './views/Order/Details.vue'),
            meta: { title: '订单详情' },
          },
        ],
      },
      {
        name: 'appeal',
        path: 'appeal/:id',
        component: () => import(/* webpackChunkName: "appeal" */ './views/Appeal.vue'),
        meta: { title: '申诉' },
      },
    ],
  },
];
