/* eslint-disable import/no-named-as-default */
import '@babel/polyfill';
import Vue from 'vue';
import Vuetify from 'vuetify';
import App from './App.vue';
import router from './setup/router-setup';
import i18n from './setup/i18n-setup';
import store from './store';
import mixins from './plugins/mixins';
import directive from './plugins/directive';
import eject from './plugins/eject';
import filters from './plugins/filters';
import components from './plugins/components';
import 'vuetify/dist/vuetify.min.css';
import './assets/styleSheet/global.scss';

Vue.mixin(mixins);
Vue.use(directive);
Vue.use(filters);
Vue.use(eject);
Vue.use(components);
Vue.use(Vuetify);

/* eslint-disable no-new */

new Vue({
  el: '#root',
  router,
  store,
  i18n,
  vuetify: new Vuetify(Object.create(null)),
  // components: { App },
  // template: '<App/>', // https://cli.vuejs.org/config/#runtimecompiler
  render: h => h(App),
});
