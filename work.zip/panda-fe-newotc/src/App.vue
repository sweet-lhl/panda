<template>
  <div id="app">
    <router-view/>
<!--    <ServicePaused />-->
  </div>
</template>

<script>
// @ is an alias to /src
// import { components } from './plugins/components';
// import { mapState, mapGetters, mapActions } from './utils/common';
// import ServicePaused from './components/ServicePaused.vue';

export default {
  name: 'app',
  computed: {},
  // components: { ServicePaused },
  watch: {},
  created() {

  },
  methods: {},
};
</script>

<style lang="scss">
  #app {
    height: 100%;
  }

  .app-header + *{
    flex-shrink: 0;
    flex-grow: 1;
  }
</style>
