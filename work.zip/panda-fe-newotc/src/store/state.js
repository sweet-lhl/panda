export default {
  coinPrice: {},
  cancelTimes: 0, // 用户取消次数
  countryList: [], // 国家列表
  tradeCoin: { buy: [], sell: [] }, // 平台支持的OTC交易对列表
  userInfo: {}, // 用户详情
  mqttConf: { // 服务端返回的mqtt配置信息
    isShow: false,
    mqttHost: 'mq.noteScript.app',
    subscriber: '',
    subscriberPwd: '',
    tcpPort: 0,
    topicPrefix: '',
    wsPort: '80',
    wssPort: '443',
  },
};
