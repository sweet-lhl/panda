import api from '../../api/apiModule_1';

/* eslint no-param-reassign: ["error", {
      "props": true,
      "ignorePropertyModificationsFor": ["state"]
    }] */

export default {
  namespaced: true,
  state: {
    realAuth: {},
  },
  mutations: {
    updateRealAuth(state, payload) { state.realAuth = payload; },
  },
  actions: {
    fetchRealAuth({ commit }) {
      return api.checkRealAuth().then(r => commit('updateRealAuth', r));
    },
  },
};
