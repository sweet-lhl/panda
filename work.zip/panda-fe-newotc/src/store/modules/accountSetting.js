import api from '../../api/apiModule_1';

/* eslint no-param-reassign: ["error", {
      "props": true,
      "ignorePropertyModificationsFor": ["state"]
    }] */

export default {
  namespaced: true,
  state: {
    bankList: [], // 银行卡列表
  },
  mutations: {
    updateBankList(state, payload) {
      state.bankList = payload;
    },
  },
  getters: {
    branchData({ bankList }) {
      return (bankList && bankList.filter(({ fpayid }) => fpayid === 1)) || [];
    },
    weChatData({ bankList }) {
      return (bankList && bankList.filter(({ fpayid }) => fpayid === 2)) || [];
    },
    cardData({ bankList }) {
      return (bankList && bankList.filter(({ fpayid }) => fpayid === 0)) || [];
    },
  },
  actions: {
    fetchBankList({ commit }) {
      return api.otcQueryPayment().then(r => commit('updateBankList', r));
    },
  },
};
