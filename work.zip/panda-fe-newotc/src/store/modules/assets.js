import api from '../../api/apiModule_1';

/* eslint no-param-reassign: ["error", {
      "props": true,
      "ignorePropertyModificationsFor": ["state"]
    }] */

export default {
  namespaced: true,
  state: {
    financialAll: { userOtcWallet: [] },
    coinAsset: { },
  },
  mutations: {
    updateFinancialAll(state, payload) {
      state.financialAll = payload;
    },
    updateCoinAsset(state, payload) {
      state.coinAsset = payload;
    },
  },
  actions: {
    fetchFinancialAll({ commit }) {
      api.fetchFinancial().then(r => commit('updateFinancialAll', r));
    },
    fetchCoinAsset({ commit, state: { financialAll } }) {
      const { userOtcWallet } = financialAll;
      const coinId = userOtcWallet.find(({ fcoinName }) => fcoinName === 'USDT')?.coinId;
      if (coinId) api.coinAsset({ coinId }).then(r => commit('updateCoinAsset', r));
    },
  },
};
