import api from '../../api/apiModule_1';
import i18n from '../../setup/i18n-setup';

/* eslint no-param-reassign: ["error", {
      "props": true,
      "ignorePropertyModificationsFor": ["state"]
    }] */

export default {
  namespaced: true,
  state: {
    bannerList: [],
    noticeList: [],
  },
  mutations: {
    updateBannerList(state, payload) {
      state.bannerList = payload;
    },
    updateNoticeList(state, payload) {
      state.noticeList = payload;
    },
  },
  actions: {
    fetchBannerList({ commit }) {
      api.fetchBanner().then(r => commit('updateBannerList', r));
    },
    fetchNoticeList({ commit }) {
      api.zendeskSign(`/api/v2/help_center/${i18n.locale.toLocaleLowerCase()}/articles.json?label_names=landingpage`)
        .then(r => commit('updateNoticeList', JSON.parse(r)?.articles));
    },
  },
};
