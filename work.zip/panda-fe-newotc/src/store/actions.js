import api from '../api/apiModule_1';

export default {
  fetchCoinPrice({ commit }, type = 0) {
    api.otcGetFlashPrice({ type }).then(r => commit('updateCoinPrice', r));
  },
  fetchCancelTimes({ commit }) {
    return api.cancelTimes().then(r => commit('updateCancelTimes', r));
  },
  fetchUserInfo({ commit }) { // 查询用户信息
    return api.userInfo().then(r => commit('updateUserInfo', r));
  },
  clearUserInfo({ commit }) { // 删除用户信息
    commit('updateUserInfo', {});
  },
  fetchTradeCoin({ commit }) {
    return api.getTradeCoinList().then(r => commit('updateTradeCoin', r));
  },
  async updateRatesConf(context) {
    const rateConf = await api.fetchRatesConf();
    context.commit('updateRatesConf', rateConf.list);
  },
};
