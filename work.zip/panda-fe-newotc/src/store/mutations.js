/* eslint no-param-reassign: ["error", {
      "props": true,
      "ignorePropertyModificationsFor": ["state"]
    }] */

export default {// 同步函数，遵循Vue同步规则
  updateCoinPrice(state, payload) {
    state.coinPrice = payload;
  },
  updateCancelTimes(state, times) {
    state.cancelTimes = times;
  },
  updateUserInfo(state, userInfo) { // 更新用户数据
    state.userInfo = userInfo;
  },
  updateTradeCoin(state, payload) { // 更新用户数据
    state.tradeCoin = payload;
  },
  updateCountryList(state, payload) {
    state.countryList = payload;
  },
};
