import { cookies } from '../utils/common';

export default { // 计算属性
  isLogin({ userInfo }) {
    return Boolean(userInfo.floginname && cookies.get('token'));
  },
};
