// time stamp
import { moment, calc } from '../utils/common';

const filters = {
  timeStampToDate(timeStamp, reg = 'YYYY.MM.DD HH:mm:ss') { // 时间戳转时间
    if (!timeStamp) return '...';
    return moment(timeStamp).format(reg);
  },
  timeDuration(start, end, key) { // 时间周期，支持单独获取一个key的时间周期
    const momentDiff = moment(start).diff(moment(end), key, true);
    const timeDuration = moment.duration(momentDiff);
    return key ? momentDiff : {
      years: timeDuration.get('years'),
      months: timeDuration.get('months'),
      weeks: timeDuration.get('weeks'),
      days: timeDuration.get('days'),
      hours: timeDuration.get('hours'),
      minutes: timeDuration.get('minutes'),
      seconds: timeDuration.get('seconds'),
      milliseconds: timeDuration.get('milliseconds'),
    };
  },
  attrSort(array, attr, rev = 1) { // 数组排序，支持对象key键值排序
  /* eslint no-nested-ternary: 0 */
    return array.sort((a, b) => {
      const [old, cur] = [
        a.constructor === Object ? a[attr] : a,
        b.constructor === Object ? b[attr] : b,
      ];
      return (old - cur) * rev;
    });
  },
  getFullNum(num) {
    // 处理非数字
    // eslint-disable-next-line no-restricted-globals
    if (isNaN(num)) { return num; }
    // 处理不需要转换的数字
    const str = `${num}`;
    if (!/e/i.test(str)) { return num; }

    return (num).toFixed(18).replace(/\.?0+$/, '');
  },
  toFixed(amount = 0, fix = 5) { // 保留小数
    const fixNum = Number(fix);
    // eslint-disable-next-line radix
    if (fixNum === 0) return parseInt(amount);
    const amountArr = String(filters.getFullNum(amount)).split('.');
    const newAmount = amountArr.length > 1 ? `0.${amountArr[1].substr(0, fixNum)}` : amount;
    const isPlus = amountArr.length > 1 && amountArr[0] === '-0' ? '-' : '';
    const data = fixNum ? Number(newAmount).toFixed(fixNum + 1).slice(0, -1) : Number(newAmount);
    return amountArr.length > 1 ? `${isPlus}${Number(amountArr[0])}.${String(data).split('.')[1]}` : data;
  },

  toFixedSize(amount = 0, fix = 5) { // 0.001保留小数
    const fixNum = filters.accuracyDigit(fix);
    // eslint-disable-next-line radix
    if (fixNum === 0) return parseInt(amount);
    const amountArr = String(filters.getFullNum(amount)).split('.');
    const newAmount = amountArr.length > 1 ? `0.${amountArr[1].substr(0, fixNum)}` : amount;
    const isPlus = amountArr.length > 1 && amountArr[0] === '-0' ? '-' : '';
    const data = fixNum ? Number(newAmount).toFixed(fixNum + 1).slice(0, -1) : Number(newAmount);
    return amountArr.length > 1 ? `${isPlus}${Number(amountArr[0])}.${data.split('.')[1]}` : data;
  },
  accuracyDigit(value) {
    const y = String(value).indexOf('.') + 1;// 获取小数点的位置
    const count = String(value).length - y;// 获取小数点后的个数
    return y > 0 ? count : 0;
  },
  percent(value) { // 转化百分号
    return filters.toFixed(calc(`${value || 0} 100 *`), 2);
  },
  strIntercept(str, length = 3) { // 过滤中间信息，不予展示
    const newStr = String(str);
    const prefix = newStr.match(new RegExp(`^[\\s\\S]{${length}}`));
    const suffix = newStr.match(new RegExp(`[\\s\\S]{${length}}$`));
    return `${prefix}****${suffix}`;
  },
  flowsGroup(flows, attr, key = 'day') { // 数据分组处理
    return this.attrSort(flows, attr, -1).reduce((acc, cur) => {
      const lastFlows = acc.slice(-1).flat();
      const lastFlow = lastFlows.slice(-1)[0] || {};
      /* [isoWeek[1-7],week[7-6]] */
      const condition = moment(lastFlow[attr]).isSame(cur[attr], key); // 按照时间进行分组
      if (condition) {
        acc.splice(-1, 1, lastFlows.concat(cur));
        return acc;
      }
      return [...acc, [cur]];
    }, []);
  },
  typeSide(status) {
    switch (status) {
      case 'BUY_OPEN':
        return '买入开多';
      case 'BUY_CLOSE':
        return '买入平空';
      case 'SELL_OPEN':
        return '卖出开空';
      case 'SELL_CLOSE':
        return '卖出平多';
      default:
        return '---';
    }
  },
};

const install = Vue => Object.entries(filters).forEach(([key, func]) => Vue.filter(key, func));

// !!window && window.Vue && install(window.Vue) // auto install

export default {
  filters,
  install,
};
