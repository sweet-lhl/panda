import os from 'os';
import i18n from '../setup/i18n-setup';
import {
  http, cookies, toast, md5, moment, isPlatform,
} from '../utils/common';
import {
  encrypt, decrypt, generateKey, generateIv,
} from '../utils/aes_128_cbc';
import { typeOf } from '../utils';
import Bridge from '../utils/bridge';

let isSigned = false; // 是否支持接口签名
// const isRefresh = true; // 是否需要缓存
const packageInfo = require('../../package');

let fastStart = true;

const xhrDefaultConfig = {
  headers: {
    OS: JSON.stringify({
      platform: os.platform(),
      totalmem: os.totalmem(),
      freemem: os.freemem(),
      endianness: os.endianness(),
      arch: os.arch(),
      tmpdir: os.tmpdir(),
      type: os.type(),
    }),
    'Content-Type': 'application/json;charset=UTF-8',
    'Cache-Control': 'no-cache',
    // 'User-Agent': os.release(),
    DEVICESOURCE: 'web',
    Accept: 'application/json',
  },
  // timeout: 1000,
};

function httpInit(instance) {
  instance.interceptors.request.use(config => ({
    ...config,
    headers: {
      ...xhrDefaultConfig.headers,
      deviceID: md5(`${navigator.userAgent}${cookies.get('token')}`),
      token: cookies.get('token') || 'BCACCOUNT_LOGIN_6fea65865d228068370b13a8413a1008_001E65847ECE4906966FA68C4015D054',
      'X-B3-Traceid': moment().valueOf() * 1000, // Traceid
      'X-B3-Spanid': moment().valueOf() * 1000,
      Language: i18n.locale,
      platform: isPlatform(), // 平台来源
      version: packageInfo.version, // 版本
    },
    transformRequest: [
      (data = {}/* , headers */) => {
        if (isSigned || typeOf(isSigned) === 'undefined') {
          return typeOf(data) === 'object'
            ? Object.entries(data).reduce((acc, cur) => acc.append(...cur) || acc, new FormData())
            : data;
        }
        const cryptoKey = generateKey(config.url);
        const cryptoIv = generateIv(cryptoKey);
        return typeOf(data) === 'formData' ? data : encrypt(cryptoKey, cryptoIv, data);
      },
    ],
  }), (error) => {
    toast(error.message);
    return Promise.reject(error);
  });

  instance.interceptors.response.use((/* response */{ data = {}, headers: { issign }, config: { url } }) => {
    isSigned = issign === 'false';
    const cryptoKey = generateKey(url);
    const cryptoIv = generateIv(cryptoKey);

    const newData = isSigned ? data : decrypt(cryptoKey, cryptoIv, data);
    if (typeOf(newData) !== 'object') return newData;
    switch (newData?.code) {
      case 100000: // 去登录
        toast('请登录');
        cookies.expire('token');
        return Promise.reject(new Error(`${newData.code} 登录超时`));
      case 0: // 正常
        return newData.data;
      /* case '100007':
        return data; // 账户已经存在 */
      case 400000: // 登录已失效，请重新登录
        toast(newData.msg || newData.message);
        if (fastStart) { // 解决安卓多次提示返回
          Bridge.callHandler('JS2NativeInteraction', { rel: 'interaction_requestLogin' });
          fastStart = false;
        }
        return Promise.reject(new Error(newData.msg || newData.message));
      default:
        try {
          toast(newData.msg || newData.message, 'error');
          return Promise.reject(new Error(newData.msg));
        } catch (error) {
          return newData;
        }
    }
  }, (error) => {
    const { response, __CANCEL__ } = error;
    if (!__CANCEL__) toast(response?.message || response?.data?.message);
    throw new Error(response);
  });

  return instance;
}

export default typeof Proxy === 'undefined' ? {
  instance: (uri) => {
    const { baseURL = uri, timeout } = xhrDefaultConfig;
    return httpInit(http.create({
      baseURL,
      timeout,
    }));
  },
} : new Proxy(Object.create(null),
  {
    get(target, key) {
      if (key === 'instance') return null;
      const { baseURL = key, timeout } = xhrDefaultConfig;
      return httpInit(http.create({
        baseURL,
        timeout,
      }));
    },
  });
