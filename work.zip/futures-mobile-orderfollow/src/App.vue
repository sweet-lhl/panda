<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
import { mapActions } from './utils/common';

export default {
  name: 'app',
  methods: {
    ...mapActions(['fetchUserInfo', 'fetchCoinList']),
  },
  created() {
    this.fetchUserInfo();
    this.fetchCoinList();
  },
};
</script>

<style lang="scss">
  #app {
    height: 100%;
  }
</style>
