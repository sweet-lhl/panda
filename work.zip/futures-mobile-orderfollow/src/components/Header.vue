<template>
  <header class="flex-align-items-center flex-justify-content-space-between header">
    <div class="flex-direction-row flex-align-items-center header-left" @click.stop="goBack">
      <svg class="icon header-back" aria-hidden="true">
        <use xlink:href="#iconfanhui1"></use>
      </svg>
      <p class="text-size-20 text-weight-6">{{title}}</p>
    </div>
    <slot name="right"></slot>
  </header>
</template>

<script>
export default {
  name: 'header',
  props: {
    backNative: { type: Boolean, default: false },
  },
  computed: {
    title() {
      return this.$route.meta.title;
    },
    isBack() {
      const { length = window.history.length } = this.$route;
      return length > 1;
    },
  },
  methods: {
    goBack() {
      if (this.backNative) {
        this.$emit('intercept');
        return;
      }
      if (this.isBack) this.$router.back();
    },
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">

  #headers {
    background: #e67a16;
    height: 42px;
    padding: 0 32px;
    overflow: hidden;
  }

  .c-1 {
    width: 25px;
  }

  .c-2 {
    flex-grow: 1;
  }

  .c-1-1, .c-2-1 {
    font-size: 18.8px;
    color: rgba(255, 255, 255, 1);
  }

  .c-2-1 {
    font-weight: initial;
    letter-spacing: 4.666px;
  }

  .header {
    height: 48px;
    font-size: 20px;
    font-weight: 500;
    padding: 0 15px;
    background: #ffffff;

    .header-left {
      height: 48px;
    }

    .header-overlay {
      background-color: rgba(0, 0, 0, .6);
    }

    .header-list {
      border-radius: 4px !important;
      top: 30px;
      right: 15px;
      width: 138px;
      height: 89px;
      background: rgba(255,255,255,1);
      box-shadow: 0 2px 8px 0 rgba(0,0,0,0.05);
      padding-left: 0;
      list-style: none;
      text-align: right;
      font-size: 14px;
      color: #2D2D2D;
      z-index: 3000;

      li {
        height: 44px;
        line-height: 44px;
        padding: 0 20px;
        border-radius: 4px;

        &:first-child {
          border: 1px solid #F9FAF9;
        }
      }
    }
  }

</style>
