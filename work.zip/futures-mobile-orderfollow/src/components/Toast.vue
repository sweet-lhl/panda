<template>
    <div class="flex-justify-content-center" :class="isShow&&'el-drawer__open'">
      <div class="flex-align-items-center home-toast ltr"
           :style="{backgroundColor:current.color,color:type==='info'?'#878787':'white'}">
        <svg class="icon toast-icon" aria-hidden="true">
          <use :xlink:href="current.icon"></use>
        </svg>
        <div class="text-size-14 text-toast">{{msg}}</div>
      </div>
    </div>
</template>

<script>
import event from '../utils/eventEmitter';

const DELAY = 1.5; // S

export default {
  name: 'toast',
  data() {
    return {
      isShow: false,
      msg: '',
      type: null,
      duration: null,
      callBack: null,
    };
  },
  computed: {
    current() {
      const { type } = this;
      switch (type) {
        case 'success':
          return { color: '#1cc561', icon: '#iconchenggong' };
        case 'info':
          return { color: '#ffffff', icon: '#icontishi1' };
        case 'error':
          return { color: '#D03F56', icon: '#icontishi' };
        default:
          return { };
      }
    },
  },
  watch: {
    isShow(n, o) {
      if (n !== o && n) {
        const timer = setTimeout(() => {
          if (typeof this.callBack === 'function') this.$nextTick(this.callBack);
          this.isShow = false;
          this.handelDestroy();
          return clearTimeout(timer);
        }, (this.duration || DELAY) * 1000);
      }
    },
  },
  beforeCreate() {
    event.on('toast', (response) => {
      if (!response) return;
      const params = typeof response === 'string' ? {
        msg: response,
        type: 'error',
        duration: null,
        callBack: null,
      } : response;
      this.setContent(params);
    });
  },
  beforeDestroy() {
    this.handelDestroy();
  },
  methods: {
    setContent({
      msg, type, duration, callBack,
    }) {
      [this.msg, this.type, this.duration, this.callBack] = [msg, type, duration, callBack];
      this.$nextTick(() => { this.isShow = true; });
    },
    handelDestroy() {
      [this.type, this.duration, this.callBack] = [null, null, null];
    },
  },
};
</script>

<style scoped lang="scss">
  .home-toast {
    position: fixed;
    z-index: 3000;
    width: 96%;
    min-height: 45px;
    border-radius: 6px;
    font-size: 14px;
    line-height: 45px;
    padding: 0 17px;
    box-shadow:0 2px 12px 0 rgba(0,0,0,0.08);
  }

  .toast-icon {
    width: 22px;
    height: 22px;
    margin-right: 10px;
  }
  .el-drawer__open .ltr {
    -webkit-animation: ltr-drawer-in .5s cubic-bezier(0,0,.2,1) .5s;
    animation: ltr-drawer-in .5s cubic-bezier(0,0,.2,1) .5s;
    transition: all .5s ease-in;
    top: 10px;
  }
  .ltr {
    -webkit-animation: ltr-drawer-out .5s cubic-bezier(0,0,.2,1) .5s;
    animation: ltr-drawer-out .5s cubic-bezier(0,0,.2,1) .5s;
    transition: all .5s ease-out;
    top: -120px;
  }
  .text-toast{
    padding: 12px 0;
    width: 90%;
    line-height: 1.5;
    text-align: justify;
  }
</style>
