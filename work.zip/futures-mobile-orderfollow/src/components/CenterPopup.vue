<template>
  <van-dialog v-model="safe"
              width="320px"
              :show-confirm-button="false">
    <div class="CenterPopup">
      <div class="flex-box justify-between items-center Center-popup-title">
        <div class="font-size-16" v-text="tips.title">提示</div>
        <!--<van-icon name="cross" @click.native="cancel"/>-->
      </div>
      <div class="Center-popup-cont">
        <slot name="content"></slot>
      </div>
      <div class="flex-align-items-center flex-auto margin-top-6">

        <div class="text-align-center cross font-size-14" @click="cancel" v-text="tips.cancel"></div>
        <div class="text-align-center border-left font-size-14 confirm"
             @click.stop="submission"
             :class="{disabled:agree}"
             v-text="tips.subText"
        >确认授权</div>
      </div>
    </div>
  </van-dialog>
</template>

<script>
export default {
  name: 'CenterPopup',
  props: {
    submission: {
      type: Function,
    },
    cancel: {
      type: Function,
    },
    agree: {// 确定按钮颜色
      type: Boolean,
      default: false,
    },
    safe: {// 频繁切换弹框
      type: Boolean,
      default: false,
    },
    tips: {
      type: Object,
      default: () => ({
        title: '提示',
        cancel: '',
        subText: '确认授权',
      }),
    },
  },
  /* data() {
    return {
      isShow: false,
    };
  },
  watch: {
    safe() {
      this.isShow = this.safe;
    },
  }, */
};
</script>

<style scoped lang="scss">
  .van-icon-cross:before{
    font-size: 14px;
  }
.CenterPopup{
  padding: 20px 20px 8px 20px;
  width: 100%;
  font-family: PingFangSC-Medium;
  color: #41414C;
}
  .Center-popup-title{
   padding-bottom: 15px;
    border-bottom: 1px solid #EEEEEE;
  }
  .Center-popup-cont{
    padding: 22px 0;
    font-family: PingFangSC-Regular;
    line-height: 30px;
    font-size: 16px;
    border-bottom: 1px solid #EEEEEE;
  }
  .border-left{
    border-left: 1px solid #EEEEEE;
  }
  .cross{
    color: #41414C;
    opacity: .6;
  }
  .font-size-14{
    font-size: 14px;
  }

  .font-size-16{
    font-weight: 600;
    font-size: 16px;
  }
  .justify-end>*{
    margin-left: 30px;
    margin-top: 40px;
    margin-bottom: 10px;
  }
  .confirm{
    font-family:PingFangSC-Medium,PingFang SC;
    color: #1CC561;
    line-height: 32px;
  }
  ::v-deep .van-dialog{
    border-radius:4px;
  }
  .disabled{
    color: #C2C2C2;
  }
</style>
