<template>
  <div class="flex-justify-content-center" :class="isShow&&'el-drawer__open'">
    <div class="home-confirm ltr">
      <div class="flex-direction-row flex-align-items-center" v-if="msg">
        <svg class="icon confirm-icon" aria-hidden="true">
          <use xlink:href="#icontishi"></use>
        </svg>
        <p class="text-size-14">{{msg}}</p>
      </div>
      <div class="flex-justify-content-flex-end" v-if="msg">
        <span class="cancel text-size-12" @click="submit">{{submitText}}<!--一键取消--></span>
      </div>
    </div>
  </div>
</template>

<script>
import event from '../utils/eventEmitter';

const DELAY = 2; // S

export default {
  name: 'confirm',
  data() {
    return {
      isShow: false,
      msg: '',
      callBack: null,
      submitText: '确认',
    };
  },
  watch: {
    isShow(n, o) {
      if (n !== o && n) {
        const timer = setTimeout(() => {
          // if (!this.callBack) this.isShow = false;
          this.isShow = false;
          return clearTimeout(timer);
        }, DELAY * 1000);
      }
    },
  },
  beforeCreate() {
    event.on('confirm', (response) => {
      if (!response) return;
      const params = typeof response === 'string' ? {
        msg: response,
        submitText: '',
        callBack: null,
      } : response;
      this.setContent(params);
    });
  },
  beforeDestroy() {
    [this.msg, this.callBack] = ['', null];
  },
  methods: {
    setContent({ msg, submitText, callBack }) {
      [this.msg, this.submitText, this.callBack] = [msg, submitText, callBack];
      this.$nextTick(() => { this.isShow = true; });
    },
    submit() {
      this.$nextTick(this.callBack);
      this.isShow = false;
    },
  },
};
</script>

<style scoped lang="scss">
  .home-confirm {
    top: -200px;
    position: fixed;
    z-index: 3000;
    width: 96%;
    margin: auto;
    min-height: 45px;
    border-radius: 6px;
    background-color: #D03F56;
    color: white;
    font-size: 14px;
    padding: 0 17px;
    &>*:first-child{
      line-height: 45px;
    }
  }
  .el-drawer__open .ltr {
    -webkit-animation: ltr-drawer-in .5s cubic-bezier(0,0,.2,1) .5s;
    animation: ltr-drawer-in .5s cubic-bezier(0,0,.2,1) .5s;
    transition: all .5s ease-in;
    top: 10px;
  }
  .ltr {
    -webkit-animation: ltr-drawer-out 225ms cubic-bezier(0,0,.1,1) .5s;
    animation: ltr-drawer-out 225ms cubic-bezier(0,0,.1,1) .5s;
    transition: all .5s ease-out;
    top: -85px;
  }
  .confirm-icon {
    width: 22px;
    height: 22px;
    margin-right: 10px;
  }
  .cancel{
    padding: 5px 10px;
    color: #FFFFFF;
    background:rgba(182,48,69,1);
    border-radius:12px;
    margin-bottom: 15px;
  }
</style>
