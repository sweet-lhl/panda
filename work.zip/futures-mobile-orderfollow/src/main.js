import '@babel/polyfill';
import Vue from 'vue';
import Vant from 'vant';
import App from './App.vue';
import router from './setup/router-setup';
import i18n from './setup/i18n-setup';
import store from './store';
import vueConfig from './plugins/vueConfig';
import mixins from './plugins/mixins';
import directive from './plugins/directive';
import eject from './plugins/eject';
import filters from './plugins/filters';
import scroll from './components/Scroll.vue';
// eslint-disable-next-line import/no-named-as-default
import components from './plugins/components';
// import jockey from './utils/jockey';
import './assets/styleSheet/global.css';
import 'vant/lib/index.css';
import './assets/styleSheet/common.css';

Vue.component('scroll', scroll);
Vue.use(Vant);
Vue.use(vueConfig);
Vue.mixin(mixins);
Vue.use(directive);
Vue.use(filters);
Vue.use(eject);
Vue.use(components);

/* eslint-disable no-new */

new Vue({
  el: '#root',
  router,
  store,
  i18n,
  // components: { App },
  // template: '<App/>', // https://cli.vuejs.org/config/#runtimecompiler
  render: h => h(App),
});
