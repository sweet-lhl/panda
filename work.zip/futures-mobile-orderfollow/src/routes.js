export default [
  /* {
    path: '/test',
    name: 'test',
    component: () => import(/!* webpackChunkName: "test" *!/ './views/Test.vue'),
    meta: { title: '测试' },
  }, */
  {
    path: '/',
    name: 'main',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "main" */ './views/Main.vue'),
    children: [
      { // 合约带单
        path: '',
        name: 'contractTape',
        component: () => import(/* webpackChunkName: "home" */ './views/ContractTape/Index.vue'),
        children: [
          { // 合约带单首页
            path: '',
            name: 'contractTape',
            component: () => import(/* webpackChunkName: "home" */ './views/ContractTape/ContractTapeHome.vue'),
            meta: { title: '社区跟单' },
          },
          { // 合约带单详情
            path: 'contractTapeDetails',
            name: 'contractTapeDetails',
            component: () => import(/* webpackChunkName: "home" */ './views/ContractTape/ContractTapeDetails.vue'),
            meta: { title: '返回' },
          },
          { // 合约带单管理
            path: 'contractTapeManagement',
            name: 'contractTapeManagement',
            component: () => import(/* webpackChunkName: "home" */ './views/ContractTape/ContractTapeManagement.vue'),
            meta: { title: '带单管理' },
          },
          { // 合约带单设置
            path: 'contractTapeSetUp',
            name: 'contractTapeSetUp',
            component: () => import(/* webpackChunkName: "home" */ './views/ContractTape/ContractTapeSetUp.vue'),
            meta: { title: '带单设置' },
          },
          { // 合约标签设置
            path: 'contractTapeLabel',
            name: 'contractTapeLabel',
            component: () => import(/* webpackChunkName: "home" */ './views/ContractTape/ContractTapeLabel.vue'),
            meta: { title: '标签设置' },
          },
          { // 带单详情
            path: 'contractOrderDetails',
            name: 'contractOrderDetails',
            component: () => import(/* webpackChunkName: "home" */ './views/ContractTape/ContractOrderDetails.vue'),
            meta: { title: '带单详情' },
          },
          { // 跟随者持仓
            path: 'contractTapeFollower',
            name: 'contractTapeFollower',
            component: () => import(/* webpackChunkName: "home" */ './views/ContractTape/ContractTapeFollower.vue'),
            meta: { title: '跟随者持仓' },
          },
        ],
      },
      { // 合约带单首页
        path: 'Administration',
        name: 'Administration',
        component: () => import(/* webpackChunkName: "home" */ './views/Administration/Index.vue'),
        meta: { title: '跟单管理' },
      }, { // 合约带单首页
        path: 'SettingsEdit',
        name: 'SettingsEdit',
        component: () => import(/* webpackChunkName: "home" */ './views/Administration/SettingsEdit.vue'),
        meta: { title: '跟单设置' },
      },
    ],
  },
];
