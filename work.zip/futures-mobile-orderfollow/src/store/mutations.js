/* eslint no-param-reassign: ["error", {
      "props": true,
      "ignorePropertyModificationsFor": ["state"]
    }] */

export default {// 同步函数，遵循Vue同步规则
  updateMqttConfig(state, config) {
    state.mqttConf = config;
  },
  updateCountryList(state, payload) {
    state.countryList = payload;
  },
  updateUserInfo(state, payload) { // 更新用户信息
    state.userInfo = payload;
  },
  updateCoinList(state, payload) { // 更新币种精度
    state.coinList = payload;
  },
};
