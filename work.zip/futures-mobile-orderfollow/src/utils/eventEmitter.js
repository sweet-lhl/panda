import EventEmitter from 'events';

export default new class extends EventEmitter {}();
