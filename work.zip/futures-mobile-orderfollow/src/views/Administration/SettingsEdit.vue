<template>
  <div class="Administration">
    <Header>
      <span v-if="edit" slot="right" class="text-size-14 right-red text-weight-6" @click="show=true">取消跟单</span>
    </Header>
    <div v-if="loading" class="loading flex-auto ">
      <van-loading class="flex-justify-content-center flex-align-items-center" type="spinner" color="#1989fa"/>
    </div>
    <div class="mustBox overflow-y">
      <div class="padding-left-15 padding-right-15 border-top-line border-bottom-line">
        <div class="flex-align-items-center flex-justify-content-space-between border-bottom-1 list">
          <div class="left-grey">跟随</div>
          <div class="right-black" v-text="followInList.tradeUserNickName||name">王二麻</div>
        </div>
        <div class="flex-align-items-center flex-justify-content-space-between border-bottom-1 list">
          <div class="left-grey">跟随币种</div>
          <div class="right-black">USDT</div>
        </div>
        <div class="flex-align-items-center flex-justify-content-space-between border-bottom-1 list">
          <div class="left-grey">跟单合约</div>
          <div class="right-black">USDT保证金合约</div>
        </div>
        <div class="flex-align-items-center flex-justify-content-space-between border-bottom-1 list">
          <div class="left-grey">跟单方式</div>
          <div class="right-black">
            <van-button :type="form.type===1?'primary':'default'" size="small" @click="form.type=1">固定张数</van-button>
            <span class="margin-left-10">
              <van-button :type="form.type===2?'primary':'default'" size="small" @click="form.type=2">比例跟单</van-button>
            </span>
          </div>
        </div>

        <div class="list border-bottom-1">
          <div class="flex-align-items-center flex-justify-content-space-between">
            <div class="left-grey">跟单{{form.type===1?'张数':'比例'}}</div>
            <van-stepper
              v-model="form.numberOrRatio"
              :max="form.type===1?config.followerSingleFixedMaximum:2"
              :min="form.type===1?1:0.01"
              input-width="77px"
              button-size="36px"
              :step="form.type===1?1:0.01"
              :decimal-length="form.type===1?0:2"
              :integer="form.type===1"/>
          </div>
          <p class="text-grey-p">{{form.type===1?'例如您设置的跟单数量为2张，交易员下单时，您都将跟单下单2张。':'设置的跟单比例是2，交易员下单1张合约时，将跟单下单2张。'}}</p>
        </div>
        <div class="list">
          <div class="flex-align-items-center flex-justify-content-space-between">
            <div class="left-grey">跟单总金额</div>
            <van-stepper
              v-model="form.maxAmount"
              :min="config.followersMinimum"
              :max="config.followersLargest"
              input-width="77px"
              button-size="36px"
              integer/>
          </div>
          <p class="text-grey-p">跟随本金达到此数值后，将不再跟随下单，最大为 {{form.maxAmount}}USDT。</p>
        </div>

      </div>
      <van-collapse v-model="activeNames" :border="false">
        <van-collapse-item title="高级设置" name="1">
          <div class="list border-bottom-1">
            <div class="flex-align-items-center flex-justify-content-space-between">
              <div class="left-grey">止盈比例</div>
              <div class="position-relative van-stepper">
               <!-- <van-stepper class="percent"
                             :class="{default:!form.stopProfit}"
                             text-percent="%" v-model="form.stopProfit"
                             min="1" input-width="77px"
                             button-size="36px" default-text="不限"
                             default-value="不限"
                             />-->
                <p class="btm van-stepper__minus" @click="form.stopProfit=form.stopProfit>1?form.stopProfit-1:1">-</p>
                <van-field
                  class="setup-stop-input van-stepper__input"
                  v-model="form.stopProfit"
                  type="number"
                  input-align="center"
                  placeholder="不限"
                >
                  <template #right-icon>%</template>
                </van-field>
                <p class="btm van-stepper__plus" @click="form.stopProfit=Number(form.stopProfit)+1">+</p>
              </div>
            </div>
            <p class="text-grey-p">盈利超过 {{form.stopProfit || '--'}}%，停止跟单并自动平仓</p>
          </div>
          <div class="list border-bottom-1">
            <div class="flex-align-items-center flex-justify-content-space-between">
              <div class="left-grey">止损比例</div>
              <div class="position-relative van-stepper">
             <!--   <van-stepper class="percent"
                             :class="{default:!form.stopLoss}"
                             text-percent="%" v-model="form.stopLoss"
                             max="80" min="20" input-width="77px"
                             button-size="36px" default-text="不限"
                             default-value="不限"
                             integer/>-->
                <p class="btm van-stepper__minus" @click="form.stopLoss=form.stopLoss>20?form.stopLoss-1:20">-</p>
                <van-field
                  class="setup-stop-input van-stepper__input"
                  v-model="form.stopLoss"
                  @blur="stopLossBlur"
                  type="number"
                  input-align="center"
                  placeholder="不限"
                >
                  <template #right-icon>%</template>
                </van-field>
                <p class="btm van-stepper__plus" @click="form.stopLoss=form.stopLoss>20?Number(form.stopLoss)+1:20">+</p>
              </div>

            </div>
            <p class="text-grey-p">亏损超过 {{form.stopLoss || '--'}}%，停止跟单并自动平仓</p>
          </div>
        </van-collapse-item>
      </van-collapse>
      <div class="padding-left-15 padding-right-15 follow-now">
        <van-button type="primary" size="large" @click="determine">{{type}}<!--立即跟随--></van-button>
      </div>
    </div>

    <CenterPopup
      :cancel="cancel"
      :safe="show"
      :tips="{
        title: '提示:',
        cancel: '再想想',
        subText: '确定',
      }"
      :submission="fetchDelete">
      <div slot="content" class="items-center font-size-16">
        <p class="opacity-6 text-align-justify font-size-14">停止跟随后将不再跟随交易员下单，交易员将不再出现在跟单列表中，已跟随开仓的订单，也将不再跟随交易员策略平仓。</p>
      </div>
    </CenterPopup>

    <CenterPopup
      :cancel="cancel"
      :safe="showAgreement"
      :tips="{
        title: '跟单协议:',
        cancel: '再考虑一下',
        subText: '我已了解',
      }"
      :agree="!result"
      :submission="()=>{perfectHandle('agreementTreaty')}">
      <div slot="content" class="items-center text-size-12 line-height-2">
          <p class="opacity-6 text-align-justify text-indent">
            跟随交易员或平台其他投资者下单，可能存在亏损风险，在风险控制不当的情况下可能会整个账户全部亏损。亏损风险由您独自承担，请知晓跟单风险。</p>
          <p class="opacity-6 text-align-justify text-indent">
            确认跟随后，您可在我的跟单管理中随时调整您的跟单策略，也可以随时停止跟单。跟随下单后，您可以随时管理自己的订单，包括平仓、止盈止损等。请知悉您的权益。</p>
          <p class="opacity-6 text-align-justify text-indent">确认跟随后，跟随开仓的订单若产生盈利，将抽取X
            %的净收益作为交易员奖励。注意，无论订单是由您自主平仓或是跟随平仓，皆会发生订单利润分成。如交易员当前已持有仓位，将不胡跟随已开仓位的操作，单交易员完全平仓后开始跟随。</p>
          <van-checkbox v-model="result"
                        class="margin-top-6 margin-bottom-6"
                        icon-size="16px"
                        shape="square"
                        checked-color="#27C08B">我已知晓
          </van-checkbox>
      </div>
    </CenterPopup>


    <CenterPopup
      :cancel="cancel"
      :safe="showNickName"
      :tips="{
        title: '请设置社区昵称:',
        cancel: '取消',
        subText: '确认',
      }"
      :agree="!nickName"
      :submission="()=>{perfectHandle('setNickName')}">
      <div slot="content" class="items-center">
        <p class="text-size-12 header-title">昵称</p>
        <van-field
          class="setup-popup-input"
          v-model="nickName"
          minlength="2"
          maxlength="12"
          placeholder="请输入您的昵称"
          clearable
        />
        <p class="margin-top-5 text-size-12 setup-popup-desc">请设置跟单昵称，填写后不支持修改，请悉知</p>
      </div>
    </CenterPopup>
  </div>
</template>

<script>
import { components } from '../../plugins/components';
import api from '../../api/apiModule_1';
import { Regex } from '../../utils/constant';
import { mapState, mapActions } from '../../utils/common';

const { Header, CenterPopup } = components;
export default {
  name: 'SettingsEdit',
  data() {
    return {
      value: 1,
      show: false,
      showAgreement: false,
      showNickName: false,
      result: false,
      activeNames: [],
      followInList: '',
      config: '',
      edit: '',
      loading: false,
      nickName: '',
      form: {
        tradeUserId: '',
        type: 1, // 类型：1-固定张数、2-比例跟单
        numberOrRatio: 1, // 张数或比例
        maxAmount: 1, // 金额
        stopProfit: '', // 止盈比例
        stopLoss: '', // 止盈比例
      },
    };
  },
  components: { Header, CenterPopup },
  computed: {
    ...mapState(['userInfo']),
    type() {
      return this.edit ? '保存' : '立即跟随';
    },
    name() {
      return this.$route.params.nickName;
    },
  },
  created() {
    this.form.tradeUserId = this.$route.query.tradeUserId;
    this.edit = this.$route.query.edit;
    this.$route.meta.title = this.edit ? '编辑跟单' : '跟单设置';
    // eslint-disable-next-line no-unused-expressions
    this.edit && this.followInfoHandle();
    this.configHandle();
  },
  watch: {
    'form.maxAmount': {
      handler(n) {
        const { followersLargest, followersMinimum } = this.config;
        if (n > followersLargest) this.form.maxAmount = followersLargest;
        if (n < followersMinimum) this.form.maxAmount = followersMinimum;
      },
      deep: true,
      immediate: true,
    },
    'form.stopProfit': {
      handler(n) {
        if (n && n < 0) this.form.stopProfit = 1;
      },
      deep: true,
      immediate: true,
    },
  },
  methods: {
    ...mapActions(['fetchUserInfo']),
    stopLossBlur() {
      const { stopLoss } = this.form;
      if (stopLoss && stopLoss > 80) this.form.stopLoss = 80;
      if (stopLoss && stopLoss < 20) this.form.stopLoss = 20;
    },
    followInfoHandle() {
      const { tradeUserId } = this.form;
      this.loading = true;
      api.followInfo({ tradeUserId }).then((data) => {
        this.followInList = data;
        this.form.type = data.withType;
        this.form.numberOrRatio = data.withAmount || 1;
        this.form.maxAmount = data.maxAmount || 1;
        this.form.stopProfit = (data.profitPercent * 100 || '');
        this.form.stopLoss = (data.lossPercent * 100) || '';
        this.loading = false;
      }).catch(() => {
        this.loading = false;
      });
    },
    configHandle() {
      api.getConfigParms().then((data) => {
        this.config = data;
      });
    },
    perfectHandle(isApi) { // setNickName => 设置昵称 agreementTreaty => 同意跟单协议
      const { nickName: nickeName } = this;
      if (isApi === 'setNickName' && nickeName.length < 2) {
        this.$toast('请输入2-12位社区昵称');
        return;
      }
      if (isApi === 'setNickName' && nickeName && Regex.HAS_SPACE.test(nickeName)) {
        this.$toast('昵称不能空或不能包含空格');
        return;
      }
      const data = isApi === 'setNickName' ? { nickeName } : {};
      api[isApi](data).then(() => {
        this.fetchUserInfo();
        this.cancel();
      });
    },
    determine() {
      const { followOrderTreaty, nickName } = this.userInfo;
      const {
        tradeUserId, type, numberOrRatio, maxAmount, stopProfit, stopLoss,
      } = this.form;

      if (!nickName) { // 开启昵称
        this.showNickName = true;
        return;
      }
      if (!followOrderTreaty) { // 开启协议
        this.showAgreement = true;
        return;
      }
      this.loading = true;
      const isApi = this.edit ? 'updateFollow' : 'follow';
      api[isApi]({
        tradeUserId,
        type,
        numberOrRatio,
        maxAmount,
        stopProfit: (stopProfit / 100) || '',
        stopLoss: (stopLoss / 100) || '',
      }).then(() => {
        this.loading = false;
        this.$toast({ msg: `${this.edit ? '修改' : '跟随'}成功`, type: 'success' });
        this.fetchUserInfo();
        this.$router.replace('/Administration');
      }).catch(() => {
        this.loading = false;
      });
    },
    cancel() {
      [this.show, this.showAgreement, this.showNickName] = [false, false, false];
    },
    fetchDelete() {
      const { tradeUserId: userId } = this.form;
      this.loading = true;
      api.cancelFollow({ userId }).then(() => {
        this.$toast({
          msg: '删除成功',
          type: 'success',
          callBack: () => {
            this.$router.replace('/Administration');
            this.loading = false;
          },
        });
        this.cancel();
      }).catch(() => { this.loading = false; });
    },
  },
};
</script>

<style scoped lang="scss">
  .Administration {
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
  }

  .list {
    padding: 20px 0;
  }

  .text-grey-p {
    font-size: 12px;
    line-height: 20px;
    margin-top: 10px;
    color: rgba(198, 198, 198, 1);
  }

  .left-grey {
    font-size: 15px;
    color: rgba(135, 135, 135, 1);
  }

  .right-black {
    font-size: 15px;
    color: rgba(45, 45, 45, 1);
  }

  .right-red {
    color: #E9556F;
  }

  .border-bottom-1 {
    border-bottom: .5px solid #F1F5FC;
  }

  .follow-now {
    margin: 20px 0;
  }

  ::v-deep .van-button {
    border-radius: 4px;
  }

  ::v-deep .van-stepper {
    border: 1px solid #EEEEEE;
    border-radius: 2px;
  }

  ::v-deep .van-stepper__input {
    margin: 0;
    border-left: 1px solid #EEEEEE;
    border-right: 1px solid #EEEEEE;
    background-color: #FFFFFF;
  }

  ::v-deep .van-stepper__minus, ::v-deep .van-stepper__plus {
    background-color: #FFFFFF;
  }

  ::v-deep .van-stepper__minus::before, ::v-deep .van-stepper__plus::before {
    width: 8px;
    height: 2px;
    color: #A3A5AC;
  }

  ::v-deep .van-stepper__minus::after, ::v-deep .van-stepper__plus::after {
    width: 1px;
    height: 8px;
    color: #A3A5AC;
  }

  ::v-deep .van-cell:not(:last-child)::after {
    left: 0;
  }

  ::v-deep .van-button--large {
    height: 40px;
  }

  .setup-popup-input {
    padding-left: 0;
  }
  ::v-deep .van-button--default {
    color: #AEAEAE;
  }
  ::v-deep .van-button--small {
    min-width: 80px;
    height: 28px;
  }
  ::v-deep .van-field__control {
    border-bottom-width:inherit!important;
  }
  .header-title {
    color: #4C4E5B;
  }
  .setup-popup-desc {
    color: #878787;
  }

  .setup-popup-input {
    height: 50px;
    border-bottom: 1px solid #F5F5F5 !important;
    font-size: 16px;
  }
  .text-indent{
    text-indent:25px
  }
  .percent[text-percent]:after{
    content: attr(text-percent);
    position: absolute;
    display: block;
    top: 10px;
    right: 38px;
    font-size: 12px;
    color: #878787;
  }
  .default[default-text]:before{
    content: attr(default-text);
    position: absolute;
    display: block;
    top: 10px;
    left: 62px;
    text-align: center;
    font-size: 12px;
    color: #878787;
    opacity: .6;
    background: white;
  }
  .percent{
    ::v-deep .van-stepper__input{
      padding-right: 12px;
    }
  }
  .van-stepper>*{
    display: inline-block;
  }
  .setup-stop-input{
    width: 75px;
    height: 36px;
    line-height: 36px;
  }
  .btm{
    width: 36px;
    height: 36px;
  }

</style>
