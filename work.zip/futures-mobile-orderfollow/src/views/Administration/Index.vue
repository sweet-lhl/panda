<template>
<div class="Administration flex-direction-column">
  <Header/>
    <div class="padding-left-15 padding-right-15 border-top-line border-bottom-line">
      <div class="flex-align-items-center list">
        <span class="font-size-16 circular" :style="{backgroundColor:userInfo.colour}">{{userInfo.nickName&&userInfo.nickName.substr(0,1)}}</span>
        <div class="userName" v-text="userInfo.nickName">西门大官人</div>
      </div>
      <div class="flex-align-items-center flex-auto list">
        <div class="left-grey text-align-left padding-left-5">
          <div class="text-size-20"><!--5920-->{{manage.withTotalAmount | toFixed(4)}}</div>
          <div class="text-grey text-size-12 margin-top-6">累计跟单金额(USDT)</div>
        </div>
        <div class="right-black text-align-right border-left position-relative padding-right-5">
          <div class="text-size-20 text-green">{{manage.withTotalPnl | toFixedSize(fetchAccuracy.assetSize)}}</div>
          <div class="text-grey text-size-12 margin-top-6">跟单总收益(USDT)</div>
        </div>
      </div>
    </div>

    <div class="current border-bottom-1">当前跟单</div>

  <div class="scroll-list">
    <scroll
      :data="manageList"
      :pullup="true"
      :pulldown="true"
      @pulldown="fetchPrevText"
      @pullup="fetchNextText"
      v-if="manageList.length"
      class="overflow-y-auto flex-1 scroll-wrapper">
      <div class="scroll-content">
        <div class="scroll-content" v-if="manageList">
          <div class="padding-left-15 padding-right-15 border-bottom-line" v-for="x in manageList">
            <div class="flex-align-items-center flex-auto list border-bottom-1">
              <div class="left-grey text-align-left padding-left-5">
                <div class="medium"><!--王二麻-->{{x.nickName}}
                  <svg class="icon iconbianji" aria-hidden="true">
                    <use xlink:href="#iconyirenzheng"></use>
                  </svg>
                </div>
                <div class="text-size-20 margin-top-20"><!--5920-->{{x.withTotalAmount | toFixed(4)}}</div>
                <div class="text-grey text-size-12 margin-top-6">累计跟单金额(USDT)</div>
              </div>
              <div class="right-black text-align-right padding-right-5">
                <div class="text-size-20" @click="$router.push({ name: 'SettingsEdit', query: { tradeUserId:x.tradeUserId,edit:1}})">
                  <svg class="icon iconbianji" aria-hidden="true">
                    <use xlink:href="#iconbianji"></use>
                  </svg>
                </div>
                <div class="text-size-20 text-green margin-top-20">{{x.withPnl | toFixedSize(fetchAccuracy.assetSize)}}</div>
                <div class="text-grey text-size-12 margin-top-6">跟单总收益(USDT)</div>
              </div>
            </div>
            <div class="margin-top-20 margin-bottom-20 text-grey text-size-12">
              <p class="margin-bottom-15 padding-left-5">固定{{x.withType===1?'张数':'比例'}}跟单：<span class="text-green">{{x.withAmount}}{{x.withType===1?'张':'倍'}}</span></p>
              <p class="text-align-justify padding-left-5 line-height-1-5">跟单总金额：
                <span class="text-green">{{x.totalAmount | toFixed(4)}}USDT</span>；止盈比例
                <span class="text-green" v-if="x.profitPercent">{{x.profitPercent | percent}}%</span>
                <span class="text-green" v-else>不限</span>；止损比例
                <span class="text-green" v-if="x.lossPercent">{{x.lossPercent | percent}}%</span>
                <span class="text-green" v-else>不限</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </scroll>
    <van-empty description="暂无数据" v-else />
  </div>
</div>
</template>

<script>
import { components } from '../../plugins/components';
import api from '../../api/apiModule_1';
import { mapState } from '../../utils/common';
import { PagingDefaultConf } from '../../utils/constant';

const { Header } = components;
export default {
  name: 'Index',
  data() {
    return {
      value: 1,
      show: false,
      activeNames: [],
      manage: '',
      manageList: '',
      pagination: { // 当前页、页数、总页数
        ...PagingDefaultConf,
      },
    };
  },
  components: { Header },
  computed: {
    ...mapState(['userInfo', 'coinList']),
    fetchAccuracy() {
      const { coinList } = this;
      return coinList.find(({ coinName }) => coinName === 'USDT') || {};
    },
  },
  created() {
    this.manageListHandle(true);
  },
  methods: {
    manageListHandle(tag) {
      const { pageIndex: pageNum, pageSize } = this.pagination;
      return api.manageList({ pageNum, pageSize }).then((data) => {
        this.manage = data;
        const manageList = data.data.data;
        if (tag) { // 是否刷新
          this.manageList = manageList;
        } else {
          this.manageList = [...this.manageList, ...manageList];
        }
        this.pagination.totalPages = data.data.totalPages;
      }).catch(() => {

      });
    },
    fetchPrevText() { // 下拉
      this.pagination.pageIndex = 1;
      this.manageListHandle(true).then(() => {
        this.$toast({ msg: '刷新成功', type: 'success' });
      });
    },
    fetchNextText() { // 上拉
      const { totalPages, pageIndex } = this.pagination;
      if (pageIndex < totalPages) {
        this.pagination.pageIndex += 1;
        this.manageListHandle(false);
      } else {
        this.$toast('没有更多数据了');
      }
    },
  },
};
</script>

<style scoped lang="scss">
  .Administration{
    font-family:PingFangSC-Medium,PingFang SC;
    font-weight:400;
    height: 100%;
  }
  .list{
    padding: 20px 0;
  }
  .text-grey{
    color:#AEAEAE;
    font-family:PingFangSC-Regular,PingFang SC;
   }
  .text-green{
    color:#1CC561;
  }
  .border-bottom-1{
    border-bottom: 1px solid #F5F5F5;
  }
  .userName{
    font-size:16px;
    font-family:PingFangSC-Semibold,PingFang SC;
    font-weight:600;
    color:rgba(45,45,45,1);
  }
  .circular {
    width: 26px;
    height: 26px;
    line-height: 26px;
    font-size: 13px;
    font-weight:600;
    display: inline-block;
    border-radius: 50%;
    text-align: center;
    color: white;
    background: rgba(39, 192, 139, 1);
    margin-right: 10px;
  }
  .current{
    font-family:PingFangSC-Medium,PingFang SC;
    padding: 20px 15px;
    font-size:15px;
    font-weight:600;
    color:rgba(76,78,91,1);
  }
  .line-height-1-5{
    line-height: 1.5;
  }
  .border-left:after{
    content: "";
    position: absolute;
    top: 10px;
    left: 0;
    width: 1px;
    height: 20px;
    background: #EEEEEE;
  }
  .margin-top-20{
    margin-top: 20px;
  }
  .margin-bottom-20{
    margin-bottom: 20px;
  }
  .margin-bottom-15{
    margin-bottom: 15px;
  }
  .medium{
    font-size:16px;
    font-family:PingFangSC-Medium,PingFang SC;
    font-weight:500;
    color:rgba(76,78,91,1);
  }
  .iconbianji{
    width: 16px;
    height: 18px;
  }
  .scroll-list {
    height: 60%;
    overflow: hidden;
  }
</style>
