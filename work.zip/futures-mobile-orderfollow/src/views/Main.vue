<template>
  <div id="main">
    <router-view/>
    <Toast/>
    <Confirm/>
  </div>
</template>
<script>
import { components } from '../plugins/components';

const {
  Toast, Confirm,
} = components;
export default {
  name: 'main',
  components: {
    Toast, Confirm,
  },
};
</script>
<style scoped lang="scss">
  #main {
    height: 100%;
  }
</style>
