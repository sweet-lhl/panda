<template>
  <div class="tape">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'contractTape',
};
</script>

<style scoped lang="scss">
  .tape {
    height: 100%;
  }
</style>
