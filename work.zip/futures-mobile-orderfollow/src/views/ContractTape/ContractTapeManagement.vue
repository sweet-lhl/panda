<template>
  <div class="flex-direction-column management">
    <Header>
      <span slot="right">
         <svg class="icon header-icon" aria-hidden="true" @click.stop="$router.push(`/contractTapeSetUp?userId=${headerData.userId}`)">
          <use xlink:href="#iconshezhi"></use>
        </svg>
      </span>
    </Header>
    <div class="line"></div>
    <div class="management-header">
      <div class="flex-direction-row flex-align-items-center border-bottom">
        <div class="avatar margin-bottom-20" :style="`background: ${headerData.colour}`">{{handleTitle(headerData.nickName)}}</div>
        <span class="title-desc margin-bottom-20">{{headerData.nickName}}</span>
        <svg class="icon title-icon margin-bottom-20" aria-hidden="true" v-if="userInfo.level === 2">
          <use xlink:href="#iconyirenzheng"></use>
        </svg>
      </div>
      <div class="flex-justify-content-space-between flex-align-items-center header-layout border-bottom">
        <ul>
          <li class="text-size-14">{{headerData.todayPnl | toFixed(8)}}</li>
          <li class="margin-top-6 text-color-gray text-size-12">预估今日收益(USDT)</li>
        </ul>
        <ul class="text-align-right">
          <li class="text-size-14">{{headerData.yesterdayPnl | toFixed(8)}}</li>
          <li class="margin-top-6 text-color-gray text-size-12">昨日收益(USDT)</li>
        </ul>
        <ul class="text-align-right">
          <li class="text-size-14 text-color-green">{{headerData.grandPnl | toFixedSize(fetchAccuracy.assetSize)}}</li>
          <li class="margin-top-6 text-color-gray text-size-12">累计收益(USDT)</li>
        </ul>
      </div>
      <div class="flex-direction-row flex-align-items-center header-layout border-bottom">
        <span class="line-height-1 ratio-text">带单利润分成比例：{{headerData.tradeRatio | percent}}%</span>
        <svg class="icon icon-mark" aria-hidden="true" @click.stop="handleMessage">
          <use xlink:href="#iconwenhao"></use>
        </svg>
      </div>
      <div class="flex-justify-content-space-between flex-align-items-center header-layout text-size-12">
        <span class="ratio-text">当前跟单人数 {{headerData.followNum}} 人</span>
        <span class="text-color-blue" @click.stop="$router.push('/contractOrderDetails')">查看</span>
      </div>
    </div>
    <div class="line"></div>
    <div class="management-footer flex-1">
      <div class="footer-title">收益明细</div>
      <div class="scroll-content">
        <scroll
          :data="tableData"
          :pullup="true"
          :pulldown="true"
          @pulldown="fetchPrevText"
          @pullup="fetchNextText"
          v-if="tableData.length"
          class="overflow-y-auto scroll-wrapper">
          <div>
            <div
              v-for="item in tableData"
              :key="`details-scroll-li${item}`"
              class="flex-justify-content-space-between flex-align-items-center border-bottom scroll-content-item">
              <ul class="margin-bottom-15">
                <li class="text-color-gray">数量</li>
                <li class="margin-top-10 text-size-14 text-color-black">{{item.tradeLayere | toFixed(8)}}</li>
              </ul>
              <ul class="text-align-center margin-bottom-15">
                <li class="text-color-gray">状态</li>
                <li class="margin-top-10 text-size-14 text-color-green">{{item.status === 1 ? '成功' : '等待中'}}</li>
              </ul>
              <ul class="text-align-right margin-bottom-15">
                <li class="text-color-gray">时间</li>
                <li class="margin-top-10 text-size-14">{{item.grantTime | timeStampToDate}}</li>
              </ul>
            </div>
          </div>
        </scroll>
        <van-empty description="暂无数据" v-else />
      </div>
    </div>
  </div>
</template>

<script>
import Header from '../../components/Header.vue';
import api from '../../api/apiModule_1';
import { mapState } from '../../utils/common';
import fill from '../../plugins/filters';

export default {
  name: 'ContractTapeManagement',
  components: { Header },
  data() {
    return {
      headerData: {},
      tableData: [],
    };
  },
  computed: {
    ...mapState(['userInfo', 'coinList']),
    fetchAccuracy() {
      const { coinList } = this;
      return coinList.find(({ coinName }) => coinName === 'USDT') || {};
    },
  },
  methods: {
    fetchFollowWithStatistics() {
      api.followWithStatistics().then((r) => {
        this.headerData = r;
      });
    },
    fetchTableData(tag) {
      const { pageSize, pageIndex } = this.pagination;
      return api.followWithPnlList({
        pageSize,
        currentPage: pageIndex,
      }).then(({ totalPages, data }) => {
        if (tag) { // 是否刷新
          this.tableData = data;
        } else {
          this.tableData = [...this.tableData, ...data];
        }
        this.pagination.totalPages = totalPages;
      });
    },
    fetchPrevText() { // 下拉
      this.pagination.pageIndex = 1;
      this.fetchTableData(true).then(() => {
        this.$toast({ msg: '刷新成功', type: 'success' });
      });
    },
    fetchNextText() { // 上拉
      const { totalPages, pageIndex } = this.pagination;
      if (pageIndex < totalPages) {
        this.pagination.pageIndex += 1;
        this.fetchTableData(false);
      } else {
        this.$toast('没有更多数据了');
      }
    },
    handleTitle(value) {
      return value?.substr(0, 1);
    },
    handleMessage() {
      this.$toast({
        type: 'info',
        msg: `跟随者每天跟单总利润的${fill.filters.percent(this.headerData.tradeRatio)}%将作为你的带单奖励，奖励将在次日凌晨结算到你的账户。跟随者主动平仓跟随订单产生的收益也将计入跟单利润，一同参与结算。`,
      });
    },
  },
  created() {
    this.fetchFollowWithStatistics();
    this.fetchTableData(true);
  },
};
</script>

<style scoped lang="scss">
  .management {
    height: 100%;
  }

  .header-icon {
    width: 20px;
    height: 20px;
  }

  .management-header {
    padding: 0 15px;
    margin-top: 20px;
  }

  .title-icon {
    width: 15px;
    height: 15px;
    margin-left: 5px;
  }

  .border-bottom {
    border-bottom: 1px solid #F5F5F5;
  }

  .header-layout {
    padding: 20px 0;

    ul {
      padding-left: 0;
    }
  }

  .text-color-gray {
    color: #AEAEAE;
  }

  .text-color-green {
    color: #1CC561;
  }

  .icon-mark {
    width: 14px;
    height: 14px;
    margin-left: 5px;
  }

  .ratio-text {
    color: #878787;
  }

  .management-footer {
    padding: 20px 15px;

    .footer-title {
      font-size: 16px;
      color: #2D2D2D;
      font-weight: 500;
    }
  }

  .scroll-content {
    height: 100%;
    overflow: hidden;
  }

  .scroll-content-item {
    margin-top: 20px;
    font-size: 12px;
  }
</style>
