<template>
  <div class="flex-direction-column home">
    <Header :backNative="true" @intercept="goFriend('interaction_popAction')">
      <span slot="right">
          <van-icon name="ellipsis" @click.stop="handleShowList"/>
          <van-overlay :show="isShowList" @click.stop="isShowList = false" class-name="header-overlay">
            <ul class="header-list position-absolute" slot="default">
              <li @click.stop="$router.push('/Administration')">跟单管理</li>
              <li v-if="userInfo.type === 0 || userInfo.type === 2"  @click.stop="handleTraders">申请成为交易员</li>
              <li v-if="userInfo.type === 1" @click.stop="$router.push('/contractTapeManagement')">带单管理</li>
            </ul>
          </van-overlay>
      </span>
    </Header>
    <div class="home-line"></div>
    <div class="home-banner">
      <div class="home-swiper background-reset"></div>
    </div>
    <div class="home-line"></div>
    <div class="flex-justify-content-space-between flex-align-items-center content-header">
      <P>交易员榜单</P>
      <div class="flex-direction-row flex-align-items-center" @click.stop="handleShowPopup">
        <svg class="icon content-header-search margin-right-20" aria-hidden="true">
          <use xlink:href="#iconsousuo-copy"></use>
        </svg>
        <svg class="icon content-header-icon" aria-hidden="true" @click.stop="handleShowSort">
          <use xlink:href="#iconpaixu"></use>
        </svg>
      </div>
    </div>
    <div class="scroll-list overflow-y">
      <van-pull-refresh v-model="isLoading" @refresh="fetchPrevText('table')">
        <van-list
          v-model="vanList.loading"
          :finished="vanList.finished"
          :error.sync="vanList.error"
          error-text="请求失败，点击重新加载"
          @load="fetchNextText('table')"
          v-if="tableData.length"
        >
          <div
            v-for="item in tableData"
            class="scroll-item"
            :key="`home-scroll-li-${item}`">
            <div class="flex-justify-content-space-between flex-align-items-center scroll-item-top" @click.stop="handleSubmit(item.userId)">
              <div class="flex-direction-row flex-align-items-center top-left">
                <div class="avatar" :style="`background: ${item.colour}`">{{handleTitle(item.nickName)}}</div>
                <div class="flex-direction-column margin-left-10">
                  <P class="item-header-text">{{item.nickName}}
                    <svg class="icon header-icon" aria-hidden="true" v-if="item.level === 2">
                      <use xlink:href="#iconyirenzheng"></use>
                    </svg>
                  </P>
                  <div :class="['flex-direction-row', item.label && 'margin-top-8']">
                    <span :class="[itemChild.select && 'item-header-round']" v-for="itemChild in item.labels" :key="`itemChild-label-${itemChild}`">
                      <span v-if="itemChild.select">{{itemChild.name}}</span>
                    </span>
                  </div>
                </div>
              </div>
              <van-button round type="primary" size="mini">跟单</van-button>
            </div>
            <div class="flex-justify-content-space-between flex-align-items-center scroll-item-bottom">
              <div class="flex-direction-column text-align-left">
                <P class="text-size-18 text-color-black">{{item.maxDrawdown | percent}}%</P>
                <span class="text-size-12 margin-top-10 text-color-gray">近3周最大回撤</span>
              </div>
              <div class="flex-direction-column text-align-right">
                <P class="text-size-18 margin-bottom-10 text-color-black">{{item.followerCount}}</P>
                <span class="text-size-12 margin-top-10 text-color-gray">累计跟随人数</span>
              </div>
              <div class="flex-direction-column text-align-right">
                <P class="text-size-18 text-color-green">{{item.cumulativePnlRatio | percent}}%</P>
                <span class="text-size-12 margin-top-10 text-color-gray">累计收益率</span>
              </div>
            </div>
            <div class="home-line"></div>
          </div>
        </van-list>
        <van-empty description="暂无数据" v-else />

      </van-pull-refresh>

      <!--<scroll
        :data="tableData"
        :pullup="true"
        :pulldown="true"
        @pulldown="fetchPrevText('table')"
        @pullup="fetchNextText('table')"
        v-if="tableData.length"
        class="overflow-y-auto flex-1 scroll-wrapper">
        <div class="scroll-content">
          <div
            v-for="item in tableData"
            class="scroll-item"
            :key="`home-scroll-li-${item}`">
            <div class="flex-justify-content-space-between flex-align-items-center scroll-item-top" @click.stop="handleSubmit(item.userId)">
              <div class="flex-direction-row flex-align-items-center top-left">
                <div class="avatar" :style="`background: ${item.colour}`">{{handleTitle(item.nickName)}}</div>
                <div class="flex-direction-column margin-left-10">
                  <P class="item-header-text">{{item.nickName}}
                    <svg class="icon header-icon" aria-hidden="true" v-if="item.level === 2">
                      <use xlink:href="#iconyirenzheng"></use>
                    </svg>
                  </P>
                  <div :class="['flex-direction-row', item.label && 'margin-top-8']">
                    <span :class="[itemChild.select && 'item-header-round']" v-for="itemChild in item.labels" :key="`itemChild-label-${itemChild}`">
                      <span v-if="itemChild.select">{{itemChild.name}}</span>
                    </span>
                  </div>
                </div>
              </div>
              <van-button round type="primary" size="mini">跟单</van-button>
            </div>
            <div class="flex-justify-content-space-between flex-align-items-center scroll-item-bottom">
              <div class="flex-direction-column text-align-left">
                <P class="text-size-18 text-color-black">{{item.maxDrawdown | percent}}%</P>
                <span class="text-size-12 margin-top-10 text-color-gray">近3周最大回撤</span>
              </div>
              <div class="flex-direction-column text-align-right">
                <P class="text-size-18 margin-bottom-10 text-color-black">{{item.followerCount}}</P>
                <span class="text-size-12 margin-top-10 text-color-gray">累计跟随人数</span>
              </div>
              <div class="flex-direction-column text-align-right">
                <P class="text-size-18 text-color-green">{{item.cumulativePnlRatio | percent}}%</P>
                <span class="text-size-12 margin-top-10 text-color-gray">累计收益率</span>
              </div>
            </div>
            <div class="home-line"></div>
          </div>
        </div>
      </scroll>
      <van-empty description="暂无数据" v-else />-->
    </div>
    <van-popup v-model="isShowPopup" round position="bottom" :style="{ height: '80%' }" :lock-scroll="false">
      <div class="flex-direction-column home-popup">
        <van-search
          v-model="searchList.nickName"
          show-action
          shape="round"
          @clear="searchData = []"
          maxlength="12"
          @search="handleOnSearch"
          placeholder="请输入搜索关键词">
          <template #action>
            <span @click.stop="handleOnSearch">搜索</span>
          </template>
        </van-search>
        <div class="popup-content overflow-y">
        <!--  <scroll
            :data="searchData"
            :pullup="true"
            :pulldown="true"
            @pulldown="fetchPrevText('search')"
            @pullup="fetchNextText('search')"
            v-if="searchData.length"
            class="overflow-y-auto flex-1 scroll-wrapper">
            <div>
              <div class="scroll-item" v-for="item in searchData" :key="`popup-search-li-${item}`">
                <div class="flex-justify-content-space-between flex-align-items-center scroll-item-top">
                  <div class="flex-direction-row flex-align-items-center top-left">
                    <div class="avatar" :style="`background: ${item.colour}`">{{handleTitle(item.nickName)}}</div>
                    <div class="flex-direction-column margin-left-10">

                      <P class="item-header-text">{{item.nickName}}
                        <svg class="icon header-icon" aria-hidden="true" v-if="item.level === 2">
                          <use xlink:href="#iconyirenzheng"></use>
                        </svg>
                      </P>
                      <div :class="['flex-direction-row', item.label && 'margin-top-8']">
                        <span :class="[itemChild.select && 'item-header-round']" v-for="itemChild in item.labels" :key="`itemChild-label-${itemChild}`">
                          <span v-if="itemChild.select">{{itemChild.name}}</span>
                        </span>
                      </div>
                    </div>
                  </div>
                  <van-button round type="primary" size="mini" @click.stop="handleSubmit(item.userId)">跟单</van-button>
                </div>
                <div class="flex-justify-content-space-between flex-align-items-center scroll-item-bottom">
                  <div class="flex-direction-column text-align-left">
                    <P class="text-size-18 text-color-black">{{maxDrawdown | toFixedSize(fetchAccuracy)}}</P>
                    <span class="text-size-12 margin-top-10 text-color-gray">近3周最大回撤</span>
                  </div>
                  <div class="flex-direction-column text-align-right">
                    <P class="text-size-18 margin-bottom-10 text-color-black">{{item.followerCount}}</P>
                    <span class="text-size-12 margin-top-10 text-color-gray">累计跟随人数</span>
                  </div>
                  <div class="flex-direction-column text-align-right">
                    <P class="text-size-18 text-color-green">{{item.cumulativePnlRatio | percent}}%</P>
                    <span class="text-size-12 margin-top-10 text-color-gray">总收益率</span>
                  </div>
                </div>
              </div>
            </div>
          </scroll>
          <van-empty description="暂无数据" v-else />-->

          <van-pull-refresh v-model="isLoading" @refresh="fetchPrevText('search')">
            <van-list
              v-model="vanList.loading"
              :finished="vanList.finished"
              :error.sync="vanList.error"
              error-text="请求失败，点击重新加载"
              @load="fetchNextText('search')"
              v-if="searchData.length"
            >
              <div class="scroll-item" v-for="item in searchData" :key="`popup-search-li-${item}`">
                <div class="flex-justify-content-space-between flex-align-items-center scroll-item-top">
                  <div class="flex-direction-row flex-align-items-center top-left">
                    <div class="avatar" :style="`background: ${item.colour}`">{{handleTitle(item.nickName)}}</div>
                    <div class="flex-direction-column margin-left-10">

                      <P class="item-header-text">{{item.nickName}}
                        <svg class="icon header-icon" aria-hidden="true" v-if="item.level === 2">
                          <use xlink:href="#iconyirenzheng"></use>
                        </svg>
                      </P>
                      <div :class="['flex-direction-row', item.label && 'margin-top-8']">
                        <span :class="[itemChild.select && 'item-header-round']" v-for="itemChild in item.labels" :key="`itemChild-label-${itemChild}`">
                          <span v-if="itemChild.select">{{itemChild.name}}</span>
                        </span>
                      </div>
                    </div>
                  </div>
                  <van-button round type="primary" size="mini" @click.stop="handleSubmit(item.userId)">跟单</van-button>
                </div>
                <div class="flex-justify-content-space-between flex-align-items-center scroll-item-bottom">
                  <div class="flex-direction-column text-align-left">
                    <P class="text-size-18 text-color-black">{{maxDrawdown | toFixedSize(fetchAccuracy)}}</P>
                    <span class="text-size-12 margin-top-10 text-color-gray">近3周最大回撤</span>
                  </div>
                  <div class="flex-direction-column text-align-right">
                    <P class="text-size-18 margin-bottom-10 text-color-black">{{item.followerCount}}</P>
                    <span class="text-size-12 margin-top-10 text-color-gray">累计跟随人数</span>
                  </div>
                  <div class="flex-direction-column text-align-right">
                    <P class="text-size-18 text-color-green">{{item.cumulativePnlRatio | percent}}%</P>
                    <span class="text-size-12 margin-top-10 text-color-gray">总收益率</span>
                  </div>
                </div>
              </div>
            </van-list>
            <van-empty description="暂无数据" v-else />

          </van-pull-refresh>
        </div>
      </div>
    </van-popup>
    <van-popup v-model="isSortPopup" position="bottom" :style="{ height: !isTab ? '30%' : '40%' }" v-if="!isTab" round>
      <div class="flex-direction-column sort-popup">
        <div class="sort-popup-item" @click.stop="handleTabRate('CUMULATIVEPNLRATIO')">累计收益率</div>
        <div class="sort-popup-item" @click.stop="handleTabRate('MAXDRAWDOWN')">近3周最大回撤</div>
        <div class="sort-popup-item" @click.stop="handleTabRate('FOLLOWERCOUNT')">累计跟随人数</div>
        <div class="home-line"></div>
        <div class="sort-popup-item cancel-btn" @click.stop="isSortPopup = false">取消</div>
      </div>

     <!-- <div class="flex-direction-column setup-popup" v-else>
        <div class="flex-justify-content-space-between flex-align-items-center setup-popup-header">
          <P>请设置社区昵称</P>
          <svg class="icon close-icon" aria-hidden="true" @click.stop="isSortPopup = false">
            <use xlink:href="#iconguanbi"></use>
          </svg>
        </div>
        <p class="text-size-12 header-title">昵称</p>
        <input type="text" minlength="2" maxlength="12" v-model="searchList.nickName" class="setup-popup-input"/>
        <span class="margin-top-5 text-size-12 setup-popup-desc">请设置跟单昵称，填写后不支持修改，请悉知</span>
        <div class="setup-popup-btn" @click.stop="handleSubmitNickName">确认</div>
      </div>-->

    </van-popup>
    <van-popup v-model="isTextPopup" position="bottom" :style="{ height: '70%' }" round>
      <div class="flex-direction-column setup-popup">
        <div class="flex-justify-content-space-between flex-align-items-center setup-popup-header text">
          <P>申请交易员</P>
          <svg class="icon close-icon" aria-hidden="true" @click.stop="isTextPopup = false">
            <use xlink:href="#iconguanbi"></use>
          </svg>
        </div>
        <div class="setup-content-text">
          <div class="text-size-20 text-align-center">申请交易员协议</div>
          <span class="text-size-16">客户资格</span>
          <div class="margin-top-10">客户应当为符合本协议相关交易法律法规要求的合格投资者：</div>
          <div class="margin-top-10 margin-bottom-10">
            <P>1.客户已年满18周岁；具有完全民事权利能力及民事行为能力；具有足够的知识与经验可以理解将要交易的产品的性质与风险。</P>
            <P>2.您是您在Panda global账户中添加的资金的合法所有人，保证资金或数字资产来源的合法性，不得借助平台运作违法行为。</P>
            <p>3.您提供的任何加密货币提款地址都是您自己的，并且您对该地址拥有完全控制权。</p>
          </div>
          <span class="text-size-16">交易服务</span>
          <P>
            您应自行谨慎判断相关比特币等虚拟货币等虚拟货币及/或信息的真实性、合法性和有效性，并自行承担因此产生的责任与损失。除非法律法规明确要求，否则，平台没有义务对所有用户的信息数据、比特币等虚拟货币信息、交易行为以及与交易有关的其它事项进行事先审查。
          </P>
          <div class="text-size-16 margin-top-10 margin-bottom-10">纠纷及法律义务</div>
          <P>
            您在平台使用跟单服务进行交易过程中与其他用户发生交易纠纷时，一旦您或其它用户任一方或双方共同提交平台要求调解处理时，平台有权根据单方判断做出调处决定，您了解并同意接受平台对于用户交易纠纷的判断和调处决定。
          </P>
          <P>
            您了解并同意平台有权应政府部门（包括司法及行政部门）的要求向其提供您向平台提供的用户信息和交易记录等必要信息。如您涉嫌侵犯他人知识产权等合法权益行为时，平台有权在初步判断涉嫌侵权、违法行为存在的情况下，向权利人、监管或法律部门提供您必要的身份信息。
          </P>
          <div class="text-size-16 margin-top-10 margin-bottom-10">分佣结算</div>
          <p>
            跟随者在跟随平仓时，若订单盈利，系统会将盈利的分佣比例部分扣除，次日凌晨将进行二次结算，统计跟随者的当日累计净收益，以此累计净收益计算出实际应付的分成，若应付分成少于已经付出的订单分成，则会将多付的分成部分返还到跟随者的账户中。
          </p>
          <P>
            跟随产生的订单，无论订单是由您自主平仓或是跟随平仓，皆会发生订单利润分成。
          </P>
          <span class="text-size-16">免责申明</span>
          <p>
            1.您知情并同意平台不对因下述任一情况而导致的任何损害赔偿承担责任，包括但不限于利润、商誉、使用、数据等方面的损失或其它无形损失的损害赔偿（无论我们是否已被告知该等损害赔偿的可能性）：平台有合理的理由认为特定会员及具体交易事项可能存在重大违法或违约情形。平台有合理的理由认为用户在平台的行为涉嫌违法或不当。通过平台服务购买或获取任何数据、信息或进行交易等行为或替代行为产生的费用及损失。您对平台跟单服务的误解。任何非因平台跟单服务的原因而引起的与平台跟单服务有关的其它损失。您直接或间接参与跟单交易导致的任何部分或全部亏损。
          </p>
          <p>
            2.跟单交易功能相关的风险，包括但不限于自动交易操作，即您的账户在没有您手动干预的情况下，可以开始和结束交易。
          </p>
          <p>
            3.跟单交易的延时性可能产生高额成本，跟单交易可能出现失败的情况。
          </p>
          <p>
            4.自动交易执行等相关交易操作无需经您人工操作即可在您账户中完成建仓与平仓交易。
          </p>
          <p>
            5.投资管理服务由您自行选择，您自行决定跟单特定交易者以及/或遵从特定交易策略。在作出此等决定时，您已经考虑了包括财务规划在内的自身整体财务状况，并且了解使用跟单交易功能具有极高的投机性，您可能招致的损失比用以跟单此交易者的金额还要大得多。
          </p>
          <p>
            6.我们所提供的跟单交易功能仅供参考。如果您根据我们网站上提供的资料或通过跟单交易功能获取的资料作出投资决定，您应自行承担风险。
          </p>
          <p>
            7.您应自主研判再作出投资决定。您应根据自身投资目标和个人及财务状况自行独立判断投资、策略、或任何其他产品及服务是否符合您自身需要。
          </p>
          <p>
            8.因使用跟单交易功能自动执行操作招致损失，您应自主全权承担责任。
          </p>
          <p>
            9.网站或客户端上的任何信息旨在为公众提供交易者和追随者的交易动态和信息服务。本网站不提供任何形式的投资建议，也绝不以任何形式暗示提供此类信息以及/或功能。您应对通过此平台或跟单交易功能搜集的信息进行独立研究并自主作出投资决定。
          </p>
          <P>
            10.未尽事宜平台保留法律范围内的最终解释权。
          </P>
          <p>
            11.风险提示：数字货币是一种高风险的投资方式，请投资者谨慎购买，并注意投资风险。Panda Global会遴选优质币种，但不对投资行为承担担保、赔偿等责任。数字资产合约交易是创新的产品，风险较高，专业性较强。请您理性判断自己的投资能力，审慎做出投资决策。
          </p>
        </div>
        <van-checkbox v-model="searchList.isChecked" icon-size="14px" checked-color="#07c160" shape="square">我已知晓</van-checkbox>
        <div class="setup-popup-btn" @click.stop="handleSureAgree">我已了解</div>
      </div>
    </van-popup>
    <CenterPopup
      :cancel="cancel"
      :safe="isDialog"
      :tips="{
        title: '提示:',
        cancel: '取消',
        subText: '前往认证',
      }"
      :submission="()=>{handleGoApp('lemonOTC_userAuth')}">
      <div slot="content" class="items-center font-size-16">
        <p class="opacity-6 text-align-justify font-size-14">请完成高级实名认证!</p>
      </div>
    </CenterPopup>
    <CenterPopup
      :cancel="()=>{handleGoApp('interaction_popAction')}"
      :safe="isOpenContract"
      :tips="{
        title: '提示:',
        cancel: '取消',
        subText: '同意协议',
      }"
      :submission="handleAgreeAgreement">
      <div slot="content" class="items-center font-size-16">
        <div class="contract-text">
          <p class="text-size-12" v-html="contractText"></p>
        </div>
      </div>
    </CenterPopup>

    <CenterPopup
      :cancel="cancel"
      :safe="isSortPopup&&isTab"
      :tips="{
        title: '请设置社区昵称:',
        cancel: '取消',
        subText: '确认',
      }"
      :agree="!searchList.nickName"
      :submission="handleSubmitNickName">
      <div slot="content" class="items-center">
        <p class="text-size-12 header-title">昵称</p>
        <van-field
          class="setup-popup-input"
          v-model="searchList.nickName"
          minlength="2"
          maxlength="12"
          placeholder="请输入您的昵称"
          clearable
        />
        <p class="margin-top-5 text-size-12 setup-popup-desc">请设置跟单昵称，填写后不支持修改，请悉知</p>
      </div>
    </CenterPopup>
  </div>
</template>

<script>
import Bridge from '../../utils/bridge';
import api from '../../api/apiModule_1';
import { components } from '../../plugins/components';
import { mapState, mapActions } from '../../utils/common';
import CenterPopup from '../../components/CenterPopup.vue';
import { PagingDefaultConf, Regex } from '../../utils/constant';

const { Header } = components;

export default {
  name: 'ContractTapeHome',
  data() {
    return {
      pagination: { ...PagingDefaultConf },
      isShowList: false, // 下拉菜单
      isShowPopup: false, // 搜索popup
      isSortPopup: false, // 排序popup
      isTextPopup: false, // 申请交易员popup
      isOpenContract: false, // 是否开通合约
      isDialog: false, // 是否显示提示弹窗
      isTab: true,
      tableData: [], // scroll 列表数据
      searchData: [], // popup弹窗数据列表
      searchList: {
        nickName: '', // 交易员昵称
        orderField: 'CUMULATIVEPNLRATIO',
        isChecked: false,
      },
      contractText: '',
      vanList: {
        loading: false,
        finished: false,
        error: false,
      },
      isLoading: false,
    };
  },
  components: { Header, CenterPopup },
  computed: {
    ...mapState(['userInfo', 'coinList']),
    fetchAccuracy() {
      const { coinList } = this;
      return coinList.find(({ coinName }) => coinName === 'USDT')?.assetSize || 0;
    },
  },
  watch: {
    userInfo: {
      handler(n, o) {
        if (n !== o) if (n.isOpenFutures === false) this.isOpenContract = true;
      },
      deep: true,
      immediate: true,
    },
  },
  methods: {
    ...mapActions(['fetchUserInfo']),
    goFriend(isPath, data) {
      Bridge.callHandler('JS2NativeInteraction', { rel: isPath, data });
    },
    handleShowList() {
      this.isShowList = !this.isShowList;
    },
    handleShowPopup() {
      this.isShowPopup = true;
    },
    handleShowSort() {
      this.isTab = false;
      this.isSortPopup = true;
    },
    handleSubmit(id) {
      if (this.userInfo.level !== 2) this.isDialog = true;

      this.$router.push(`/contractTapeDetails?userId=${id}`);
    },
    fetchTableData(refresh, tag) { // 获取列表数据
      const { pageIndex: pageNum, pageSize } = this.pagination;
      const { nickName, orderField } = this.searchList;

      return api.followTraders({
        nickName, // 交易员昵称
        orderField, // 排序字段
        pageNum,
        pageSize,
      }).then(({ totalPages, data }) => {
        this.pagination.totalPages = totalPages;
        // 加载状态结束
        this.vanList.loading = false;
        if (refresh) { // 是否刷新
          this[`${tag}Data`] = data;
        } else {
          this[`${tag}Data`] = [...this[`${tag}Data`], ...data];
        }
        const { pageIndex } = this.pagination;
        if (totalPages <= pageIndex) {
          /* 所有数据加载完毕 */
          this.vanList.finished = true;
          return;
        }
        this.vanList.finished = false;
        this.pagination.pageIndex += 1;
      }).catch(() => {
        this.vanList.error = true;
      });
    },
    fetchPrevText(target) { // 下拉
      this.pagination.pageIndex = 1;
      this.fetchTableData(true, target).then(() => {
        this.pagination.pageIndex = 2;
        this.$toast({ msg: '刷新成功', type: 'success' });
        this.isLoading = false;
      });
    },
    fetchNextText(target) { // 上拉
      this.fetchTableData(false, target);
    },
    handleOnSearch() {
      if (this.searchList.nickName) {
        this.pagination.pageIndex = 1;
        this.fetchTableData(true, 'search');
        this.isLoading = false;
        this.vanList.finished = false;
      } else {
        this.$toast('请输入搜索关键词');
      }
    },
    handleTabRate(value) { // 排序
      this.searchList.orderField = value;
      this.pagination.pageIndex = 1;
      this.fetchTableData(true, 'table').then(() => {
        this.isSortPopup = false;
      });
    },
    handleSureAgree() {
      const { searchList: { isChecked } } = this;
      if (!isChecked) this.$toast('请同意用户协议!');
      if (isChecked) {
        api.agreementFollowOrderTreaty().then(() => {
          api.applyTrader().then(() => {
            this.isTextPopup = false;
            this.$toast({ msg: '申请成功', type: 'success' });
            this.fetchUserInfo();// 更新用户详情
          });
        });
      }
    },
    cancel() {
      [this.isDialog, this.isOpenContract, this.isSortPopup, this.isTab] = [false, false, false, false];
    },
    fetchHomeOpenTreaty() {
      return api.homeOpenTreaty().then((r) => {
        this.contractText = r;
      });
    },
    handleAgreeAgreement() {
      api.accountOpen().then(() => {
        this.isOpenContract = false;
        this.fetchUserInfo();// 更新用户详情
      });
    },
    handleGoApp(target) {
      this.cancel();
      this.goFriend(target);
    },
    handleSubmitNickName() {
      const { searchList: { nickName } } = this;
      if (nickName.length < 2) {
        this.$toast('请输入2-12位社区昵称');
        return;
      }
      if (nickName && !Regex.HAS_SPACE.test(nickName)) {
        api.setNickName({
          nickeName: String(nickName),
        }).then(() => {
          this.isTextPopup = true;
          this.isSortPopup = false;
          this.$toast({ msg: '设置成功', type: 'success' });
          this.fetchUserInfo();// 更新用户详情
        });
      } else {
        this.$toast('昵称不能空或不能包含空格');
      }
    },
    handleTraders() {
      const { level, nickName, traderNumber } = this.userInfo;
      this.isShowList = false;
      if (level !== 2) { // 实名认证
        this.isDialog = true;
        return;
      }
      if (traderNumber) { // 跟随的交易员
        this.$confirm({
          msg: '提示：需要取消你所有跟随的交易员',
          submitText: '一键取消',
          callBack: () => {
            api.cancelAllFollow().then(() => {
              this.isTextPopup = false;
              this.$toast({ msg: '取消成功', type: 'success' });
              this.fetchUserInfo();// 更新用户详情
            });
          },
        });
        return;
      }
      if (!nickName) {
        this.isTab = true;
        this.isSortPopup = true;
        return;
      }
      this.isTextPopup = true;
      this.isSortPopup = false;
    },
    handleTitle(value) {
      return value?.substr(0, 1);
    },
  },
  created() {
    this.fetchTableData(true, 'table');
    this.fetchHomeOpenTreaty();
  },
  mounted() {

  },
};
</script>

<style scoped lang="scss">
  .home {
    height: 100%;
  }

  .header {
    height: 48px;
    font-size: 20px;
    font-weight: 500;
    padding: 0 15px;

    .header-left {
      height: 48px;
    }

    .header-overlay {
      background-color: rgba(0, 0, 0, .6);
    }

    .header-list {
      border-radius: 4px !important;
      top: 30px;
      right: 15px;
      background: rgba(255, 255, 255, 1);
      box-shadow: 0 2px 8px 0 rgba(0, 0, 0, 0.05);
      padding-left: 0;
      list-style: none;
      text-align: right;
      font-size: 14px;
      color: #2D2D2D;
      z-index: 3000;

      li {
        height: 44px;
        line-height: 44px;
        padding: 0 20px;
        border-radius: 4px;

        &:first-child {
          border: 1px solid #F9FAF9;
        }
      }
    }
  }

  .popup-search {
    margin: 10px 45px 15px 10px;
    border-radius: 18px;
    background-color: #F5F5F5;
    height: 36px;

    .search-icon {
      font-size: 18px;
      color: #94959D;
    }

    .search-input {
      width: 82.5%;
      height: 36px;
      font-size: 14px;

      &:focus {
        border: 0;
      }
    }
  }

  .home-popup {
    height: 100%;
  }

  .popup-content {
    height: 88%;
  }

  .home-banner {
    padding: 15px 15px 10px 15px;

    .home-swiper {
      height: 80px;
      border-radius: 10px;
      background-image: url("../../assets/images/banner.png");
      background-size: 100% 100%;
    }
  }

  .header-back {
    width: 14px;
    height: 18px;
    margin-right: 6px;
  }

  .home-line {
    height: 5px;
    background-color: #F9FAF9;
  }

  .content-header {
    padding: 20px 15px 10px 15px;
    height: 48px;
    font-size: 18px;
    color: #4C4E5B;
    font-weight: 500;
    border-bottom: 1px solid #F5F5F5;
  }

  .content-header-icon {
    width: 14px;
    height: 12px;
  }

  .content-header-search {
    width: 15px;
    height: 15px;
  }

  .scroll-list {
    height:calc(100% - 215px);
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
  }

  .scroll-item {

    .scroll-item-top {
      height: 70px;
      border-bottom: 1px solid #F5F5F5;
      padding: 0 15px;
    }

    .item-header-text {
      font-size: 16px;
      color: #535461;
      font-weight: 500;
      max-width: 200px;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    }

    .item-header-round {
      width: 50px;
      height: 20px;
      border-radius: 10px;
      color: #27C08B;
      border: 1px solid #27C08B;
      line-height: 19px;
      font-size: 12px;
      margin-right: 5px;
      text-align: center;

      &:last-child {
        margin-right: 0;
      }
    }

    .scroll-item-bottom {
      padding: 20px 15px;
    }
  }

  ::v-deep .van-button--primary {
    border-radius: 12px;
    width: 50px;
    height: 24px;
    background-color: #1CC561;
  }

  .text-color-green {
    color: #1CC561;
  }

  .text-color-gray {
    color: #AEAEAE;
  }

  .text-color-black {
    color: #2D2D2D;
  }

  .sort-popup {

    .sort-popup-item {
      padding: 0 15px;
      height: 50px;
      text-align: center;
      font-size: 14px;
      color: #2D2D2D;
      line-height: 50px;
      border-bottom: 1px solid #F5F5F5;

      &.cancel-btn {
        border-bottom: 0;
        color: #878787;
      }
    }
  }

  .home-toast {
    top: 10px;
    position: fixed;
    z-index: 3000;
    width: 92%;
    min-height: 45px;
    border-radius: 6px;
    background-color: #D03F56;
    color: white;
    font-size: 14px;
    line-height: 45px;
    padding: 0 17px;
  }

  .toast-icon {
    width: 22px;
    height: 22px;
    margin-right: 10px;
  }

  .setup-popup {
    padding: 0 15px;
  }

  .setup-popup-header {
    margin-top: 30px;
    font-size: 20px;
    color: #2D2D2D;
    font-weight: 500;
    margin-bottom: 40px;

    &.text {
      margin-bottom: 26px;
    }

    .close-icon {
      width: 16px;
      height: 16px;
    }

    .header-title {
      color: #4C4E5B;
    }
  }

  .setup-popup-desc {
    color: #878787;
  }

  .setup-popup-input {
    height: 50px;
    border-bottom: 1px solid #F5F5F5 !important;
    font-size: 16px;
  }

  .setup-popup-btn {
    height: 40px;
    line-height: 40px;
    text-align: center;
    color: white;
    font-size: 16px;
    background-color: #1CC561;
    margin-top: 20px;
  }

  ::v-deep .van-search {
    margin: 0 8px;
  }

  ::v-deep .van-field__control {
    border: 0 !important;
  }

  ::v-deep .van-checkbox__label {
    font-size: 12px;
    color: #70717C;
  }

  ::v-deep .van-button__text {
    font-size: 14px;
  }

  .contract-text {
    height: 300px !important;
    overflow-y: scroll !important;
  }

  .setup-content-text {
    height: 280px;
    overflow-y: scroll;
    margin-bottom: 10px;
    line-height: 22px;

    p {
      text-indent: 20px;
    }
  }
  .header-icon {
    width: 15px;
    height: 15px;
    margin-left: 5px;
  }
  .header-title {
    color: #4C4E5B;
  }
  .setup-popup-desc {
    color: #878787;
  }

  .setup-popup-input {
    height: 50px;
    border-bottom: 1px solid #F5F5F5 !important;
    font-size: 16px;
  }
  ::v-deep .van-cell{
    padding-left: 0;
  }
</style>
