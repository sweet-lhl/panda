<template>
  <div class="tape-label">
    <Header>
      <span slot="right" class="header-btn" @click.stop="handleSave">保存</span>
    </Header>
    <div class="flex-align-items-center flex-wrap-wrap tape-label-content">
      <div
        :class="['content-item', item.select && 'active']"
        v-for="(item, i) in labelData"
        @click.stop="handleSelectLabel(i,item)"
        :key="`content-item-li-${item}`">
        {{item.name}}
      </div>
    </div>
    <van-divider>最多选择4个标签</van-divider>
  </div>
</template>

<script>
import Header from '../../components/Header.vue';
import api from '../../api/apiModule_1';

export default {
  name: 'ContractTapeLabel',
  components: { Header },
  data() {
    return {
      labelData: [],
    };
  },
  computed: {
    userId() {
      const { userId } = this.$route.query;
      return userId;
    },
    labelList() {
      const { labelData } = this;
      // eslint-disable-next-line
      return labelData.filter((item) => {
        if (item.select) return item;
      });
    },
  },
  methods: {
    fetchLabelText() {
      const { userId } = this;
      api.followTraderInfo({ userId }).then(({ labels }) => {
        this.labelData = labels;
      });
    },
    handleSelectLabel(i, item) {
      const { labelData, labelList } = this;
      if (labelList.length <= 3) {
        labelData[i].select = !item.select;
      } else {
        if (!item.select) {
          this.$toast('最多只能选择4个标签');
        }

        labelData[i].select = false;
      }
    },
    handleSave() {
      const { labelList } = this;
      const labelKeys = labelList.map(item => item.key).join(',');
      api.followUpdateLabel({
        labelKeys,
      }).then(() => {
        this.$toast({ msg: '保存成功', type: 'success' });
      });
    },
  },
  created() {
    this.fetchLabelText();
  },
};
</script>

<style scoped lang="scss">
  .tape-label {
    height: 100%;
    background: #F9FAF9;
  }

  .header-btn {
    font-size: 14px;
    color: #1CC561;
  }

  .tape-label-content {
    margin: 40px 0 0 26px;
  }

  .content-item {
    font-size: 12px;
    padding: 4px 16px;
    border-radius: 12px;
    margin-right: 25px;
    margin-bottom: 20px;
    border: 1px solid #AEAEAE;
    color: #AEAEAE;

    &.active {
      border-color: #27C08B;
      color: #27C08B;
    }
  }

  ::v-deep .van-divider {
    margin: 0 53px;
    color: #AEAEAE;
    font-size: 12px;
    border-color: #AEAEAE;
  }
</style>
