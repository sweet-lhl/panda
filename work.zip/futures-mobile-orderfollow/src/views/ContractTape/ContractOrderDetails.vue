<template>
  <div class="order">
    <Header />
    <div class="line"></div>
      <scroll
        :data="tableData"
        :pullup="true"
        :pulldown="true"
        @pulldown="fetchPrevText"
        @pullup="fetchNextText"
        v-if="tableData.length"
        class="overflow-hidden flex-1 scroll-wrapper">
        <div>
          <ul
            v-for="item in tableData"
            :key="`order-scroll-item-${item}`"
            class="order-scroll-item"
            @click.stop="$router.push(`/contractTapeFollower?id=${item.userId}`)">
            <li class="flex-justify-content-space-between flex-align-items-center text-size-14 text-color-black">
              <P class="text-size-14 text-color-black text-weight-5">{{item.nickName}}</P>
              <svg class="icon order-scroll-icon" aria-hidden="true">
                <use xlink:href="#iconxiangyou"></use>
              </svg>
            </li>
            <li class="flex-justify-content-space-between flex-align-items-center text-size-12 margin-top-16 text-color-gray">
              <p>跟单总额</p>
              <P>跟随收益</P>
            </li>
            <li class="flex-justify-content-space-between flex-align-items-center margin-top-10 text-size-14">
              <p>{{item.totalAmount | toFixed(4)}}</p>
              <P class="text-color-green">{{item.pnlRatio | toFixedSize(fetchAccuracy.assetSize)}}</P>
            </li>
            <li class="margin-top-20 line"></li>
          </ul>
        </div>
      </scroll>
    <van-empty description="暂无数据" v-else />
  </div>
</template>

<script>
import Header from '../../components/Header.vue';
import api from '../../api/apiModule_1';
import { PagingDefaultConf } from '../../utils/constant';
import { mapState } from '../../utils/common';

export default {
  name: 'ContractOrderDetails',
  components: { Header },
  data() {
    return {
      tableData: [],
      pagination: { // 当前页、页数、总页数
        ...PagingDefaultConf,
      },
    };
  },
  computed: {
    ...mapState(['coinList']),
    fetchAccuracy() {
      const { coinList } = this;
      return coinList.find(({ coinName }) => coinName === 'USDT') || {};
    },
  },
  methods: {
    fetchTableData(tag) {
      const { pageIndex: pageNum, pageSize } = this.pagination;

      return api.followWithHenchList({
        pageNum,
        pageSize,
      }).then(({ data, totalPages }) => {
        if (tag) { // 是否刷新
          this.tableData = data;
        } else {
          this.tableData = [...this.tableData, ...data];
        }
        this.pagination.totalPages = totalPages;
      });
    },
    fetchPrevText() { // 下拉
      this.pagination.pageIndex = 1;
      this.fetchTableData(true).then(() => {
        this.$toast({ msg: '刷新成功', type: 'success' });
      });
    },
    fetchNextText() { // 上拉
      const { totalPages, pageIndex } = this.pagination;
      if (pageIndex < totalPages) {
        this.pagination.pageIndex += 1;
        this.fetchTableData(false);
      } else {
        this.$toast('没有更多数据了');
      }
    },
  },
  created() {
    this.fetchTableData(true);
  },
};
</script>

<style scoped lang="scss">
  .order {
    height: 100%;
  }

  .order-scroll {
    overflow: hidden;
  }

  .order-scroll-item {
    font-size: 12px;

    li {
      padding: 0 15px;

      &:first-child {
        padding-top: 15px;
      }

      &:last-child {
        padding: 0;
      }
    }

    .order-scroll-icon {
      width: 9px;
      height: 14px;
    }
  }

  ul {
    padding-left: 0;
  }

  .text-color-gray {
    color: #AEAEAE;
  }

  .text-color-black {
    color: #2D2D2D;
  }

  .text-color-green {
    color: #1CC561;
  }

  .gray {
    color: #878787;
  }
</style>
