<template>
  <div class="follower">
    <Header />
    <div class="line"></div>
      <div class="follower-content">
        <div
          v-for="item in tableData"
          :key="`follower-content-item-${item}`"
          class="scroll-user-item text-size-14">
          <div class="flex-direction-row flex-align-items-center user-item-layout">
            <p class="text-color-black text-weight-5">{{item.nickName}}</p>
            <span class="margin-left-10 gray">{{item.symbolName}}</span>
            <span :class="[item.isLong == 0 ? 'layout-short' : 'layout-tag']">{{item.isLong == 0 ? '空仓' : '多仓'}}</span>
          </div>
          <div class="flex-justify-content-space-between flex-align-items-center margin-top-15 margin-bottom-15 user-item-layout">
            <ul>
              <li class="text-color-gray text-size-12">开仓价</li>
              <li class="text-color-black text-weight-5 margin-top-10">{{item.avgPrice | toFixedSize(accuracy[item.symbolId].tickSize)}}</li>
            </ul>
            <ul class="text-align-right">
              <li class="text-color-gray text-size-12">持仓量(张)</li>
              <li class="text-color-black text-weight-5 margin-top-10">{{item.total}}</li>
            </ul>
            <ul class="text-align-right">
              <li class="text-color-gray text-size-12">收益率</li>
              <li class="text-color-black text-weight-5 margin-top-10">{{item.profitRate | percent}}%</li>
            </ul>
          </div>
          <div class="flex-justify-content-space-between flex-align-items-center user-item-footer">
            <p>保证金率：{{item.marginRate | percent}}%</p>
            <p>强平价格：{{item.liquidationPrice | toFixedSize(accuracy[item.symbolId].tickSize)}}</p>
          </div>
          <div class="line"></div>
        </div>
        <van-empty description="暂无数据" v-if="tableData.length === 0" />
      </div>
  </div>
</template>

<script>
import Header from '../../components/Header.vue';
import api from '../../api/apiModule_1';

export default {
  name: 'ContractTapeFollower',
  components: { Header },
  data() {
    return {
      tableData: [],
      accuracy: '',
    };
  },
  computed: {
    fetchId() {
      const { id } = this.$route.query;
      return id;
    },
  },
  methods: {
    fetchFuturesAccuracy() {
      api.futuresAccuracy()
        .then((r) => {
          this.accuracy = r;
        });
    },
    fetchTableData() {
      const { fetchId } = this;

      api.followWithPositions({
        userId: fetchId,
      }).then((data) => {
        this.tableData = data;
      });
    },
  },
  created() {
    this.fetchFuturesAccuracy();
    this.fetchTableData();
  },
};
</script>

<style scoped lang="scss">
  .follower {
    height: 100%;
  }

  .follower-content {
    height: 92%;
    overflow-y: scroll;
  }

  .user-item-layout {
    padding: 0 15px;
  }

  .scroll-user-item {
    padding-top: 22px;

    .layout-tag {
      width: 30px;
      height: 18px;
      text-align: center;
      line-height: 18px;
      color: #1CC561;
      background:rgba(28,197,97,.1);
      font-size: 12px;
      margin-left: 6px;
    }

    .layout-short {
      background:rgba(233,85,111,.1);
      color: #E9556F;
      font-size: 12px;
      margin-left: 6px;
      width: 30px;
      height: 18px;
      text-align: center;
      line-height: 18px;
    }

    .user-item-footer {
      font-size: 12px;
      color: #878787;
      border-top: 1px solid #F5F5F5;
      padding: 10px 0;
      margin: 0 15px;
    }
  }

  .text-color-gray {
    color: #AEAEAE;
  }

  .text-color-black {
    color: #2D2D2D;
  }

  .text-color-green {
    color: #1CC561;
  }

  .gray {
    color: #878787;
  }

  ul {
    padding-left: 0;
  }
</style>
