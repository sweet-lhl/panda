<template>
  <div class="setup">
    <Header />
    <div class="line"></div>
    <div class="flex-justify-content-space-between flex-align-items-center setup-layout">
      <p class="layout-text">开启带单</p>
      <van-switch v-model="isChecked" active-color="#07c160" inactive-color="#ECEDED" size="26px" @change="handleChangeStatus" />
    </div>
    <div class="flex-justify-content-space-between flex-align-items-center setup-layout" @click.stop="$router.push(`/contractTapeLabel?userId=${userId}`)">
      <p class="layout-text">选择标签</p>
      <svg class="icon layout-icon" aria-hidden="true">
        <use xlink:href="#iconxiangyou"></use>
      </svg>
    </div>
  </div>
</template>

<script>
import Header from '../../components/Header.vue';
import api from '../../api/apiModule_1';

export default {
  name: 'ContractTapeSetUp',
  components: { Header },
  data() {
    return {
      isChecked: false,
    };
  },
  computed: {
    userId() {
      const { userId } = this.$route.query;
      return userId;
    },
  },
  created() {
    this.fetchUserTraderInfo();
  },
  methods: {
    handleChangeStatus() {
      const { isChecked } = this;
      api.followUpdateShowStatus({
        showStatus: isChecked ? 1 : 0,
      }).then(() => {
        this.$toast({ msg: `${isChecked ? '打开成功' : '关闭成功'}`, type: 'success' });
      }).catch((e) => {
        if (e) this.fetchUserTraderInfo();
      });
    },
    fetchUserTraderInfo() {
      const { userId } = this.$route.query;
      api.followTraderInfo({ userId })
        .then(({ showStatus }) => {
          this.isChecked = showStatus === 1;
        });
    },
  },
};
</script>

<style scoped lang="scss">
  .setup {
    height: 100%;
    background: #F9FAF9;
  }

  .setup-layout {
    padding: 0 15px;
    border-bottom: 1px solid #F1F5FC;
    font-size: 15px;
    color: #878787;
    background-color: #ffffff;

    &:last-child {
      border-bottom: 0;
    }

    .layout-text {
      margin: 20px 0;
    }
  }

  ::v-deep .van-switch {
    width: 50px;
  }

  .layout-icon {
    width: 7px;
    height: 12px;
  }
</style>
