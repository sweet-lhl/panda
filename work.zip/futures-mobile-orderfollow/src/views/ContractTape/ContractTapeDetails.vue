<template>
  <div class="flex-direction-column details">
    <Header :headerTitle="title" />
    <header class="details-user">
      <div class="flex-justify-content-space-between flex-align-items-center header-layout">
        <div class="flex-direction-row flex-align-items-center user-title">
          <div class="avatar" :style="`background: ${headData.colour}`">{{userName}}</div>
          <p class="header-text">{{headData.nickName}}</p>
          <svg class="icon header-icon" aria-hidden="true" v-if="headData.level === 2">
            <use xlink:href="#iconyirenzheng"></use>
          </svg>
        </div>
        <van-button round type="primary" size="mini" @click.stop="$router.push({ name: 'SettingsEdit', query: { tradeUserId:userId}, params:{nickName:headData.nickName}})">跟单</van-button>
      </div>
      <div v-if="labelList.length">
        <div class="header-label">个人标签</div>
        <div class="flex-direction-row flex-align-items-center header-bottom">
          <div :class="[item.select && 'header-item']" v-for="item in labelList" :key="`header-label-${item}`">
            <P v-if="item.select">{{item.name}}</P>
          </div>
        </div>
      </div>
    </header>
    <div class="line"></div>
    <div class="details-content">
      <div class="flex-justify-content-space-between flex-align-items-center content-layout">
        <ul>
          <li class="text-size-18 text-weight-6">{{headData.cumulativePnlRatio | percent}}%</li>
          <li class="margin-top-4 text-size-12 text-color-gray">累计收益率</li>
          <li class="margin-top-20 text-size-18 text-weight-6">{{headData.tradeDays||0}}</li>
          <li class="text-size-12 text-color-gray margin-top-3">交易天数</li>
        </ul>
        <ul class="text-align-right">
          <li class="text-size-18 text-weight-6">{{headData.tradeSuccessRatio | percent}}%</li>
          <li class="margin-top-4 text-size-12 text-color-gray">近3周交易胜率</li>
          <li class="margin-top-20 text-size-18 text-weight-6">{{headData.tradeCount}}</li>
          <li class="text-size-12 text-color-gray margin-top-3">交易笔数</li>
        </ul>
        <ul class="text-align-right">
          <li class="text-size-18 text-weight-6 text-color-green">{{headData.maxDrawdown | percent}}%</li>
          <li class="margin-top-4 text-size-12 text-color-gray">近3周最大回撤</li>
          <li class="margin-top-20 text-size-18 text-weight-6 text-color-green">{{headData.followerCount}}</li>
          <li class="text-size-12 text-color-gray margin-top-3">累计跟随人数</li>
        </ul>
      </div>
      <div class="flex-direction-row flex-align-items-center content-text">
        <span class="line-height-1">跟单利润分成比例：{{headData.tradeRatio | percent}}%</span>
        <svg class="icon content-icon" aria-hidden="true" @click.stop="handleMessage">
          <use xlink:href="#iconwenhao"></use>
        </svg>
      </div>
    </div>
    <div class="line"></div>
    <div class="flex-direction-row scroll-list-title">
      <div class="flex-direction-column">
        <span :class="['title-text', tabIndex === 'first' && 'active', 'margin-right-20']" @click.stop="tabIndex = 'first'">历史订单</span>
        <span :class="[tabIndex === 'first' && 'tab-line']"></span>
      </div>
      <div class="flex-direction-column">
        <span :class="['title-text', tabIndex === 'second' && 'active', 'margin-right-20']" @click.stop="tabIndex = 'second'">跟随者</span>
        <span :class="[tabIndex === 'second' && 'tab-line']"></span>
      </div>
    </div>
    <div class="scroll-content" :style="{height:labelList.length?'calc(100% - 442px)':'calc(100% - 355px)'}">
      <scroll
        :data="tableData"
        :pullup="true"
        :pulldown="true"
        @pulldown="fetchPrevText"
        @pullup="fetchNextText"
        v-if="tableData.length"
        class="overflow-y-auto flex-1 scroll-wrapper">
        <div v-if="tabIndex === 'first'">
          <div class="scroll-item"
               v-for="item in tableData"
               :key="`scroll-item-li-first-${item}`">
            <div class="flex-justify-content-space-between flex-align-items-center scroll-item-header">
              <div>
                <label class="line-height-1 text-size-14 text-weight-6">{{item.symbolName}}</label>
                <span :class="[(item.side || '').includes('BUY') ? 'scroll-item-desc' : 'scroll-item-empty' ]">{{item.side | typeSide}}</span>
              </div>
              <p>开仓时间：{{Number(item.time) | timeStampToDate}}</p>
            </div>
            <div class="flex-justify-content-space-between flex-align-items-center scroll-item-content">
              <ul>
                <li class="text-size-12 text-color-gray">平仓价</li>
                <li class="margin-top-10 text-size-14 text-weight-6">{{item.price | toFixedSize(accuracy[item.symbolId].tickSize)}}</li>
              </ul>
              <ul class="text-align-right">
                <li class="text-size-12 text-color-gray">平仓数量</li>
                <li class="margin-top-10 text-size-14 text-weight-6">{{item.amount | toFixedSize(accuracy[item.symbolId].stepSize)}}</li>
              </ul>
              <ul class="text-align-right">
                <li class="text-size-12 text-color-gray">收益</li>
                <li class="margin-top-10 text-size-14 text-weight-6 text-color-green">{{item.pnl | toFixedSize(accuracy[item.symbolId].quoteCoindNameAssetSize)}}</li>
              </ul>
            </div>
            <div class="line"></div>
          </div>
        </div>
        <div v-else>
          <div class="flex-direction-column scroll-item-follower"
               v-for="item in tableData"
               :key="`scroll-item-li-second-${item}`">
            <span class="text-size-14 text-weight-6 follower-title">{{item.userNickName}}</span>
            <div class="flex-justify-content-space-between flex-align-items-center follower-text">
              <p>跟单总额</p>
              <P>收益</P>
            </div>
            <div class="flex-justify-content-space-between flex-align-items-center follower-footer">
              <P class="text-size-14 text-weight-6">{{item.totalAmount | toFixed(4)}} USDT</P>
              <P class="text-size-14 text-weight-6 text-color-green">{{item.cumulativePnl | toFixedSize(fetchAccuracy.assetSize)}}</P>
            </div>
            <div class="line"></div>
          </div>
        </div>
      </scroll>
      <van-empty description="暂无数据" v-if="tableData.length === 0"/>
    </div>
  </div>
</template>

<script>
import Header from '../../components/Header.vue';
import api from '../../api/apiModule_1';
import { mapState } from '../../utils/common';
import { PagingDefaultConf } from '../../utils/constant';
import fill from '../../plugins/filters';

export default {
  name: 'ContractTapeDetails',
  components: { Header },
  data() {
    return {
      tabIndex: 'first',
      headData: {},
      pagination: {
        ...PagingDefaultConf,
        totalPage: 0,
      },
      tableData: [],
      accuracy: '',
    };
  },
  computed: {
    ...mapState(['userInfo', 'coinList']),
    fetchAccuracy() {
      const { coinList } = this;
      return coinList.find(({ coinName }) => coinName === 'USDT') || {};
    },
    userId() {
      const { userId } = this.$route.query;
      return userId;
    },
    userName() {
      const { headData } = this;
      return headData.nickName?.substr(0, 1);
    },
    labelList() {
      const { labels = [] } = this.headData;
      // eslint-disable-next-line
          return labels.filter((item) => {
        if (item.select) return item;
      });
    },
  },
  watch: {
    tabIndex: {
      handler(n, o) {
        if (n !== o) {
          this.tableData = [];
          this.pagination = {
            ...PagingDefaultConf,
          };
          this.fetchTableData(true);
        }
      },
    },
  },
  methods: {
    fetchUserTraderInfo() {
      const { userId } = this;
      api.followTraderInfo({ userId })
        .then((r) => {
          this.headData = r;
        });
    },
    fetchFuturesAccuracy() {
      api.futuresAccuracy()
        .then((r) => {
          this.accuracy = r;
        });
    },
    fetchPrevText() { // 下拉
      this.pagination.pageIndex = 1;
      this.fetchTableData(true).then(() => {
        this.$toast({ msg: '刷新成功', type: 'success' });
      });
    },
    fetchNextText() { // 上拉
      const { totalPages, pageIndex } = this.pagination;
      if (pageIndex < totalPages) {
        this.pagination.pageIndex += 1;
        this.fetchTableData(false);
      } else {
        this.$toast('没有更多数据了');
      }
    },
    fetchTableData(tag) {
      const { tabIndex, userId } = this;
      const { pageIndex: pageNum, pageSize } = this.pagination;

      return api[tabIndex === 'first'
        ? 'followGetHistoryOrders'
        : 'followFollowers']({
        tradeUserId: userId,
        pageNum,
        pageSize,
      }).then(({ data, totalPages }) => {
        if (tag) { // 是否刷新
          this.tableData = data;
        } else {
          this.tableData = [...this.tableData, ...data];
        }
        this.pagination.totalPages = totalPages;
      });
    },
    handleMessage() {
      this.$toast({
        type: 'info',
        msg: `跟随后，系统将按天统计跟单收益，当天跟随订单扣除所有费用后的净利润，将有${fill.filters.percent(this.headData.tradeRatio)}%作为带单奖励分享给该交易员。`,
      });
    },
  },
  created() {
    this.fetchUserTraderInfo();
    this.fetchFuturesAccuracy();
    this.fetchTableData(true);
  },
};
</script>

<style scoped lang="scss">
  .details {
    height: 100%;
  }

  .details-user {
    padding: 0 15px;
  }

  .header-layout {
    margin-top: 12px;
    border-bottom: 1px solid #F5F5F5;
    padding-bottom: 10px;
  }
  .user-title{
    width: 77%;
  }

  .header-text {
    font-size: 20px;
    color: #2D2D2D;
    font-weight: 600;
    margin-left: 10px;
    max-width: 68%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }

  .header-icon {
    width: 15px;
    height: 15px;
    margin-left: 10px;
  }

  ::v-deep .van-button--primary {
    background-color: #1CC561;
    border: 1px solid #1CC561;
  }

  .header-label {
    margin-top: 20px;
    color: #AEAEAE;
    font-size: 12px;
  }

  .header-bottom {
    margin-top: 10px;
    margin-bottom: 20px;
  }

  .header-item {
    padding: 4px 16px;
    border: 1px solid #27C08B;
    border-radius: 10px;
    font-size: 12px;
    color: #27C08B;
    margin-right: 5px;

    &:last-child {
      margin-right: 0;
    }
  }

  .item-icon {
    width: 14px;
    height: 10px;
    margin-right: 3px;
  }

  .details-content {
    padding: 20px 25px;

    ul {
      padding-left: 0;
      margin-bottom: 20px;
    }

    .content-layout {
      border-bottom: 1px solid #F5F5F5;
    }
  }

  .text-color-gray {
    color: #AEAEAE;
  }

  .text-color-green {
    color: #1CC561;
  }

  .content-text {
    font-size: 12px;
    color: #878787;
    margin-top: 15px;
  }

  .content-icon {
    width: 14px;
    height: 14px;
    margin-left: 10px;
  }

  .scroll-content {
    /*height: 33.6%;*/
    height: calc(100% - 156px - 185px - 30px);
    overflow: hidden;
  }

  .scroll-list-title {
    padding: 0 15px;
    margin-top: 24px;

    .title-text {
      font-size: 14px;
      color: #878787;

      &.active {
        font-weight: 600;
        color: #2D2D2D;
        font-size: 16px;
      }
    }

    .tab-line {
      height: 2px;
      width: 30px;
      margin-top: 5px;
      background-color: #2D2D2D;
    }
  }

  .scroll-item {

    .scroll-item-header {
      margin: 22px 15px 0 15px;
      padding-bottom: 12px;
      border-bottom: 1px solid #F5F5F5;
      p{
        color: #878787;
      }
      label{
        color: #2D2D2D;
      }
    }

    .scroll-item-desc {
      padding: 2px 3px;
      background:rgba(28,197,97,.1);
      text-align: center;
      color: #1CC561;
      font-size: 12px;
      border-radius: 2px;
      margin-left: 5px;
    }

    .scroll-item-empty {
      background:rgba(233,85,111,.1);
      color: #E9556F;
      padding: 2px 3px;
      text-align: center;
      font-size: 12px;
      border-radius: 2px;
      margin-left: 5px;
    }
  }

  .scroll-item-content {
    padding: 20px 15px 20px 15px;
    border-bottom: 1px solid #F5F5F5;

    ul {
      padding-left: 0;
    }
  }

  .scroll-item-follower {
    margin: 20px 0;

    .follower-title {
      padding: 0 15px;
      color: #2D2D2D;
      margin-bottom: 17px;
    }

    .follower-text {
      padding: 0 15px;
      font-size: 12px;
      color: #AEAEAE;
      margin-bottom: 10px;
    }

    .follower-footer {
      padding: 0 15px;
      margin-bottom: 20px;
      font-weight:500;
    }
  }

  ::v-deep .van-empty__image {
    width: 100px;
    height: 100px;
  }

  ::v-deep .van-button {
    font-size: 12px;
  }
</style>
