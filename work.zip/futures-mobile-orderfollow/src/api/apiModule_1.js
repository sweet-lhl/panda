import http from '../plugins/http';
import { Joi } from '../utils/common';
// import store from '../store';
import schemas from './schemas';

const version = 'v1'; // https://www.panda.co/api/v1/test
const key = `api/futures/${version}`;

const api = http[key] || http.instance(key); // api modules.test

class Service {
  api = api;

  // 需要验证参数的接口请使用@validate装饰器同步抛出错误给下一层业务组件
  // 不关心返回状态的api,可直接返回api的promise，无需重复书写async功能函数
  // @validate(schemas.test) // 可以在此处验证参数
  test(params) {
    // 进行参数验证的promise，在then方法回调里必须返回一个新的promise对象，否则会导致请求失败后走成功(then)方法，期望去catch处理异常。
    // return this.api.post('/news', params);
    return Joi.validate(params, schemas.test).then(values => this.api.post('/news', values));
  }

  manageList(params) { // 【跟随者】跟单管理
    return this.api.get('/follow/manage/list', { params });
  }

  agreementTreaty(params) { // 同意跟单协议
    return this.api.get('/follow/agreementFollowOrderTreaty', { params });
  }

  setNickName(params) { // 设置昵称
    return this.api.get('/follow/setNickName', { params });
  }

  follow(params) { // 【跟随者】进行跟单
    return this.api.get('/follow/follow', { params });
  }

  cancelFollow(params) { // 【跟随者】取消跟单
    return this.api.get('/follow/cancelFollow', { params });
  }

  cancelAllFollow(params) { // 【跟随者】一键取消全部跟单
    return this.api.get('/follow/cancelAllFollow', { params });
  }

  followInfo(params) { // 【跟随者】查询跟单设置
    return this.api.get('/follow/followInfo', { params });
  }

  getConfigParms(params) { // 跟单系统参数
    return this.api.get('/follow/getConfigParms', { params });
  }

  updateFollow(params) { // 【跟随者】更新跟单设置
    return this.api.get('/follow/updateFollow', { params });
  }

  uploadFile(params) {
    this.api.post('/upload/file', params);
  }

  quotationHistory(params, cancelToken) {
    this.api.post('/quotation/history', params, { cancelToken });
  }

  followTraders(params) { // 交易员榜单（排行）
    return this.api.get('/follow/traders', { params });
  }

  futuresPrecision() { // 合约币种精度
    return this.api.get('/precision');
  }

  futuresAccuracy() { // 合约币种精度
    return this.api.get('/futuresAccuracy');
  }

  followFuturesUserInfo() { // 用户信息
    return this.api.get('/follow/futuresUserInfo');
  }

  homeOpenTreaty() { // 开通合约协议
    return this.api.get('/home/openTreaty');
  }

  accountOpen() { // 开通合约
    return this.api.post('/account/open');
  }

  agreementFollowOrderTreaty() { // 同意跟单协议
    return this.api.get('/follow/agreementFollowOrderTreaty');
  }

  followWithStatistics(params) { // 带单管理统计
    return this.api.get('/follow/with/statistics', { params });
  }

  followWithPnlList(params) { // 带单管理收益明细
    return this.api.get('follow/with/pnlList', { params });
  }

  followUpdateShowStatus(params) { // 交易员更新状态
    return this.api.get('/follow/updateShowStatus', { params });
  }

  applyTrader(params) { // 【交易者==】交易员申请
    return this.api.get('/follow/applyTrader', { params });
  }

  followTraderInfo(params) { // 交易员信息
    return this.api.get('/follow/traderInfo', { params });
  }

  followWithHenchList(params) { // 带单详情-当前跟随者
    return this.api.get('/follow/with/henchList', { params });
  }

  followWithPositions(params) { // 带单详情跟随者仓位
    return this.api.get('/follow/with/positions', { params });
  }

  followGetHistoryOrders(params) { // 交易员的历史订单
    return this.api.get('/follow/getHistoryOrders', { params });
  }

  followFollowers(params) { // 交易员的跟随者
    return this.api.get('/follow/followers', { params });
  }

  followUpdateLabel(params) { // 交易员更新标签
    return this.api.get('/follow/updateLabel', { params });
  }
}

export default new Service();
