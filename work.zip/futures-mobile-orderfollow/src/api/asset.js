import http from '../plugins/http';

const version = 'v1'; // https://www.panda.co/api/v1/test
const key = `api/${version}`;

const api = http[key] || http.instance(key); // api modules.test

class Service {
  api = api;

  userInfo() {
    return this.api.post('/user/info');
  }
}

export default new Service();
