// import api from '../../api/apiModule_1';

/* eslint no-param-reassign: ["error", {
      "props": true,
      "ignorePropertyModificationsFor": ["state"]
    }] */

export default {
  namespaced: true,
  state: {
    msg: 'this is about page',
  },
  mutations: {

  },
  actions: {

  },
};
