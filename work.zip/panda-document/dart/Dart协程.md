> 当需要延迟生成值序列时，请考虑使用`generator`函数。

###### 有两种方法生成`generator`函数：

1. 同步生成器：返回一个[Iterable](https://api.dart.dev/stable/dart-core/Iterable-class.html)对象。
2. 异步生成器：返回一个[Stream](https://api.dart.dev/stable/dart-async/Stream-class.html)对象。

###### 要实现同步generator功能，请将功能主体标记为`sync *`，并使用`yield`语句传递值：

```dart
Iterable<int> naturalsTo(int n) sync* {
  int k = 0;
  while (k < n) yield k++;
}
```

###### 要实现异步generator函数，请将函数主体标记为`async *`，并使用`yield`语句传递值：

```dart
Stream<int> asynchronousNaturalsTo(int n) async* {
  int k = 0;
  while (k < n) yield k++;
}
```

###### 如果generator是递归的，则可以使用`yield *`来提高其性能：

```dart
Iterable<int> naturalsDownFrom(int n) sync* {
  if (n > 0) {
    yield n;
    yield* naturalsDownFrom(n - 1);
  }
}
```
