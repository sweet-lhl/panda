> `typedef`或函数类型别名有助于定义指向内存中可执行代码的指针。简而言之，可以将`typedef`用作引用函数的指针。

> 当将函数类型分配给变量时，typedef会保留类型信息。

#### 实现typedef的步骤

1. 定义一个typedef。

    > typedef可用于指定我们希望特定功能匹配的功能签名。函数签名由函数的参数（包括其类型）定义。返回类型不是函数签名的一部分。
    
    ```dart
    typedef function_name(parameters)
    ```

2. 将函数分配给typedef变量。

    > typedef变量可以指向具有与typedef相同签名的任何函数。您可以使用以下签名将函数分配给typedef变量。
    
    ```dart
    type_def  var_name = function_name
    ```

3. 调用功能。

    > typedef变量可用于调用函数。这是调用函数的方法:
    
    ```dart
    var_name(parameters)
    ```

#### 示例

###### 1. 首先，让我们定义一个`typedef`。在这里，我们定义一个函数签名。该函数将使用两个整数类型的输入参数。返回类型不是函数签名的一部分。

```dart
typedef ManyOperation(int firstNo , int secondNo); //function signature
```

###### 2. 接下来，让我们定义功能。定义一些具有与`ManyOperation typedef`相同的函数签名的函数。

```dart
Add(int firstNo,int second){ 
   print("Add result is ${firstNo+second}"); 
}  
Subtract(int firstNo,int second){ 
   print("Subtract result is ${firstNo-second}"); 
}  
Divide(int firstNo,int second){ 
   print("Add result is ${firstNo/second}"); 
}
```

###### 3. 最后，我们将通过`typedef`调用该函数。声明一个`ManyOperations`类型的变量。将函数名称分配给声明的变量。

```dart
ManyOperation oper ;  

// 可以指向任何具有相同签名的方法
oper = Add; 
oper(10,20); 
oper = Subtract; 
oper(30,20); 
oper = Divide; 
oper(50,5); 
```

###### `oper`变量可以指向采用两个整数参数的任何方法。`Add`函数的引用已分配给该变量。Typedef可以在运行时切换函数引用。

现在让我们将所有部分放在一起，看看完整的程序：

```dart
typedef ManyOperation(int firstNo , int secondNo); 
//function signature  

Add(int firstNo,int second){ 
   print("Add result is ${firstNo+second}"); 
} 
Subtract(int firstNo,int second){ 
   print("Subtract result is ${firstNo-second}"); 
}
Divide(int firstNo,int second){ 
   print("Divide result is ${firstNo/second}"); 
}  
Calculator(int a, int b, ManyOperation oper){ 
   print("Inside calculator"); 
   oper(a,b); 
}  
void main(){ 
   ManyOperation oper = Add; 
   oper(10,20); 
   oper = Subtract; 
   oper(30,20); 
   oper = Divide; 
   oper(50,5); 
} 
```

###### 该程序应产生以下输出-

```dart
Add result is 30 
Subtract result is 10 
Divide result is 10.0 
```

###### `Typedef`也可以作为参数传递给函数。考虑以下示例-

```dart
typedef ManyOperation(int firstNo , int secondNo);   //function signature 
Add(int firstNo,int second){ 
   print("Add result is ${firstNo+second}"); 
}  
Subtract(int firstNo,int second){
   print("Subtract result is ${firstNo-second}"); 
}  
Divide(int firstNo,int second){ 
   print("Divide result is ${firstNo/second}"); 
}  
Calculator(int a,int b ,ManyOperation oper){ 
   print("Inside calculator"); 
   oper(a,b); 
}  
main(){ 
   Calculator(5,5,Add); 
   Calculator(5,5,Subtract); 
   Calculator(5,5,Divide); 
} 
```

它将产生以下输出-

```dart
Inside calculator 
Add result is 10 
Inside calculator 
Subtract result is 0 
Inside calculator 
Divide result is 1.0
```