#### 数据类型

1. numbers
  - property
    + int hashCode `返回数字的哈希码`
    + bool isFinite `如果数量有限，则为true；否则为false`
    + bool isInfinite `如果数字是正无穷大或负无穷大，则为true；否则为false`
    + bool isNaN `如果数字是非数字双精度值，则为true；否则为false`
    + bool isNegative `如果数字为负，则为true；否则为false`
    + num sign `根据数字的符号和数值，返回-1，0或加+1`
    + Type runtimeType `对象的运行时类型的表示形式`
  - methods
    + num abs() `返回this的绝对值`
    + int ceil() `返回不小于this的下一个最小整数`
    + double ceilToDouble() `返回不小于this的下一个最小双精度整数值`
    + num clamp(num lowerLimit, num upperLimit) `返回this钳位在范围lowerLimit - upperLimit`
    + int compareTo(num other) `与this相比较`
    + int floor() `返回不大于this的最大整数`
    + double floorToDouble() `返回不大于this的双精度整数值`
    + num remainder(num other) `此操作的结果r满足： this == (this ~/ other) * other + r`
    + int round() `返回最接近this的整数[四舍五入]`
    + double roundToDouble() `返回最接近this的双精度整数值`
    + double toDouble() `将this作为double返回`
    + int toInt() `将this截断为整数，并将结果作为int返回`
    + String toString() `将this转换为字符串类型并返回`
    + String toStringAsExponential([int fractionDigits])
    + String toStringAsFixed(int fractionDigits)
    + String toStringAsPrecision(int precision);
    + int truncate()
    + double truncateToDouble()
  - static
    + num num.parse()
    + num num.tryParse()
  - operators
    + num operator %(num other)
    + num operator *(num other)
    + num operator +(num other)
    + num operator -(num other)
    + double operator /(num other)
    + bool operator <(num other)
    + bool operator <=(num other)
    + bool operator ==(Object other)
    + bool operator >(num other)
    + bool operator >=(num other)
    + num operator unary-()
    + int operator ~/(num other)
2. strings
  - properties
    + List<int> codeUnits
    + int hashCode
    + bool isEmpty
    + bool isNotEmpty
    + int length
    + Runes runes
    + Type runtimeType
  - methods
    + int codeUnitAt(int index)
    + int compareTo(String other)
    + bool contains(Pattern other, [ int startIndex = 0 ])
    + bool endsWith(String other)
    + int indexOf(Pattern pattern, [ int start ])
    + int lastIndexOf(Pattern pattern, [ int start ])
    + String padLeft(int width, [ String padding = ' ' ])
    + String padRight(int width, [ String padding = ' ' ])
    + String replaceAll(Pattern from, String replace)
    + String replaceAllMapped(Pattern from, String replace(Match match))
    + String replaceFirst(Pattern from, String to, [ int startIndex = 0 ])
    + String replaceFirstMapped(Pattern from, String replace(Match match), [ int startIndex = 0 ])
    + String replaceRange(int start, int end, String replacement)
    + List<String> split(Pattern pattern)
    + String splitMapJoin(Pattern pattern, { String onMatch(Match match), String onNonMatch(String nonMatch) })
    + bool startsWith(Pattern pattern, [ int index = 0 ])
    + String substring(int startIndex, [ int endIndex ])
    + String toLowerCase()
    + String toUpperCase() 
    + String trim()
    + String trimLeft()
    + String trimRight()
    + Match Iterable<Match> allMatches(String string, [ int start = 0 ])
    + Match matchAsPrefix(String string, [ int start = 0 ])
    + String toString()
  - constructors
    + String.fromCharCode(int charCode)
    + String.fromCharCodes(Iterable<int> charCodes, [ int start = 0 int end ])
    + String.fromEnvironment(String name, { String defaultValue })
  - operators
    + String operator *(int times)
    + String operator +(String other)
    + bool operator ==(Object other)
    + String operator [](int index)
3. booleans
  - properties
    + int hashCode
    + Type runtimeType
  - methods
    + String toString()
  - operators
    + bool operator &(bool other)
    + bool operator ^(bool other)
    + bool operator |(bool other)
    + bool operator ==(dynamic other)
  - constructors
    + bool.fromEnvironment(String name, { bool defaultValue: false })
4. lists (或者称之为数组[arrays])
  - properties
    + E first
    + E last
    + int length
    + Iterable<E> reversed
    + int hashCode
    + bool isEmpty
    + bool isNotEmpty
    + Iterator<E> iterator
    + Type runtimeType
    + E single
  - methods
    + void add(E value)
    + void addAll(Iterable<E> iterable)
    + Map<int, E> asMap()
    + List<R> cast<R>()
    + void clear()
    + void fillRange(int start, [ int end, [ E fillValue ])
    + Iterable<E> getRange(int start int end)
    + int indexOf(E element, [ int start = 0 ])
    + int indexWhere(bool test(E element), [ int start = 0 ])
    + void insert(int index, E element)
    + void insertAll(int index, Iterable<E> iterable)
    + int lastIndexOf(E element, [ int start ])
    + int lastIndexWhere(bool test(E element), [ int start ])
    + bool remove(Object value)
    + E removeAt(int index)
    + E removeLast()
    + viod removeRange(int start int end)
    + viod removeWhere(bool test(E element))
    + viod replaceRange(int start, int end, Iterable<E> replacement)
    + viod retainWhere(bool test(E element))
    + viod setAll(int index, Iterable<E> iterable)
    + viod setRange(int start, int end, Iterable<E> iterable, [ int skipCount = 0 ])
    + void shuffle([Random random ])
    + void sort([int compare(E a E b) ])
    + List<E> sublist(int start, [ int end ])
    + bool any(bool test(E element))
    + bool contains(Object element)
    + E elementAt(int index)
    + bool every(bool test(E element))
    + Iterable<T> expand<T>(Iterable<T> f(E element))
    + E firstWhere(bool test(E element), { E orElse() })
    + T old<T>(T initialValue, T combine(T previousValue, E element))
    + Iterable<E> followedBy(Iterable<E> other)
    + void forEach(void f(E element))
    + String join([String separator = "" ])
    + E lastWhere(bool test(E element), { E orElse() })
    + Iterable<T> map<T>(T f(E e))
    + E reduce(E combine(E value E element))
    + E singleWhere(bool test(E element), { E orElse() })
    + Iterable<E> skip(int count)
    + Iterable<E> skipWhile(bool test(E value))
    + Iterable<E> take(int count)
    + Iterable<E> takeWhile(bool test(E value))
    + List<E> toList({bool growable: true })
    + Set<E> toSet()
    + String toString()
    + Iterable<E> where(bool test(E element))
    + Iterable<T> whereType<T>()
  - operators
    + List<E> operator +(List<E> other)
    + bool operator ==(Object other)
    + E operator [](int index)
    + void operator []=(int index, E value)
  - static
    + List<T> `castFrom<S, T>(List<S> source)`
    + void copyRange<T>(List<T> target, [ int at, List<T> source, [ int start int end ])
    + void writeIterable<T>(List<T> target, int at, Iterable<T> source)
  - constructors
    + List([int length ])
    + List.filled(int length, E fill, { bool growable: false })
    + List.from(Iterable elements, { bool growable: true })
    + List.generate(int length, E generator(int index), { bool growable: true })
    + List.of(Iterable<E> elements, { bool growable: true })
    + List.unmodifiable(Iterable elements)
5. sets
  - constructors
    + Set()
    + Set.from(Iterable elements)
    + Set.identity()
    + Set.of(Iterable<E> elements)
  - properties
    + Iterator<E> iterator
    + E first
    + int hashCode
    + bool isEmpty
    + bool isNotEmpty
    + E last
    + int length
    + Type runtimeType
    + E single
  - methods
    + bool add(E value)
    + void addAll(Iterable<E> elements)
    + Set<R> cast<R>()
    + void clear()
    + bool contains(Object value)
    + bool containsAll(Iterable<Object> other)
    + Set<E> difference(Set<Object> other)
    + Set<E> intersection(Set<Object> other)
    + E lookup(Object object)
    + bool remove(Object value)
    + void removeAll(Iterable<Object> elements)
    + void removeWhere(bool test(E element))
    + void retainAll(Iterable<Object> elements)
    + void retainWhere(bool test(E element))
    + Set<E> toSet() 
    + Set<E> union(Set<E> other)
    + bool any(bool test(E element))
    + E elementAt(int index)
    + bool every(bool test(E element))
    + Iterable<T> expand<T>(Iterable<T> f(E element))
    + E firstWhere(bool test(E element), { E orElse() })
    + T fold<T>(T initialValue, T combine(T previousValue, E element))
    + Iterable<E> followedBy(Iterable<E> other)
    + void forEach(void f(E element))
    + String join([String separator = "" ])
    + E lastWhere(bool test(E element), { E orElse() })
    + Iterable<T> map<T>(T f(E e))
    + E reduce(E combine(E value E element))
    + E singleWhere(bool test(E element), { E orElse() })
    + Iterable<E> skip(int count)
    + Iterable<E> skipWhile(bool test(E value))
    + Iterable<E> take(int count)
    + Iterable<E> takeWhile(bool test(E value))
    + List<E> toList({bool growable: true })
    + String toString()
    + Iterable<E> where(bool test(E element))
    + Iterable<T> whereType<T>()
  - operators
    + bool operator ==(dynamic other)
  - static
    + Set<T> `castFrom<S, T>(Set<S> source, { Set<R> newSet() })`
5. maps
  - constructors
    + Map()
    + Map.from(Map other)
    + Map.fromEntries(Iterable<MapEntry<K, V>> entries)
    + Map.fromIterable(Iterable iterable, { K key(dynamic element), V value(dynamic element) })
    + Map.fromIterables(Iterable<K> keys, Iterable<V> values)
    + Map.identity()
    + Map.of(Map<K, V> other)
    + Map.unmodifiable(Map other)
  - properties
    + Iterable<MapEntry<K, V>> entries
    + bool isEmpty
    + bool isNotEmpty
    + Iterable<K> keys
    + int length
    + Iterable<V> values
    + int hashCode
    + Type runtimeType
  - methods
    + void addAll(Map<K, V> other);
    + void addEntries(Iterable<MapEntry<K, V>> newEntries)
    + Map<RK, RV> cast<RK, RV>()
    + void clear()
    + bool containsKey(Object key)
    + bool containsValue(Object value)
    + void forEach(void f(K key, V value))
    + Map<K2, V2> map<K2, V2>(MapEntry<K2, V2> f(K key, V value))
    + V putIfAbsent(K key, V ifAbsent())
    + V remove(Object key)
    + void removeWhere(bool predicate(K key, V value))
    + V update(K key, V update(V value), { V ifAbsent() })
    + void updateAll(V update(K key, V value))
    + String toString()
  - operators
    + V operator [](Object key)
    + void operator []=(K key, V value)
    + bool operator ==(dynamic other)
  - static
    + Map<K2, V2> castFrom<K, V, K2, V2>(Map<K, V> source) 
6. runes(用于在字符串中表示Unicode字符)
  - constructors
    + Runes(String string)
  - properties
    + RuneIterator iterator
    + int last
    + String string
    + int first
    + int hashCode
    + bool isEmpty
    + bool isNotEmpty
    + int length
    + Type runtimeType
    + int single
  - methods
    + bool any(bool test(int element))
    + Iterable<R> cast<R>()
    + bool contains(Object element)
    + int elementAt(int index)
    + bool every(bool test(int element))
    + Iterable<T> expand<T>(Iterable<T> f(int element))
    + int firstWhere(bool test(int element), { int orElse() })
    + T fold<T>(T initialValue, T combine(T previousValue, int element))
    + Iterable<int> followedBy(Iterable<int> other)
    + void forEach(void f(int element))
    + String join([String separator = "" ])
    + int lastWhere(bool test(int element), { int orElse() })
    + Iterable<T> map<T>(T f(int e))
    + int reduce(int combine(int value int element))
    + int singleWhere(bool test(int element), { int orElse() })
    + Iterable<int> skip(int count)
    + Iterable<int> skipWhile(bool test(int value))
    + Iterable<int> take(int count)
    + Iterable<int> takeWhile(bool test(int value))
    + List<int> toList({bool growable: true })
    + Set<int> toSet()
    + String toString()
    + Iterable<int> where(bool test(int element))
    + Iterable<T> whereType<T>()
  - operators
    + bool operator ==(dynamic other)
7. symbols
  - constructors
    + Symbol(String name)
  - properties
    + int hashCode
    + Type runtimeType
  - methods
    + String toString()
  - operators
    + bool operator ==(dynamic other)
  - constants
    + const Symbol empty
    + const Symbol unaryMinus