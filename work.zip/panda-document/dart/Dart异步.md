#### 基本操作符

1. 一元后缀`expr++` `expr--` `()` `[]` `.` `?.`
```dart
num a = 1;

assert(a++ == 1);
assert(a-- == 1);
assert(a++ == 1);
assert(a?.toString() == '1');
```
2. 一元前缀`-expr` `!expr` `~expr` `++expr` `--expr` `await expr`
```dart
num a = 1;

assert(-a == -1);
assert(!false == true);
assert(~-2 == a);
assert(++a == 2);
ssert(--a == 0);
```

3. 算数运算符 `*` `/` `%` `~/` `+` `-`

```dart
assert(2 + 3 == 5);
assert(2 - 3 == -1);
assert(2 * 3 == 6);
assert(5 / 2 == 2.5); // Result is a double
assert(5 ~/ 2 == 2); // Result is an int
assert(5 % 2 == 1); // Remainder

assert('5/2 = ${5 ~/ 2} r ${5 % 2}' == '5/2 = 2 r 1');
```

4. 关系运算符 `==` `!=` `>` `<` `>=` `<=`

```dart
assert(2 == 2);
assert(2 != 3);
assert(3 > 2);
assert(2 < 3);
assert(3 >= 3);
assert(2 <= 3);
```

5. 类型测试 `as` `is` `is!`

```dart
if (emp is Person) {
  // Type check
  emp.firstName = 'Bob';
}

(emp as Person).firstName = 'Bob';
```

6. 赋值运算 `=` `–=` `/=` `%=` `>>=` `^=` `+=` `*=` `~/=` `<<=` `&=` `|=`

> 复合赋值运算符的工作原理: `a op= b`  <==>  `a = a op b`

```dart
num a = 2; // Assign using =
a *= 3; // Assign and multiply: a = a * 3
assert(a == 6);

```

7. 逻辑运算符 `!expr` `||` `&&`

```dart
if (!done && (col == 0 || col == 3)) {
  // ...Do something...
}
```

8. 按位和移位运算符 `&` `|` `^` `~expr` `<<` `>>`

```dart
final value = 0x22;
final bitmask = 0x0f;

assert((value & bitmask) == 0x02); // AND
assert((value & ~bitmask) == 0x20); // AND NOT
assert((value | bitmask) == 0x2f); // OR
assert((value ^ bitmask) == 0x2d); // XOR
assert((value << 4) == 0x220); // Shift left
assert((value >> 4) == 0x02); // Shift right
```

9. 条件表达式 `condition ? expr1 : expr2` `expr1 ?? expr2`

    - condition ? expr1 : expr2
    
        > 如果条件为true，则求值expr1（并返回其值）；否则为false。否则，求值并返回expr2的值。
        
    - expr1 ?? expr2
    
        > 如果expr1不为null，则返回其值；否则，返回0。否则，求值并返回expr2的值。
        
```dart
String playerName(String name) => name ?? 'Guest';

String visibility = isPublic ? 'public' : 'private';
```

10. 级联符号 `..`

> 级联允许您对同一对象执行一系列操作。除了函数调用，您还可以访问同一对象上的字段。这通常可以节省创建临时变量的步骤，并使您可以编写更多流畅的代码

__注意：这不是链式调用，链式调用是基于前一次返回的结果的后续一系列操作。__

```dart
querySelector('#confirm') // Get an object.
  ..text = 'Confirm' // Use its members.
  ..classes.add('important')
  ..onClick.listen((e) => window.alert('Confirmed!'));
```

11. 其它运算符 `()` `[]` `.` `?.` `...` `[if (collection) ClassName()]` `[for (var section in sections)]`