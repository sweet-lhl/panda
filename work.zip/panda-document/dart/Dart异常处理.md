#### 抛出异常

> 抛出异常（throw）是一个表达式

```dart
throw FormatException('Expected at least 1 section');
throw 'Out of llamas!';

void distanceTo(Point other) => throw UnimplementedError();
```

#### 捕获异常

```dart
try {
  breedMoreLlamas();
}catch (e, s) {
  // No specified type, handles all
  print('Exception details:\n $e');
  print('Stack trace:\n $s');
}finally {
  // Always clean up, even if an exception is thrown.
  cleanLlamaStalls();
}
```