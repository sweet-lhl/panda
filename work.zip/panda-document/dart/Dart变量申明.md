1. `var`

> 类似于JavaScript中的`var`，它可以接收任何类型的变量，但最大的不同是Dart中`var`变量一旦赋值，类型便会确定，则不能再改变其类型。(纯`WEB开发者`注意)

```dart
var t;
t = "hi world";
// 下面代码在dart中会报错，因为变量t的类型已经确定为String
t = 1000; // 类型一旦确定后则不能再更改其类型。
```

2. `dynamic`和`Object`

> Object 是Dart所有对象的根基类，也就是说所有类型都是Object的子类(包括Function和Null)，所以任何类型的数据都可以赋值给Object声明的对象. dynamic与var一样都是关键词,声明的变量可以赋值任意对象。 而dynamic与Object相同之处在于,他们声明的变量可以在后期改变赋值类型。

```dart
dynamic t;
 Object x;
 t = "hi world";
 x = 'Hello Object';
 //下面代码没有问题
 t = 1000;
 x = 1000;
 ```
 
 > dynamic与Object不同的是,dynamic声明的对象编译器会提供所有可能的组合, 而Object声明的对象只能使用Object的属性与方法, 否则编译器会报错。
 
 ```dart
 dynamic a;
 Object b;
 main() {
     a = "";
     b = "";
     printLengths();
 }   

 printLengths() {
     // no warning
     print(a.length);
     // warning:
     // The getter 'length' is not defined for the class 'Object'
     print(b.length);
 }
 ```
 
 > 上述代码中，变量a不会报错, 变量b编译器会报错。
 
 > dynamic的这个特性与Objective-C中的id作用很像. dynamic的这个特点使得我们在使用它时需要格外注意,这很容易引入一个运行时错误.
 
 3. `final`和`const`
 
> 如果您从未打算更改一个变量，那么使用 final 或 const，不是var，也不是一个类型。 一个 final 变量只能被设置一次，两者区别在于：const 变量是一个编译时常量，final变量在第一次使用时被初始化。被final或者const修饰的变量，变量类型可以省略。

```dart
//可以省略String这个类型声明
final str = "hi world";
//final String str = "hi world"; 
const str1 = "hi world";
//const String str1 = "hi world";
```