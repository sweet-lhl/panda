> 如果查看基本数组类型List的API文档，您会发现该类型实际上是List <E>。 <…>标记将List标记为通用（或参数化）类型-具有正式类型参数的类型。按照惯例，大多数类型变量都具有单字母名称，例如E，T，S，K和V。

#### 为什么要使用泛型？

> 泛型通常是实现类型安全所必需的，但是泛型不仅具有允许运行代码的优点，还具有更多的优点：

+ 正确指定泛型类型可产生更好的代码。
+ 您可以使用泛型来减少代码重复。

#### Using collection literals

> 列表，集合和映射文字可以被参数化。参数化文字与您已经看到的文字一样，只不过您在左方括号之前添加了<type>（用于列表和集合）或<keyType，valueType>（用于maps）

```dart
var names = <String>['Seth', 'Kathy', 'Lars'];
var uniqueNames = <String>{'Seth', 'Kathy', 'Lars'};
var pages = <String, String>{
  'index.html': 'Homepage',
  'robots.txt': 'Hints for web robots',
  'humans.txt': 'We are people, not machines'
};
```

#### Using parameterized types with constructors

> 要在使用构造函数时指定一种或多种类型，请将类型放在类名之后的尖括号（<...>）中。

```dart
var nameSet = Set<String>.from(names);
var views = Map<int, View>();
```

#### Generic collections and the types they contain

> Dart泛型类型已经过优化，这意味着它们在运行时会携带其类型信息

```dart
var names = List<String>();
names.addAll(['Seth', 'Kathy', 'Lars']);
print(names is List<String>); // true
```

__注意：相反，Java中的泛型使用了擦除，这意味着泛型类型参数在运行时被删除。在Java中，您可以测试对象是否为List，但不能测试对象是否为List <String>。__

#### Restricting the parameterized type

> 在实现泛型类型时，您可能希望限制其参数的类型。您可以使用扩展来做到这一点。

```dart
class Foo<T extends SomeBaseClass> {
  // Implementation goes here...
  String toString() => "Instance of 'Foo<$T>'";
}

class Extender extends SomeBaseClass {...}
```

#### Using generic methods

> 最初，Dart的通用支持仅限于类。一种称为通用方法的较新语法，允许在方法和函数上使用类型参数。

```dart
T first<T>(List<T> ts) {
  // Do some initial work or error checking, then...
  T tmp = ts[0];
  // Do some additional checking or processing...
  return tmp;
}
```
###### 在这里，第一个（<T>）上的泛型类型参数允许您在多个地方使用类型参数T：

1. 在函数的返回类型（T）中。
2. 在参数的类型中（List <T>）。
3. 在局部变量（T tmp）的类型。