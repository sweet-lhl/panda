#### 条件判断

> 条件判断必须使用布尔值！

```dart
if (isRaining()) {
  you.bringRainCoat();
} else if (isSnowing()) {
  you.wearJacket();
} else {
  car.putTopDown();
}
```

#### For循环

```dart
StringBuffer message = StringBuffer('Dart is fun');

  for (int i = 0; i < 5; i++) {
    message.write('!');
  }
  
// 闭包捕获索引值，避免异常发生
List<Function> callbacks = [];
  
  for (int i = 0; i < 5; i++) {
    callbacks.add(() => print(i));
  }
  callbacks.forEach((c) => c());
  
// 可迭代对象惯用遍历方式
candidates.forEach((candidate) => candidate.interview());
  
// Set,Map遍历使用for-in
List<num> collection = [0, 1, 2];
  for (int x in collection) {
    print(x); // 0 1 2
  }
}
```

#### While、do-while循环

```dart
while (!isDone()) { // 循环之前判断条件
  doSomething();
}

do { // 循环之后判断条件
  printLine();
} while (!atEndOfPage());
```

#### Break、continue语句

```dart
while (true) {
  if (shutDownRequested()) break; // 使用break停止循环
  processIncomingRequests();
}

for (int i = 0; i < candidates.length; i++) {
  var candidate = candidates[i];
  if (candidate.yearsExperience < 5) {
    continue; // 使用继续跳转到下一个循环迭代
  }
  candidate.interview();
}

// 如果是在循环迭代器，可以在帅选条件之后执行循环
candidates
    .where((c) => c.yearsExperience >= 5)
    .forEach((c) => c.interview());
```

#### Switch语句

> case语句的子句可以有局部变量，这些局部变量仅在该子句内可见

```dart
String command = 'OPEN';

switch (command) {
  case 'OTHER': // 支持空case语句
  case 'CLOSED':
    executeClosed();
    break;
  case 'PENDING':
    executePending();
    break;
  case 'APPROVED':
    executeApproved();
    break;
  case 'DENIED':
    executeDenied();
    break;
  case 'OPEN':
    executeOpen();
    break;
  default:
    executeUnknown();
}

switch (command) {
  case 'CLOSED':
    executeClosed();
    continue nowClosed;
  // 使用continue跳到标签处

  nowClosed:
  case 'NOW_CLOSED':
    // 当command为CLOSED和NOW_CLOSED时将在此处执行
    executeNowClosed();
    break;
}
```

#### Assert（断言）语句

> 在`开发过程中`，使用断言语句— assert(condition, optionalMessage); —如果布尔条件为假，则中断正常执行。

```dart
String urlString = 'http://www.baidu.com';

assert(urlString.startsWith('https'), 'URL ($urlString) should start with "https".');
```