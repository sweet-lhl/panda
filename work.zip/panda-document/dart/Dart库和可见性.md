> 导入和库指令可以帮助您创建模块化且可共享的代码库。库不仅提供API，而且是隐私的单位：以下划线（_）开头的标识符仅在库内部可见。每个Dart应用程序都是一个库，即使它不使用库指令。 可以使用软件包分发库。

#### 获取包

> 拥有pubspec后，您可以从应用程序的顶级目录运行pub get:

```basic
 cd <path-to-my_app>
 pub get
```

###### 此过程称为获取依赖关系。

> 当pub获得远程软件包时，它将其下载到pub维护的单个系统缓存目录中。在Mac和Linux上，此目录默认为〜/ .pub-cache。在Windows上，该文件位于％APPDATA％\Pub\Cache\bin中，尽管其确切位置可能因Windows版本而异。您可以使用PUB_CACHE环境变量指定其他位置。

#### 升级依赖

```basic
pub upgrade #升级所有依赖至最新版本
pub upgrade transmogrify #升级transmogrify至最新版本
```

#### 使用库

```dart
import 'dart:html';
```

> 要导入的唯一必需参数是指定库的URI。对于内置库，URI具有特殊的dart:scheme。对于其他库，可以使用文件系统路径或package:scheme。

```dart
import 'package:test/test.dart';
```
__URI代表统一资源标识符。URL（统一资源定位符）是一种常见的URI。__

##### 指定库前缀

###### 如果导入两个标识符冲突的库，则可以为一个或两个库指定一个前缀。例如，如果library1和library2都具有Element类，那么您可能具有以下代码：

```dart
import 'package:lib1/lib1.dart';
import 'package:lib2/lib2.dart' as lib2;

// Uses Element from lib1.
Element element1 = Element();

// Uses Element from lib2.
lib2.Element element2 = lib2.Element();
```

##### 仅导入库的一部分

> 如果只想使用一部分库，则可以有选择地导入该库。

```dart
// Import only foo.
import 'package:lib1/lib1.dart' show foo;

// Import all names EXCEPT foo.
import 'package:lib2/lib2.dart' hide foo;

```

##### 懒加载库

###### 延迟加载（也称为懒加载）允许Web应用程序在需要库时以及在需要时按需加载库。在某些情况下，您可能会使用延迟加载：

- 为了减少网络应用的初始启动时间。
- 执行A/B测试，例如尝试算法的替代实现。
- 加载很少使用的功能，例如可选的屏幕和对话框。

__仅dart2js支持延迟加载。 Flutter，Dart VM和dartdevc不支持延迟加载。__

> 要延迟加载库，必须首先使用deferred as导入它。

```dart
import 'package:greetings/hello.dart' deferred as hello;
```

###### 当您需要该库时，请使用库的标识符调用loadLibrary().
```dart
Future greet() async {
  await hello.loadLibrary();
  hello.printGreeting();
}
```

在前面的代码中，`await`关键字将暂停执行，直到加载该库为止。

您可以在一个库上多次调用loadLibrary()，而不会出现问题。该库仅加载一次。

###### 使用延迟加载时，请注意以下几点：

+ 延迟库的常量不是导入文件中的常量。请记住，这些常量在加载延迟的库之前不存在。
+ 您不能在导入文件中使用延迟库中的类型。而是考虑将接口类型移到由延迟库和导入文件导入的库中。
+ Dart将deferred作为命名空间隐式地将loadLibrary()插入到您定义的命名空间中。 loadLibrary()函数返回Future。

#### 创建库

> Dart生态系统使用软件包来共享软件，例如库和工具。

###### 下图显示了最简单的库包的布局：

![What makes a library package](https://dart.dev/assets/libraries/simple-lib2-81ebdc20fdb53d3abbc4364956141eb0f6f8f275d1636064fc3e1db959b93c1a.png)

##### 一个库的最低要求:

- pubspec配置文件。
    > 库的pubspec.yaml文件与应用程序包的文件相同-没有特殊的指示以表明该包是库。
- lib目录。
    > 如您所期望的，库代码位于lib目录下，并且对其他软件包是公共的。您可以根据需要在lib下创建任何层次结构。按照约定，实现代码位于lib/src下。lib/src下的代码被认为是私有的；其他软件包永远不需要导入src/...公开lib/src下的API，您可以从直接在lib下的文件中导出lib/src文件。

###### 如果未指定库指令，则会根据每个库的路径和文件名为它们生成一个唯一标记。因此，我们建议您从代码中省略库指令，除非您打算生成库级文档。

##### 整理库包

> 创建小型的单个库（称为微型库）时，库包最容易维护，扩展和测试。在大多数情况下，每个类都应位于自己的微型库中，除非您遇到两个类紧密耦合的情况。

__注意：您可能听说过part指令，该指令可将库拆分为多个Dart文件。我们建议您避免使用part而是创建小型库。__

> 直接在lib下创建一个“主”库文件，`lib/<package-name>.dart`,导出所有公共API。这使用户可以通过导入单个文件来获得库的所有功能。

> lib目录可能还包含其他可导入的目录（非src、libraries），例如，也许您的主库跨平台工作，但是您创建了依赖dart:io或dart:html的单独的库。某些软件包具有单独的库，但如果没有主库，则应使用前缀导入。

###### 让我们看一下现实世界中库包的结构：shelf。这个shelf包提供了一种使用Dart创建Web服务器的简便方法，并以Dart库软件包常用的结构进行布局：

![package:shelf](https://dart.dev/assets/libraries/shelf-02e5fd43b660fcef7dbe6a883c40159e0379c8ee2088288ca60ed7dc8781bafd.png)

###### 直接在lib下，主库文件shelf.dart从lib/src导出几个文件：

```dart
export 'src/cascade.dart';
export 'src/handler.dart';
export 'src/handlers/logger.dart';
export 'src/hijack_exception.dart';
export 'src/middleware.dart';
export 'src/pipeline.dart';
export 'src/request.dart';
export 'src/response.dart';
export 'src/server.dart';
export 'src/server_handler.dart';
```

__这个shelf包还包含一个小型库：shelf_io。该适配器处理dart:io的HttpRequest对象。__

###### Web应用程序提示：为了在使用dartdevc开发时获得最佳性能，请将实现文件放在/lib/src下，而不是在/lib下的其他地方。另外，避免导入package:package_name/src/....

##### 导入库文件

![my_package.import](https://dart.dev/assets/libraries/import-lib-rules-e1777e235dd56aa23f770babcccedb6a12be80af2c3e63065640b889d78be595.png)

##### 有条件地导入和导出库文件

> 如果您的库支持多个平台，则可能需要有条件地导入或导出库文件。一个常见的用例是同时支持Web和native平台的库。

```dart
// lib/hw_mp.dart
export 'src/hw_none.dart' // Stub implementation
    if (dart.library.io) 'src/hw_io.dart' // dart:io implementation
    if (dart.library.html) 'src/hw_html.dart'; // dart:html implementation
```

> 该代码的作用如下：

1. 在可以使用dart:io的应用程序（例如，命令行应用程序）中，导出src/hw_io.dart。
2. 在可以使用dart:html的应用程序（网络应用程序）中，导出src/hw_html.dart。
3. 否则，导出src/hw_none.dart。

__要有条件地导入文件，请使用与上面相同的代码，但是将export更改为import。__

__注意：有条件的导入或导出仅检查该库是否可在当前平台上使用，而不检查它是否已实际导入或使用。__

###### 所有有条件导出的库都必须实现相同的API。例如，这是dart：io的实现：

```dart
// lib/src/hw_io.dart
import 'dart:io';

void alarm([String text]) {
  stderr.writeln(text ?? message);
}

String get message => 'Hello World from the VM!';
```

```dart
// lib/src/hw_none.dart
void alarm([String text]) => throw UnsupportedError('hw_none alarm');

String get message => throw UnsupportedError('hw_none message');
```

###### 在任何平台上，您都可以导入具有条件导出代码的库：

```dart
import 'package:hw_mp/hw_mp.dart';

void main() {
  print(message);
}
```

##### 提供其它文件

> 通常包含测试(test)、文档、示例(example)、命令(bin)、工具(tool)、README.md、CHANGELOG.md、.gitignore ...

##### 分发开源库

> 如果您的库是开源的，我们建议在[pub.dev](https://pub.dev)站点上共享它。要发布或更新库，请使用pub publish，会上传您的软件包并创建或更新其页面。

> pub.dev网站不仅托管您的程序包，而且还生成并托管您程序包的API参考文档。软件包的“关于”框中提供了最新生成的文档的链接；

###### 为确保您包的API文档在pub.dev网站上看起来不错，请按照以下步骤操作：

1. 在发布软件包之前，请运行[dartdoc](https://github.com/dart-lang/dartdoc#dartdoc)工具，以确保您的文档生成成功并且外观符合预期。
2. 发布软件包后，请检查“版本”选项卡，以确保文档已成功生成。
3. 如果文档根本没有生成，请在“版本”标签中单击“失败”以查看dartdoc输出。

#### `pubspec.yaml`示例

```yaml
name: newtify
version: 1.2.3
description: >-
  Have you been turned into a newt?  Would you like to be?
  This package can help. It has all of the
  newt-transmogrification functionality you have been looking
  for.
homepage: https://example-pet-store.com/newtify
documentation: https://example-pet-store.com/newtify/docs
environment:
  sdk: '>=2.0.0 <3.0.0'
dependencies:
  efts: ^2.0.4
  transmogrify: ^0.4.0
dev_dependencies:
  test: '>=0.6.0 <0.12.0'
```

+ name - 包名称，必须。
+ version - 版本，必须。
+ description - 包的描述信息，必须。
+ homepage - 指向软件包主页（或源代码存储库）的URL，可选。
+ repository - 指向软件包的源代码存储库的URL，可选。
+ issue_tracker - 指向程序包问题跟踪器的URL，可选。
+ documentation - 指向软件包文档的URL，可选。
+ dependencies - 包的有依赖项，可选。
+ dev_dependencies - 包的开发依赖项，可选。
+ dependency_overrides - 需要覆盖的依赖项，可选。
+ environment - 适配环境，Dart2开始必须。
+ executables - 用于将软件包的可执行文件放入PATH，可选。
+ publish_to - 指定发布程序包的位置，可选。
+ author - 作者，自定义。