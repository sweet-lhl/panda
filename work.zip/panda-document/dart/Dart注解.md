> 使用注解（元数据）提供有关您的代码的其他信息。元数据批注以字符@开头，后跟对编译时常量的引用（例如`@deprecated`）或对常量构造函数的调用。

> 所有Dart代码都可以使用两个注解：`@deprecated`和`@override`。

```dart
class Television {
  /// _Deprecated: Use [turnOn] instead._
  @deprecated
  void activate() {
    turnOn();
  }

  /// Turns the TV's power on.
  void turnOn() {...}
}
```

###### 您可以定义自己的元数据注释。这是定义带有两个参数的`@todo`注释的示例：

```dart
library todo;

class Todo {
  final String who;
  final String what;

  const Todo(this.who, this.what);
}
```

######这是使用@todo批注的示例：

```dart
import 'todo.dart';

@Todo('seth', 'make this do something')
void doSomething() {
  print('do something');
}
```

> 元数据可以出现在库，类，typedef，类型参数，构造函数，工厂，函数，字段，参数或变量声明之前，也可以出现在导入或导出指令之前。您可以在运行时使用反射来检索元数据。