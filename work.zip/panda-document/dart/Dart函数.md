#### 调用方式

```dart
isNoble(atomicNumber);
```

#### 申明方式

```dart
bool isNoble(int atomicNumber) {
  return _nobleGases[atomicNumber] != null;
}

// lambda表达式
// bool isNoble(int atomicNumber) => _nobleGases[atomicNumber] != null;
```

##### 参数

1. 位置参数[指定参数名调用]
```dart
void enableFlags({bool bold, bool hidden}) {print('enableFlags-$bold-$hidden')} // 申明

enableFlags(bold: true, hidden: false); // 调用
```
2. 必填参数
```dart
import 'package:meta/meta.dart';

void enableFlags(bool bold, @required bool hidden) {print('enableFlags-$bold-$hidden')} // 申明
    
    enableFlags(true, false); // 调用
```
3. 可选参数
```dart
import 'package:meta/meta.dart';

void enableFlags(bool bold, [@required bool hidden]) {print('enableFlags-$bold-$hidden')} // 申明
    
    enableFlags(true); // 调用
```
4. 默认参数

```dart
void enableFlags([bool bold = false, bool hidden = false]) {print('enableFlags-$bold-$hidden')} // 可选默认参数

void enableFlagsT({bool bold: true, bool hidden: false}) {print('enableFlags-$bold-$hidden')} // 位置默认参数

enableFlags(); // 调用
enableFlagsT();
```

#### 匿名函数

```dart
(() {
    print('test');
  })();
```
#### 闭包

```dart
Function makeAdder(num addBy) {
  return (num i) => addBy + i;
}

makeAdder(1)(1);
```
    
> 在dart中，函数默认值为null，默认返回值为null。

```dart
foo() {}

assert(foo() == null);
```