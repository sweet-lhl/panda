> Dart是一种具有类和基于Mixin的继承的面向对象语言。每个对象都是一个类的实例，并且所有类都来自Object。 基于混合的继承意味着尽管每个类（对象除外）都只有一个超类，但是一个类主体可以在多个类层次结构中重用。

#### 调用类的成员
> 对象具有由函数和数据（分别为方法和实例变量）组成的成员。调用方法时，您可以在对象上调用它：该方法可以访问该对象的功能和数据。

##### 使用“.”来引用实例变量或方法：

```dart
var p = Point(2, 2);

// Set the value of the instance variable y.
p.y = 3;

// Get the value of y.
assert(p.y == 3);

// Invoke distanceTo() on p.
num distance = p.distanceTo(Point(4, 4));
```

##### 使用“?.”代替“.”，避免左边的操作数为`null`时，引发异常：

```dart
// If p is non-null, set its y value to 4.
p?.y = 4;
```

##### 使用constructors
> 使用构造函数创建对象。构造函数名称可以是ClassName或ClassName.identifier。

```dart
var p1 = new Point(2, 2);
var p2 = new Point.fromJson({'x': 1, 'y': 2});
```

__提示：在Dart2中你可以省略`new`关键字：__

```dart
var p1 = Point(2, 2);
var p2 = Point.fromJson({'x': 1, 'y': 2});
```

##### 一些类提供常量构造函数。要使用常量构造函数创建编译时常量，请将const关键字放在构造函数名称之前：

```dart
var p = const ImmutablePoint(2, 2);
```

##### 构造两个相同的编译时常量会产生一个规范的实例：

```dart
var a = const ImmutablePoint(1, 1);
var b = const ImmutablePoint(1, 1);

assert(identical(a, b)); // They are the same instance!
```

##### 在常量上下文中，可以在构造函数或文字之前省略const。例如，看下面的代码，它创建一个const映射：

```dart
// Lots of const keywords here.
const pointAndLine = const {
  'point': const [const ImmutablePoint(0, 0)],
  'line': const [const ImmutablePoint(1, 10), const ImmutablePoint(-2, 11)],
};
```

__在dart2中您可以省略除首次使用const关键字外的所有内容（恒定的上下文中）：__

```dart
// Only one const, which establishes the constant context.
const pointAndLine = {
  'point': [ImmutablePoint(0, 0)],
  'line': [ImmutablePoint(1, 10), ImmutablePoint(-2, 11)],
};
```

__如果常量构造函数在常量上下文之外，并且在不使用const的情况下被调用，则它将创建一个非常量对象：__

```dart
var a = const ImmutablePoint(1, 1); // Creates a constant
var b = ImmutablePoint(1, 1); // Does NOT create a constant

assert(!identical(a, b)); // NOT the same instance!
```

#### 实例变量

##### 实例变量的申明

```dart
class Point {
  num x; // Declare instance variable x, initially null.
  num y; // Declare y, initially null.
  num z = 0; // Declare z, initially 0.
}
```

__所有未初始化的实例变量的值都为null。__

__所有实例变量都会生成一个隐式的getter方法。非最终实例变量也会生成隐式的setter方法。__

```dart
class Point {
  num x;
  num y;
}

void main() {
  var point = Point();
  point.x = 4; // Use the setter method for x.
  assert(point.x == 4); // Use the getter method for x.
  assert(point.y == null); // Values default to null.
}
```

#### Constructors
> 通过创建一个与其类名称相同的函数来声明构造函数（另加一个可选的标识符，如命名构造函数中所述）

```dart
class Point {
  num x, y;

  Point(num x, num y) {
    // There's a better way to do this, stay tuned.
    this.x = x;
    this.y = y;
  }
}
```

__`this`关键字引用当前实例__

__仅当名称冲突时才使用`this`，除此之外，dart样式将忽略这个`this`，这意味着在开发中你可以省略`this`__

##### 将构造函数参数分配给实例变量，语法糖：

```dart
class Point {
  num x, y;

  // Syntactic sugar for setting x and y
  // before the constructor body runs.
  Point(this.x, this.y); // 调用构造器将直接赋值，这在仅需要赋值的条件下非常方便。
}
```

##### Default constructors
> 如果您不声明构造函数，则会为您提供默认的构造函数。默认构造函数没有参数，并在超类中调用无参数构造函数。

##### Constructors aren’t inherited
> 子类不会从其超类继承构造函数。声明没有构造函数的子类仅具有默认（没有参数，没有名称）构造函数。

##### Named constructors
> 使用命名构造函数可为一个类实现多个构造函数。

```dart
class Point {
  num x, y;

  Point(this.x, this.y);

  // Named constructor
  Point.origin() {
    x = 0;
    y = 0;
  }
}
```

#### 调用非默认超类构造函数

> 默认情况下，子类中的构造函数会调用超类的未命名，无参数的构造函数。超类的构造函数在构造函数主体的开头被调用。如果还使用了初始化程序列表，它将在调用超类之前执行。顺序如下：

    1. 初始化列表
    2. 超类的无参数构造函数
    3. 主类的无参数构造函数

> 如果超类没有未命名，无参数的构造函数，则必须手动调用超类中的构造函数之一。在构造函数主体（如果有）之前，在冒号（:)之后指定超类构造函数。

```dart
class Person {
  String firstName;

  Person.fromJson(Map data) {
    print('in Person');
  }
}

class Employee extends Person {
  // Person does not have a default constructor;
  // you must call super.fromJson(data).
  Employee.fromJson(Map data) : super.fromJson(data) {
    print('in Employee');
  }
}

main() {
  var emp = new Employee.fromJson({});

  // Prints:
  // in Person
  // in Employee
  if (emp is Person) {
    // Type check
    emp.firstName = 'Bob';
  }
  (emp as Person).firstName = 'Bob';
}
```

__因为超类构造函数的参数是在调用构造函数之前求值的，所以参数可以是表达式，例如函数调用：__

```dart
class Employee extends Person {
  Employee() : super.fromJson(defaultData);
  // ···
}
```
__警告：超类构造函数的参数无权访问此函数。例如，参数可以调用静态方法，而不能调用实例方法。__

##### Initializer list

> 除了调用超类构造函数外，您还可以在构造函数主体运行之前初始化实例变量。用逗号分隔初始化程序。

```dart
// Initializer list sets instance variables before
// the constructor body runs.
Point.fromJson(Map<String, num> json)
    : x = json['x'],
      y = json['y'] {
  print('In Point.fromJson(): ($x, $y)');
}
```

__在开发过程中，您可以通过使用初始化列表中的assert来验证输入：__

```dart
Point.withAssert(this.x, this.y) : assert(x >= 0) {
  print('In Point.withAssert(): ($x, $y)');
}
```

##### Redirecting constructors
> 有时，构造函数的唯一目的是重定向到同一类中的另一个构造函数。重定向构造函数的主体为空，构造函数调用出现在冒号（:)后面。

```dart
class Point {
  num x, y;

  // The main constructor for this class.
  Point(this.x, this.y);

  // Delegates to the main constructor.
  Point.alongXAxis(num x) : this(x, 0);
}
```

##### Constant constructors

> 如果您的类产生了永不改变的对象，则可以使这些对象具有编译时常量。为此，请定义`const`构造函数，并确保所有实例变量都是`final`（最终变量）。

```dart
class ImmutablePoint {
  static final ImmutablePoint origin =
      const ImmutablePoint(0, 0);

  final num x, y;

  const ImmutablePoint(this.x, this.y);
}
```

##### Factory constructors

> 在实现并非总是创建其类的新实例的构造函数时，请使用factory关键字

__以下示例演示了工厂构造函数从缓存中返回对象的方法：__

```dart
class Logger {
  final String name;
  bool mute = false;

  // _cache is library-private, thanks to
  // the _ in front of its name.
  static final Map<String, Logger> _cache =
      <String, Logger>{};

  factory Logger(String name) {
    return _cache.putIfAbsent(
        name, () => Logger._internal(name));
  }

  Logger._internal(this.name);

  void log(String msg) {
    if (!mute) print(msg);
  }
}

// 调用
var logger = Logger('UI');
logger.log('Button clicked');
```

__注意：工厂构造函数无权访问`this`。__

#### 方法

> 方法是提供对象行为的函数。

1. Instance methods.
    > 对象上的实例方法可以访问实例变量。  
    __以下示例中的distanceTo()方法是一个实例方法的示例：__
    
    ```dart
    import 'dart:math';
    
    class Point {
      num x, y;
    
      Point(this.x, this.y);
    
      num distanceTo(Point other) {
        var dx = x - other.x;
        var dy = y - other.y;
        return sqrt(dx * dx + dy * dy);
      }
    }

    ```

2. Getters and setters。
    > Getters和setters是特殊的方法，可提供对对象属性的读写访问权限。每个实例变量都有一个getter，如果合适的话，还会有一个setter。

    __您可以通过使用get和set关键字实现getter和setter来创建其他属性。__
    
    ```dart
    class Rectangle {
      num left, top, width, height;
    
      Rectangle(this.left, this.top, this.width, this.height);
    
      // Define two calculated properties: right and bottom.
      num get right => left + width;
      set right(num value) => left = value - width;
      num get bottom => top + height;
      set bottom(num value) => top = value - height;
    }
    
    void main() {
      var rect = Rectangle(3, 4, 20, 15);
      assert(rect.left == 3);
      rect.right = 12;
      assert(rect.left == -8);
    }
    ```
3. Abstract methods.
    > getter和setter方法可以是抽象的，定义一个接口，但将其实现留给其他类使用。抽象方法只能存在于抽象类中。

    ```dart
    abstract class Doer {
      // Define instance variables and methods...
    
      void doSomething(); // Define an abstract method.
    }
    
    class EffectiveDoer extends Doer {
      void doSomething() {
        // Provide an implementation, so the method is not abstract here...
      }
    }
    
    ```
    
#### Abstract classes

> 使用abstract修饰符定义一个抽象类-一个无法实例化的类。抽象类对于定义接口很有用，通常带有一些实现。如果您希望抽象类看起来可实例化，请定义一个`factory constructor`。

```dart
// This class is declared abstract and thus
// can't be instantiated.
abstract class AbstractContainer {
  // Define constructors, fields, methods...

  void updateChildren(); // Abstract method.
}
```

#### Implicit interfaces

> 每个类都隐式定义一个接口，该接口包含该类及其实现的所有接口的所有实例成员。

> 如果您想创建一个支持B类API的A类而不继承B的实现，则A类应实现B接口。

__类通过在Implements子句中声明一个或多个接口，然后提供接口所需的API来实现一个或多个接口。例如：__

```dart
// A person. The implicit interface contains greet().
class Person {
  // In the interface, but visible only in this library.
  final _name;

  // Not in the interface, since this is a constructor.
  Person(this._name);

  // In the interface.
  String greet(String who) => 'Hello, $who. I am $_name.';
}

// An implementation of the Person interface.
class Impostor implements Person {
  get _name => '';

  String greet(String who) => 'Hi $who. Do you know who I am?';
}

String greetBob(Person person) => person.greet('Bob');

void main() {
  print(greetBob(Person('Kathy')));
  print(greetBob(Impostor()));
}
```

__这是指定一个类实现多个接口的示例：__

```dart
class Point implements Comparable, Location {...}
```

#### Extending a class

> 非超类方法调用，无需使用`super`关键字。

> 使用`extends`来创建子类，使用`super`来引用超类：

```dart
class Television {
  void turnOn() {
    _illuminateDisplay();
    _activateIrSensor();
  }
  // ···
}

class SmartTelevision extends Television {
  void turnOn() {
    super.turnOn();
    _bootNetworkInterface();
    _initializeMemory();
    _upgradeApps();
  }
  // ···
}

```

##### Overriding members

> 子类可以覆盖实例方法，getter和setter。您可以使用@override批注指示您有意覆盖成员：

```dart
class Television {
  void turnOn() {
    _illuminateDisplay();
    _activateIrSensor();
  }
  // ···
}

class SmartTelevision extends Television {
  @override
  void turnOn() {...}
  // ···
}
```

__要缩小代码类型安全的方法参数或实例变量的类型，可以使用covariant关键字。__

#### Overridable operators

> 您可以覆盖下表中显示的运算符。例如，如果定义一个Vector类，则可以定义一个+方法来添加两个向量。

> 注意：您可能已经注意到`!=`不是可重写的运算符。表达式`e1!= e2`只是`!(e1 == e2)`的语法糖。

__这是一个覆盖+和-运算符的类的示例：__

```dart
class Vector {
  final int x, y;

  Vector(this.x, this.y);

  Vector operator +(Vector v) => Vector(x + v.x, y + v.y);
  Vector operator -(Vector v) => Vector(x - v.x, y - v.y);

  // Operator == and hashCode not shown. For details, see note below.
  // ···
}

void main() {
  final v = Vector(2, 3);
  final w = Vector(2, 2);

  assert(v + w == Vector(4, 5));
  assert(v - w == Vector(0, 1));
}
```

#### noSuchMethod()

> 要在代码尝试使用不存在的方法或实例变量时进行检测或作出反应，可以重写noSuchMethod()：

```dart
class A {
  // Unless you override noSuchMethod, using a
  // non-existent member results in a NoSuchMethodError.
  @override
  void noSuchMethod(Invocation invocation) {
    print('You tried to use a non-existent member: ' +
        '${invocation.memberName}');
  }
}
```

__除非满足以下条件之一，否则您不能调用未实现的方法：__

1. 接收者具有动态的静态类型。
2. 接收器具有定义未实现方法的静态类型（abstract[抽象]是可以的），接收器的动态类型具有noSuchMethod()的实现，该实现与Object类中的实现不同。

#### Enumerated types

> 枚举类型（通常称为枚举或枚举）是一种特殊的类，用于表示固定数量的常量值。

###### 使用enums

__使用enum关键字声明枚举类型：__

```dart
enum Color { red, green, blue }
```

__枚举中的每个值都有一个索引获取器，它返回该值在枚举声明中从零开始的位置。例如，第一个值的索引为0，第二个值的索引为1。__

```dart
assert(Color.red.index == 0);
assert(Color.green.index == 1);
assert(Color.blue.index == 2);
```

__要获取枚举中所有值的列表，请使用枚举的`values`常量。__

```dart
List<Color> colors = Color.values;
assert(colors[2] == Color.blue);
```

__您可以在switch语句中使用枚举，如果不处理所有的枚举值，则会收到警告：__

```dart
var aColor = Color.blue;

switch (aColor) {
  case Color.red:
    print('Red as roses!');
    break;
  case Color.green:
    print('Green as grass!');
    break;
  default: // Without this, you see a WARNING.
    print(aColor); // 'Color.blue'
}
```

###### 枚举类型具有以下限制：

1. 您不能继承，混入或实现枚举。
2. 您无法显式实例化枚举。

#### Adding features to a class: mixins

> 混合是一种在多个类层次结构中重用类代码的方法。

###### 要使用mixin，请使用`with`关键字，后跟一个或多个mixin名称。以下示例显示了两个使用mixins的类：

```dart
class Musician extends Performer with Musical {
  // ···
}

class Maestro extends Person with Musical, Aggressive, Demented {
  Maestro(String maestroName) {
    name = maestroName;
    canConduct = true;
  }
}
```

###### 要实现mixin，请创建一个扩展Object且不声明构造函数的类。除非您希望mixin可用作常规类，否则请使用`mixin`关键字而不是class。例如：

```dart
mixin Musical {
  bool canPlayPiano = false;
  bool canCompose = false;
  bool canConduct = false;

  void entertainMe() {
    if (canPlayPiano) {
      print('Playing piano');
    } else if (canConduct) {
      print('Waving hands');
    } else {
      print('Humming to self');
    }
  }
}
```

###### 要指定只有某些类型可以使用mixin（例如，以便您的mixin可以调用它未定义的方法），请使用on来指定所需的超类：

```dart
mixin MusicalPerformer on Musician {
  // ···
}
```

__Dart 2.1中引入了对mixin关键字的支持。早期版本中的代码通常改用抽象类。__

#### Class variables and methods

> 使用static关键字实现类范围的变量和方法。

##### Static variables

__静态变量（类变量）对于类范围的状态和常量很有用：__

```dart
class Queue {
  static const initialCapacity = 16;
  // ···
}

void main() {
  assert(Queue.initialCapacity == 16);
}
```

> 静态变量在使用之前不会初始化。

##### Static methods

__Static methods （class methods）不能在实例上操作，因此无法访问`this`。例如：__

```dart
import 'dart:math';

class Point {
  num x, y;
  Point(this.x, this.y);

  static num distanceBetween(Point a, Point b) {
    var dx = a.x - b.x;
    var dy = a.y - b.y;
    return sqrt(dx * dx + dy * dy);
  }
}

void main() {
  var a = Point(2, 2);
  var b = Point(4, 4);
  var distance = Point.distanceBetween(a, b);
  assert(2.8 < distance && distance < 2.9);
  print(distance);
}
```

__您可以使用静态方法作为编译时常量。例如，您可以将静态方法作为参数传递给常量构造函数。__

##### Callable(可调用) classes

> 为了允许像函数一样调用Dart类的实例，请实现call()方法。

```dart
class WannabeFunction {
  call(String a, String b, String c) => '$a $b $c!';
}

main() {
  WannabeFunction wf = new WannabeFunction();
  String out = wf("Hi","there,","gang");
  print('$out');
}
```